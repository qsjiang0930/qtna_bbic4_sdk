/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : qrpe_debug.c                                               **
**  Description : qrpe debug functions                                       **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#include "common.h"
#include "qrpe_debug.h"

static int g_dbg_output = LOG_OUTPUT_NONE;
static int g_dbg_level = LOG_WARNING;

static const char *g_dbg_level_names[] = {
	"Off...",
	"Error.",
	"Warn..",
	"Notice",
	"Info..",
	"Debug.",
};

static int qrpe_level_no(const char *level_name)
{
	int ind;
	for (ind = 0; ind <
		sizeof(g_dbg_level_names) / sizeof(g_dbg_level_names[0]); ind++) {
		if (strncasecmp(g_dbg_level_names[ind], level_name, strlen(level_name)) == 0) {
			return ind + LOG_CRIT;
		}
	}
	return -1;
}

static void qrpe_debug_set_level(const char *level_name)
{
	int level;
	if (!level_name)
		return;
	level = qrpe_level_no(level_name);
	if (level < 0)
		return;
	g_dbg_level = level;
}

static void qrpe_debug_set_output(const char *output)
{
	if (!output)
		return;
	if (strcasecmp(output, "stdout") == 0)
		g_dbg_output = LOG_OUTPUT_STDOUT;
	else if (strcasecmp(output, "syslog") == 0)
		g_dbg_output = LOG_OUTPUT_SYSLOG;
	else
		g_dbg_output = LOG_OUTPUT_NONE;
}

void qrpe_debug_set(const char *level_name, const char *output)
{
	qrpe_debug_set_level(level_name);
	qrpe_debug_set_output(output);
}

void qrpe_debug_printf(int level, const char *func,
	uint32_t line, const char *fmt, ...)
{
	va_list ap;
	int index;
	if (LOG_OUTPUT_NONE == g_dbg_output)
		return;
	if (level > g_dbg_level)
		return;
	va_start(ap, fmt);
	index = level - LOG_CRIT;
	if (LOG_OUTPUT_STDOUT == g_dbg_output) {
		printf("%010lu [%-6.6s] [QRPE] (%-20.20s:%04u) ",
			time(NULL), g_dbg_level_names[index], func, line);
		vprintf(fmt, ap);
		printf("\n");
	} else {
		char format[256];
		snprintf(format, 256, "%010lu [QRPE] (%-20.20s:%04u) %s",
			time(NULL), func, line, fmt);
		vsyslog(level, format, ap);
	}
	va_end(ap);
}

void qrpe_debug_dump(const char *title, int level, const char *func,
	uint32_t line, uint8_t *buf, int len)
{
	int i, index = level - LOG_CRIT;
	char *strbuf, *pos;
	if (LOG_OUTPUT_NONE == g_dbg_output
		|| level > g_dbg_level)
		return;

	strbuf = QRPE_MALLOC(128			/* header */
			+ len * 3			/* data */
			+ ((len - 1) >> 3) * 4		/* 4 blanks */
			+ ((len - 1) >> 4) + 1		/* line break */
			+ 1 + 1);			/* last line break + ending */
	if(NULL == strbuf)
		return;

	pos = strbuf;

	if (LOG_OUTPUT_STDOUT == g_dbg_output)
		pos += snprintf(pos, 120, "%010lu [%-6.6s] [QRPE] (%-20.20s:%04u) %s [%05u]:",
				time(NULL), g_dbg_level_names[index], func, line, title, len);
	else
		pos += snprintf(pos, 120, "%010lu [QRPE] (%-20.20s:%04u) %s [%05u]:",
				time(NULL), func, line, title, len);

	for (i = 0; i < len; i++) {
		if ((i & 0xf) == 0)
			pos += sprintf(pos, "\n");
		else if ((i & 0x7) == 0)
			pos += sprintf(pos, "    ");
		pos += sprintf(pos, "%02x ", buf[i]);
	}
	pos += sprintf(pos, "\n");
	*pos = '\0';

	if (LOG_OUTPUT_STDOUT == g_dbg_output)
		printf("%s", strbuf);
	else
		syslog(LOG_DEBUG, "%s", strbuf);

	QRPE_FREE(strbuf);
}

