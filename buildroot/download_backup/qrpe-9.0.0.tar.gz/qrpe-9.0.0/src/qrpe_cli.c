/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : qrpe_cli.c                                                 **
**  Description : qrpe command line function                                 **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#include "common.h"
#include "qrpe_cli.h"

char cli_path[64];

static int qrpe_ctrl_cli_sock_open()
{
	int sd;
	struct sockaddr_un addr;
	int path_len;

	path_len = snprintf(cli_path, 63, "%s-cli-%d", QRPE_UNIX_PATH, getpid());
	if (path_len >= sizeof(addr.sun_path)) {
		printf("sun_path oversize\n");
		return -1;
	}

	sd = socket(PF_UNIX, SOCK_DGRAM, 0);
	if (sd < 0) {
		printf("Failed to open PF_UNIX socket: %s\n", strerror(errno));
		return -1;
	}

	unlink(cli_path);
	memset(&addr, 0, sizeof(addr));
	addr.sun_family = AF_UNIX;
	strcpy(addr.sun_path, cli_path);
	if (bind(sd, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
		printf("Failed to bind to %s: %s\n", addr.sun_path, strerror(errno));
		close(sd);
		return -1;
	}

	return sd;
}

static int qrpe_ctrl_cli_req(int sd, char *req, int req_len)
{
	char *rep;
	struct timeval timeout;
	struct sockaddr_un addr;
	socklen_t addr_len;
	int ret = -1;

	if(NULL == (rep = calloc(QRPE_CTRL_PACKET_LEN, sizeof(char)))) {
		printf("can not alloc rep\n");
		goto _end;
	}

	memset(&addr, 0, sizeof(addr));
	addr.sun_family = AF_UNIX;
	strcpy(addr.sun_path, QRPE_UNIX_PATH);
	addr_len = sizeof(addr);

	if (sendto(sd, req, req_len, 0, (struct sockaddr *)&addr, addr_len) < 0) {
		printf("Failed to send cmd to QRPE: %s\n", strerror(errno));
		goto _end;
	}

	timeout.tv_sec = 5;
	timeout.tv_usec = 0;
	if (setsockopt(sd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout)) < 0) {
		printf("Failed to set recv timeout: %s\n", strerror(errno));
		goto _end;
	}

	if (recvfrom(sd, rep, QRPE_CTRL_PACKET_LEN - 1, 0, (struct sockaddr *)&addr, &addr_len) < 0) {
		printf("Failed to receive cli output from QRPE: %s\n", strerror(errno));
		goto _end;
	}
	rep[QRPE_CTRL_PACKET_LEN - 1] = '\0';
	printf("%s", rep);

	ret = 0;
_end:
	if (rep)
		free(rep);

	return ret;
}

static char req[QRPE_CTRL_REQ_LEN];
int main(int argc, char *argv[])
{
	int sd, i;
	uint32_t len = QRPE_CTRL_REQ_LEN - 1;
	char *pos;

	if (argc > 16) {
		printf("Too many parameters (> 16)\n");
		return -1;
	}

	memset(req, 0, sizeof(req));

	sd = qrpe_ctrl_cli_sock_open();
	if (sd < 0)
		return -1;

	req[0] = argc;
	pos = &req[1];
	for (i = 0; i < argc; ++i, ++pos) {
		pos += snprintf(pos, len, "%s", argv[i]);
		if(pos - req >= QRPE_CTRL_REQ_LEN) {
			printf("cli len over 128\n");
			break;
		}
		len = QRPE_CTRL_REQ_LEN - (pos - req);
	}

	qrpe_ctrl_cli_req(sd, req, pos - req);

	close(sd);
	unlink(cli_path);

	return 0;
}
