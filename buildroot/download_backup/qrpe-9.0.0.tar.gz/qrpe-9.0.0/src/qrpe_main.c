/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : qrpe_main.c                                                **
**  Description : qrpe main function                                         **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#include "common.h"
#include "version.h"
#include "qrpe_message.h"
#include "qrpe_driver.h"
#include "qrpe.h"
#include "qrpe_debug.h"
#include "qrpe_cli.h"

QRPE_CONTEXT_T g_ctx;
QRPE_CONFIG_T g_conf;

#ifndef QRPE_SUBVERSION
#define QRPE_SUBVERSION	"unknown"
#endif

static void qrpe_init_conf(void)
{
	memset(&g_conf, 0, sizeof(g_conf));
	g_conf.dbg_level = "warn";
	g_conf.dbg_output = "stdout";
	g_conf.qtna_roam_period = 9;
}

static void qrpe_print_help(void)
{
	printf("Usage: qrpe [-l LEVEL] [-o OUTPUT] [-p PID_FILE] [-D]\n"
		"	-l LEVEL	:debug level (off/erroe/warn/notice/info/debug)\n"
		"	-o OUTPUT	:debug output (stdout/syslog/none)\n"
		"	-p PID_FILE	:file for storing PID\n"
		"	-t		:QTNA sta roam period\n"
		"	-D		:daemonize\n"
	);
}

static void qrpe_parse_args(int argc, char *argv[])
{
	int c;

	while ((c = getopt(argc, argv, "o:l:p:t:D")) != -1) {
		switch (c) {
		case 'o':
			g_conf.dbg_output = optarg;
			break;

		case 'l':
			g_conf.dbg_level = optarg;
			break;

		case 'p':
			g_conf.pid_file = optarg;
			break;

		case 't':
			g_conf.qtna_roam_period = atoi(optarg);
			break;

		case 'D':
			g_conf.daemonize = 1;
			break;

		default:
			qrpe_print_help();
		}
	}
}

static void qrpe_deinit_intfs(void)
{
	int i;
	for (i = 0; i < g_ctx.intfs; i++) {
		if (g_ctx.intf_ctx[i].ops
			&& g_ctx.intf_ctx[i].ops->deinit_intf)
			g_ctx.intf_ctx[i].ops->deinit_intf(g_ctx.intf_ctx[i].priv);
		memset(g_ctx.intf_ctx + i, 0, sizeof(QRPE_INTF_T));
	}
}

static void qrpe_deinit_radios(void)
{
	int i;
	for (i = 0; i < g_ctx.radios; i++) {
		if (g_ctx.radio_ctx[i].ops
			&& g_ctx.radio_ctx[i].ops->deinit_radio)
			g_ctx.radio_ctx[i].ops->deinit_radio(g_ctx.radio_ctx[i].priv);
		memset(g_ctx.radio_ctx + i, 0, sizeof(QRPE_RADIO_T));
	}
}

#ifdef CONFIG_SUPPORT_QTNA_BACKBONE
static void qrpe_deinit_wds_intfs(void)
{
	int i;
	for (i = 0; i < g_ctx.wds_intfs; i++) {
		if (g_ctx.wds_intf_ctx[i].ops
			&& g_ctx.wds_intf_ctx[i].ops->deinit_intf)
			g_ctx.wds_intf_ctx[i].ops->deinit_intf(g_ctx.wds_intf_ctx[i].priv);
		memset(g_ctx.wds_intf_ctx + i, 0, sizeof(QRPE_INTF_T));
	}
}
#endif

static void qrpe_deinit_context(void)
{
	qrpe_deinit_link();
	if (g_ctx.ioctl_sock)
		close(g_ctx.ioctl_sock);
	qrpe_deinit_drivers();
	qrpe_deinit_intfs();
#ifdef CONFIG_SUPPORT_QTNA_BACKBONE
	qrpe_deinit_wds_intfs();
#endif
	qrpe_deinit_radios();
}

static char *qrpe_get_intf_name(char *p)
{
	int start = 0, end = 0;

	while (p[start] > 0 && p[start] < 128 && isspace(p[start]))
		start++;
	end = start;
	while (p[end] > 0 && p[end] < 128 && p[end] != ':' && !isspace(p[end]))
		end++;
	if (p[end] != ':')
		return NULL;

	p[end] = '\0';
	return p + start;
}

QRPE_INTF_T *qrpe_find_intf_by_ifname(const char *ifname)
{
	int i;
	if (!ifname)
		return NULL;

	for (i = 0; i < g_ctx.intfs; i++) {
		if (!strcmp(g_ctx.intf_ctx[i].ifname, ifname))
			return &g_ctx.intf_ctx[i];
	}
	return NULL;
}

QRPE_INTF_T *qrpe_find_intf_by_ifmac(uint8_t *mac)
{
	int i;
	if (!mac)
		return NULL;

	for (i = 0; i < g_ctx.intfs; i++) {
		if (!memcmp(g_ctx.intf_ctx[i].ifmac, mac, ETH_ALEN))
			return &g_ctx.intf_ctx[i];
	}
	return NULL;
}

QRPE_INTF_T *qrpe_find_intf_by_ifindex(int ifindex)
{
	int i;

	for (i = 0; i < g_ctx.intfs; i++) {
		if (ifindex == g_ctx.intf_ctx[i].ifindex)
			return &g_ctx.intf_ctx[i];
	}
	return NULL;
}

static QRPE_INTF_T *qrpe_new_intf(const char *ifname)
{
	QRPE_INTF_T *intf = NULL;
	if (g_ctx.intfs >= QRPE_SUPPORT_INTFS) {
		QRPE_WARN("Skip add intf %s: Intfs is overload %u >= %u",
			ifname, g_ctx.intfs, QRPE_SUPPORT_INTFS);
		return NULL;
	}
	intf = g_ctx.intf_ctx + g_ctx.intfs;
	strncpy(intf->ifname, ifname, IFNAMSIZ - 1);
	g_ctx.intfs++;
	return intf;
}

void qrpe_update_intf_mac(QRPE_INTF_T *intf, int ifindex)
{
	struct ifreq ifr;
	ifr.ifr_ifindex = ifindex;
	if (!intf)
		return;

	strncpy(ifr.ifr_name, intf->ifname, IFNAMSIZ - 1);
	if (ioctl(g_ctx.ioctl_sock, SIOCGIFHWADDR, &ifr) >= 0)
		memcpy(intf->ifmac, ifr.ifr_hwaddr.sa_data, ETH_ALEN);
	intf->ifindex = ifindex;
}

static QRPE_INTF_T *qrpe_add_intf(const char *ifname, const QRPE_DRIVER_OPS_T *ops)
{
	QRPE_INTF_T *intf = NULL;
	struct ifreq ifr;

	QRPE_DEBUG("Add or Update intf %s", ifname);
	intf = qrpe_find_intf_by_ifname(ifname);
	if (!intf)
		intf = qrpe_new_intf(ifname);

	if (intf) {
		strncpy(ifr.ifr_name, ifname, IFNAMSIZ - 1);
		if (ioctl(g_ctx.ioctl_sock, SIOCGIFINDEX, &ifr) >= 0)
			qrpe_update_intf_mac(intf, ifr.ifr_ifindex);
		intf->ops = ops;
		intf->status = QRPE_INTF_STATUS_DOWN;
		if (!intf->priv && ops->init_intf)
			intf->priv = ops->init_intf(ifname);
		QRPE_DEBUG("Update intf %s: ifindex %u; mac " MACSTR "; driver %s", ifname,
			intf->ifindex, MAC2STR(intf->ifmac), ops->name);
	}
	return intf;
}

QRPE_INTF_T *qrpe_probe_intf(const char *ifname)
{
	const QRPE_DRIVER_OPS_T *driver = NULL;
	QRPE_INTF_T *intf = NULL;

	if (!ifname)
		return NULL;

	QRPE_DEBUG("Probe driver for intf %s", ifname);
	driver = qrpe_driver_probe_intf(ifname);
	if (driver)
		intf = qrpe_add_intf(ifname, driver);
	return intf;
}

QRPE_RADIO_T *qrpe_find_radio_by_ifname(const char *ifname)
{
	int i;
	if (!ifname)
		return NULL;

	for (i = 0; i < g_ctx.radios; i++) {
		if (!strcmp(g_ctx.radio_ctx[i].ifname, ifname))
			return &g_ctx.radio_ctx[i];
	}
	return NULL;
}

QRPE_RADIO_T *qrpe_find_radio_by_uid(uint8_t *radio_uid)
{
	int i;
	if (!radio_uid)
		return NULL;

	for (i = 0; i < g_ctx.radios; i++) {
		if (!memcmp(g_ctx.radio_ctx[i].uid, radio_uid, ETH_ALEN))
			return &g_ctx.radio_ctx[i];
	}
	return NULL;
}

static QRPE_RADIO_T *qrpe_new_radio(const char *ifname)
{
	QRPE_RADIO_T *radio = NULL;
	if (g_ctx.radios >= QRPE_SUPPORT_RADIOS) {
		QRPE_WARN("Skip add radio %s: Radios is overload %u >= %u",
			ifname, g_ctx.radios, QRPE_SUPPORT_RADIOS);
		return NULL;
	}
	radio = g_ctx.radio_ctx + g_ctx.radios;
	strncpy(radio->ifname, ifname, IFNAMSIZ - 1);
	g_ctx.radios++;
	return radio;
}

static QRPE_RADIO_T *qrpe_add_radio(const char *ifname, const QRPE_DRIVER_OPS_T *ops)
{
	QRPE_RADIO_T *radio = NULL;
	struct ifreq ifr;

	QRPE_DEBUG("Add or Update radio %s", ifname);
	radio = qrpe_find_radio_by_ifname(ifname);
	if (!radio)
		radio = qrpe_new_radio(ifname);

	if (radio) {
		strncpy(ifr.ifr_name, ifname, IFNAMSIZ - 1);
		if (ioctl(g_ctx.ioctl_sock, SIOCGIFHWADDR, &ifr) >= 0)
			memcpy(radio->uid, ifr.ifr_hwaddr.sa_data, ETH_ALEN);

		radio->ops = ops;
		radio->intf_mask = 0;

		if (!radio->priv && ops->init_radio)
			radio->priv = ops->init_radio(ifname);
		QRPE_DEBUG("Update radio %s: Radio Unique Identifier " MACSTR "; driver %s",
			ifname, MAC2STR(radio->uid), ops->name);
	}
	return radio;
}

QRPE_RADIO_T *qrpe_probe_radio(const char *ifname)
{
	const QRPE_DRIVER_OPS_T *driver = NULL;
	QRPE_RADIO_T *radio = NULL;

	if (!ifname)
		return NULL;

	QRPE_DEBUG("Probe radio %s", ifname);
	driver = qrpe_driver_probe_radio(ifname);
	if (driver)
		radio = qrpe_add_radio(ifname, driver);
	return radio;
}

#ifdef CONFIG_SUPPORT_QTNA_BACKBONE
QRPE_INTF_T *qrpe_find_wds_intf_by_ifname(const char *ifname)
{
	int i;
	if (!ifname)
		return NULL;

	for (i = 0; i < g_ctx.wds_intfs; i++) {
		if (!strcmp(g_ctx.wds_intf_ctx[i].ifname, ifname))
			return &g_ctx.wds_intf_ctx[i];
	}
	return NULL;
}

static QRPE_INTF_T *qrpe_new_wds_intf(const char *ifname)
{
	QRPE_INTF_T *intf = NULL;
	if (g_ctx.wds_intfs >= QTNA_WDS_MAXNUM) {
		QRPE_WARN("Skip add wds intf %s: Intfs is overload %u >= %u",
			ifname, g_ctx.wds_intfs, QTNA_WDS_MAXNUM);
		return NULL;
	}
	intf = g_ctx.wds_intf_ctx + g_ctx.wds_intfs;
	strncpy(intf->ifname, ifname, IFNAMSIZ - 1);
	g_ctx.wds_intfs++;
	return intf;
}

QRPE_INTF_T *qrpe_find_or_add_wds_intf(const char *ifname)
{
	QRPE_INTF_T *intf = NULL;
	struct ifreq ifr;

	QRPE_DEBUG("Add or Update wds intf %s", ifname);
	intf = qrpe_find_wds_intf_by_ifname(ifname);
	if (!intf)
		intf = qrpe_new_wds_intf(ifname);

	if (intf) {
		const QRPE_DRIVER_OPS_T *ops = &qrpe_qtna_driver_ops;
		strncpy(ifr.ifr_name, ifname, IFNAMSIZ - 1);
		if (ioctl(g_ctx.ioctl_sock, SIOCGIFINDEX, &ifr) >= 0)
			qrpe_update_intf_mac(intf, ifr.ifr_ifindex);
		intf->ops = ops;
		intf->status = QRPE_INTF_STATUS_DOWN;
		if (!intf->priv)
			intf->priv = ops->init_intf(ifname);
		QRPE_DEBUG("Update wds intf %s: ifindex %u; mac " MACSTR "", ifname,
			intf->ifindex, MAC2STR(intf->ifmac));
	}
	return intf;
}
#endif

static void qrpe_probe_devs(void)
{
	FILE *fd = NULL;
	char buf[256];
	QRPE_INTF_T *intf = NULL;
	QRPE_RADIO_T *radio = NULL;

	fd = fopen(QRPE_PROCNET_DEVS64, "r");
	if (!fd) {
		fd = fopen(QRPE_PROCNET_DEVS, "r");
		if (!fd)
			return;
	}

	fgets(buf, 256, fd);
	fgets(buf, 256, fd);

	while (fgets(buf, 256, fd)) {
		char *ifname = qrpe_get_intf_name(buf);
		/* probes for radios */
		if (ifname)
			radio = qrpe_probe_radio(ifname);
		if (radio && radio->ops)
			QRPE_INFO("Find %s driver for radio %s", radio->ops->name, ifname);

		/* probes for interfaces */
		if (ifname)
			intf = qrpe_probe_intf(ifname);
		if (intf && intf->ops)
			QRPE_INFO("Find %s driver for intf %s", intf->ops->name, ifname);
#ifdef CONFIG_SUPPORT_QTNA_BACKBONE
		if (!intf && ifname && !strncmp(ifname, "wds", 3))
			qrpe_find_or_add_wds_intf(ifname);
#endif
	}
	fclose(fd);
}

static int qrpe_init_ctrl_sock(void)
{
	struct sockaddr_un addr;

	g_ctx.ctrl_sock = socket(PF_UNIX, SOCK_DGRAM, 0);
	if (g_ctx.ctrl_sock < 0)
		return -1;

	unlink(QRPE_UNIX_PATH);
	memset(&addr, 0, sizeof(addr));
	addr.sun_family = AF_UNIX;
	strcpy(addr.sun_path, QRPE_UNIX_PATH);
	if (bind(g_ctx.ctrl_sock, (struct sockaddr *) &addr, sizeof(addr)) < 0)
		return -1;

	return 0;
}

static int qrpe_init_context(void)
{
	memset(&g_ctx, 0, sizeof(g_ctx));
	g_ctx.rtm_sock = -1;
	g_ctx.read_sock = -1;
#ifdef CONFIG_SUPPORT_RTNETLINK
	g_ctx.write_sock = -1;
#elif defined QRPE_COMM_GENNETLINK

#endif
	g_ctx.ctrl_sock = -1;
	g_ctx.ioctl_sock = socket(PF_INET, SOCK_DGRAM, 0);
	if (g_ctx.ioctl_sock < 0) {
		QRPE_ERROR("Failed to create IOCTL socket");
		return -1;
	}

	if (qrpe_init_ctrl_sock() < 0) {
		QRPE_ERROR("Failed to init ctrl sock");
		return -1;
	}

	if (qrpe_init_link() < 0) {
		QRPE_ERROR("Failed to init link");
		return -1;
	}

	qrpe_init_drivers();
	qrpe_probe_devs();

	return 0;
}

static int os_daemonize(const char *pid_file)
{
	if (daemon(0, 1)) {
		perror("daemon");
		return -1;
	}

	if (pid_file) {
		FILE *f = fopen(pid_file, "w");
		if (f) {
			fprintf(f, "%u\n", getpid());
			fclose(f);
		}
	}

	return 0;
}

int main(int argc, char *argv[])
{
#ifndef QRPE_PATCH_MAXNO
	printf("qtna-rpe(%s-%s) started\n", QRPE_VERSION, QRPE_SUBVERSION);
#else
	printf("qtna-rpe(%s-%s-%d) started\n", QRPE_VERSION, QRPE_SUBVERSION, QRPE_PATCH_MAXNO);
#endif

	qrpe_init_conf();
	qrpe_parse_args(argc, argv);

	QRPE_SET_DEBUG(g_conf.dbg_level, g_conf.dbg_output);

	if (g_conf.daemonize && os_daemonize(g_conf.pid_file)) {
		QRPE_WARN("Unable to daemonise qrpe daemon");
		fprintf(stderr, "Unable to daemonise qrpe daemon\n");
		perror("daemon");
		return -1;
	}

	if (qrpe_init_context() < 0) {
		QRPE_ERROR("Failed to init context");
		goto _end;
	}

	qrpe_message_loop();

_end:
	if (g_conf.pid_file)
		unlink(g_conf.pid_file);

	qrpe_deinit_context();
	return 0;
}

