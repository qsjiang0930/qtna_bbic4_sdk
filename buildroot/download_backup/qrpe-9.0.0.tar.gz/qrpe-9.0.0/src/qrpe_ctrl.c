/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : qrpe_ctrl.c                                                **
**  Description : qrpe ctrl function                                         **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#include "common.h"
#include "qrpe_message.h"
#include "qrpe_driver.h"
#include "qrpe.h"
#include "qrpe_debug.h"
#include "qrpe_cli.h"

static int qrpe_print_ctrl_usage(char *cli, char *rep, int rep_len)
{
	return snprintf(rep, rep_len,
		"Usage: %s <command> [<parameter>] [<value>]\n"
		"Commands:\n"
		"	dbg level/output <level>                : set dbg level (off/error/warn/notice/info/debug); output(stdout/syslog/none)\n"
		"	test <cmd> [params]			: only for test\n", basename(cli)
	);
}

static int qrpe_ctrl_handle_req(char *req, char *rep, int rep_len)
{
	int argc, i;
	char *argv[16] = { NULL };
	char *pos, *end;

	argc = req[0];

	pos = &req[1];
	for (i = 0; i < argc && i < 16; ++i, ++pos) {
		argv[i] = pos;
		while(*pos)
			++pos;
	}

	if (argc <= 1)
		return qrpe_print_ctrl_usage(argv[0], rep, rep_len);

	pos = rep;
	end = rep + rep_len;
	if(strcmp("dbg", argv[1]) == 0) {
		if (argc <= 3)
			return qrpe_print_ctrl_usage(argv[0], rep, rep_len);

		if(strcmp("level", argv[2]) == 0)
			qrpe_debug_set(argv[3], NULL);
		else if(strcmp("output", argv[2]) == 0)
			qrpe_debug_set(NULL, argv[3]);
		else
			return qrpe_print_ctrl_usage(argv[0], rep, rep_len);

		pos += snprintf(rep, rep_len, "success\n");
	} else if(strcmp("test", argv[1]) == 0) {
		if (argc <= 2)
			return qrpe_print_ctrl_usage(argv[0], rep, rep_len);
		pos += snprintf(rep, rep_len, "test command %s not support\n", argv[2]);
	}  else {
		return qrpe_print_ctrl_usage(argv[0], rep, rep_len);
	}

	if(pos > end)
		return rep_len;

	return pos - rep;
}

static char g_req[QRPE_CTRL_REQ_LEN];
static char g_rep[QRPE_CTRL_PACKET_LEN];
int qrpe_receive_ctrl_message(int sd)
{
	int nread, rep_len;
	struct sockaddr_un addr;
	socklen_t addr_len;

	memset(g_req, 0, QRPE_CTRL_REQ_LEN);
	memset(g_rep, 0, QRPE_CTRL_PACKET_LEN);

	memset(&addr, 0, sizeof(addr));
	addr_len = sizeof(addr);
	nread = recvfrom(g_ctx.ctrl_sock, g_req, sizeof(g_req), MSG_DONTWAIT, (struct sockaddr *)&addr, &addr_len);

	if (nread < 0) {
		QRPE_WARN("Failed to receive frame from ctrl socket: %s\n", strerror(errno));
		return -1;
	}

	rep_len = qrpe_ctrl_handle_req(g_req, g_rep, QRPE_CTRL_PACKET_LEN);
	if(rep_len < 0) {
		QRPE_WARN("Failed to handle the ctrl req: %d\n", rep_len);
		return -1;
	}

	if (sendto(g_ctx.ctrl_sock, g_rep, rep_len, 0, (struct sockaddr *)&addr, addr_len) < 0) {
		QRPE_WARN("Failed to send frame to ctrl socket: %s\n", strerror(errno));
		return -1;
	}

	return 0;
}

