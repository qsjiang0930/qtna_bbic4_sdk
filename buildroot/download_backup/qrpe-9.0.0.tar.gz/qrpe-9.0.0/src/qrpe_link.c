/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : qrpe_link.c                                                **
**  Description : qrpe link function                                         **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#include "common.h"
#include "qrpe_message.h"
#include "qrpe_driver.h"
#include "qrpe.h"
#include "qrpe_debug.h"

static void qrpe_deinit_comm_link(void)
{
#ifdef CONFIG_SUPPORT_RTNETLINK
	if (g_ctx.read_sock >= 0)
		close(g_ctx.read_sock);
	if (g_ctx.write_sock >= 0)
		close(g_ctx.write_sock);
#elif defined CONFIG_SUPPORT_GENNETLINK
	if(g_ctx.nlcb)
		nl_cb_put(g_ctx.nlcb);
	if(g_ctx.write_nl_sock)
		nl_socket_free(g_ctx.write_nl_sock);
	if(g_ctx.read_nl_sock)
		nl_socket_free(g_ctx.read_nl_sock);
#endif
}

#ifdef CONFIG_SUPPORT_RTNETLINK
static int qrpe_init_comm_rtnetlink(void)
{
	struct sockaddr_nl read_addr, write_addr;
	/*init app read socket */
	g_ctx.read_sock = socket(PF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
	if (g_ctx.read_sock < 0) {
		QRPE_ERROR("Failed to open netlink socket: %s", strerror(errno));
		return -1;
	}

	memset(&read_addr, 0, sizeof(read_addr));
	read_addr.nl_family = AF_NETLINK;
	read_addr.nl_groups = RTMGRP_NOTIFY;

	if (bind(g_ctx.read_sock, (struct sockaddr *) &read_addr, sizeof(read_addr)) < 0) {
		QRPE_ERROR("Failed to bind netlink socket: %s", strerror(errno));
		return -1;
	}

	/*init app write socket */
	g_ctx.write_sock = socket(PF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
	if (g_ctx.write_sock < 0) {
		QRPE_ERROR("Failed to open netlink socket: %s", strerror(errno));
		return -1;
	}

	return 0;
}
#endif

#ifdef CONFIG_SUPPORT_GENNETLINK
static struct nl_sock *qrpe_init_genl_sock(struct nl_cb *nlcb, const char *group_name)
{
	int group;
	struct nl_sock *nl_sock = NULL;
	nl_sock = nl_socket_alloc_cb(nlcb);
	if(NULL == nl_sock) {
		QRPE_ERROR("Failed to alloc nl sock");
		return NULL;
	}
	nl_socket_set_nonblocking(nl_sock);
	nl_socket_disable_seq_check(nl_sock);
	if (genl_connect(nl_sock)) {
		QRPE_ERROR("Failed to connect nl sock");
		goto _fail;
	}

	if (!group_name)
		return nl_sock;

	group = genl_ctrl_resolve_grp(nl_sock, QRPE_FAMILY_NAME, group_name);
	if (group < 0) {
		QRPE_ERROR("Failed to resolve nl group");
		goto _fail;
	}

	if (nl_socket_add_memberships(nl_sock, group, 0) < 0) {
		QRPE_ERROR("Failed to add menbership");
		goto _fail;
	}

	return nl_sock;

_fail:
	if (nl_sock)
		nl_socket_free(nl_sock);
	return NULL;
}

static int qrpe_init_comm_gennetlink(void)
{
	g_ctx.nlcb = nl_cb_alloc(NL_CB_DEFAULT);
	if(NULL == g_ctx.nlcb) {
		QRPE_ERROR("Failed to alloc nl cb");
		return -1;
	}

	if (NULL == (g_ctx.write_nl_sock
		= qrpe_init_genl_sock(g_ctx.nlcb, NULL))) {
		QRPE_ERROR("Failed to init write nl sock: %s", QRPE_APP_EVENT);
		return -1;
	}

	if (NULL == (g_ctx.read_nl_sock
		= qrpe_init_genl_sock(g_ctx.nlcb, QRPE_APP_COMMAND))) {
		QRPE_ERROR("Failed to init read nl sock: %s", QRPE_APP_COMMAND);
		return -1;
	}

	if(nl_socket_modify_cb(g_ctx.read_nl_sock, NL_CB_VALID, NL_CB_CUSTOM,
		qrpe_recv_message_from_app_by_gennetlink, NULL)) {
		QRPE_ERROR("Modify nl callback failed");
		return -1;
	}

	g_ctx.qrpe_fam_id = genl_ctrl_resolve(g_ctx.read_nl_sock, QRPE_FAMILY_NAME);
	if (g_ctx.qrpe_fam_id < 0) {
		QRPE_ERROR("Can not find generic netlink(%s)", QRPE_FAMILY_NAME);
		return -1;
	}

	g_ctx.read_sock = nl_socket_get_fd(g_ctx.read_nl_sock);
	if (g_ctx.read_sock < 0) {
		QRPE_ERROR("Failed to get sock from nl");
		return -1;
	}

	return 0;
}
#endif

static int qrpe_init_comm_link(void)
{
	int ret = -1;

#ifdef CONFIG_SUPPORT_RTNETLINK
	ret = qrpe_init_comm_rtnetlink();
#elif defined CONFIG_SUPPORT_GENNETLINK
	ret = qrpe_init_comm_gennetlink();
#endif

	if (ret < 0)
		qrpe_deinit_comm_link();
	return ret;
}

static void qrpe_deinit_rtm_sock(void)
{
	if (g_ctx.rtm_sock >= 0)
		close(g_ctx.rtm_sock);
}

static int qrpe_init_rtm_sock(void)
{
	struct sockaddr_nl addr;
	g_ctx.rtm_sock = socket(PF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
	if (g_ctx.rtm_sock < 0) {
		QRPE_ERROR("Failed to open rtnetlink socket for driver event: %s", strerror(errno));
		return -1;
	}

	memset(&addr, 0, sizeof(addr));
	addr.nl_family = AF_NETLINK;
	addr.nl_groups = RTMGRP_LINK;

	if (bind(g_ctx.rtm_sock, (struct sockaddr *)&addr, sizeof(addr)) < 0)	{
		QRPE_ERROR("Failed to bind rtnetlink socket for driver event: %s", strerror(errno));
		return -1;
	}
	return 0;
}

int qrpe_init_link(void)
{
	int ret;

	QRPE_DEBUG("Begin init the link");
	ret = qrpe_init_comm_link();
	if (ret >= 0)
		return qrpe_init_rtm_sock();

	return ret;
}

void qrpe_deinit_link(void)
{
	qrpe_deinit_comm_link();
	qrpe_deinit_rtm_sock();
}

