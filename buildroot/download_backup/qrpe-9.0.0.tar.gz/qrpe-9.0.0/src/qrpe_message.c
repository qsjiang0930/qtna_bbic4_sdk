/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : qrpe_message.c                                             **
**  Description : qrpe event and command handler                             **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#include "common.h"
#include "qrpe_message.h"
#include "qrpe_driver.h"
#include "qrpe.h"
#include "qrpe_debug.h"

uint8_t g_rx_buff[QRPE_MAX_MSG_LEN];
uint8_t g_tx_buff[QRPE_MAX_MSG_LEN];

/* index is the event id, see the QRPE_EVENT_ID_E */
static inline const char *qrpe_event_to_name(uint16_t id)
{
#define E2S(x)	case x:	return #x;
	switch(id) {
	E2S(QRPE_EVENT_INTF_STATUS)
	E2S(QRPE_EVENT_INTF_INFO)
	E2S(QRPE_EVENT_PROBE_REQ)
	E2S(QRPE_EVENT_CONNECT_COMPLETE)
	E2S(QRPE_EVENT_DEAUTH)
	E2S(QRPE_EVENT_DISASSOC)
	E2S(QRPE_EVENT_STA_PHY_STATS)
	E2S(QRPE_EVENT_BSS_TRANS_STATUS)
	E2S(QRPE_EVENT_STA_NONASSOC_STATS)
	E2S(QRPE_EVENT_AUTH)
	E2S(QRPE_EVENT_ASSOC_REQ)
	E2S(QRPE_EVENT_FRAME)
	E2S(QRPE_EVENT_RADIO_INFO)
	E2S(QRPE_EVENT_RADIO_STATUS)
	E2S(QRPE_EVENT_ROAM_FAIL)
	E2S(QRPE_EVENT_ASSOC_ADDITIONAL_INFO)

	E2S(QRPE_EVENT_SPDIA_INFO)
	E2S(QRPE_EVENT_INTF_UPDATE_NOTIFY)
	E2S(QRPE_EVENT_RADIO_PWRSAVE)
	E2S(QRPE_EVENT_CHAN_STATE_CAC)
	E2S(QRPE_EVENT_CHAN_STATE_UPDATE)
	default: return "UNKNOW EVENT";
	}
#undef E2S
}

/* index is the cmd id, see the QRPE_COMMAND_ID_E */
static inline const char *qrpe_command_to_name(uint16_t id)
{
#define C2S(x)	case x:	return #x;
	switch(id) {
	C2S(QRPE_CMD_INIT)
	C2S(QRPE_CMD_DEINIT)
	C2S(QRPE_CMD_GET_INTF_STATUS)
	C2S(QRPE_CMD_GET_INTF_INFO)
	C2S(QRPE_CMD_DEAUTHENTICATE)
	C2S(QRPE_CMD_STA_MAC_FILTER)
	C2S(QRPE_CMD_GET_STA_STATS)
	C2S(QRPE_CMD_BSS_TRANS_REQ)
	C2S(QRPE_CMD_FAT_MONITOR_START)
	C2S(QRPE_CMD_MONITOR_START)
	C2S(QRPE_CMD_MONITOR_STOP)
	C2S(QRPE_CMD_GET_NONASSOC_STATS)
	C2S(QRPE_CMD_FRAME)
	C2S(QRPE_CMD_REGISTER_FRAME)
	C2S(QRPE_CMD_SET_USER_CAP)
	C2S(QRPE_CMD_DISASSOC)
	C2S(QRPE_CMD_RADIO_CHANGE_CHAN)
	C2S(QRPE_CMD_ROAM)
	C2S(QRPE_CMD_CTRL_INTF_FEAT)

	C2S(QRPE_CMD_SPDIA_CTRL)
	default: return "UNKNOW COMMAND";
	}
#undef C2S
}

/* SONiQ use the L in TLV to find the next T, not by the aligned L.
 * But these Ls have been updated in Spec to keep in line with SONiQ implement,
 * So use this function to get the L from the valid len */
static uint16_t qrpe_tlv_vlen(uint16_t type, uint16_t len)
{
	switch (type) {
	case TLVTYPE_STA_MAC:
		len = QRPE_IE_LEN(ETH_ALEN);
		break;
	case TLVTYPE_CHANNEL_BAND:
		len = QRPE_IE_LEN(3);
		break;
	case TLVTYPE_BEACON_INTERVAL:
		len = QRPE_IE_LEN(sizeof(uint16_t));
		break;
	case TLVTYPE_VHT_CAPABILITY:
		len = QRPE_IE_LEN(VHT_CAP_LEN);
		break;
	default:
		break;
	}
	return len;
}

static uint16_t qrpe_get_min_len(uint16_t type)
{
	uint16_t len = 0;

	switch (type) {
	case TLVTYPE_STA_MAC:
	case TLVTYPE_PEER_MACADDR:
		len = ETH_ALEN;
		break;
	case TLVTYPE_CHANNEL_BAND:
		len = 3;
		break;
	case TLVTYPE_BSSID_MDID:
		len = 8;
		break;
	case TLVTYPE_TS_LAST_RX:
	case TLVTYPE_AGE_LAST_RX:
	case TLVTYPE_TS_LAST_TX:
	case TLVTYPE_AGE_LAST_TX:
		len = sizeof(uint64_t);
		break;
	case TLVTYPE_CHANNEL_BAND_CC:
	case TLVTYPE_RX_PHYRATE:
	case TLVTYPE_TX_PHYRATE:
	case TLVTYPE_AVERAGE_FAT:
	case TLVTYPE_INTERFACE_CAPABILITY:
	case TLVTYPE_EXT_INTF_CAPABILITY:
	case TLVTYPE_RSSI:
	case TLVTYPE_RSSI_ADV:
	case TLVTYPE_INTERFACE_TYPE:
	case TLVTYPE_STA_AIRTIME:
	case TLVTYPE_PKTS:
	case TLVTYPE_BL_MASK:
	case TLVTYPE_STATUS_CODE:
	case TLVTYPE_NRIE_INDEX:
	case TLVTYPE_NOISE:
	case TLVTYPE_SPDIA_CONF:
	case TLVTYPE_SPDIA_TONES:
	case TLVTYPE_SPDIA_DETAILS:
	case TLVTYPE_SPDIA_SUPPORTED_FEATURES:
	case TLVTYPE_SPDIA_CAPABILITIES:
	case TLVTYPE_INTF_DRIVER_CFG:
		len = sizeof(uint32_t);
		break;
	case TLVTYPE_BEACON_INTERVAL:
		len = sizeof(uint16_t);
		break;
	case TLVTYPE_HT_CAPABILITY:
		len = HT_CAP_LEN;
		break;
	case TLVTYPE_HT_OPERATION:
		len = HT_OP_LEN;
		break;
	case TLVTYPE_VHT_CAPABILITY:
		len = VHT_CAP_LEN;
		break;
	case TLVTYPE_VHT_OPERATION:
		len = VHT_OP_LEN;
		break;
	case TLVTYPE_NRIE:
		len = (QRPE_NRIE_MIN_LEN - 2);
		break;
	default:
		break;
	}

	return len;
}

static inline uint32_t qrpe_encap_tlv_head(TLV_T *tlv, uint16_t type,
	uint16_t len)
{
	uint16_t vlen = qrpe_tlv_vlen(type, len);
	uint16_t ie_len = QRPE_IE_LEN(vlen);

	tlv->type = host_to_le16(type);
	tlv->len = host_to_le16(vlen);

	return ie_len + sizeof(TLV_T);
}

static inline uint32_t qrpe_tlv_space(uint16_t type, uint16_t len)
{
	uint16_t vlen = qrpe_tlv_vlen(type, len);
	uint16_t ie_len = QRPE_IE_LEN(vlen);

	return ie_len + sizeof(TLV_T);
}

static inline uint32_t qrpe_encap_tlv(uint8_t *start, uint16_t type,
	uint8_t *value, uint16_t len)
{
	TLV_T *tlv = (TLV_T *)start;
	uint32_t ie_len = qrpe_encap_tlv_head(tlv, type, len);

	memcpy(tlv->value, value, len);
	if (ie_len > len + sizeof(TLV_T))
		memset(tlv->value + len, 0, ie_len - len - sizeof(TLV_T));

	return ie_len;
}

static inline uint32_t qrpe_encap_tlv_uint16(uint8_t *pos, uint16_t type, uint16_t value)
{
	value = host_to_le16(value);
	return qrpe_encap_tlv(pos, type, (uint8_t *)(&value), sizeof(value));
}

static inline uint32_t qrpe_encap_tlv_uint32(uint8_t *pos, uint16_t type, uint32_t value)
{
	value = host_to_le32(value);
	return qrpe_encap_tlv(pos, type, (uint8_t *)(&value), sizeof(value));
}

static inline uint32_t qrpe_encap_tlv_uint64(uint8_t *pos, uint16_t type, uint64_t value)
{
	value = host_to_le64(value);
	return qrpe_encap_tlv(pos, type, (uint8_t *)(&value), sizeof(value));
}

static inline uint32_t qrpe_encap_tlv_uint32_sequence(uint8_t *pos,
	uint16_t type, uint32_t *value, uint32_t nums)
{
	TLV_T *tlv = (TLV_T *)pos;
	uint32_t i, *val = (uint32_t *)tlv->value;

	for (i = 0; i < nums; i++)
		*(val + i) = host_to_le32(value[i]);

	return qrpe_encap_tlv_head(tlv, type, sizeof(uint32_t) * nums);
}

static void qrpe_build_event_head(uint8_t *head, uint16_t id, uint8_t coding,
	uint8_t ver, uint16_t len, uint8_t *bssid)
{
	QRPE_EVENT_T *event = (QRPE_EVENT_T *)head;

	QRPE_INFO("Build app event [%s]: bssid " MACSTR "; ver %u; len %u;",
		qrpe_event_to_name(id), MAC2STR(bssid), ver, len);
	event->id = host_to_le16(id);
	event->coding = coding;
	event->api_ver = ver;
	event->payload_len = host_to_le16(len);
	memcpy(event->mac, bssid, ETH_ALEN);
}

static inline uint8_t *qrpe_get_event_payload(uint8_t *head)
{
	return (((QRPE_EVENT_T *)head)->payload);
}

static inline uint8_t *qrpe_get_command_payload(QRPE_COMMAND_T *head)
{
	return (head->payload);
}

static inline uint16_t qrpe_get_command_payload_len(QRPE_COMMAND_T *head)
{
	return le_to_host16(head->payload_len);
}

static inline int qrpe_check_tx_space(uint8_t *pos, uint32_t len)
{
	if (g_tx_buff + QRPE_MAX_MSG_LEN - pos < len)
		return 0;
	return 1;
}

typedef void (*init_block_t)(void);
typedef int (*check_block_t)(uint16_t);
typedef void (*parse_ie_t)(void **, uint8_t *, uint16_t, uint16_t);
typedef void (*process_block_t)(void *, void *, uint8_t *, int);

static void qrpe_parse_tlv(void *ctx, uint8_t *frm, uint16_t frm_len,
	init_block_t init_cb, check_block_t check_cb,
	parse_ie_t parse_cb, process_block_t process_cb)
{
	TLV_T *t;
	uint16_t type, len, min_len;
	void *ies = NULL;

	if (init_cb)
		init_cb();

	while (frm_len >= sizeof(TLV_T)) {
		t = (TLV_T *)frm;
		type = le_to_host16(t->type);
		len = le_to_host16(t->len);
		min_len = qrpe_get_min_len(type);

		if (frm_len < len + sizeof(TLV_T))  {
			QRPE_WARN("Drop Tag(%u): len(%u) is over left frame len(%u)", type, len, frm_len);
			return;
		}

		if (min_len > len) {
			QRPE_WARN("Drop Tag(%u): len(%u) is not over min len(%u)", type, len, min_len);
			goto _next;
		}

		if (ies && check_cb && check_cb(type))
			process_cb(ctx, ies, frm, 1);

		parse_cb(&ies, frm, type, len);

_next:
		frm += (sizeof(TLV_T) + QRPE_IE_LEN(len));
		frm_len -= (sizeof(TLV_T) + QRPE_IE_LEN(len));
	}

	if (ies)
		process_cb(ctx, ies, frm, 0);
}

#ifdef CONFIG_SUPPORT_RTNETLINK
static void qrpe_send_event_by_rtnetlink(uint8_t *event, uint32_t len)
{
	struct nlmsghdr *nlh = NULL;
	struct sockaddr_nl dest_addr;
	struct msghdr msg;
	struct iovec iov;

	if (g_ctx.write_sock < 0)
		return;

	nlh = (struct nlmsghdr *)QRPE_CALLOC(1, NLMSG_SPACE(NLMSG_LENGTH(len)));
	if (!nlh)
		return;

	nlh->nlmsg_len = NLMSG_LENGTH(len);
	nlh->nlmsg_pid = getpid();
	nlh->nlmsg_type = QRPE_RTLINK_EVENT;
	nlh->nlmsg_flags = 0;

	memcpy(NLMSG_DATA(nlh), event, len);

	memset(&dest_addr, 0, sizeof(dest_addr));
	dest_addr.nl_family = AF_NETLINK;
#ifdef CONFIG_RTNETLINK_EVENT_MULTICAST
	dest_addr.nl_groups = RTMGRP_NOTIFY;
#else
	dest_addr.nl_pid = QRPE_EVENT_PID;
#endif
	iov.iov_base = (void *)nlh;
	iov.iov_len = nlh->nlmsg_len;

	memset(&msg, 0, sizeof(msg));
	msg.msg_name = (void *)&dest_addr;
	msg.msg_namelen = sizeof(dest_addr);
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;

	if (sendmsg(g_ctx.write_sock, &msg, 0) < 0)
		QRPE_DEBUG("Send msg failed: %s", strerror(errno));

	QRPE_FREE(nlh);
}
#endif

#ifdef CONFIG_SUPPORT_GENNETLINK
static void qrpe_send_event_by_gennetlink(uint8_t *event, uint32_t len)
{
	struct nl_msg *nlmsg = NULL;
	uint32_t maxlen = nlmsg_total_size(nla_total_size(len)) + nlmsg_total_size(0);
	nlmsg = nlmsg_alloc_size(maxlen);
	if (!nlmsg) {
		QRPE_ERROR("Failed to allocate netlink message");
		goto _end;
	}

	genlmsg_put(nlmsg, 0, 0, g_ctx.qrpe_fam_id, 0, 0, QRPE_GENL_PEER_EVENT, 0);
	if (nla_put(nlmsg, QRPE_ATTR_TX_APP_EVENT, len, event)) {
		QRPE_ERROR("Failed to add event attr");
		goto _end;
	}
	if (nl_send_auto_complete(g_ctx.write_nl_sock, nlmsg) < 0)
		QRPE_ERROR("Failed to send event");

_end:
	if(nlmsg)
		nlmsg_free(nlmsg);
}
#endif

static void qrpe_send_event(uint8_t *event, uint32_t len)
{
#ifdef CONFIG_SUPPORT_RTNETLINK
	qrpe_send_event_by_rtnetlink(event, len);
#elif defined CONFIG_SUPPORT_GENNETLINK
	qrpe_send_event_by_gennetlink(event, len);
#endif
}

static void qrpe_send_probe_req_or_assoc(uint32_t drv_event, QRPE_INTF_T *intf, QRPE_DRV_PROBE_REQ_T *drv_probe_req)
{
	QRPE_EVENT_PROBE_REQ_T *probe_req =
		(QRPE_EVENT_PROBE_REQ_T *)qrpe_get_event_payload(g_tx_buff);
	uint16_t event_id;
	uint8_t version;

	if (drv_event == QRPE_DRV_EVENT_PROBE_REQ) {
		event_id = QRPE_EVENT_PROBE_REQ;
		version = QRPE_API_VER(1);
	} else if (drv_event == QRPE_DRV_EVENT_ASSOC_REQ) {
		event_id = QRPE_EVENT_ASSOC_REQ;
		version = QRPE_API_VER(5);
	} else
		return;

	memcpy(probe_req->peer_mac, drv_probe_req->peer_mac, ETH_ALEN);
	probe_req->curr_band = host_to_le16(drv_probe_req->curr_band);
	probe_req->rssi = host_to_le32(drv_probe_req->rssi);
	probe_req->rx_ss_info = host_to_le16(drv_probe_req->rx_ss_info);
	probe_req->max_phy_rate = host_to_le16(drv_probe_req->max_phy_rate);
	probe_req->tstamp = host_to_le64(drv_probe_req->tstamp);
	probe_req->channel = drv_probe_req->channel;
	probe_req->sta_capab = (drv_probe_req->band_width & QRPE_STACAPB_BANDWIDTH_MASK)
		<< QRPE_STACAPB_BANDWIDTH_SHIFT;
	probe_req->sta_capab |= (drv_probe_req->support_11v & QRPE_STACAPB_SUPPORT_11V_MASK)
		<< QRPE_STACAPB_SUPPORT_11V_SHIFT;
	probe_req->sta_capab |= (drv_probe_req->support_vht & QRPE_STACAPB_SUPPORT_VHT_MASK)
		<< QRPE_STACAPB_SUPPORT_VHT_SHIFT;
	probe_req->sta_capab |= (drv_probe_req->mumimo_capab & QRPE_STACAPB_MUMIMO_MASK)
		<< QRPE_STACAPB_MUMIMO_SHIFT;
	probe_req->sta_capab |= (drv_probe_req->support_he & QRPE_STACAPB_11AX_MASK)
		<< QRPE_STACAPB_11AX_SHIFT;
	probe_req->cookie_len = host_to_le16(drv_probe_req->cookie_len);
	memcpy(probe_req->cookie, drv_probe_req->cookie, drv_probe_req->cookie_len);

	qrpe_build_event_head(g_tx_buff, event_id, QRPE_CODING_FIXED, version,
		sizeof(QRPE_EVENT_PROBE_REQ_T) + drv_probe_req->cookie_len, intf->ifmac);
	qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T)
		+ sizeof(QRPE_EVENT_PROBE_REQ_T) + drv_probe_req->cookie_len);
}

static void qrpe_send_auth(QRPE_INTF_T *intf, QRPE_DRV_AUTH_T *drv_auth)
{
	QRPE_EVENT_AUTH_T *auth =
		(QRPE_EVENT_AUTH_T *)qrpe_get_event_payload(g_tx_buff);

	memcpy(auth->peer_mac, drv_auth->peer_mac, ETH_ALEN);
	auth->curr_band = drv_auth->curr_band;
	auth->channel = drv_auth->channel;
	auth->rssi = host_to_le32(drv_auth->rssi);
	auth->cookie_len = host_to_le16(drv_auth->cookie_len);
	memcpy(auth->cookie, drv_auth->cookie, drv_auth->cookie_len);

	qrpe_build_event_head(g_tx_buff, QRPE_EVENT_AUTH,
		QRPE_CODING_FIXED, QRPE_API_VER(5),
		sizeof(QRPE_EVENT_PROBE_REQ_T) + drv_auth->cookie_len, intf->ifmac);
	qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T)
		+ sizeof(QRPE_EVENT_AUTH_T) + drv_auth->cookie_len);
}

static void qrpe_send_connect_complete(QRPE_INTF_T *intf, QRPE_DRV_CONNECT_T *drv_connect)
{
	QRPE_EVENT_CONNECT_T *connect =
		(QRPE_EVENT_CONNECT_T *)qrpe_get_event_payload(g_tx_buff);

	memcpy(connect->peer_mac, drv_connect->peer_mac, ETH_ALEN);
	connect->rx_ss_info = host_to_le16(drv_connect->rx_ss_info);
	connect->max_phy_rate = host_to_le16(drv_connect->max_phy_rate);
	connect->node_type = drv_connect->node_type;
	connect->curr_band = drv_connect->curr_band;
	connect->channel = drv_connect->channel;
	connect->sta_capab = (drv_connect->band_width & QRPE_STACAPB_BANDWIDTH_MASK)
		<< QRPE_STACAPB_BANDWIDTH_SHIFT;
	connect->sta_capab |= (drv_connect->support_11v & QRPE_STACAPB_SUPPORT_11V_MASK)
		<< QRPE_STACAPB_SUPPORT_11V_SHIFT;
	connect->sta_capab |= (drv_connect->support_vht & QRPE_STACAPB_SUPPORT_VHT_MASK)
		<< QRPE_STACAPB_SUPPORT_VHT_SHIFT;
	connect->sta_capab |= (drv_connect->mumimo_capab & QRPE_STACAPB_MUMIMO_MASK)
		<< QRPE_STACAPB_MUMIMO_SHIFT;
	connect->sta_capab |= (drv_connect->support_he & QRPE_STACAPB_11AX_MASK)
		<< QRPE_STACAPB_11AX_SHIFT;
	connect->cookie_len = host_to_le16(drv_connect->cookie_len);
	memcpy(connect->cookie, drv_connect->cookie, drv_connect->cookie_len);

	qrpe_build_event_head(g_tx_buff, QRPE_EVENT_CONNECT_COMPLETE,
		QRPE_CODING_FIXED, QRPE_API_VER(4),
		sizeof(QRPE_EVENT_CONNECT_T) + drv_connect->cookie_len, intf->ifmac);
	qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T)
		+ sizeof(QRPE_EVENT_CONNECT_T) + drv_connect->cookie_len);
}

static void qrpe_send_disassoc(QRPE_INTF_T *intf, QRPE_DRV_DISASSOC_T *drv_disassoc)
{
	QRPE_EVENT_DISASSOC_T *disassoc =
		(QRPE_EVENT_DISASSOC_T *)qrpe_get_event_payload(g_tx_buff);

	memcpy(disassoc->peer_mac, drv_disassoc->peer_mac, ETH_ALEN);
	disassoc->reason_code = host_to_le16(drv_disassoc->reason_code);
	disassoc->direction = drv_disassoc->direction;

	qrpe_build_event_head(g_tx_buff, QRPE_EVENT_DISASSOC,
		QRPE_CODING_FIXED, QRPE_API_VER(1),
		sizeof(QRPE_EVENT_DISASSOC_T), intf->ifmac);
	qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T) + sizeof(QRPE_EVENT_DISASSOC_T));
}

static void qrpe_send_trans_status(QRPE_INTF_T *intf, QRPE_DRV_TRANS_STATUS_T *drv_status)
{
	QRPE_EVENT_TRANS_STATUS_T *status =
		(QRPE_EVENT_TRANS_STATUS_T *)qrpe_get_event_payload(g_tx_buff);

	memcpy(status->sta_mac, drv_status->sta_mac, ETH_ALEN);
	status->status_code = host_to_le16(drv_status->status_code);

	qrpe_build_event_head(g_tx_buff, QRPE_EVENT_BSS_TRANS_STATUS,
		QRPE_CODING_FIXED, QRPE_API_VER(2),
		sizeof(QRPE_EVENT_TRANS_STATUS_T), intf->ifmac);
	qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T) + sizeof(QRPE_EVENT_TRANS_STATUS_T));
}

static uint16_t qrpe_convert_intf_status(QRPE_INTF_T *intf)
{
	int intf_status = QRPE_INTF_GET_STATUS(intf);
	int cac = QRPE_INTF_GET_CAC_STATE(intf);
	uint16_t status;

	if (cac == QRPE_INTF_CAC_STATE_RUNNING) {
		status = INTF_STATUS_NONAVAILABLE;
	} else {
		if (intf_status == QRPE_INTF_STATUS_DELETED)
			status = INTF_STATUS_DELETED;
		else if (intf_status == QRPE_INTF_STATUS_UP)
			status = INTF_STATUS_UP;
		else if (intf_status == QRPE_INTF_STATUS_DOWN)
			status = INTF_STATUS_DOWN;
		else
			status = INTF_STATUS_INVALID;
	}
	return status;
}

static void qrpe_send_intf_status(QRPE_INTF_T *intf)
{
	QRPE_EVENT_INTF_STATUS_T *intf_status =
		(QRPE_EVENT_INTF_STATUS_T *)qrpe_get_event_payload(g_tx_buff);
	uint16_t status = qrpe_convert_intf_status(intf);
	strncpy(intf_status->ifname, intf->ifname, QRPE_IFNAMSIZ);
	intf_status->ifname_size = strlen(intf_status->ifname);
	intf_status->status = host_to_le16(status);

	qrpe_build_event_head(g_tx_buff, QRPE_EVENT_INTF_STATUS,
		QRPE_CODING_FIXED, QRPE_API_VER(1),
		sizeof(QRPE_EVENT_INTF_STATUS_T), intf->ifmac);
	qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T) + sizeof(QRPE_EVENT_INTF_STATUS_T));
}

static void qrpe_update_and_send_intf_status_for_radio(QRPE_INTF_T *intf, QRPE_DRV_INTF_STATUS_T *drv_status);
static void qrpe_update_and_send_intf_status(QRPE_INTF_T *intf, QRPE_DRV_INTF_STATUS_T *drv_status)
{
	if (drv_status->type == QRPE_INTF_STATUS_TYPE_CAC) {
		if (drv_status->all_bss) {
			drv_status->all_bss = 0;
			qrpe_update_and_send_intf_status_for_radio(intf, drv_status);
		} else {
			QRPE_INTF_SET_CAC_STATE(intf, drv_status->status);
			qrpe_send_intf_status(intf);
		}
	}
}

static int qrpe_checking_intf_on_same_radio(QRPE_INTF_T *intf1, QRPE_INTF_T *intf2)
{
	QRPE_DRV_INTF_INFO_T intf_info[2];
	int ret1, ret2;

	memset(intf_info, 0, sizeof(intf_info));
	if (intf1->ops != intf2->ops)
		return QRPE_FALSE;
	/* TODO: need extra info to check whether intfs are on same radio
	 * currenly assume there is only one radio for one driver */
	else { /*add check for both qtna chip in 2.4G+5G based platform*/
		ret1 = qrpe_driver_get_intf_info(intf1, QRPE_INTF_SUBCMD_INFO, &intf_info[0]);
		ret2 = qrpe_driver_get_intf_info(intf2, QRPE_INTF_SUBCMD_INFO, &intf_info[1]);

		if (ret1 < 0 || ret2 < 0) {
			QRPE_ERROR("get intf_info fail");
			return QRPE_FALSE;
		}
		if(intf_info[0].band != intf_info[1].band)
			return QRPE_FALSE;
		else
			return QRPE_TRUE;
	}
}

static void qrpe_update_and_send_intf_status_for_radio(QRPE_INTF_T *intf, QRPE_DRV_INTF_STATUS_T *drv_status)
{
	int i;
	drv_status->all_bss = 0;
	for (i = 0; i < g_ctx.intfs; i++) {
		if (QRPE_TRUE == qrpe_checking_intf_on_same_radio(intf, g_ctx.intf_ctx + i))
			qrpe_update_and_send_intf_status(g_ctx.intf_ctx + i, drv_status);
	}
}

static uint32_t qrpe_build_intf_info(uint8_t *start, QRPE_INTF_T *intf,
	QRPE_DRV_INTF_INFO_T *intf_info)
{
	uint8_t *pos = start;
	uint8_t value[8], drivercap = 0;
	int tlv_len;
	uint32_t extcap = 0;

	memcpy(value, intf->ifmac, ETH_ALEN);
	*(uint16_t *)&value[ETH_ALEN] = intf_info->mdid;
	pos += qrpe_encap_tlv(pos, TLVTYPE_BSSID_MDID, value, 8);

	/* aligned to 4 bytes including string ending */
	tlv_len = (strlen((char *)intf->ifname) + 4) & (~0x3);
	pos += qrpe_encap_tlv(pos, TLVTYPE_IFNAME, (uint8_t *)intf->ifname, tlv_len);

	if (intf_info->intf_type == QRPE_NODE_TYPE_VAP
		|| intf_info->intf_type == QRPE_NODE_TYPE_STA) {
		/* logical interface type */
		pos += qrpe_encap_tlv(pos, TLVTYPE_INTERFACE_TYPE, (uint8_t *)&intf_info->intf_type, 4);

		/* radio interface mac address */
		pos += qrpe_encap_tlv(pos, TLVTYPE_RADIO_MACADDR, intf->radio_uid, ETH_ALEN);

		/* 502 BSA APP dependent */
		value[0] = intf_info->channel;
		value[1] = intf_info->band;
		value[2] = intf_info->opclass;
		pos += qrpe_encap_tlv(pos, TLVTYPE_CHANNEL_BAND, value, 3);
		/* 5502 include the country code */
		value[1] = intf_info->opclass;
		memcpy(value + 2, intf_info->cc_alpha, 2);
		pos += qrpe_encap_tlv(pos, TLVTYPE_CHANNEL_BAND_CC, value, 4);

		drivercap |= intf_info->support_btm << QRPE_DRIVER_SUPPORT_BTM_SHIFT;
		drivercap |= intf_info->support_ht << QRPE_DRIVER_SUPPORT_HT_SHIFT;
		drivercap |= intf_info->support_vht << QRPE_DRIVER_SUPPORT_VHT_SHIFT;
		drivercap |= intf_info->support_monitor << QRPE_DRIVER_SUPPORT_MONITOR_SHIFT;
		drivercap |= intf_info->support_omonitor << QRPE_DRIVER_SUPPORT_OMONITOR_SHIFT;
		drivercap |= intf_info->support_erw << QRPE_DRIVER_SUPPORT_ERW_SHIFT;
		/* support QRPE_CMD_DISASSOC command */
		drivercap |= (1 << QRPE_DRIVER_SUPPORT_DISASSOC_SHIFT);
		drivercap |= intf_info->support_spdia << QRPE_DRIVER_SUPPORT_SPDIA_SHIFT;
		value[0] = drivercap;
		value[1] = intf_info->phytype;
		value[2] = intf_info->capinfo & 0xff;
		value[3] = intf_info->capinfo >> 8;
		pos += qrpe_encap_tlv(pos, TLVTYPE_INTERFACE_CAPABILITY, value, 4);

		pos += qrpe_encap_tlv(pos, TLVTYPE_HT_CAPABILITY, intf_info->htcap, HT_CAP_LEN);
		pos += qrpe_encap_tlv(pos, TLVTYPE_HT_OPERATION, intf_info->htop, HT_OP_LEN);
		if (intf_info->phytype == 9) { /* vht */
			pos += qrpe_encap_tlv(pos, TLVTYPE_VHT_CAPABILITY, intf_info->vhtcap, VHT_CAP_LEN);
			pos += qrpe_encap_tlv(pos, TLVTYPE_VHT_OPERATION, intf_info->vhtop, VHT_OP_LEN);
		}

		/* Report the extented driver capabilitise */
		extcap |= intf_info->support_set_cc3rd << QRPE_EXTCAP_SUPPORT_SET_CC3RD_SHIFT;
		extcap |= intf_info->support_pmf_mfpr << QRPE_EXTCAP_SUPPORT_PMF_MFPR_SHIFT;
		extcap |= intf_info->support_pmf_mfpc << QRPE_EXTCAP_SUPPORT_PMF_MFPC_SHIFT;
		extcap |= intf_info->support_backhaul_sta << QRPE_EXTCAP_SUPPORT_BACKHAUL_STA_SHIFT;
		pos += qrpe_encap_tlv_uint32(pos, TLVTYPE_EXT_INTF_CAPABILITY, extcap);

		/* List of frame IEs that the driver support to set */
		pos += qrpe_encap_tlv(pos, TLVTYPE_IE_EDIT_ALLOWED,
			intf_info->supp_elemid_mask, MAX_DRV_EID_MASK_LEN);

		/* List of frame extended capability that the driver support to set */
		pos += qrpe_encap_tlv(pos, TLVTYPE_EXTCAP_EDIT_ALLOWED,
			intf_info->supp_extcap, MAX_DRV_EXTCAP_LEN);

		/* List of tx/rx management frames that the driver can dispose by user space */
		pos += qrpe_encap_tlv(pos, TLVTYPE_REG_MGMT_FRAME_TX,
			intf_info->reg_tx_frame, intf_info->reg_tx_frm_len);
		pos += qrpe_encap_tlv(pos, TLVTYPE_REG_MGMT_FRAME_RX,
			intf_info->reg_rx_frame, intf_info->reg_rx_frm_len);

		/* HE capabilities and HE operation (element id + len + id_ext) */
		if (intf_info->hecap[0] == QRPE_IEEE80211_ELEMID_EXT
			&& intf_info->hecap[2] == QRPE_IEEE80211_ELEMID_EXT_HECAP) {
			tlv_len = intf_info->hecap[1] + 2;
			pos += qrpe_encap_tlv(pos, TLVTYPE_HE_CAPABILITY, intf_info->hecap, tlv_len);
		}
		if (intf_info->heop[0] == QRPE_IEEE80211_ELEMID_EXT
			&& intf_info->heop[2] == QRPE_IEEE80211_ELEMID_EXT_HEOP) {
			tlv_len = intf_info->heop[1] + 2;
			pos += qrpe_encap_tlv(pos, TLVTYPE_HE_OPERATION, intf_info->heop, tlv_len);
		}

		if (intf_info->support_spdia) {
			value[0] = intf_info->spdia_feature_support;
			value[1] = value[2] = value[3] = 0;
			pos += qrpe_encap_tlv(pos, TLVTYPE_SPDIA_SUPPORTED_FEATURES, value, 4);

			value[0] = intf_info->spdia_sta_support_count;
			pos += qrpe_encap_tlv(pos, TLVTYPE_SPDIA_CAPABILITIES, value, 4);
		}
	}
	if (intf_info->intf_type == QRPE_NODE_TYPE_VAP) {
		pos += qrpe_encap_tlv(pos, TLVTYPE_SSID, intf_info->ssid, intf_info->ssid_len);

		pos += qrpe_encap_tlv_uint16(pos, TLVTYPE_BEACON_INTERVAL, intf_info->bintval);
		pos += qrpe_encap_tlv(pos, TLVTYPE_ESPI_FIELD, (uint8_t *)intf_info->espi,
				sizeof(QRPE_DRV_ESPI_T) * QRPE_DRV_AC_MAXNUM);
		pos += qrpe_encap_tlv(pos, TLVTYPE_TXPOWER_BACKOFF,
				(uint8_t *)&intf_info->bcnpwr_backoff, 1);
	}
	if (intf_info->intf_type == QRPE_NODE_TYPE_NOTWIFI
		|| intf_info->intf_type == QRPE_NODE_TYPE_STA)
		pos += qrpe_encap_tlv(pos, TLVTYPE_PEER_MACADDR, intf_info->bssid, ETH_ALEN);

	return pos - start;
}

static uint32_t qrpe_build_intf_fat(uint8_t *start, QRPE_INTF_T *intf,
	QRPE_DRV_INTF_INFO_T *intf_info)
{
	uint8_t value[4];
	uint8_t *pos = start;

	value[0] = intf_info->channel;
	value[1] = intf_info->band;
	*(uint16_t *)&value[2] = intf_info->avg_fat;
	pos += qrpe_encap_tlv(pos, TLVTYPE_AVERAGE_FAT, value, 4);

	return pos - start;
}

static void qrpe_send_intf_info(QRPE_INTF_T *intf, int sub_cmd, QRPE_DRV_INTF_INFO_T *intf_info)
{
	uint8_t *payload = qrpe_get_event_payload(g_tx_buff);
	uint32_t len = 0;
	switch(sub_cmd) {
	case QRPE_INTF_SUBCMD_INFO:
		len = qrpe_build_intf_info(payload, intf, intf_info);
		break;

	case QRPE_INTF_SUBCMD_FAT:
		len = qrpe_build_intf_fat(payload, intf, intf_info);
		break;

	default:
		return;
	}

	qrpe_build_event_head(g_tx_buff, QRPE_EVENT_INTF_INFO,
		QRPE_CODING_TLV, QRPE_API_VER(3), len, intf->ifmac);
	qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T) + len);
}

static void qrpe_update_intf_radio_uid(QRPE_INTF_T *intf)
{
	QRPE_RADIO_T *radio = NULL;

	radio = qrpe_find_radio_by_ifname(intf->info.radio_name);
	if (radio)
		memcpy(intf->radio_uid, radio->uid, ETH_ALEN);
}

static void qrpe_report_intf_info(QRPE_INTF_T *intf, int sub_cmd)
{
	int ret = qrpe_driver_get_intf_info(intf, sub_cmd, &intf->info);
	if (ret < 0)
		return;

	qrpe_update_intf_radio_uid(intf);
	qrpe_send_intf_info(intf, sub_cmd, &intf->info);
}

struct opclass_chan_table {
	uint8_t global_index;
	uint8_t chan_set[QRPE_DRV_CHAN_MAXNUM_PER_OPCLASS];
};

/* global operating class table for channel set conversion */
static const struct opclass_chan_table gb_opclass_chan[] = {
	{81, {1,2,3,4,5,6,7,8,9,10,11,12,13,0}},
	{82, {14,0}},
	{83, {1,2,3,4,5,6,7,8,9,0}},
	{84, {5,6,7,8,9,10,11,12,13,0}},
	{94, {133,137,0}},
	{95, {132,134,136,138,0}},
	{96, {131,132,133,134,135,136,137,138,0}},
	{101, {21,25,0}},
	{102, {11,13,15,17,19,0}},
	{103, {1,2,3,4,5,6,7,8,9,10,0}},
	{104, {184,192,0}},
	{105, {188,196,0}},
	{106, {191,195,0}},
	{107, {189,191,193,195,197,0}},
	{108, {188,189,190,191,192,193,194,195,196,197,0}},
	{109, {184,188,192,196,0}},
	{110, {183,184,185,186,187,188,189,0}},
	{111, {182,183,184,185,186,187,188,189,0}},
	{112, {8,12,16,0}},
	{113, {7,8,9,10,11,0}},
	{114, {6,7,8,9,10,11,0}},
	{115, {36,40,44,48,0}},
	{116, {36,44,0}},
	{117, {40,48,0}},
	{118, {52,56,60,64,0}},
	{119, {52,60,0}},
	{120, {56,64,0}},
	{121, {100,104,108,112,116,120,124,128,132,136,140,144,0}},
	{122, {100,108,116,124,132,140,0}},
	{123, {104,112,120,128,136,144,0}},
	{124, {149,153,157,161,0}},
	{125, {149,153,157,161,165,169,0}},
	{126, {149,157,0}},
	{127, {153,161,0}},
	{128, {36,40,44,48,52,56,60,64,100,104,108,112,116,120,124,128,132,136,140,144,149,153,157,161,0}},
	{129, {36,40,44,48,52,56,60,64,100,104,108,112,116,120,124,128,132,136,140,144,149,153,157,161,0}},
	{130, {36,40,44,48,52,56,60,64,100,104,108,112,116,120,124,128,132,136,140,144,149,153,157,161,0}},
	{180, {1,2,3,4,5,6,0}},
};

static uint32_t qrpe_build_non_operable_chans(uint8_t *start,
	QRPE_DRV_CHAN_ENTRY_T *chans, uint8_t ch_num, uint8_t global_index)
{
	uint8_t *pos = start;
	int i, j, idx = -1, num = 0;
	uint8_t value[QRPE_DRV_CHAN_MAXNUM_PER_OPCLASS] = {0,};

	for (i = 0; i < ARRAY_SIZE(gb_opclass_chan); i++) {
		if (gb_opclass_chan[i].global_index == global_index)
			idx = i;
	}
	if (idx < 0) {
		QRPE_ERROR("can't find global opclass");
		goto __end;
	}

	for (i = 0; i < QRPE_DRV_CHAN_MAXNUM_PER_OPCLASS
		&& gb_opclass_chan[idx].chan_set[i]; i++) {
		for (j = 0; j < ch_num; j++) {
			if (gb_opclass_chan[idx].chan_set[i]
				== chans[j].chan)
				break;
		}
		if (j == ch_num)
			value[num++] = gb_opclass_chan[idx].chan_set[i];
	}

__end:
	pos += qrpe_encap_tlv(pos, TLVTYPE_OPCLASS_NON_OPERABLE_CHANS, value, num);

	return pos - start;
}

static uint32_t qrpe_build_radio_info(uint8_t *start, QRPE_RADIO_T *radio,
	QRPE_DRV_RADIO_INFO_T *radio_info)
{
	uint8_t *pos = start;
	uint8_t value[8];
	int i;
	int tlv_len;

	pos += qrpe_encap_tlv(pos, TLVTYPE_RADIO_MACADDR, radio->uid, ETH_ALEN);

	tlv_len = (strlen((char *)radio->ifname) + 4) & (~0x3);
	pos += qrpe_encap_tlv(pos, TLVTYPE_RADIO_IFNAME, (uint8_t *)radio->ifname, tlv_len);

	value[0] = radio_info->max_bsses;
	value[1] = radio_info->opclass_nums;
	pos += qrpe_encap_tlv(pos, TLVTYPE_RADIO_INFO, value, 2);

	/* opclass info */
	for (i = 0; i < radio_info->opclass_nums; i++) {
		value[0] = radio_info->opclass[i].global_opclass;
		value[1] = radio_info->opclass[i].bandwidth;
		value[2] = radio_info->opclass[i].max_power;
		pos += qrpe_encap_tlv(pos, TLVTYPE_OPCLASS_INFO_BW_EIRP, value, 3);

		pos += qrpe_build_non_operable_chans(pos, radio_info->opclass[i].chans,
			radio_info->opclass[i].chan_nums, radio_info->opclass[i].global_opclass);

		value[0] = 0;
		pos += qrpe_encap_tlv(pos, TLVTYPE_OPCLASS_CHANS_MIN_FREQ_SEPARA, value, 1);
	}

	return pos - start;
}

static void qrpe_send_radio_info(QRPE_RADIO_T *radio, QRPE_DRV_RADIO_INFO_T *radio_info)
{
	uint8_t *payload = qrpe_get_event_payload(g_tx_buff);
	uint32_t len = 0;

	len = qrpe_build_radio_info(payload, radio, radio_info);

	qrpe_build_event_head(g_tx_buff, QRPE_EVENT_RADIO_INFO,
		QRPE_CODING_TLV, QRPE_API_VER(8), len, radio->uid);
	qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T) + len);
}

static void qrpe_report_radio_info(QRPE_RADIO_T *radio)
{
	int ret = qrpe_driver_get_radio_info(radio, &radio->info);
	if (ret < 0)
		return;

	qrpe_send_radio_info(radio, &radio->info);
}

#define QRPE_SET_CHANS_PERE_REASION(value, pref, reason)	\
	    QRPE_SET_BITS(value, pref, QRPE_CHANS_PREF_MASK, QRPE_CHANS_PREF_SHIFT);	\
	    QRPE_SET_BITS(value, reason, QRPE_CHANS_REASON_MASK, QRPE_CHANS_REASON_SHIFT);
static uint32_t qrpe_build_radio_status(uint8_t *start, QRPE_RADIO_T *radio,
	QRPE_DRV_RADIO_INFO_T *radio_status, uint8_t include_ps)
{
	uint8_t *pos = start;
	uint8_t value[2 * QRPE_DRV_OPCLASS_MAXNUM] = {0,};
	uint8_t pref, reason_code;
	int i, j, chan_status;

	pos += qrpe_encap_tlv(pos, TLVTYPE_RADIO_MACADDR, radio->uid, ETH_ALEN);

	if (include_ps) {
		value[0] = radio->info.ps_status;
		pos += qrpe_encap_tlv(pos, TLVTYPE_RADIO_STATE, value, 4);
	}

	if (radio_status) {
		for (i = 0; i < radio_status->opclass_nums; i++) {
			value[0] = radio_status->opclass[i].global_opclass;
			pos += qrpe_encap_tlv(pos, TLVTYPE_OPCLASS_INFO, value, 1);

			for (j = 0; j < radio_status->opclass[i].chan_nums; j++) {
				value[2 * j] = radio_status->opclass[i].chans[j].chan;
				chan_status = radio_status->opclass[i].chans[j].status;
				if (chan_status == QRPE_DRV_CHAN_STATUS_NON_OPERABLE) {
					pref = QRPE_CHANS_PREF_MIN;
					reason_code = QRPE_CHANS_REASON_UNSPEC;
				} else if (chan_status == QRPE_DRV_CHAN_STATUS_RADAR_DETECTED) {
					pref = QRPE_CHANS_PREF_MIN;
					reason_code = QRPE_CHANS_REASON_DISALLOWED_RADAR;
				} else if (chan_status == QRPE_DRV_CHAN_STATUS_CAC_VALID) {
					pref = QRPE_CHANS_PREF_MAX;
					reason_code = QRPE_CHANS_REASON_DFS_AVAILABLE;
				} else if (chan_status == QRPE_DRV_CHAN_STATUS_CAC_REQUIRED) {
					pref = QRPE_CHANS_PREF_MIN;
					reason_code = QRPE_CHANS_REASON_DFS_STATE_UNKNOWN;
				} else {
					pref = QRPE_CHANS_PREF_MAX;
					reason_code = QRPE_CHANS_REASON_UNSPEC;
				}
				QRPE_SET_CHANS_PERE_REASION(value[2 * j + 1], pref, reason_code);
			}
			pos += qrpe_encap_tlv(pos, TLVTYPE_OPCLASS_CHANS_PREF_REASON, value, 2 * j);
		}
	}

	return pos - start;
}

static void qrpe_send_radio_status(QRPE_RADIO_T *radio,
	QRPE_DRV_RADIO_INFO_T *radio_status, uint8_t include_ps)
{
	uint8_t *payload = qrpe_get_event_payload(g_tx_buff);
	uint32_t len = 0;

	len = qrpe_build_radio_status(payload, radio, radio_status, include_ps);

	qrpe_build_event_head(g_tx_buff, QRPE_EVENT_RADIO_STATUS,
		QRPE_CODING_TLV, QRPE_API_VER(8), len, radio->uid);
	qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T) + len);
}

static void qrpe_update_and_send_radio_status_chan(QRPE_INTF_T *intf,
		QRPE_DRV_CHAN_ENTRY_T *chan_status, uint8_t is_manual)
{
	QRPE_RADIO_T *radio = NULL;
	QRPE_DRV_RADIO_INFO_T *info;
	int i, j, ret, cnt = 0, idx = 0;
	uint8_t status;
	uint8_t opclass_set[QRPE_DRV_OPCLASS_MAXNUM] = {0,};

	if (NULL == (radio = qrpe_find_radio_by_uid(intf->radio_uid)))
		return;

	info = &radio->info;
	for (i = 0; i < info->opclass_nums; i++) {
		for (j = 0; j < info->opclass[i].chan_nums; j++) {
			if (info->opclass[i].chans[j].chan == chan_status->chan
				&& info->opclass[i].chans[j].status != chan_status->status) {
				opclass_set[cnt++] = i;
				info->opclass[i].chans[j].status = chan_status->status;
				QRPE_DEBUG("radio status update: chan(%u) cnt(%d) opclass_idx(%d)",
					chan_status->chan, cnt, i);
			}
		}
	}

	for (i = 0; i < cnt && !is_manual; i++) {
		idx = opclass_set[i];
		for (j = 0; j < info->opclass[idx].chan_nums; j++) {
			ret = qrpe_driver_get_chan_status(intf,
				info->opclass[idx].chans[j].chan, &status);
			if (ret < 0)
				continue;

			if (info->opclass[idx].chans[j].status != status)
				info->opclass[idx].chans[j].status = status;
		}
	}
	if (cnt == 0)
		return;

	qrpe_send_radio_status(radio, info, 0);
}

static void qrpe_update_and_send_radio_status_pwrsave(QRPE_INTF_T *intf,
		QRPE_DRV_RADIO_PWRSAVE_STATUS_T *drv_status)
{
	QRPE_RADIO_T *radio = NULL;

	if (NULL == (radio = qrpe_find_radio_by_uid(intf->radio_uid)))
		return;

	if (radio->info.ps_status == drv_status->ps_state)
		return;

	QRPE_DEBUG("radio status update: pwrsave(%u)", drv_status->ps_state);
	radio->info.ps_status = drv_status->ps_state;

	qrpe_send_radio_status(radio, NULL, 1);
}

static int qrpe_update_intf_status(QRPE_INTF_T *intf)
{
	struct ifreq ifr;
	int interface_up_flags = IFF_UP | IFF_RUNNING;
	int result_flags, retval;

	if (g_ctx.ioctl_sock < 0)
		return -EINVAL;

	QRPE_DEBUG("QRPE get interface status for %s", intf->ifname);

	memset(&ifr, 0, sizeof(ifr));
	strncpy(ifr.ifr_name, intf->ifname, sizeof(ifr.ifr_name) - 1);
	retval = ioctl(g_ctx.ioctl_sock, SIOCGIFFLAGS, &ifr);
	if(retval < 0) {
		QRPE_ERROR("IOCTL failed for %s", ifr.ifr_name);
		return -EIO;
	}

	result_flags = ifr.ifr_flags & interface_up_flags;
	if(result_flags == interface_up_flags)
		QRPE_INTF_SET_STATUS(intf, QRPE_INTF_STATUS_UP);
	else if (result_flags == IFF_UP)
		QRPE_INTF_SET_STATUS(intf, QRPE_INTF_STATUS_UP);
	else
		QRPE_INTF_SET_STATUS(intf, QRPE_INTF_STATUS_DOWN);

	return 0;
}

static void qrpe_report_intf_status(QRPE_INTF_T *intf)
{
	int ret = qrpe_update_intf_status(intf);
	if (ret < 0)
		return;

	qrpe_send_intf_status(intf);
}

#define MAX_STAS_PER_EVENT	32
static void qrpe_send_sta_stats(QRPE_INTF_T *intf, QRPE_DRV_STA_STATS_T *stats)
{
	uint8_t *payload = qrpe_get_event_payload(g_tx_buff);
	uint8_t *pos = payload;
	uint8_t value[4];
	int i = 0;
	uint32_t len;

	for (i = 0; i < stats->num_sta; i++) {
		pos += qrpe_encap_tlv(pos, TLVTYPE_STA_MAC, stats->entries[i].sta, ETH_ALEN);
		pos += qrpe_encap_tlv_uint32(pos, TLVTYPE_RX_PHYRATE,
			stats->entries[i].assoc_stats.rx_phy_rate);
		memcpy(value, (uint16_t *)&stats->entries[i].assoc_stats.rx_phy_rate, 2);
		memcpy(value + 2, (uint16_t *)&stats->entries[i].assoc_stats.rx_bandwidth, 2);
		pos += qrpe_encap_tlv_uint32(pos, TLVTYPE_RX_PHYRATE_BW, *(uint32_t *)value);
		pos += qrpe_encap_tlv_uint64(pos, TLVTYPE_AGE_LAST_RX,
			stats->entries[i].assoc_stats.age_last_rx_pkt);
		pos += qrpe_encap_tlv_uint32(pos, TLVTYPE_TX_PHYRATE,
			stats->entries[i].assoc_stats.tx_phy_rate);
		memcpy(value, (uint16_t *)&stats->entries[i].assoc_stats.tx_phy_rate, 2);
		memcpy(value + 2, (uint16_t *)&stats->entries[i].assoc_stats.tx_bandwidth, 2);
		pos += qrpe_encap_tlv_uint32(pos, TLVTYPE_TX_PHYRATE_BW, *(uint32_t *)value);
		pos += qrpe_encap_tlv_uint64(pos, TLVTYPE_AGE_LAST_TX,
			stats->entries[i].assoc_stats.age_last_tx_pkt);
		pos += qrpe_encap_tlv_uint32(pos, TLVTYPE_RSSI,
			stats->entries[i].assoc_stats.rssi_dbm);
		pos += qrpe_encap_tlv_uint32(pos, TLVTYPE_STA_AIRTIME,
			stats->entries[i].assoc_stats.avg_airtime);
		pos += qrpe_encap_tlv_uint32(pos, TLVTYPE_PKTS,
			stats->entries[i].assoc_stats.pkts_per_sec);
		pos += qrpe_encap_tlv_uint32_sequence(pos, TLVTYPE_LINK_STATS,
			(uint32_t *)&stats->entries[i].assoc_stats.stats,
			sizeof(stats->entries[i].assoc_stats.stats) / sizeof(uint32_t));
		if (0 == (i + 1) % MAX_STAS_PER_EVENT) {
			len = pos - payload;
			qrpe_build_event_head(g_tx_buff, QRPE_EVENT_STA_PHY_STATS,
				QRPE_CODING_TLV, QRPE_API_VER(1), len, intf->ifmac);
			qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T) + len);

			payload = qrpe_get_event_payload(g_tx_buff);
			pos = payload;
		}
	}

	len = pos - payload;
	qrpe_build_event_head(g_tx_buff, QRPE_EVENT_STA_PHY_STATS,
		QRPE_CODING_TLV, QRPE_API_VER(1), len, intf->ifmac);
	qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T) + len);
}

static void qrpe_report_sta_stats(QRPE_INTF_T *intf, uint8_t *sta)
{
	int ret;
	QRPE_DRV_STA_STATS_T *stats = (QRPE_DRV_STA_STATS_T *)QRPE_CALLOC(1,
		sizeof(QRPE_DRV_STA_STATS_T));
	if (!stats)
		return;

	ret = qrpe_driver_get_sta_stats(intf, sta, stats);
	if (ret >= 0)
		qrpe_send_sta_stats(intf, stats);

	QRPE_FREE(stats);
}

static void qrpe_send_nonassoc_sta_stats(QRPE_INTF_T *intf, QRPE_DRV_STA_STATS_T *stats)
{
	uint8_t *payload = qrpe_get_event_payload(g_tx_buff);
	uint8_t *pos = payload;
	int i = 0;
	uint32_t len;
	uint8_t value[4];

	if (!stats->num_sta) {
		QRPE_DEBUG("Get 0 monitor sta stats");
		return;
	}

	for (i = 0; i < stats->num_sta; i++) {
		pos += qrpe_encap_tlv(pos, TLVTYPE_STA_MAC, stats->entries[i].sta, ETH_ALEN);
		pos += qrpe_encap_tlv_uint32(pos, TLVTYPE_RSSI,
			stats->entries[i].monitor_stats.rssi_dbm);

		value[0] = (int8_t)stats->entries[i].monitor_stats.rssi_dbm;
		value[1] = stats->entries[i].monitor_stats.frame_type;
		value[2] = stats->entries[i].monitor_stats.channel;
		value[3] = 0;
		pos += qrpe_encap_tlv(pos, TLVTYPE_RSSI_ADV, value, 4);

		pos += qrpe_encap_tlv_uint64(pos, TLVTYPE_AGE_LAST_RX,
			stats->entries[i].monitor_stats.age);

		if (0 == (i + 1) % MAX_STAS_PER_EVENT) {
			len = pos - payload;
			qrpe_build_event_head(g_tx_buff, QRPE_EVENT_STA_NONASSOC_STATS,
				QRPE_CODING_TLV, QRPE_API_VER(4), len, intf->ifmac);
			qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T) + len);

			payload = qrpe_get_event_payload(g_tx_buff);
			pos = payload;
		}
	}

	len = pos - payload;
	qrpe_build_event_head(g_tx_buff, QRPE_EVENT_STA_NONASSOC_STATS,
		QRPE_CODING_TLV, QRPE_API_VER(4), len, intf->ifmac);
	qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T) + len);
}

static void qrpe_report_nonassoc_sta_stats(QRPE_INTF_T *intf, uint8_t *sta)
{
	int ret;
	QRPE_DRV_STA_STATS_T *stats = (QRPE_DRV_STA_STATS_T *)QRPE_CALLOC(1,
		sizeof(QRPE_DRV_STA_STATS_T));
	if (!stats)
		return;
	ret = qrpe_driver_get_monitor_sta_stats(intf, sta, stats);

	if (ret >= 0)
		qrpe_send_nonassoc_sta_stats(intf, stats);

	QRPE_FREE(stats);
}

static void qrpe_send_frame(QRPE_INTF_T *intf, QRPE_DRV_FRAME_T *drv_frame)
{
        uint8_t *payload = qrpe_get_event_payload(g_tx_buff);
        uint8_t *pos = payload;
        uint8_t value[4];
        uint32_t len, need_space = qrpe_tlv_space(TLVTYPE_FRAME, drv_frame->frame_len);

        value[0] = drv_frame->rssi_dbm;
        value[1] = 0;
        value[2] = drv_frame->channel;
        value[3] = drv_frame->erw_result;
        pos += qrpe_encap_tlv(pos, TLVTYPE_RSSI_ADV, value, 4);

        if (!qrpe_check_tx_space(pos, need_space)) {
                QRPE_WARN("Drop frame: no enough space for frame(len: %u)", need_space);
                return;
        }
        pos += qrpe_encap_tlv(pos, TLVTYPE_FRAME,
                drv_frame->frame, drv_frame->frame_len);

        len = pos - payload;
        qrpe_build_event_head(g_tx_buff, QRPE_EVENT_FRAME,
                QRPE_CODING_TLV, QRPE_API_VER(6), len, intf->ifmac);
        qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T) + len);
}

static uint32_t qrpe_build_roam_fail(uint8_t *start, QRPE_INTF_T *intf,
	QRPE_DRV_ROAM_STATUS_T *roam_status)
{
	uint8_t *pos = start;
	uint8_t value[4] = {0,};

	pos += qrpe_encap_tlv(pos, TLVTYPE_PEER_MACADDR, roam_status->target, ETH_ALEN);

	value[0] = roam_status->channel;
	value[2] = roam_status->opclass;
	pos += qrpe_encap_tlv(pos, TLVTYPE_CHANNEL_BAND, value, 3);

	pos += qrpe_encap_tlv(pos, TLVTYPE_ROAM_FAIL, &roam_status->reason, 1);

	return pos - start;
}

static void qrpe_send_roam_fail(QRPE_INTF_T *intf, QRPE_DRV_ROAM_STATUS_T *drv_roam)
{
	uint8_t *payload = qrpe_get_event_payload(g_tx_buff);
	uint32_t len = 0;

	len = qrpe_build_roam_fail(payload, intf, drv_roam);

	qrpe_build_event_head(g_tx_buff, QRPE_EVENT_ROAM_FAIL,
		QRPE_CODING_TLV, QRPE_API_VER(8), len, intf->ifmac);
	qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T) + len);
}

static void qrpe_send_assoc_additional_info(QRPE_INTF_T *intf, QRPE_DRV_ASSOC_ADDITIONAL_INFO *info)
{
	uint8_t *payload = qrpe_get_event_payload(g_tx_buff);
	uint8_t *pos = payload;
	uint16_t len = 0;

	pos += qrpe_encap_tlv(pos, TLVTYPE_STA_MAC, info->sta_mac, ETH_ALEN);
	pos += qrpe_encap_tlv(pos, TLVTYPE_PSK_KEYID, info->keyid, info->len_keyid);
	len = pos - payload;

	qrpe_build_event_head(g_tx_buff, QRPE_EVENT_ASSOC_ADDITIONAL_INFO,
			QRPE_CODING_TLV, QRPE_API_VER(9), len, intf->ifmac);
	qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T) + len);
}

#ifdef CONFIG_SUPPORT_QTNA_SPDIA
static void qrpe_send_spdia_info(QRPE_INTF_T *intf, QRPE_DRV_SPDIA_INFO_T *spdia)
{
	uint8_t *payload = qrpe_get_event_payload(g_tx_buff);
	uint8_t *pos = payload;
	uint8_t value[4];
	uint32_t len;

	pos += qrpe_encap_tlv(pos, TLVTYPE_STA_MAC, spdia->peer_mac, ETH_ALEN);
	pos += qrpe_encap_tlv_uint32_sequence(pos,
		TLVTYPE_RSSI_VECTOR, (uint32_t *)spdia->rssis, spdia->chains);
	pos += qrpe_encap_tlv_uint32(pos, TLVTYPE_NOISE, spdia->hw_noise);
	pos += qrpe_encap_tlv_uint64(pos, TLVTYPE_TS_LAST_RX, spdia->timestamp);

	value[0] = spdia->nc;
	value[1] = spdia->nr;
	value[2] = spdia->ng;
	value[3] = 0;
	pos += qrpe_encap_tlv(pos, TLVTYPE_SPDIA_CONF, value, 4);
	pos += qrpe_encap_tlv_uint32(pos, TLVTYPE_SPDIA_TONES, spdia->ntones);

	value[0] = spdia->chan;
	QRPE_SET_BITS(value[1], spdia->bf_mode, QRPE_SPDIA_MODE_MASK, QRPE_SPDIA_MODE_SHIFT);
	QRPE_SET_BITS(value[1], spdia->bw, QRPE_SPDIA_BW_MASK, QRPE_SPDIA_BW_SHIFT);
	value[2] = spdia->mcs;
	value[3] = spdia->mcs_ss;
	pos += qrpe_encap_tlv(pos, TLVTYPE_SPDIA_DETAILS, value, 4);

	if (spdia->payload) {
		if (pos - g_tx_buff + sizeof(TLV_T)
			+ QRPE_IE_LEN(spdia->payload_len) > QRPE_MAX_MSG_LEN) {
			QRPE_ERROR("Drop SPDIA payload: len(%u) is too large", spdia->payload_len);
			return;
		}
		pos += qrpe_encap_tlv(pos, TLVTYPE_SPDIA_PAYLOAD,
			spdia->payload, spdia->payload_len);
	}

	len = pos - payload;
	qrpe_build_event_head(g_tx_buff, QRPE_EVENT_SPDIA_INFO,
		QRPE_CODING_TLV, QRPE_API_VER(7), len, intf->ifmac);
	qrpe_send_event(g_tx_buff, sizeof(QRPE_EVENT_T) + len);
}
#endif

void qrpe_report_event_from_driver(uint8_t *mac, uint32_t id, void *event)
{
	QRPE_INTF_T *intf = NULL;
	if (!mac)
		return;
	if (NULL == (intf = qrpe_find_intf_by_ifmac(mac)))
		return;

	QRPE_INFO("Recv driver event [%s:%u]", qrpe_event_to_name(id), id);
	switch(id) {
	case QRPE_DRV_EVENT_INTF_STATUS:
		qrpe_update_and_send_intf_status(intf, (QRPE_DRV_INTF_STATUS_T *)event);
		break;

	case QRPE_DRV_EVENT_CHAN_STATE_CAC:
		qrpe_update_and_send_radio_status_chan(intf, (QRPE_DRV_CHAN_ENTRY_T *)event, 0);
		break;

	case QRPE_DRV_EVENT_CHAN_STATE_UPDATE:
		qrpe_update_and_send_radio_status_chan(intf, (QRPE_DRV_CHAN_ENTRY_T *)event, 1);
		break;

	case QRPE_DRV_EVENT_RADIO_PWRSAVE:
		qrpe_update_and_send_radio_status_pwrsave(intf, (QRPE_DRV_RADIO_PWRSAVE_STATUS_T *)event);
		break;

	case QRPE_DRV_EVENT_PROBE_REQ:
	case QRPE_DRV_EVENT_ASSOC_REQ:
		qrpe_send_probe_req_or_assoc(id, intf, (QRPE_DRV_PROBE_REQ_T *)event);
		break;

	case QRPE_DRV_EVENT_AUTH:
		qrpe_send_auth(intf, (QRPE_DRV_AUTH_T *)event);
		break;

	case QRPE_DRV_EVENT_CONNECT_COMPL:
		qrpe_send_connect_complete(intf, (QRPE_DRV_CONNECT_T *)event);
		break;

	case QRPE_DRV_EVENT_DEAUTH:
	case QRPE_DRV_EVENT_DISASSOC:
		qrpe_send_disassoc(intf, (QRPE_DRV_DISASSOC_T *)event);
		break;

	case QRPE_DRV_EVENT_BSS_TRANS_STATUS:
		qrpe_send_trans_status(intf, (QRPE_DRV_TRANS_STATUS_T *)event);
		break;

	case QRPE_DRV_EVENT_STA_PHY_STATS:
		qrpe_send_sta_stats(intf, (QRPE_DRV_STA_STATS_T *)event);
		break;

#ifdef CONFIG_SUPPORT_QTNA_SPDIA
	case QRPE_DRV_EVENT_SPDIA_INFO:
		qrpe_send_spdia_info(intf, (QRPE_DRV_SPDIA_INFO_T *)event);
		break;
#endif

	case QRPE_DRV_EVENT_INTF_UPDATE_NOTIFY:
		qrpe_report_intf_info(intf, QRPE_INTF_SUBCMD_INFO);
		break;

	case QRPE_DRV_EVENT_FRAME:
		qrpe_send_frame(intf, (QRPE_DRV_FRAME_T *)event);
		break;

	case QRPE_DRV_EVENT_ROAM_FAIL:
		qrpe_send_roam_fail(intf, (QRPE_DRV_ROAM_STATUS_T *)event);
		break;

	case QRPE_DRV_EVENT_ASSOC_ADDITIONAL_INFO:
		qrpe_send_assoc_additional_info(intf, (QRPE_DRV_ASSOC_ADDITIONAL_INFO *)event);
		break;

	default:
		break;
	}
}

static void qrpe_update_radio_mask_by_intf(QRPE_INTF_T *intf, int intf_idx)
{
	QRPE_RADIO_T *radio = NULL;

	/* find radio context, update radio intf_mask */
	radio = qrpe_find_radio_by_uid(intf->radio_uid);
	if (radio)
		radio->intf_mask |= (1 << intf_idx);
}

static void qrpe_process_command_init(QRPE_COMMAND_T *cmd, unsigned int len)
{
	int i;
	QRPE_INTF_T *intf;
	QRPE_RADIO_T *radio;

	g_ctx.inited = 1;
	for (i = 0; i < g_ctx.radios; i++) {
		radio = &g_ctx.radio_ctx[i];
		qrpe_report_radio_info(radio);
		qrpe_send_radio_status(radio, &radio->info, 1);
	}
	for (i = 0; i < g_ctx.intfs; i++) {
		intf = &g_ctx.intf_ctx[i];
		qrpe_driver_set_status(intf, QRPE_INTF_ENABLE);
		qrpe_report_intf_info(intf, QRPE_INTF_SUBCMD_INFO);
		qrpe_report_intf_status(intf);
		qrpe_update_radio_mask_by_intf(intf, i);
		qrpe_driver_report_associated_stas(intf);
	}
#ifdef CONFIG_SUPPORT_QTNA_BACKBONE
	for (i = 0; i < g_ctx.wds_intfs; i++) {
		intf = &g_ctx.wds_intf_ctx[i];
		qrpe_update_intf_status(intf);
		qrpe_qtna_wds_intf_status_changed(intf);
	}
#endif
}

static void qrpe_process_command_deinit(QRPE_COMMAND_T *cmd, unsigned int len)
{
	int i;

	g_ctx.inited = 0;
	for (i = 0; i < g_ctx.intfs; i++) {
		QRPE_INTF_T *intf = &g_ctx.intf_ctx[i];
		qrpe_driver_set_status(intf, QRPE_INTF_DISABLE);
	}
}

static void qrpe_process_command_get_intf_status(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf = qrpe_find_intf_by_ifmac(cmd->mac);
	if (intf)
		qrpe_report_intf_status(intf);
}

static void qrpe_process_command_get_intf_info(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf;
	QRPE_COMMAND_INTF_INFO_T *intf_info =
		(QRPE_COMMAND_INTF_INFO_T *)qrpe_get_command_payload(cmd);
	uint32_t need_len = sizeof(QRPE_COMMAND_INTF_INFO_T);
	int sub_cmd = QRPE_INTF_SUBCMD_INFO;
	if (cmd->api_ver < QRPE_API_VER(2))
		need_len -= sizeof(uint32_t);

	if (len < need_len + sizeof(QRPE_COMMAND_T))
		return;

	intf = qrpe_find_intf_by_ifmac(cmd->mac);
	if (intf) {
		if (cmd->api_ver >= QRPE_API_VER(2))
			sub_cmd = le_to_host32(intf_info->cmd_spec);
		qrpe_report_intf_info(intf, sub_cmd);
	}
}

static void qrpe_process_command_deauth(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf;
	QRPE_COMMAND_DEAUTH_T *deauth =
		(QRPE_COMMAND_DEAUTH_T *)qrpe_get_command_payload(cmd);

	if (len < sizeof(QRPE_COMMAND_DEAUTH_T) + sizeof(QRPE_COMMAND_T))
		return;

	intf = qrpe_find_intf_by_ifmac(cmd->mac);
	if (intf)
		qrpe_driver_deauth_sta(intf, deauth->sta_mac, le_to_host16(deauth->reason));
}

static void qrpe_process_command_disassoc(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf = qrpe_find_intf_by_ifmac(cmd->mac);
	QRPE_COMMAND_DISASSOC_T *disassoc =
		(QRPE_COMMAND_DISASSOC_T *)qrpe_get_command_payload(cmd);

	if (!intf || (len < sizeof(QRPE_COMMAND_DISASSOC_T) + sizeof(QRPE_COMMAND_T)))
		return;

	qrpe_driver_disassoc_sta(intf, disassoc->sta_mac, le_to_host16(disassoc->reason));
}

static void qrpe_process_filter_subcmd_mac_filter(QRPE_INTF_T *intf, uint8_t *frm, uint16_t len)
{
	QRPE_COMMAND_STA_FILTER_T *filter = (QRPE_COMMAND_STA_FILTER_T *)frm;
	uint8_t accept = 0;
	uint16_t action;

	if (len < sizeof(QRPE_COMMAND_STA_FILTER_T))
		return;

	action = le_to_host16(filter->action);
	if (action == QRPE_FILTER_DENY)
		accept = 0;
	else if (action == QRPE_FILTER_ALLOW)
		accept = 1;
	else
		return;

	qrpe_driver_filter_sta(intf, filter->sta_mac, accept);
}

typedef struct {
	uint8_t *mac;
	uint8_t *mask;
	uint8_t *rssi;
	uint8_t *reject_mode;
	uint8_t *reject_payload;
} ERW_PARSE_T;
static int qrpe_check_erw_block(uint16_t type)
{
	if (TLVTYPE_STA_MAC == type)
		return 1;
	return 0;
}

static void qrpe_parse_erw_block(void **ies, uint8_t *frm, uint16_t type, uint16_t len)
{
	static ERW_PARSE_T erw;
	*ies = (void *)&erw;

	if (qrpe_check_erw_block(type))
		memset(&erw, 0, sizeof(erw));

	switch (type) {
	case TLVTYPE_STA_MAC:
		erw.mac = frm;
		break;
	case TLVTYPE_BL_MASK:
		erw.mask = frm;
		break;
	case TLVTYPE_RSSI:
		erw.rssi = frm;
		break;
	case TLVTYPE_STATUS_CODE:
		erw.reject_mode = frm;
		break;
	/* NR index and NR IE will be parsed in qrpe_process_erw_block */
	case TLVTYPE_NRIE_INDEX:
		if (!erw.reject_payload)
			erw.reject_payload = frm;
		break;
	default:
		break;
	}
}

typedef struct {
	uint8_t *nr_id;
	uint8_t *nr_ie;
} ERW_NR_PARSE_T;
static int qrpe_check_erw_nrie_block(uint16_t type)
{
	if (TLVTYPE_NRIE_INDEX == type)
		return 1;
	return 0;
}

static void qrpe_parse_erw_nrie_block(void **ies, uint8_t *frm, uint16_t type, uint16_t len)
{
	static ERW_NR_PARSE_T erw_nr;
	*ies = (void *)&erw_nr;

	if (qrpe_check_erw_nrie_block(type))
		memset(&erw_nr, 0, sizeof(erw_nr));

	switch (type) {
	case TLVTYPE_NRIE_INDEX:
		erw_nr.nr_id = frm;
		break;
	case TLVTYPE_NRIE:
		erw_nr.nr_ie = frm;
		break;
	default:
		break;
	}
}

typedef struct {
	QRPE_INTF_T *intf;
	uint32_t *mask;
	uint8_t set_nr;
} QRPE_ERW_NRIE_CTX_T;

static QRPE_DRV_ERW_NRIE_T g_drv_erw_nrie;
static void qrpe_process_erw_nrie_block(void *ctx, void *ies, uint8_t *eblock, int more)
{
	static int ind = 0;
	ERW_NR_PARSE_T *erw_nr_ies = (ERW_NR_PARSE_T *)ies;
	QRPE_ERW_NRIE_CTX_T *nrie_ctx = (QRPE_ERW_NRIE_CTX_T *)ctx;
	uint16_t nr_id;

	if (!erw_nr_ies->nr_id)
		return;

	nr_id = le_to_host16(*(uint16_t *)QRPE_IE_GET_VALUE(erw_nr_ies->nr_id));
	if (nr_id >= MAX_DRV_NR_ENTRY) {
		QRPE_WARN("Skip the neigh report: index(%u) >= %u", nr_id, MAX_DRV_NR_ENTRY);
		return;
	}
	*(nrie_ctx->mask + nr_id / QRPE_UINT32_BITS) |= (1 << (nr_id % QRPE_UINT32_BITS));

	if (!nrie_ctx->set_nr)
		return;

	if (erw_nr_ies->nr_ie) {
		uint16_t len = QRPE_IE_GET_LEN(erw_nr_ies->nr_ie);
		if (len < QRPE_NRIE_MIN_LEN - 2
			|| len > QRPE_NRIE_MAX_LEN - 2) {
			QRPE_WARN("Skip the neigh report: payload len(%u) is not in range(%u - %u) for index(%u) ",
				len, QRPE_NRIE_MIN_LEN, QRPE_NRIE_MAX_LEN, nr_id);
			return;
		}

		memset(g_drv_erw_nrie.entries + ind, 0, sizeof(QRPE_DRV_ERW_NRIE_ENTRY_T));
		g_drv_erw_nrie.entries[ind].index = nr_id;
		memcpy(g_drv_erw_nrie.entries[ind].nrie + 2, QRPE_IE_GET_VALUE(erw_nr_ies->nr_ie), len);
		g_drv_erw_nrie.entries[ind].len = len + 2;
		g_drv_erw_nrie.entries[ind].nrie[0] = QRPE_NRIE_EID;
		g_drv_erw_nrie.entries[ind].nrie[1] = len;

		ind++;
	}

	if (!more && ind > 0) {
		g_drv_erw_nrie.num = ind;
		qrpe_driver_set_erw(nrie_ctx->intf, QRPE_DRV_ERW_OP_UPDATE_NRIE_ENTRIES, &g_drv_erw_nrie);
		ind = 0;
	}
}

static void qrpe_erw_set_nrie_and_get_mask(QRPE_INTF_T *intf, uint8_t *frm, uint8_t *efrm, uint32_t *mask)
{
	QRPE_ERW_NRIE_CTX_T ctx;

	if (efrm < frm)
		return;

	ctx.intf = intf;
	ctx.mask = mask;
	ctx.set_nr = 1;
	qrpe_parse_tlv(&ctx, frm, efrm - frm, NULL, qrpe_check_erw_nrie_block,
		qrpe_parse_erw_nrie_block, qrpe_process_erw_nrie_block);
}

static QRPE_DRV_ERW_T g_drv_erw;
static void qrpe_process_erw_block_for_erw_entry(QRPE_INTF_T *intf, void *ies, uint8_t *eblock, int more)
{
	static int ind = 0;
	uint8_t remove_all = 0;
	ERW_PARSE_T *erw_ies = (ERW_PARSE_T *)ies;

	if (ind >= MAX_DRV_STA_ENTRY) {
		g_drv_erw.num_sta = ind;
		qrpe_driver_set_erw(intf, QRPE_DRV_ERW_OP_SET_ENTRIES, &g_drv_erw);
		ind = 0;
	}

	memset(g_drv_erw.entries + ind, 0, sizeof(QRPE_DRV_ERW_ENTRY_T));
	if (erw_ies->mac && erw_ies->mask) {
		uint8_t mask_byte1 = *(QRPE_IE_GET_VALUE(erw_ies->mask));
		uint8_t mask_byte2 = *(QRPE_IE_GET_VALUE(erw_ies->mask) + 1);

		memcpy(g_drv_erw.entries[ind].sta, QRPE_IE_GET_VALUE(erw_ies->mac), ETH_ALEN);
		if (QRPE_GET_BITS(mask_byte1, QRPE_ERW_OP_MASK, QRPE_ERW_OP_SHIFT)) {
			g_drv_erw.entries[ind].erw_op = QRPE_DRV_ERW_OP_ADD;

			if (QRPE_GET_BITS(mask_byte1, QRPE_ERW_MINRSSI_MASK, QRPE_ERW_MINRSSI_SHIFT))
				g_drv_erw.entries[ind].erw_mode = QRPE_DRV_ERW_MODE_MIN;
			else if (QRPE_GET_BITS(mask_byte1, QRPE_ERW_MAXRSSI_MASK, QRPE_ERW_MAXRSSI_SHIFT))
				g_drv_erw.entries[ind].erw_mode = QRPE_DRV_ERW_MODE_MAX;
			else
				g_drv_erw.entries[ind].erw_mode = QRPE_DRV_ERW_MODE_NONE;

			if (!QRPE_GET_BITS(mask_byte2, QRPE_ERW_PROBE_RESP_MASK, QRPE_ERW_PROBE_RESP_SHIFT))
				g_drv_erw.entries[ind].erw_probe_resp = 1;
			if (!QRPE_GET_BITS(mask_byte2, QRPE_ERW_ASSOC_RESP_MASK, QRPE_ERW_ASSOC_RESP_SHIFT))
				g_drv_erw.entries[ind].erw_assoc_resp = 1;
			if (!QRPE_GET_BITS(mask_byte2, QRPE_ERW_AUTH_RESP_MASK, QRPE_ERW_AUTH_RESP_SHIFT))
				g_drv_erw.entries[ind].erw_auth_resp = 1;

			if (g_drv_erw.entries[ind].erw_mode != QRPE_DRV_ERW_MODE_NONE
				&& erw_ies->rssi)
				g_drv_erw.entries[ind].rssi
					= le_to_host32(*(uint32_t *)(QRPE_IE_GET_VALUE(erw_ies->rssi)));
			if (erw_ies->reject_mode)
				g_drv_erw.entries[ind].reject_mode
					= le_to_host16(*(uint16_t *)(QRPE_IE_GET_VALUE(erw_ies->reject_mode)));
			if (g_drv_erw.entries[ind].reject_mode == QRPE_ERW_REJECT_WITH_NR
				&& erw_ies->reject_payload)
				qrpe_erw_set_nrie_and_get_mask(intf,
					erw_ies->reject_payload, eblock, g_drv_erw.entries[ind].reject_nrie_mask);
		} else {
			g_drv_erw.entries[ind].erw_op = QRPE_DRV_ERW_OP_DEL;
			if (IS_NULL_ADDR(g_drv_erw.entries[ind].sta)) {
				remove_all = 1;

				goto __end;
			}
		}

		ind++;
	}

__end:
	memset(erw_ies, 0, sizeof(ERW_PARSE_T));

	if (!more || remove_all) {
		if (ind > 0) {
			g_drv_erw.num_sta = ind;
			qrpe_driver_set_erw(intf, QRPE_DRV_ERW_OP_SET_ENTRIES, &g_drv_erw);
		}
		if (remove_all)
			qrpe_driver_set_erw(intf, QRPE_DRV_ERW_OP_REMOVE_ALL, NULL);
		ind = 0;
	}
}

static void qrpe_process_erw_block_for_clr_nr(QRPE_INTF_T *intf, ERW_PARSE_T *ies, uint8_t *eblock, int more)
{
	QRPE_DRV_ERW_NRIE_MASK_T mask;
	QRPE_ERW_NRIE_CTX_T ctx;

	if (!ies->reject_payload
		|| eblock < ies->reject_payload)
		return;

	memset(&mask, 0, sizeof(mask));
	ctx.intf = intf;
	ctx.mask = mask;
	ctx.set_nr = 0;
	qrpe_parse_tlv(&ctx, ies->reject_payload, eblock - ies->reject_payload,
		NULL, qrpe_check_erw_nrie_block,
		qrpe_parse_erw_nrie_block, qrpe_process_erw_nrie_block);

	qrpe_driver_set_erw(intf, QRPE_DRV_ERW_OP_DELETE_NRIE_ENTRIES, &mask);
}

static void qrpe_process_erw_block(void *ctx, void *ies, uint8_t *eblock, int more)
{
	QRPE_INTF_T *intf = (QRPE_INTF_T *)ctx;
	ERW_PARSE_T *erw_ies = (ERW_PARSE_T *)ies;
	uint8_t mask_byte1;

	if (!erw_ies->mask)
		return;

	mask_byte1 = *(QRPE_IE_GET_VALUE(erw_ies->mask));
	if (QRPE_GET_BITS(mask_byte1, QRPE_ERW_NR_CLR_MASK, QRPE_ERW_NR_CLR_SHIFT))
		qrpe_process_erw_block_for_clr_nr(intf, erw_ies, eblock, more);
	else
		qrpe_process_erw_block_for_erw_entry(intf, erw_ies, eblock, more);
}

static void qrpe_process_filter_subcmd_erw(QRPE_INTF_T *intf, uint8_t *frm, uint16_t len)
{
	qrpe_parse_tlv(intf, frm, len, NULL, qrpe_check_erw_block,
		qrpe_parse_erw_block, qrpe_process_erw_block);
}

static void qrpe_process_command_sta_mac_filter(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf = qrpe_find_intf_by_ifmac(cmd->mac);
	uint8_t *frm = qrpe_get_command_payload(cmd);

	if (!intf || len < sizeof(QRPE_COMMAND_T) + le_to_host16(cmd->payload_len))
		return;

	len = len - sizeof(QRPE_COMMAND_T);
	if (cmd->api_ver < QRPE_API_VER(5))
		qrpe_process_filter_subcmd_mac_filter(intf, frm, len);
	else
		qrpe_process_filter_subcmd_erw(intf, frm, len);
}

#ifdef CONFIG_SUPPORT_QTNA_BACKBONE
static void qrpe_get_sta_stats_for_qhop(void)
{
	uint8_t bcast_addr[ETH_ALEN] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
	int i;
	for (i = 0; i < g_ctx.wds_intfs; i++) {
		if (QRPE_INTF_GET_STATUS(&g_ctx.wds_intf_ctx[i]) == QRPE_INTF_STATUS_UP)
			qrpe_report_sta_stats(&g_ctx.wds_intf_ctx[i], bcast_addr);
	}
}
#endif

static void qrpe_process_command_get_sta_stats(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf;
	uint8_t *sta = qrpe_get_command_payload(cmd);

	if (len < ETH_ALEN + sizeof(QRPE_COMMAND_T))
		return;

	intf = qrpe_find_intf_by_ifmac(cmd->mac);
	if (intf)
		qrpe_report_sta_stats(intf, sta);

#ifdef CONFIG_SUPPORT_QTNA_BACKBONE
	if (qrpe_qtna_check_first_intf(intf) >= 0)
		qrpe_get_sta_stats_for_qhop();
#endif
}

static void qrpe_process_command_trans_req(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf;
	QRPE_COMMAND_TRANS_REQ_T *trans_req =
		(QRPE_COMMAND_TRANS_REQ_T *)qrpe_get_command_payload(cmd);
	QRPE_DRV_BTM_REQ_T *drv_btm_req;
	if (len < sizeof(QRPE_COMMAND_TRANS_REQ_T) + sizeof(QRPE_COMMAND_T) + trans_req->subel_len)
		return;

	intf = qrpe_find_intf_by_ifmac(cmd->mac);
	if (intf) {
		drv_btm_req = QRPE_CALLOC(1, (sizeof(QRPE_DRV_BTM_REQ_T) + trans_req->subel_len));
		if (!drv_btm_req)
			return;

		memcpy(drv_btm_req->sta_mac, trans_req->sta_mac, ETH_ALEN);
		drv_btm_req->disassoc_timer = le_to_host16(trans_req->timer);
		drv_btm_req->req_mode = trans_req->mode;
		drv_btm_req->val_intvl = trans_req->validity;
		memcpy(drv_btm_req->bssid, trans_req->bssid, ETH_ALEN);
		drv_btm_req->bssid_info = le_to_host32(trans_req->bssid_info);
		drv_btm_req->opclass = trans_req->opclass;
		drv_btm_req->channel = trans_req->channel;
		drv_btm_req->phytype = trans_req->phytype;
		drv_btm_req->subel_len = trans_req->subel_len;
		memcpy(drv_btm_req->subels, trans_req->subels, trans_req->subel_len);

		qrpe_driver_send_btm_req(intf, drv_btm_req);

		QRPE_FREE(drv_btm_req);
	}
}

static void qrpe_process_command_fat_monitor_start(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf;
	QRPE_COMMAND_FAT_MONITOR_START_T *fat_monitor =
		(QRPE_COMMAND_FAT_MONITOR_START_T *)qrpe_get_command_payload(cmd);

	if (len < sizeof(QRPE_COMMAND_FAT_MONITOR_START_T) + sizeof(QRPE_COMMAND_T))
		return;

	intf = qrpe_find_intf_by_ifmac(cmd->mac);
	if (intf)
		qrpe_driver_start_fat_monitor(intf, le_to_host32(fat_monitor->period));
}

static void qrpe_process_command_monitor_start(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf;
	QRPE_COMMAND_MONITOR_START_T *monitor =
		(QRPE_COMMAND_MONITOR_START_T *)qrpe_get_command_payload(cmd);
	uint8_t mask = 0;

	if (len < sizeof(QRPE_COMMAND_MONITOR_START_T) + sizeof(QRPE_COMMAND_T))
		return;

	intf = qrpe_find_intf_by_ifmac(cmd->mac);
	if (intf) {
		mask |= (intf->info.support_monitor ? QRPE_DRV_MONITOR_MASK : 0);
		mask |= (intf->info.support_omonitor ? QRPE_DRV_OMONITOR_MASK : 0);
		qrpe_driver_start_monitor(intf, le_to_host16(monitor->period),
			le_to_host16(monitor->duty_cycle), mask);
	}
}

static void qrpe_process_command_monitor_stop(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf;
	uint8_t mask = 0;

	intf = qrpe_find_intf_by_ifmac(cmd->mac);
	if (intf) {
		mask |= (intf->info.support_monitor ? QRPE_DRV_MONITOR_MASK : 0);
		mask |= (intf->info.support_omonitor ? QRPE_DRV_OMONITOR_MASK : 0);
		qrpe_driver_stop_monitor(intf, mask);
	}
}

static void qrpe_process_command_get_nonassoc_sta_stats(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf;
	uint8_t *sta = qrpe_get_command_payload(cmd);

	if (len < ETH_ALEN + sizeof(QRPE_COMMAND_T))
		return;

	intf = qrpe_find_intf_by_ifmac(cmd->mac);
	if (intf)
		qrpe_report_nonassoc_sta_stats(intf, sta);
}

typedef struct {
	uint8_t *frm_ch;
	uint8_t *frm;
} FRAME_PARSE_T;
static FRAME_PARSE_T g_frm_parse;

static void qrpe_init_frame_block(void)
{
	memset(&g_frm_parse, 0, sizeof(g_frm_parse));
}

static void qrpe_parse_frame_block(void **ies,
	uint8_t *frm, uint16_t type, uint16_t len)
{
	*ies = (void *)&g_frm_parse;

	switch (type) {
	case TLVTYPE_CHANNEL_BAND:
		g_frm_parse.frm_ch = frm;
		break;
	case TLVTYPE_FRAME:
		g_frm_parse.frm = frm;
		break;
	default:
		break;
	}
}

static void qrpe_process_frame_block(void *ctx,
	void *ies, uint8_t *eblock, int more)
{
	QRPE_INTF_T *intf = (QRPE_INTF_T *)ctx;
	FRAME_PARSE_T *frm_ies = (FRAME_PARSE_T *)ies;
	uint8_t chan = 0;
	uint16_t len;

	if (frm_ies->frm_ch
		&& QRPE_IE_GET_LEN(frm_ies->frm_ch) >= 1)
		chan = QRPE_IE_GET_UINT8(frm_ies->frm_ch, 0);

	if (!frm_ies->frm) {
		QRPE_WARN("Drop send frame command: no frame is found");
		return;
	}

	len = QRPE_IE_GET_LEN(frm_ies->frm);
	if (len < IEEE80211_FRAME_MIN_LEN) {
		QRPE_WARN("Drop send frame command: frame len(%u) seems incorrect");
		return;
	}

	qrpe_driver_send_frame(intf, chan,
		QRPE_IE_GET_VALUE(frm_ies->frm),len);
}

static void qrpe_process_command_frame(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf = qrpe_find_intf_by_ifmac(cmd->mac);
	uint16_t payload_len = qrpe_get_command_payload_len(cmd);

	if (!intf || len < sizeof(QRPE_COMMAND_T) + payload_len)
		return;

	qrpe_parse_tlv(intf, qrpe_get_command_payload(cmd), payload_len,
		qrpe_init_frame_block, NULL,
		qrpe_parse_frame_block, qrpe_process_frame_block);
}

typedef struct {
	uint8_t *frm;
	uint8_t txrx;
} REG_FRM_PARSE_T;
static REG_FRM_PARSE_T g_reg_frm;
static void qrpe_init_reg_frame_block(void)
{
	memset(&g_reg_frm, 0, sizeof(g_reg_frm));
}

static int qrpe_check_register_frame_block(uint16_t type)
{
	if (TLVTYPE_FRAME_RX_SEL == type
		|| TLVTYPE_FRAME_TX_SEL == type)
		return 1;
	return 0;
}

static void qrpe_parse_register_frame_block(void **ies,
	uint8_t *frm, uint16_t type, uint16_t len)
{
	*ies = (void *)&g_reg_frm;

	switch (type) {
	case TLVTYPE_FRAME_TX_SEL:
		g_reg_frm.txrx = 1;
		break;
	case TLVTYPE_FRAME_RX_SEL:
		g_reg_frm.txrx = 0;
		break;
	default:
		break;
	}
	g_reg_frm.frm = frm;
}

static void qrpe_process_register_frame_block(void *ctx,
	void *ies, uint8_t *eblock, int more)
{
	QRPE_INTF_T *intf = (QRPE_INTF_T *)ctx;
	REG_FRM_PARSE_T *reg_frm = (REG_FRM_PARSE_T *)ies;
	uint8_t flags = 0, subtype = 0, match_len = 0;
	uint8_t drv_process;
	uint8_t *match = NULL;
	uint16_t len;

	if (!reg_frm->frm) {
		QRPE_WARN("Not find reg frame");
		return;
	}

	if (reg_frm->txrx)
		flags = QRPE_DRV_REG_FLAG_XMIT;
	else
		flags = QRPE_DRV_REG_FLAG_RECV;

	len = QRPE_IE_GET_LEN(reg_frm->frm);
	/* unregister all the frames */
	if (!len) {
		flags |= QRPE_DRV_REG_FLAG_DEL_ALL;
		qrpe_driver_register_frame(intf, 0, NULL, 0, flags);
		return;
	}

	if (len < 3) {
		QRPE_WARN("Drop register frame command:"
			"reg frame ie len(%u) less than 3", len);
		return;
	}

	subtype = QRPE_IE_GET_UINT8(reg_frm->frm, 0);
	drv_process = QRPE_IE_GET_UINT8(reg_frm->frm, 1);
	match_len = QRPE_IE_GET_UINT8(reg_frm->frm, 2);
	if (len < 3 + match_len) {
		QRPE_WARN("Drop register frame command:"
			"reg frame ie len(%u) less than 3 + %u", len, match_len);
		return;
	}
	if (match_len)
		match = QRPE_IE_GET_VALUE(reg_frm->frm) + 3;

	if (drv_process == QRPE_DRV_FRAME_COPY)
		flags |= QRPE_DRV_REG_FLAG_SKB_COPY;
	else if (drv_process == QRPE_DRV_FRAME_BYPASS)
		flags |= QRPE_DRV_REG_FLAG_BYPASS;

	qrpe_driver_register_frame(intf, subtype, match, match_len, flags);
}

static void qrpe_process_command_register_frame(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf = qrpe_find_intf_by_ifmac(cmd->mac);
	uint16_t payload_len = qrpe_get_command_payload_len(cmd);

	if (!intf || len < sizeof(QRPE_COMMAND_T) + payload_len)
		return;
	qrpe_parse_tlv(intf, qrpe_get_command_payload(cmd), payload_len,
		qrpe_init_reg_frame_block, qrpe_check_register_frame_block,
		qrpe_parse_register_frame_block, qrpe_process_register_frame_block);
}

typedef struct {
	uint8_t *app_ies;
	uint8_t *extcap;
	uint8_t *third_cc;
} USERCAP_PARSE_T;
static USERCAP_PARSE_T g_usercap_parse;

static void qrpe_init_set_user_cap_block(void)
{
	memset(&g_usercap_parse, 0, sizeof(g_usercap_parse));
}

static int qrpe_check_set_user_cap_block(uint16_t type)
{
	if (TLVTYPE_ADDIES == type)
		return 1;
	return 0;
}

static void qrpe_parse_set_user_cap_block(void **ies,
	uint8_t *frm, uint16_t type, uint16_t len)
{
	*ies = (void *)&g_usercap_parse;

	if(qrpe_check_set_user_cap_block(type))
		g_usercap_parse.app_ies = NULL;

	switch (type) {
	case TLVTYPE_ADDIES:
		g_usercap_parse.app_ies = frm;
		break;
	case TLVTYPE_EXTCAP_SETS:
		g_usercap_parse.extcap = frm;
		break;
	case TLVTYPE_THIRD_CC:
		g_usercap_parse.third_cc = frm;
		break;
	default:
		break;
	}
}

static void qrpe_process_frame_mask_and_ies(QRPE_INTF_T *intf, uint8_t *ie)
{
	uint16_t len = QRPE_IE_GET_LEN(ie);
	uint32_t mask;
	uint8_t *appie;

	/* Masks + non IEs */
	if (len < 4) {
		QRPE_WARN("Drop the Frame Mask IE: the length(%u) is too less", len);
		return;
	}

	mask = QRPE_IE_GET_UINT32(ie, 0);
	appie = QRPE_IE_GET_VALUE(ie) + 4;

	if (mask & QRPE_APPIE_FOR_PROBE)
		qrpe_driver_update_ies(intf, QRPE_SUBTYPE_PROBE_RESP, appie, len - 4);
	if (mask & QRPE_APPIE_FOR_BEACON)
		qrpe_driver_update_ies(intf, QRPE_SUBTYPE_BEACON, appie, len - 4);
	if (mask & QRPE_APPIE_FOR_AUTH)
		qrpe_driver_update_ies(intf, QRPE_SUBTYPE_AUTH, appie, len - 4);
	if (mask & QRPE_APPIE_FOR_ASSOC)
		qrpe_driver_update_ies(intf, QRPE_SUBTYPE_ASSOC_RESP, appie, len - 4);
}

static void qrpe_process_extcap_ie_and_mask(QRPE_INTF_T *intf, uint8_t *ie)
{
	uint16_t len = QRPE_IE_GET_LEN(ie);
	if (len & 0x01) {
		QRPE_WARN("Drop the Extcap IE: the length(%u) is not even", len);
		return;
	}

	qrpe_driver_update_extcap(intf, QRPE_IE_GET_VALUE(ie),
		QRPE_IE_GET_VALUE(ie) + len / 2, len / 2);
}

static void qrpe_process_third_cc_string(QRPE_INTF_T *intf, uint8_t *ie)
{
	uint16_t len = QRPE_IE_GET_LEN(ie);
	if (len < 1) {
		QRPE_WARN("Drop the Third CC String IE: the length(%u) is not correct", len);
		return;
	}

	qrpe_driver_update_3rd_cc(intf, QRPE_IE_GET_UINT8(ie, 0));
}

static void qrpe_process_set_user_cap_block(void *ctx,
	void *ies, uint8_t *eblock, int more)
{
	QRPE_INTF_T *intf = (QRPE_INTF_T *)ctx;
	USERCAP_PARSE_T *usercap_ies = (USERCAP_PARSE_T *)ies;

	if (usercap_ies->app_ies)
		qrpe_process_frame_mask_and_ies(intf, usercap_ies->app_ies);

	if (!more) {
		if (usercap_ies->extcap)
			qrpe_process_extcap_ie_and_mask(intf, usercap_ies->extcap);
		if (usercap_ies->third_cc)
			qrpe_process_third_cc_string(intf, usercap_ies->third_cc);
	}
}

static void qrpe_process_command_set_user_cap(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf = qrpe_find_intf_by_ifmac(cmd->mac);
	uint16_t payload_len = qrpe_get_command_payload_len(cmd);

	if (!intf || len < sizeof(QRPE_COMMAND_T) + payload_len)
		return;

	qrpe_parse_tlv(intf, qrpe_get_command_payload(cmd), payload_len,
		qrpe_init_set_user_cap_block, qrpe_check_set_user_cap_block,
		qrpe_parse_set_user_cap_block, qrpe_process_set_user_cap_block);
}

#ifdef CONFIG_SUPPORT_QTNA_SPDIA
static void qrpe_process_command_spdia_ctrl(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf;
	QRPE_COMMAND_SPDIA_CTRL_T *ctrl =
		(QRPE_COMMAND_SPDIA_CTRL_T *)qrpe_get_command_payload(cmd);

	if (len < sizeof(QRPE_COMMAND_SPDIA_CTRL_T) + sizeof(QRPE_COMMAND_T))
		return;

	intf = qrpe_find_intf_by_ifmac(cmd->mac);
	if (intf)
		qrpe_driver_ctrl_sta_spdia(intf, ctrl->peer_mac, ctrl->period, ctrl->spdia_feature,
			ctrl->spdia_ng, ctrl->spdia_smooth);
}
#endif

typedef struct {
	uint8_t *mac;
	uint8_t *change_chan;
} CHANGE_CHAN_PARSE_T;

static CHANGE_CHAN_PARSE_T g_change_chan;

static void qrpe_init_change_chan_block(void)
{
	g_change_chan.mac = NULL;
	g_change_chan.change_chan = NULL;
}

static int qrpe_set_channel_and_pwr(QRPE_RADIO_T *radio_if,
	uint8_t opclass, uint8_t channel, uint8_t bw, uint8_t tx_backoff)
{
	uint32_t vap_mask, i;
	int ret = -1;

	if (!radio_if) {
		QRPE_WARN("radio_if is NULL");
		return ret;
	}
	ret = qrpe_driver_change_chan(radio_if, channel, bw);

	vap_mask = radio_if->intf_mask;
	for (i = 0; i < QRPE_SUPPORT_INTFS; i++) {
		if (vap_mask & (1 << i))
			ret = qrpe_driver_set_power_backoff(&g_ctx.intf_ctx[i], tx_backoff);
	}
	return ret;
}

static void qrpe_process_change_chan(void *ctx,
	void *ies, uint8_t *eblock, int more)
{
	CHANGE_CHAN_PARSE_T *p_record = (CHANGE_CHAN_PARSE_T *)ies;
	QRPE_RADIO_T *radio_if = NULL;
	uint8_t mac_addr[ETH_ALEN];
	uint8_t i, opclass = 0, channel = 0, bw = 0, tx_backoff = 0;

	if (more || !p_record->mac || !p_record->change_chan
		|| QRPE_IE_GET_LEN(p_record->mac) < ETH_ALEN)
		return;

	/* radio mac*/
	memcpy(mac_addr, (uint8_t *)QRPE_IE_GET_VALUE(p_record->mac), ETH_ALEN);
	radio_if = qrpe_find_radio_by_uid(mac_addr);
	if (!radio_if) {
		QRPE_WARN("can NOT find" MACSTR "in local radios",
			MAC2STR(mac_addr));
		return;
	}

	/*details of change chan */
	opclass = *QRPE_IE_GET_VALUE(p_record->change_chan);
	channel = *(QRPE_IE_GET_VALUE(p_record->change_chan) + 1);
	tx_backoff = *(QRPE_IE_GET_VALUE(p_record->change_chan) + 2);

	for (i = 0; i < QRPE_DRV_OPCLASS_MAXNUM; i++) {
		if (opclass == radio_if->info.opclass[i].global_opclass) {
			bw = radio_if->info.opclass[i].bandwidth;
			break;
		}
	}
	if (0 == bw) {
		QRPE_WARN("can NOT find BW with opclass[%d]", opclass);
		return;
	}

	qrpe_set_channel_and_pwr(radio_if, opclass, channel, bw, tx_backoff);
}

static void qrpe_parse_change_chan(void **ies,
		uint8_t *frm, uint16_t type, uint16_t len)
{
	if (!frm)
		return;
	*ies = (void *)&g_change_chan;

	switch(type) {
	case TLVTYPE_RADIO_MACADDR:
		g_change_chan.mac = frm;
		break;
	case TLVTYPE_CHAN_CHANGE_INFO:
		g_change_chan.change_chan = frm;
		break;
	default:
		break;
	}
}

static void qrpe_process_command_radio_change_chan(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_RADIO_T *radio = qrpe_find_radio_by_uid(cmd->mac);
	uint16_t payload_len = qrpe_get_command_payload_len(cmd);

	if (!radio || len < (payload_len + sizeof(QRPE_COMMAND_T)))
		return;

	qrpe_parse_tlv(radio, qrpe_get_command_payload(cmd), payload_len,
		qrpe_init_change_chan_block, NULL,
		qrpe_parse_change_chan, qrpe_process_change_chan);
}

typedef struct {
	uint8_t *drv_feature;
	uint8_t *monitor_cfg;
	uint8_t *omonitor_chan;
} INTF_FEAT_PARSE_T;
static INTF_FEAT_PARSE_T g_intf_feat;

static void qrpe_init_ctrl_intf_feat_block(void)
{
	memset(&g_intf_feat, 0, sizeof(g_intf_feat));
}

static void qrpe_parse_ctrl_intf_feat_block(void **ies,
	uint8_t *frm, uint16_t type, uint16_t len)
{
	*ies = (void *)&g_intf_feat;

	switch (type) {
	case TLVTYPE_INTF_DRIVER_CFG:
		g_intf_feat.drv_feature = frm;
		break;
	case TLVTYPE_MONITOR_CFG:
		g_intf_feat.monitor_cfg = frm;
		break;
	case TLVTYPE_OMONITOR_CFG:
		g_intf_feat.omonitor_chan = frm;
		break;
	default:
		break;
	}
}

static void qrpe_process_ctrl_intf_feat_block(void *ctx,
	void *ies, uint8_t *eblock, int more)
{
	QRPE_INTF_T *intf = (QRPE_INTF_T *)ctx;
	INTF_FEAT_PARSE_T *cfg_ies = (INTF_FEAT_PARSE_T *)ies;
	uint16_t feat, mask;
	uint16_t period = 0, duty_cycle = 0;

        if (!cfg_ies->drv_feature
		|| QRPE_IE_GET_LEN(cfg_ies->drv_feature) < 4) {
		QRPE_WARN("Drop set intf command: cfg drv_feature incorrect");
		return;
	}
	feat = QRPE_IE_GET_UINT16(cfg_ies->drv_feature, 0);
	mask = QRPE_IE_GET_UINT16(cfg_ies->drv_feature, 2);

	if (mask & QRPE_DRV_INTF_FEAT_MONITOR) {
		if (feat & QRPE_DRV_INTF_FEAT_MONITOR) {
			if (!cfg_ies->monitor_cfg
				|| QRPE_IE_GET_LEN(cfg_ies->monitor_cfg) < 4) {
				QRPE_WARN("Drop set intf command: cfg monitor incorrect");
				return;
			}
			period = QRPE_IE_GET_UINT16(cfg_ies->monitor_cfg, 0);
			duty_cycle = QRPE_IE_GET_UINT16(cfg_ies->monitor_cfg, 2);
			if (duty_cycle & 0x8000) {
				QRPE_WARN("Drop set intf command: not support in driver now");
				return;
			}
			qrpe_driver_start_monitor(intf, period, duty_cycle, QRPE_DRV_MONITOR_MASK);
		} else
			qrpe_driver_stop_monitor(intf, QRPE_DRV_MONITOR_MASK);
	}

	if (mask & QRPE_DRV_INTF_FEAT_OMONITOR_AUTO) {
		if (feat & QRPE_DRV_INTF_FEAT_OMONITOR_AUTO)
			qrpe_driver_start_monitor(intf, period, duty_cycle, QRPE_DRV_OMONITOR_MASK);
		else
			qrpe_driver_stop_monitor(intf, QRPE_DRV_OMONITOR_MASK);
	}

	if (mask & QRPE_DRV_INTF_FEAT_MAP_BSTA) {
		if (feat & QRPE_DRV_INTF_FEAT_MAP_BSTA)
			qrpe_driver_set_backhaul_sta(intf, 1);
		else
			qrpe_driver_set_backhaul_sta(intf, 0);
	}

	if (mask & QRPE_DRV_INTF_FEAT_OMONITOR_ONDEMAND) {
		if (feat & QRPE_DRV_INTF_FEAT_OMONITOR_ONDEMAND) {
			if (!cfg_ies->omonitor_chan
				|| QRPE_IE_GET_LEN(cfg_ies->omonitor_chan) < 1) {
				QRPE_WARN("Drop set intf command: cfg omonitor channel incorrect");
				return;
			}
			qrpe_driver_start_omonitor_ondemand(intf,
				QRPE_IE_GET_UINT8(cfg_ies->omonitor_chan, 0));
		}
	}

	if (mask & QRPE_DRV_INTF_FEAT_IGNORE_HWPBC) {
		if (feat & QRPE_DRV_INTF_FEAT_IGNORE_HWPBC)
			qrpe_driver_ignore_hw_pbc(intf, 1);
		else
			qrpe_driver_ignore_hw_pbc(intf, 0);
	}
}

static void qrpe_process_command_ctrl_intf_feat(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf = qrpe_find_intf_by_ifmac(cmd->mac);
	uint16_t payload_len = qrpe_get_command_payload_len(cmd);

	if (!intf || len < sizeof(QRPE_COMMAND_T) + payload_len)
		return;

	qrpe_parse_tlv(intf, qrpe_get_command_payload(cmd), payload_len,
			qrpe_init_ctrl_intf_feat_block, NULL,
			qrpe_parse_ctrl_intf_feat_block, qrpe_process_ctrl_intf_feat_block);
}

typedef struct {
	uint8_t *target;
	uint8_t *chan_opclass;
} STA_ROAM_PARSE_T;
static STA_ROAM_PARSE_T g_sta_roam;

static void qrpe_init_roam_block(void)
{
	memset(&g_sta_roam, 0, sizeof(g_sta_roam));
}

static void qrpe_parse_roam_block(void **ies,
	uint8_t *frm, uint16_t type, uint16_t len)
{
	*ies = &g_sta_roam;

	switch (type) {
	case TLVTYPE_PEER_MACADDR:
		g_sta_roam.target = frm;
		break;
	case TLVTYPE_CHANNEL_BAND:
		g_sta_roam.chan_opclass = frm;
		break;
	default:
		break;
	}
}

static void qrpe_process_roam_block(void *ctx, void *ies,
		uint8_t *eblock, int more)
{
	QRPE_INTF_T *intf = (QRPE_INTF_T *)ctx;
	STA_ROAM_PARSE_T *roam_ies = (STA_ROAM_PARSE_T *)ies;
	uint8_t chan, opclass;

	if (!roam_ies->chan_opclass
		|| QRPE_IE_GET_LEN(roam_ies->chan_opclass) < 3) {
		QRPE_WARN("Drop sta roam command: no chan and opclass found");
		return;
	}

	if (!roam_ies->target) {
		QRPE_WARN("Drop sta roam command: no target found");
		return;
	}

	chan = QRPE_IE_GET_UINT8(roam_ies->chan_opclass, 0);
	opclass = QRPE_IE_GET_UINT8(roam_ies->chan_opclass, 2);

	qrpe_driver_roam(intf, QRPE_IE_GET_VALUE(roam_ies->target),
		chan, opclass);
}

static void qrpe_process_command_roam(QRPE_COMMAND_T *cmd, unsigned int len)
{
	QRPE_INTF_T *intf = qrpe_find_intf_by_ifmac(cmd->mac);
	uint16_t payload_len = qrpe_get_command_payload_len(cmd);

	if (!intf || len < sizeof(QRPE_COMMAND_T) + payload_len)
		return;

	if (intf->info.intf_type != QRPE_NODE_TYPE_STA) {
		QRPE_WARN("Drop sta roam command: only valid for STA type");
		return;
	}

	qrpe_parse_tlv(intf, qrpe_get_command_payload(cmd), payload_len,
			qrpe_init_roam_block, NULL,
			qrpe_parse_roam_block, qrpe_process_roam_block);
}

static void qrpe_process_message_from_app(void *ctx, unsigned char *msg, unsigned int len)
{
	QRPE_COMMAND_T *cmd = (QRPE_COMMAND_T *)msg;
	uint16_t cmd_id;
	if (!msg && len < sizeof(QRPE_COMMAND_T)) {
		QRPE_WARN("Command from app is wrong");
		return;
	}

	cmd_id = le_to_host16(cmd->id);
	QRPE_INFO("Recv app command [%s:%u]", qrpe_command_to_name(cmd_id), cmd_id);
	switch(cmd_id) {
	case QRPE_CMD_INIT:
		qrpe_process_command_init(cmd, len);
		break;
	case QRPE_CMD_DEINIT:
		qrpe_process_command_deinit(cmd, len);
		break;
	case QRPE_CMD_GET_INTF_STATUS:
		qrpe_process_command_get_intf_status(cmd, len);
		break;
	case QRPE_CMD_GET_INTF_INFO:
		qrpe_process_command_get_intf_info(cmd, len);
		break;
	case QRPE_CMD_DEAUTHENTICATE:
		qrpe_process_command_deauth(cmd, len);
		break;
	case QRPE_CMD_STA_MAC_FILTER:
		qrpe_process_command_sta_mac_filter(cmd, len);
		break;
	case QRPE_CMD_GET_STA_STATS:
		qrpe_process_command_get_sta_stats(cmd, len);
		break;
	case QRPE_CMD_BSS_TRANS_REQ:
		qrpe_process_command_trans_req(cmd, len);
		break;
	case QRPE_CMD_FAT_MONITOR_START:
		qrpe_process_command_fat_monitor_start(cmd, len);
		break;
	case QRPE_CMD_MONITOR_START:
		qrpe_process_command_monitor_start(cmd, len);
		break;
	case QRPE_CMD_MONITOR_STOP:
		qrpe_process_command_monitor_stop(cmd, len);
		break;
	case QRPE_CMD_GET_NONASSOC_STATS:
		qrpe_process_command_get_nonassoc_sta_stats(cmd, len);
		break;
	case QRPE_CMD_FRAME:
		qrpe_process_command_frame(cmd, len);
		break;
	case QRPE_CMD_REGISTER_FRAME:
		qrpe_process_command_register_frame(cmd, len);
		break;
	case QRPE_CMD_SET_USER_CAP:
		qrpe_process_command_set_user_cap(cmd, len);
		break;
	case QRPE_CMD_DISASSOC:
		qrpe_process_command_disassoc(cmd, len);
		break;
#ifdef CONFIG_SUPPORT_QTNA_SPDIA
	case QRPE_CMD_SPDIA_CTRL:
		qrpe_process_command_spdia_ctrl(cmd, len);
		break;
#endif
	case QRPE_CMD_ROAM:
		qrpe_process_command_roam(cmd, len);
		break;
	case QRPE_CMD_RADIO_CHANGE_CHAN:
		qrpe_process_command_radio_change_chan(cmd, len);
		break;
	case QRPE_CMD_CTRL_INTF_FEAT:
		qrpe_process_command_ctrl_intf_feat(cmd, len);
		break;
	default:
		QRPE_WARN("Unsupport command %u", cmd_id);
		break;
	}
}

void qrpe_process_rtm_message(void (*cb)(struct ifinfomsg *ifi, uint8_t *buf, size_t len),
	struct nlmsghdr *h)
{
	if (cb == NULL || NLMSG_PAYLOAD(h, 0) < sizeof(struct ifinfomsg))
		return;

	cb(NLMSG_DATA(h), (uint8_t *) NLMSG_DATA(h) + NLMSG_ALIGN(sizeof(struct ifinfomsg)),
		NLMSG_PAYLOAD(h, sizeof(struct ifinfomsg)));
}

#ifdef CONFIG_SUPPORT_QTNA_BACKBONE
static void qrpe_process_linkmode_event_for_qhop(char *ifname, struct ifinfomsg *ifi)
{
	QRPE_INTF_T *intf = NULL;
	uint8_t status = QRPE_INTF_STATUS_DOWN;
	if(strncmp(ifname, "wds", 3))
		return;

	intf = qrpe_find_or_add_wds_intf(ifname);
	if ((ifi->ifi_flags & IFF_UP) || (ifi->ifi_flags & IFF_RUNNING))
		status = QRPE_INTF_STATUS_UP;
	QRPE_INTF_SET_STATUS(intf, status);
	if (g_ctx.inited)
		qrpe_qtna_wds_intf_status_changed(intf);
}
#endif

static void qrpe_process_linkmode_event(struct ifinfomsg *ifi)
{
	char ifname[IFNAMSIZ + 1] = {0};
	QRPE_INTF_T *intf = NULL;
	uint8_t status = QRPE_INTF_STATUS_DOWN;

	if_indextoname(ifi->ifi_index, ifname);
	intf = qrpe_probe_intf(ifname);
	if (!intf) {
#ifdef CONFIG_SUPPORT_QTNA_BACKBONE
		qrpe_process_linkmode_event_for_qhop(ifname, ifi);
#endif
		return;
	}

	if ((ifi->ifi_flags & IFF_UP) || (ifi->ifi_flags & IFF_RUNNING)) {
		qrpe_update_intf_mac(intf, ifi->ifi_index);
		status = QRPE_INTF_STATUS_UP;
		if (g_ctx.inited) {
			qrpe_driver_set_status(intf, QRPE_INTF_ENABLE);
			qrpe_report_intf_info(intf, QRPE_INTF_SUBCMD_INFO);
		}
	}
	QRPE_INTF_SET_STATUS(intf, status);
	QRPE_DEBUG("Intf %s link changed: %s", ifname, status == QRPE_INTF_STATUS_UP ? "up" : "down");
	if (g_ctx.inited)
		qrpe_send_intf_status(intf);
}

static void qrpe_process_rtm_newlink_message(struct ifinfomsg *ifi, uint8_t *buf, size_t len)
{
	int attrlen;
	struct rtattr *attr;
	attrlen = len;
	attr = (struct rtattr *) buf;

	while (RTA_OK(attr, attrlen)) {
		switch(attr->rta_type) {
		case IFLA_LINKMODE:
			qrpe_process_linkmode_event(ifi);
			break;
		}
		attr = RTA_NEXT(attr, attrlen);
	}
}

static void qrpe_process_rtm_dellink_message(struct ifinfomsg *ifi, uint8_t *buf, size_t len)
{
	QRPE_INTF_T *intf = qrpe_find_intf_by_ifindex(ifi->ifi_index);
	if (intf) {
		QRPE_DEBUG("Intf %s link delete", intf->ifname);
		QRPE_INTF_SET_STATUS(intf, QRPE_INTF_STATUS_DELETED);
		if (g_ctx.inited)
			qrpe_send_intf_status(intf);
	}
}

static void qrpe_receive_rtnetlink_message(int sock)
{
	int len;
	struct nlmsghdr *h;

	len = recvfrom(sock, g_rx_buff, QRPE_MAX_MSG_LEN, MSG_DONTWAIT,
		NULL, NULL);
	if (len < 0) {
		if (errno != EINTR && errno != EAGAIN)
			QRPE_WARN("Failed receive from driver: %s", strerror(errno));
		return;
	}

	h = (struct nlmsghdr *)g_rx_buff;
	while (NLMSG_OK(h, len)) {
		switch (h->nlmsg_type) {
			case RTM_NEWLINK:
				qrpe_process_rtm_message(qrpe_process_rtm_newlink_message, h);
				break;
			case RTM_DELLINK:
				qrpe_process_rtm_message(qrpe_process_rtm_dellink_message, h);
				break;
			default:
				break;
		}

		h = NLMSG_NEXT(h, len);
	}

	if (len > 0)
		QRPE_WARN("Extra %u bytes in the end of netlink message", len);
}

#ifdef CONFIG_SUPPORT_RTNETLINK
static void qrpe_recv_message_from_app_by_rtnetlink(int sock)
{
	int len;
	struct nlmsghdr *h;
#ifdef CONFIG_RTNETLINK_EVENT_MULTICAST
	len = recvfrom(sock, g_rx_buff, QRPE_MAX_MSG_LEN, MSG_DONTWAIT,
		NULL, NULL);
#else
	struct msghdr msg;
	struct iovec iov;
	struct sockaddr_nl src_addr;

	memset(&src_addr, 0, sizeof(src_addr));

	iov.iov_base = (void *)g_rx_buff;
	iov.iov_len = QRPE_MAX_MSG_LEN;

	memset(&msg, 0, sizeof(msg));
	msg.msg_name = (void *)&src_addr;
	msg.msg_namelen = sizeof(src_addr);
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;

	len = recvmsg(sock, &msg, MSG_DONTWAIT);
#endif
	if (len < 0) {
		if (errno != EINTR && errno != EAGAIN)
			QRPE_WARN("Failed receive from app: %s", strerror(errno));
		return;
	}

	h = (struct nlmsghdr *)g_rx_buff;
	while (NLMSG_OK(h, len)) {
		switch (h->nlmsg_type) {
			case QRPE_RTLINK_COMMAND:
				qrpe_process_message_from_app(NULL,
					(uint8_t *)NLMSG_DATA(h), NLMSG_PAYLOAD(h,0));
				break;
			default:
				break;
		}

		h = NLMSG_NEXT(h, len);
	}

	if (len > 0)
		QRPE_WARN("Extra %u bytes in the end of netlink message", len);
}
#elif defined CONFIG_SUPPORT_GENNETLINK
int qrpe_recv_message_from_app_by_gennetlink(struct nl_msg *nlmsg, void *arg)
{
	struct genlmsghdr *gnlh;
	struct nlattr *tb[NUM_QRPE_ATTR + 1];

	gnlh = nlmsg_data(nlmsg_hdr(nlmsg));
	if(gnlh->cmd != QRPE_GENL_DRV_APP_CMD)
		return NL_SKIP;

	nla_parse(tb, NUM_QRPE_ATTR, genlmsg_attrdata(gnlh, 0),
			genlmsg_attrlen(gnlh, 0), NULL);
	if(tb[QRPE_ATTR_RX_APP_COMMAND])
		qrpe_process_message_from_app(NULL,
			(uint8_t *)nla_data(tb[QRPE_ATTR_RX_APP_COMMAND]),
			nla_len(tb[QRPE_ATTR_RX_APP_COMMAND]));

	return NL_OK;
}
#endif

#define FD_SET_ADV(_fd, _set)	do {	\
		FD_SET((_fd), (_set));	\
		if ((_fd) >= max_fd)	\
			max_fd = (_fd) + 1;	\
	} while (0)

void qrpe_message_loop(void)
{
	int max_fd;

	QRPE_DEBUG("Loop...");
	while(1) {
		fd_set rfds;
		int ret;

		FD_ZERO(&rfds);
		max_fd = qrpe_driver_init_fdset(QRPE_FDSET_TYPE_READ, &rfds);
		FD_SET_ADV(g_ctx.rtm_sock, &rfds);
		FD_SET_ADV(g_ctx.read_sock, &rfds);
		FD_SET_ADV(g_ctx.ctrl_sock, &rfds);

		ret = select(max_fd + 1, &rfds, NULL, NULL, NULL);
		if(ret < 0) {
			if(errno == EAGAIN || errno == EINTR)
				continue;
			QRPE_WARN("unhandled the signal....: %s", strerror(errno));
			break;
		}

		if(FD_ISSET(g_ctx.rtm_sock, &rfds))
			qrpe_receive_rtnetlink_message(g_ctx.rtm_sock);

		qrpe_driver_check_fdset(QRPE_FDSET_TYPE_READ, &rfds);

		if(FD_ISSET(g_ctx.read_sock, &rfds))
#ifdef CONFIG_SUPPORT_RTNETLINK
			qrpe_recv_message_from_app_by_rtnetlink(g_ctx.read_sock);
#elif defined CONFIG_SUPPORT_GENNETLINK
			nl_recvmsgs(g_ctx.read_nl_sock, g_ctx.nlcb);
#endif

		if(FD_ISSET(g_ctx.ctrl_sock, &rfds))
			qrpe_receive_ctrl_message(g_ctx.ctrl_sock);
	}
}

