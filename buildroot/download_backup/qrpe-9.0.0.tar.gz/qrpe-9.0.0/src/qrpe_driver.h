/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : qrpe_driver.h                                              **
**  Description : qrpe driver definitions                                    **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#ifndef __QRPE_DRIVER_H__
#define __QRPE_DRIVER_H__

#define MAX_DRV_STA_ENTRY	128	/*!< max clients supported on one interface */
#define MAX_DRV_NR_ENTRY	128	/*!< max neigh report entry supported on one interface */
#define MAX_DRV_REG_FRAME_LEN	128	/*!< max registerable frame supported on one interface */
#define MAX_DRV_EID_MASK_LEN 	32 	/*!< max octets element id supported on one interface */
#define MAX_DRV_EXTCAP_LEN 	12 	/*!< max octets extended capability supported on one interface */

/**
 * @brief BSS interface infomation, used for get_intf_info ops in QRPE_DRIVER_OPS_T
 */

#define QRPE_DRIVER_SPDIA_REORDER	(1 << 0)
#define QRPE_DRIVER_SPDIA_MODE_DATA	(1 << 1)
#define QRPE_DRIVER_SPDIA_MODE_NDP	(1 << 2)

/**
 * @brief estimated service parameters, used in QRPE_DRV_INTF_INFO_T
 */
typedef struct {
	uint8_t ac;                             /*!< Access Category: 0: AC_BK, 1: AC_BE, 2: AC_VI, 3: AC_VO; other value means espi is invlid */
	uint8_t format;                         /*!< Data Format (see Table 9-261 of Ref. IEEE802.11-2016) */
	uint8_t window;                         /*!< BA Window Size (see Table 9-262 of Ref. IEEE802.11-2016) */
	uint8_t duration;                       /*!< Data PPDU Duration target (see  §9.4.2.174 of Ref. IEEE802.11-2016) */
} QRPE_DRV_ESPI_T;

typedef struct {
	char radio_name[IFNAMSIZ];		/*!< Intf created on which radio name */
	uint8_t ssid[QRPE_MAX_SSID_LEN + 1];	/*!< SSID string */
	uint8_t ssid_len;			/*!< SSID string len */
	uint8_t bssid[ETH_ALEN];		/*!< BSSID of BSS operating or associated on this interface */
	uint16_t mdid;				/*!< Mobility Domain ID */
	uint8_t channel;			/*!< Current Channel */
	uint8_t band;				/*!< Operational Band: 2G(0); 5G(1) */
	uint8_t cc_alpha[2];			/*!< Country code used */
	uint16_t opclass;			/*!< Operating Class encoded as in Beacons */
	uint8_t phytype;			/*!< fhss(1), dsss(2), irbaseband(3), ofdm(4), hrdsss(5), erp(6), ht(7), dmg(8), vht(9) */
	uint32_t bcnpwr_backoff;		/*!< Current beacon power backoff */
	uint32_t support_btm:1;			/*!< Support sending 802.11v unsolicited BSS Transition? */
	uint32_t support_ht:1;			/*!< Support operating as HT BSS? */
	uint32_t support_vht:1;			/*!< Support operating as VHT BSS? */
	uint32_t support_monitor:1;		/*!< Support current channel monitor? */
	uint32_t support_omonitor:1;		/*!< Support off channel monitor? */
	uint32_t support_erw:1;			/*!< Support enhanced response withhold? */
	uint32_t support_set_cc3rd:1; 		/*!< Support set the thrid byte of country code */
	uint32_t support_pmf_mfpr:1;		/*!< Same value of BIT6 of the RSN Capabilities field (MFPR) */
	uint32_t support_pmf_mfpc:1;		/*!< Same value of BIT7 of the RSN Capabilities field (MFPC) */
	uint32_t support_spdia:1;		/*!< Support spatial diagnostic? */
	uint32_t support_backhaul_sta:1;	/*!< Support backhaul station? */
	uint8_t spdia_feature_support;		/*!< The combination of spdia mode and reorder */
	uint8_t spdia_sta_support_count; 	/*! < Sta count that spdia support */
	uint16_t capinfo;			/*!< Capabilities Information field from Beacons */
	uint16_t bintval;			/*!< Beacon Interval */
	uint8_t htcap[HT_CAP_LEN];		/*!< As advertised in Beacons and Probes */
	uint8_t htop[HT_OP_LEN];		/*!< As advertised in Beacons and Probes */
	uint8_t vhtcap[VHT_CAP_LEN];		/*!< As advertised in Beacons and Probes */
	uint8_t vhtop[VHT_OP_LEN];		/*!< As advertised in Beacons and Probes */
	uint8_t hecap[HE_CAP_MAXLEN];		/*!< As advertised in Beacons and Probes */
	uint8_t heop[HE_OP_MAXLEN];		/*!< As advertised in Beacons and Probes */
	uint16_t avg_fat;			/*!< Average Free Airtime, used for sub_cmd QRPE_INTF_SUBCMD_FAT */
	uint8_t supp_elemid_mask[MAX_DRV_EID_MASK_LEN];/*! Driver support add element id */
	uint8_t supp_extcap[MAX_DRV_EXTCAP_LEN];/*! Driver support extended capability */
	uint8_t reg_tx_frm_len; 		/*!< Registrable Tx Management Frame length */
	uint8_t reg_tx_frame[MAX_DRV_REG_FRAME_LEN];   /*!< Registrable Tx Management Frame, @see ieee80211_qrpe_intf_info */
	uint8_t reg_rx_frm_len;			/*!< Registrable Rx Management Frame length */
	uint8_t reg_rx_frame[MAX_DRV_REG_FRAME_LEN];   /*!< Registrable Rx Management Frame, @see ieee80211_qrpe_intf_info */

	uint32_t intf_type; 			/*!< Intf type: unknow(0), ap(1), sta(2), wds(3), tdls(4), repeater(5), notwifi(6) */
	uint16_t intf_type_1905; 		/*!< 1905 intf type, only valid when intf_type is notwifi */

#define QRPE_DRV_AC_MAXNUM 	4
	QRPE_DRV_ESPI_T espi[QRPE_DRV_AC_MAXNUM]; /*!< estimated service parameters for each access category */
} QRPE_DRV_INTF_INFO_T;

#define QRPE_DRV_ERW_OP_SET_ENTRIES		0
#define QRPE_DRV_ERW_OP_REMOVE_ALL		1
#define QRPE_DRV_ERW_OP_UPDATE_NRIE_ENTRIES	2
#define QRPE_DRV_ERW_OP_DELETE_NRIE_ENTRIES	3

#define QRPE_DRV_NRIE_MASK_NUMS	(MAX_DRV_NR_ENTRY / QRPE_UINT32_BITS)
/**
 * @brief erw nrie mask, used for set_erw ops in QRPE_DRIVER_OPS_T with QRPE_DRV_ERW_OP_DELETE_NRIE_ENTRIES sub op
 */
typedef uint32_t QRPE_DRV_ERW_NRIE_MASK_T[QRPE_DRV_NRIE_MASK_NUMS];

/**
 * @brief entry of erw, used for set_erw ops in QRPE_DRIVER_OPS_T with QRPE_DRV_ERW_OP_SET_ENTRIES sub op
 */
typedef struct {
	uint8_t sta[ETH_ALEN];			/*!< STA mac address */
#define QRPE_DRV_ERW_OP_ADD	0
#define QRPE_DRV_ERW_OP_DEL	1
	uint8_t erw_op;				/*!< ERW Op */
#define QRPE_DRV_ERW_MODE_NONE	0
#define QRPE_DRV_ERW_MODE_MIN	1
#define QRPE_DRV_ERW_MODE_MAX	2
	uint8_t erw_mode;				/*!< ERW mode */
	uint8_t erw_probe_resp:1;			/*!< Withhold probe resp */
	uint8_t erw_assoc_resp:1;			/*!< Withhold (re)assoc resp */
	uint8_t erw_auth_resp:1;			/*!< Withhold auth resp */
	int8_t rssi;					/*!< ERW rssi threshold */
	uint16_t reject_mode;				/*!< ERW reject status code */
	QRPE_DRV_ERW_NRIE_MASK_T reject_nrie_mask;	/*!< ERW Neigh Report IEs mask, valid under the status code is 82 */
} QRPE_DRV_ERW_ENTRY_T;

/**
 * @brief structure of erw, used for set_erw ops in QRPE_DRIVER_OPS_T with QRPE_DRV_ERW_OP_SET_ENTRIES sub op
 */
typedef struct {
	uint16_t num_sta;					/*!< Client numbers */
	QRPE_DRV_ERW_ENTRY_T entries[MAX_DRV_STA_ENTRY];	/*!< All Clients entries */
} QRPE_DRV_ERW_T;

/**
 * @brief entry of erw nrie, used for set_erw ops in QRPE_DRIVER_OPS_T with QRPE_DRV_ERW_OP_UPDATE_NRIE_ENTRIES sub op
 */
typedef struct {
	uint16_t index;				/*!< Neigh Report IE index */
#define QRPE_NRIE_MIN_LEN			(2 + 13)
#define QRPE_NRIE_MAX_LEN			(2 + 255)
	uint16_t len;				/*!< Neigh Report IE len */
#define QRPE_NRIE_EID				(52)
	uint8_t nrie[QRPE_NRIE_MAX_LEN];	/*!< Neigh Report IE */
} QRPE_DRV_ERW_NRIE_ENTRY_T;

/**
 * @brief structure of erw nrie, used for set_erw ops in QRPE_DRIVER_OPS_T with QRPE_DRV_ERW_OP_SET_NRIE_ENTRIES sub op
 */
typedef struct {
	uint16_t num;						/*!< Neigh Report numbers */
	QRPE_DRV_ERW_NRIE_ENTRY_T entries[MAX_DRV_NR_ENTRY];	/*!< All Neigh Report entries */
} QRPE_DRV_ERW_NRIE_T;

/**
 * @brief link statistics, used in QRPE_DRV_STA_STATS_T
 */
typedef struct {
	uint32_t tx_packets;                /*!< Transmitted packets to peer */
	uint32_t tx_bytes;                  /*!< Transmitted bytes to peer */
	uint32_t rx_packets;                /*!< Received packets from peer */
	uint32_t rx_bytes;                  /*!< Received bytes from peer */
	uint32_t tx_errs;                   /*!< Transmitted packets errors to peer */
	uint32_t rx_errs;                   /*!< Received packets errors from peer */
	uint32_t tx_retries;                /*!< Retransmission count to peer */
} QRPE_DRV_LINK_STATS_T;

/**
 * @brief entry of station statistics, used for get_sta_stats/get_monitor_sta_stats ops in QRPE_DRIVER_OPS_T, and for QRPE_DRV_EVENT_STA_PHY_STATS
 */
typedef struct {
	uint8_t sta[ETH_ALEN];			/*!< STA mac address */
	union {
		struct {
			uint64_t age_last_rx_pkt;	/*!< Age of last rx */
			uint64_t age_last_tx_pkt;	/*!< Age of last tx */
			uint32_t rx_phy_rate;		/*!< Phy rate of rx */
			uint32_t rx_bandwidth;		/*!< Bandwidth of rx */
			uint32_t tx_phy_rate;		/*!< Phy rate of tx */
			uint32_t tx_bandwidth;		/*!< Bandwidth of tx */
			uint32_t pkts_per_sec;		/*!< Ptks per second */
			uint32_t avg_airtime;		/*!< Average Airtime */
			int32_t rssi_dbm;		/*!< Rssi */
			QRPE_DRV_LINK_STATS_T stats;    /*!< Link statistics */
		} assoc_stats;			/*!< Associated STA's statistics */
		struct {
			uint64_t age;			/*!< Age of the lastest monitored */
			int32_t rssi_dbm;		/*!< Rssi */
			uint8_t channel;		/*!< Channel monitored */
			uint8_t frame_type;		/*!< Frame type monitored */
		} monitor_stats;		/*!< Non-associated STA's statistics */
	};
} QRPE_DRV_STA_STATS_ENTRY_T;

/**
 * @brief structure of stations statistics, used for get_sta_stats/get_monitor_sta_stats ops in QRPE_DRIVER_OPS_T, and for QRPE_DRV_EVENT_STA_PHY_STATS
 */
typedef struct {
	uint16_t num_sta;			/*!< Client numbers */
	QRPE_DRV_STA_STATS_ENTRY_T entries[MAX_DRV_STA_ENTRY];	/*!< All Clients entries */
} QRPE_DRV_STA_STATS_T;

/**
 * @brief structure for roam status, used for QRPE_DRV_EVENT_ROAM_FAIL event
 * @see QRPE_DRV_EVENT_ROAM_FAIL
 */
typedef struct {
	uint8_t target[ETH_ALEN];       /*!< Target bssid */
	uint8_t channel;                /*!< Channel */
	uint8_t opclass;                /*!< Operation class */
#define QRPE_DRV_ROAM_REASON_SUCCESS		0
#define QRPE_DRV_ROAM_REASON_UNKNOWN_BSSID	1
#define QRPE_DRV_ROAM_REASON_UNKNOWN_CHANNEL	2
#define QRPE_DRV_ROAM_REASON_NO_PROBE_RESP	3
#define QRPE_DRV_ROAM_REASON_NO_ASSOC_RESP	4
#define QRPE_DRV_ROAM_REASON_UNKNOWN_FAILURE	5
#define QRPE_DRV_ROAM_REASON_CONNECT_KEYWRONG	6
	uint8_t reason;                 /*!< Reason */
} QRPE_DRV_ROAM_STATUS_T;

/**
 * @brief structure of btm req, used for send_btm_req ops in QRPE_DRIVER_OPS_T
 */
typedef struct {
	uint8_t sta_mac[ETH_ALEN];	/*!< Mac Address of station to which the BSS Trans. Mgmt. Request should be addressed */
	uint16_t disassoc_timer;	/*!< Used as field “Disassociation Timer” of the BSS Trans. M. Req. frame */
	uint8_t req_mode;		/*!< Used as field “Request mode” of the BSS Trans. Mgmt. Request frame */
	uint8_t val_intvl;		/*!< Used as field “Validity Interval” of the BSS Trans. Mgmt. Req. frame */
	uint8_t bssid[ETH_ALEN];	/*!< Used as field “BSSID” of the sole Neighbor Report included within the BSS Trans. Mgmt. Req. frame as Candidate#1 */
	uint32_t bssid_info;		/*!< Used as field “BSSID Information” of the sole Neighbor Report… */
	uint8_t opclass;		/*!< Used as field “Operating Class” of the sole Neighbor Report… */
	uint8_t channel;		/*!< Used as field “Channel” of the sole Neighbor Report… */
	uint8_t phytype;		/*!< Used as field “PHY Type” of the sole Neighbor Report… */
	uint8_t subel_len;		/*!< Length of the field “SUBELS” */
	uint8_t subels[0];		/*!< Used as field “Other SubElements” of the sole Neighbor Report included within the BSS Trans. Mgmt. Req. frame as Candidate#1 */
} QRPE_DRV_BTM_REQ_T;

#define QRPE_DRV_EVENT_INTF_STATUS		QRPE_EVENT_INTF_STATUS		/*!< Reporting when interface status changed(except the delete/down/up that will be monitored by upper) */
#define QRPE_DRV_EVENT_PROBE_REQ		QRPE_EVENT_PROBE_REQ		/*!< Reporting when probe req received */
#define QRPE_DRV_EVENT_CONNECT_COMPL		QRPE_EVENT_CONNECT_COMPLETE	/*!< Reporting when STA associated with */
#define QRPE_DRV_EVENT_DEAUTH			QRPE_EVENT_DEAUTH		/*!< Reporting when STA deauthed(issued by local or remote) */
#define QRPE_DRV_EVENT_DISASSOC			QRPE_EVENT_DISASSOC		/*!< Reporting when STA disassociated(issued by local or remote */
#define QRPE_DRV_EVENT_BSS_TRANS_STATUS		QRPE_EVENT_BSS_TRANS_STATUS	/*!< Reporting when BSS Trans. Response received */
#define QRPE_DRV_EVENT_STA_PHY_STATS		QRPE_EVENT_STA_PHY_STATS	/*!< Reporting when some associated STA's phy statistics updated, now is just for BSA on pearl */
#define QRPE_DRV_EVENT_INTF_UPDATE_NOTIFY	QRPE_EVENT_INTF_UPDATE_NOTIFY	/*!< Reporting when interface's configuration changed */
#define QRPE_DRV_EVENT_AUTH			QRPE_EVENT_AUTH			/*!< Reporting when auth received */
#define QRPE_DRV_EVENT_ASSOC_REQ		QRPE_EVENT_ASSOC_REQ		/*!< Reporting when (re)assoc received */
#define QRPE_DRV_EVENT_FRAME			QRPE_EVENT_FRAME		/*!< Reporting when registered frame received */
#define QRPE_DRV_EVENT_ROAM_FAIL		QRPE_EVENT_ROAM_FAIL 		/*!< Reporting when STA roam status failed */
#define QRPE_DRV_EVENT_ASSOC_ADDITIONAL_INFO	QRPE_EVENT_ASSOC_ADDITIONAL_INFO	/*!< Report additional info.*/
#define QRPE_DRV_EVENT_CHAN_STATE_CAC	 	QRPE_EVENT_CHAN_STATE_CAC	/*!< Reporting when channel status changed by CAC */
#define QRPE_DRV_EVENT_CHAN_STATE_UPDATE	QRPE_EVENT_CHAN_STATE_UPDATE 	/*!< Reporting when channel status changed by setting */
#define QRPE_DRV_EVENT_RADIO_PWRSAVE		QRPE_EVENT_RADIO_PWRSAVE	/*!< Reporting when radio power save status changed */
#define QRPE_DRV_EVENT_SPDIA_INFO		QRPE_EVENT_SPDIA_INFO		/*!< Reporting when SPDIA clooceted */

/**
 * @brief structure of interface status, used for QRPE_DRV_EVENT_INTF_STATUS event
 * @see QRPE_DRV_EVENT_INTF_STATUS
 */
typedef struct {
#define QRPE_INTF_STATUS_TYPE_NORMAL	0
#define QRPE_INTF_STATUS_TYPE_CAC	1
	int type;			/*!< Status type: normal(0); cac(1) */
#define QRPE_INTF_STATUS_DELETED	0
#define QRPE_INTF_STATUS_UP		1
#define QRPE_INTF_STATUS_DOWN		2

#define QRPE_INTF_CAC_STATE_NOTRUNNING	0
#define QRPE_INTF_CAC_STATE_RUNNING	1
	int status;			/*!< Status: normal: deleted(0), up(1), down(2); cac: notrunning(0), running(1) */
	int all_bss;			/*!< If status reported on main bss interface, will set for all BSSes on same radio */
} QRPE_DRV_INTF_STATUS_T;

/**
 * @brief structure of radio status, used for QRPE_DRV_EVENT_RADIO_STATUS_PWRSAVE event
 * @see QRPE_DRV_EVENT_RADIO_STATUS_PWRSAVE
 */
typedef struct {
	uint8_t ps_state;
} QRPE_DRV_RADIO_PWRSAVE_STATUS_T;

/**
 * @brief structure of probe from sta, used for QRPE_DRV_EVENT_PROBE_REQ event
 * @see QRPE_DRV_EVENT_PROBE_REQ
 */
typedef struct {
	uint8_t peer_mac[ETH_ALEN];	/*!< Mac Address of device frame was received from or send to */
	uint16_t curr_band;		/*!< Current band 2.GHz or 5GHz of station */
	int32_t rssi;			/*!< RSSI value of received Probe Request */
	uint16_t rx_ss_info;		/*!< Max supported RX spatial streams */
	uint16_t max_phy_rate;		/*!< Max PHY rate that this client can support */
	uint64_t tstamp;		/*!< Timestamp of the received probe request */
	uint8_t channel;		/*!< Channel where the Probe was decoded */
	uint8_t band_width;		/*!< Supported Bandwidth */
	uint8_t support_11v:1;		/*!< Set if "BSS Transition Field" (bit19 of Capability Field) in Extended Capabilities IE is set */
	uint8_t support_vht:1;		/*!< Set if the the “VHT Capabilities” IE is present */
	uint8_t support_ht:1;		/*!< Set if the the “HT Capabilities” IE is present */
	uint8_t mumimo_capab:2;		/*!< The “MU Beamformer Capable“ (bit19/20 of VHT Cap Field) */
	uint8_t support_he:1;		/*!< Set if the the “HE Capabilities” IE is present */
	uint16_t cookie_len;		/*!< Private data length (0 if next field is not provided) */
	uint8_t cookie[0];		/*!< Private data pointer (Probe request frame) if previous field is non zero */
} QRPE_DRV_PROBE_REQ_T;

/**
 * @brief structure of auth from sta, used for QRPE_DRV_EVENT_AUTH event
 * @see QRPE_DRV_EVENT_AUTH
 */
typedef struct {
	uint8_t peer_mac[ETH_ALEN];	/*!< Mac Address of the peer device */
	uint8_t curr_band;		/*!< Current band 2.GHz or 5GHz of station */
	uint8_t channel;		/*!< Channel where the Probe was decoded */
	int32_t rssi;			/*!< RSSI value of received Probe Request */
	uint64_t tstamp;		/*!< Timestamp of the received probe request */
	uint16_t cookie_len;		/*!< Private data length (0 if next field is not provided) */
	uint8_t cookie[0];		/*!< Private data pointer (Probe request frame) if previous field is non zero */
} QRPE_DRV_AUTH_T;

/**
 * @brief structure of (re)assoc from sta, used for QRPE_DRV_EVENT_ASSOC event
 * @see QRPE_DRV_EVENT_ASSOC
 */
typedef QRPE_DRV_PROBE_REQ_T QRPE_DRV_ASSOC_REQ_T;

/**
 * @brief structure of sta connect, used for QRPE_DRV_EVENT_CONNECT_COMPL event
 * @see QRPE_DRV_EVENT_CONNECT_COMPL
 */
typedef struct {
	uint8_t peer_mac[ETH_ALEN];	/*!< Mac Address of the peer device */
	uint16_t rx_ss_info;		/*!< Max supported RX spatial streams */
	uint16_t max_phy_rate;		/*!< Max PHY rate that this client can support */
	uint8_t node_type;		/*!< Node type: unknow(0), ap(1), sta(2), wds(3), tdls(4), repeater(5), notwifi(6) */
	uint8_t curr_band;		/*!< Current band 2.GHz or 5GHz of station */
	uint8_t channel;		/*!< Current operating channel of station */
	uint8_t band_width;		/*!< Supported Bandwidth */
	uint8_t support_11v:1;		/*!< Set if "BSS Transition Field" (bit19 of Capability Field) in Extended Capabilities IE is set */
	uint8_t support_vht:1;		/*!< Set if the the “"VHT Capabilities” IE is present */
	uint8_t support_ht:1;		/*!< Set if the the “"HT Capabilities” IE is present */
	uint8_t mumimo_capab:2;		/*!< “MU Beamformer Capable“ (bit19/20 of VHT Cap Field) */
	uint8_t support_he:1;		/*!< Set if the the “HE Capabilities” IE is present */
	uint16_t cookie_len;		/*!< Private data length (0 if next field is not provided) */
	uint8_t cookie[0];		/*!< Private data pointer (Associate request frame) if previous field is non zero */
} QRPE_DRV_CONNECT_T;

/**
 * @brief structure of sta connect, used for QRPE_DRV_EVENT_BSS_TRANS_STATUS event
 * @see QRPE_DRV_EVENT_BSS_TRANS_STATUS
 */
typedef struct {
	uint8_t sta_mac[ETH_ALEN];	/*!< Mac Address of station */
	uint16_t status_code;		/*!< Status Code from BSS Transition Management Request */
} QRPE_DRV_TRANS_STATUS_T;

/**
 * @brief structure of sta disassoc, used for QRPE_DRV_EVENT_DISASSOC event
 * @see QRPE_DRV_EVENT_DISASSOC
 */
typedef struct {
	uint8_t peer_mac[ETH_ALEN];	/*!< Mac Address of station */
	uint16_t reason_code;		/*!< Disassociate reason code */
	uint8_t direction;		/*!< BSS generate disassoc or received from peer client: self(0), peer(1) */
} QRPE_DRV_DISASSOC_T;

/**
 * @brief structure of sta deauth, used for QRPE_DRV_EVENT_DEAUTH event
 * @see QRPE_DRV_EVENT_DEAUTH
 */
typedef QRPE_DRV_DISASSOC_T QRPE_DRV_DEAUTH_T;

/**
 * @brief structure for management frame, used for QRPE_DRV_EVENT_FRAME event
 * @see QRPE_DRV_EVENT_FRAME
 */
typedef struct {
	int32_t rssi_dbm;		/*!< Rssi of the Frame received */
	uint8_t channel;		/*!< Channel of the Frame received from */
	uint8_t erw_result;		/*!< ERW result: 0: no withhold and reject; 1: withhold; 2: reject */
	uint32_t frame_len;		/*!< Frame Lenght */
	uint8_t frame[0];		/*!< Content of the Frame received */
} QRPE_DRV_FRAME_T;

#ifdef CONFIG_SUPPORT_QTNA_SPDIA
/**
 * @brief structure of SPDIA info, used for QRPE_DRV_EVENT_SPDIA_INFO event
 * @see QRPE_DRV_EVENT_SPDIA_INFO
 */
typedef struct {
	uint8_t peer_mac[ETH_ALEN];	/*!< Mac Address of the peer device */
#define QRPE_DRV_MAX_CHAINS	8
	uint8_t chains;
	int32_t rssis[QRPE_DRV_MAX_CHAINS];	/*!< Per chain RSSI */
	int32_t hw_noise;		/*!< Receiver noise estimate(multipled by 10) */
	uint64_t timestamp;		/*!< Info collected releative time (ms) */
	uint8_t bf_mode;		/*!< 11ac - 1, 11n - 0 */
	uint8_t nc;			/*!< Number of columns in CSI matrix */
	uint8_t nr;			/*!< Number of rows in CSI matrix */
	uint8_t ng;			/*!< Grouping parameter */
	uint8_t bw;			/*!< BW of current frame(0 - 20MHz, 1 - 40MHz, 2 - 80MHz) */
	uint8_t chan;			/*!< Channel of current transmission */
	uint8_t mcs;			/*!< MCS of current packet */
	uint8_t mcs_ss;			/*!< Number of streams used for MCS */
	uint32_t ntones;		/*!< Number of subcarriers */
	uint32_t payload_len;		/*!< Payload len */
	uint8_t *payload;		/*!< Payload */
} QRPE_DRV_SPDIA_INFO_T;
#endif

/**
 * @brief channel attributes
 */
typedef struct {
	uint8_t chan; 				/*!< Channel number */
#define QRPE_DRV_CHAN_STATUS_NON_OPERABLE 	(0)
#define QRPE_DRV_CHAN_STATUS_CAC_REQUIRED 	(1)
#define QRPE_DRV_CHAN_STATUS_RADAR_DETECTED 	(2)
#define QRPE_DRV_CHAN_STATUS_CAC_VALID		(3)
#define QRPE_DRV_CHAN_STATUS_AVAILABLE		(4)
	uint8_t status; 			/*!< Channel status */
	uint8_t min_freq_separation;		/*!< Minimum frequency separation (in multiples of 10 MHz) that this radio would require when operating on this channel */
} QRPE_DRV_CHAN_ENTRY_T;

/**
 * @brief operation class attributes
 */
typedef struct {
	uint8_t global_opclass; 		/*!< Global operation class id */
	uint8_t bandwidth; 			/*!< bandwidth */
	uint8_t max_power; 			/*!< Max tx power operating on this opclass */
#define QRPE_DRV_CHAN_MAXNUM_PER_OPCLASS    32
	uint8_t chan_nums; 			/*!< Number of channels that opclass supported */
	QRPE_DRV_CHAN_ENTRY_T chans[QRPE_DRV_CHAN_MAXNUM_PER_OPCLASS];   /*!< channels belongs to this operation class, ended with 0 */
} QRPE_DRV_OPCLASS_ENTRY_T;

/**
 * @brief radio information, used for get_radio_info ops in QRPE_DRIVER_OPS_T
 */
typedef struct {
	uint8_t max_bsses;                      /*!< Max bss numbers supported on this radio */
	uint8_t ps_status;			/*!< Radio power save status */
#define QRPE_DRV_OPCLASS_MAXNUM 32
	uint8_t opclass_nums; 			/*!< Numbers of opclass that radio supported */
	QRPE_DRV_OPCLASS_ENTRY_T opclass[QRPE_DRV_OPCLASS_MAXNUM];      /*!< Operation Classes supported on this radio, ended with 0 */
} QRPE_DRV_RADIO_INFO_T;

/**
 * @brief psk-keyid information, used for QRPE_DRV_EVENT_ASSOC_ADDITIONAL_INFO event
 * @see QRPE_DRV_EVENT_ASSOC_ADDITIONAL_INFO
 */
#define PSK_KEYID_LEN_MAX	32
typedef struct {
	uint8_t sta_mac[ETH_ALEN];
	uint16_t len_keyid;
	uint8_t keyid[PSK_KEYID_LEN_MAX];
} QRPE_DRV_ASSOC_ADDITIONAL_INFO;


#define QRPE_INTF_ENABLE	1	/*!< for set_status ops, enable the RPE function on one interface */
#define QRPE_INTF_DISABLE	0	/*!< for set_status ops, disable the RPE function on one interface */

#define QRPE_SUBTYPE_ASSOC_REQ		0x00
#define QRPE_SUBTYPE_ASSOC_RESP		0x10
#define QRPE_SUBTYPE_REASSOC_REQ	0x20
#define QRPE_SUBTYPE_REASSOC_RESP	0x30
#define QRPE_SUBTYPE_PROBE_REQ		0x40
#define QRPE_SUBTYPE_PROBE_RESP		0x50
#define QRPE_SUBTYPE_BEACON		0x80
#define QRPE_SUBTYPE_ATIM		0x90
#define QRPE_SUBTYPE_DISASSOC		0xa0
#define QRPE_SUBTYPE_AUTH		0xb0
#define QRPE_SUBTYPE_DEAUTH		0xc0
#define QRPE_SUBTYPE_ACTION		0xd0
#define QRPE_SUBTYPE_ACTION_NOACK	0xe0

/* register frame support flags */
#define QRPE_DRV_REG_FLAG_BYPASS	0x01
#define QRPE_DRV_REG_FLAG_SKB_COPY	0x02
#define QRPE_DRV_REG_FLAG_RECV		0x04
#define QRPE_DRV_REG_FLAG_XMIT		0x08
#define QRPE_DRV_REG_FLAG_DEL_ALL	0x80

/**
 * @brief prototype of the receving event's callback function
 * @param param1	bssid of the event reporter
 * @param param2	event id
 * @param param3	event data
 */
typedef void (*QRPE_DRV_EVENT_CALLBACK_F)(uint8_t *, uint32_t, void *);

#define QRPE_FDSET_TYPE_READ	0	/*!< for init_fdset/check_and_process_fdset ops, read fdset */
#define QRPE_FDSET_TYPE_WRITE	1	/*!< for init_fdset/check_and_process_fdset ops, write fdset */
#define QRPE_FDSET_TYPE_ERROR	2	/*!< for init_fdset/check_and_process_fdset ops, error fdset */

/**
 * @brief mask of current/off channel monitor, used for start/stop monitor driver operations
 */
#define QRPE_DRV_MONITOR_MASK	(1 << 0)
#define QRPE_DRV_OMONITOR_MASK	(1 << 1)

/**
 * @brief mask of driver feature that support, used for QRPE_CMD_CTRL_INTF_FEAT command
 */
#define QRPE_DRV_INTF_FEAT_MONITOR		(1 << 3)
#define QRPE_DRV_INTF_FEAT_MAP_BSTA		(1 << 7)
#define QRPE_DRV_INTF_FEAT_OMONITOR_AUTO	(1 << 8)
#define QRPE_DRV_INTF_FEAT_OMONITOR_ONDEMAND	(1 << 9)
#define QRPE_DRV_INTF_FEAT_IGNORE_HWPBC 	(1 << 15)

/**
 * @brief driver operations structure
 */
typedef struct {
	const char *name;	/*!< Name of the driver ops */
	const char *desc;	/*!< Description of the driver ops */
	/**
	* Check whether the interface belongs to this driver ops by ifname.
	* @param[in]	ifname		interface name
	* @return	0 for Yes OR negitive for No
	*/
	int (*probe_intf)(const char *ifname);
	/**
	* Check whether the interface is radio name belongs to this driver.
	* @param[in]    ifname          interface name
	* @return       0 for Yes OR negitive for No
	*/
	int (*probe_radio)(const char *ifname);
	/**
	* Init the driver context.
	* @param[in]	cb		callback function for event reporting
	* @return	0 for Sucessful OR negitive for Fail
	* @see		QRPE_DRV_EVENT_CALLBACK_F
	*/
	int (*init)(QRPE_DRV_EVENT_CALLBACK_F cb);
	/**
	* Init radio.
	* @param[in]    ifname          radio interface name
	* @return       private data
	* @note         the return value used by other radio related ops
	*/
	void * (*init_radio)(const char *ifname);
	/**
	* Deinit one radio.
	* @param[in]	priv		radio's private data. @see init_radio
	*/
	void (*deinit_radio)(void *priv);
	/**
	* Deinit the driver context.
	*/
	void (*deinit)(void);
	/**
	* Set the driver's fds for listening.
	* @param[in]	type		fds type
	* @param[out]	fds		Fdset
	* @return	Max fd of these fds, OR -1 if no fd to set
	* @see		QRPE_FDSET_TYPE_READ
	* @see		QRPE_FDSET_TYPE_WRITE
	* @see		QRPE_FDSET_TYPE_ERROR
	*/
	int (*init_fdset)(uint8_t type, fd_set *fds);
	/**
	* Check the driver's fds and process the fds if setted.
	* @param[in]	type		fds type
	* @param[in]	fds		Fdset
	* @see		QRPE_FDSET_TYPE_READ
	* @see		QRPE_FDSET_TYPE_WRITE
	* @see		QRPE_FDSET_TYPE_ERROR
	*/
	void (*check_and_process_fdset)(uint8_t type, fd_set *fds);

	/**
	* Init one interface.
	* @param[in]	ifname		interface name
	* @return	private data
	* @note		the return value used by other ops
	*/
	void * (*init_intf)(const char *ifname);
	/**
	* Deinit one interface.
	* @param[in]	priv		interface's private data. @see init_intf
	*/
	void (*deinit_intf)(void *priv);
	/**
	* Set the rpe function on interface.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	status		enable or disable the rpe function. @see QRPE_INTF_ENABLE @see QRPE_INTF_DISABLE
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*set_status)(void *priv, uint8_t status);
	/**
	* Deauth one STA.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	sta		mac of STA needed to be deauthed
	* @param[in]	reason		deauth reason code
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*deauth_sta)(void *priv, uint8_t *sta, uint16_t reason);
	/**
	* Disassoc one STA.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	sta		mac of STA needed to be deauthed
	* @param[in]	reason		deauth reason code
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*disassoc_sta)(void *priv, uint8_t *sta, uint16_t reason);
	/**
	* Filter one STA.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	sta		mac of STA needed to be filtered
	* @param[in]	accept		0 for deny, others for allow
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*filter_sta)(void *priv, uint8_t *sta, uint8_t accept);
	/**
	* Set erw for STAs.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	op		operation id: 0: set erw table; 1: remove all; 2: update erw nr table; 3: delete erw nr table
	* @param[in]	erw		param for erw sub ops
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*set_erw)(void *priv, uint8_t op, void *erw);
	/**
	* Get interface infomation.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	sub_cmd		which infomation to get, 0 for all info, 2 for reserved, 3 for FAT
	* @param[out]	intf_info	interface infomation result
	* @return	0 for Sucessful OR negitive for Fail
	* @see		QRPE_DRV_INTF_INFO_T
	*/
	int (*get_intf_info)(void *priv, int sub_cmd, QRPE_DRV_INTF_INFO_T *intf_info);
	/**
	* Get radio infomation.
	* @param[in]    priv            radio's private data. @see init_radio
	* @param[out]   radio_info      radio infomation result
	* @return       0 for Sucessful OR negitive for Fail
	* @see          QRPE_DRV_RADIO_INFO_T
	*/
	int (*get_radio_info)(void *priv, QRPE_DRV_RADIO_INFO_T *radio_info);
        /**
	 * Get channel status.
	 * @param[in]    priv            radio's private data. @see init_radio
	 * @param[in]    chan            channel number definition in spec
	 * @param[out]   status		 channel cac status result
	 * @return       0 for Sucessful OR negitive for Fail
	 * @see          QRPE_DRV_CHAN_ENTRY_T
	 */
	int (*get_chan_status)(void *priv, uint8_t chan, uint8_t *status);
	/**
	* Get assocaited STA's statistics.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	sta		mac address of station for which info are requested, broadcast for all associated stations
	* @param[out]	stats		statistics result
	* @return	0 for Sucessful OR negitive for Fail
	* @see		QRPE_DRV_STA_STATS_T
	*/
	int (*get_sta_stats)(void *priv, uint8_t *sta, QRPE_DRV_STA_STATS_T *stats);
	/**
	* Get non-assocaited STA's statistics(by monitor).
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	sta		mac address of station for which info are requested, broadcast for all monitored stations
	* @param[out]	stats		statistics result
	* @return	0 on Successful OR negitive on Fail
	* @see		QRPE_DRV_STA_STATS_T
	*/
	int (*get_monitor_sta_stats)(void *priv, uint8_t *sta, QRPE_DRV_STA_STATS_T *stats);
	/**
	* Start fat monitoring.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	period		periodicity [s] of the fat monitoring function
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*start_fat_monitor)(void *priv, uint32_t period);
	/**
	* Start monitoring.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	period		periodicity [ms] of the monitoring function
	* @param[in]	duty_cycle	percentage of time to spend in monitor mode
	* @param[in]    mask		support current/off channel monitor mode mask
	* @see		QRPE_DRV_MONITOR_MASK
	* @see		QRPE_DRV_OMONITOR_MASK
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*start_monitor)(void *priv, uint32_t period, uint32_t duty_cycle, uint8_t mask);
	/**
	* Stop monitoring.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]    mask		support current/off channel monitor mode mask
	* @see		QRPE_DRV_MONITOR_MASK
	* @see		QRPE_DRV_OMONITOR_MASK
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*stop_monitor)(void *priv, uint8_t mask);
	/**
	* Ask driver to report QRPE_DRV_EVENT_CONNECT_COMPL for all associated STAs.
	* @param[in]	priv		interface's private data. @see init_intf
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*report_associated_stas)(void *priv);
	/**
	* Ask driver to send unsolicited BSS Transmission Request.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	req		parampters for this request
	* @return	0 for Sucessful OR negitive for Fail
	* @see		QRPE_DRV_BTM_REQ_T
	*/
	int (*send_btm_req)(void *priv, QRPE_DRV_BTM_REQ_T *req);
	/**
	* Ask driver to send frame on specified channel, required for RPEv6.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	channel		channel sent on, 0: current channel
	* @param[in]	frame		frame need to be sent
	* @param[in]	frame_len	frame length
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*send_frame)(void *priv, uint8_t channel, uint8_t *frame, uint16_t frame_len);
	/**
	* Ask driver to register management frame, required for RPEv6.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	subtype		sub type of the management
	* @param[in]	match		value of the bytes to match against the beginning of the frame payload
	* @param[in]	match_len	number of bytes to match against the beginning of the frame payload
	* @param[in]	flags 		flags of registrable frame:
	* 				QRPE_REG_FLAG_BYPASS(0x01), QRPE_REG_FLAG_SKB_COPY(0x02),
	* 				QRPE_REG_FLAG_RECV(0x04), QRPE_REG_FLAG_XMIT(0x08)
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*register_frame)(void *priv, uint8_t subtype, uint8_t *match, uint8_t match_len, uint8_t flags);
	/**
	* Ask driver to update the APP IEs, required for RPEv6.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	subtype		the sub type of the management the ies attched into, @see SUBTYPE
	* @param[in]	ies		ies payload
	* @param[in]	ies_len		length of the ies payload
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*update_ies)(void *priv, uint8_t subtype, uint8_t *ies, uint32_t ies_len);
	/**
	* Ask driver to update the bits in extended capabilities IE, required for RPEv6.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	extcap		extended capabilities, the format is the same as the IE contents
	* @param[in]	extcap_mask	those bits that needed to be updated
	* @param[in]	extcap_len	length of the extended capabilities
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*update_extcap)(void *priv, uint8_t *extcap, uint8_t *extcap_mask, uint16_t extcap_len);
	/**
	* Ask driver to update the third byte in the country code IE, required for RPEv6.
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	val		the 3rd byte of the country code string
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*update_3rd_cc)(void *priv, uint8_t val);
#ifdef CONFIG_SUPPORT_QTNA_SPDIA
	/**
	* Ask driver to start/stop the SPDIA collection and reporting for specified STA
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	sta		mac address of station requested
	* @param[in]	period		reporting period(ms), and 0 means stop
	* @param[in]	spdia_feature	The combination of enable/disable tone reordering and operation mode setting
	* @param[in]	ng		decimation control
	* @param[in]	smooth		channel smoothing
	* @return	0 on Successful OR negitive on Fail
	*/
	int (*ctrl_sta_spdia)(void *priv, uint8_t *sta, uint16_t period,
		uint8_t spdia_feature, uint8_t ng, uint8_t smooth);
#endif
	/**
	* Change the channel and bandwidth for the interface.
	* @param[in]    priv            radio's private data. @see init_radio
	* @param[in]    ch              channel number
	* @param[in]    bw              bandwidth
	* @return       0 for Sucessful OR negitive for Fail
	*/
	int (*change_chan)(void *priv, uint8_t ch, uint8_t bw);
	/**
	* Set the beacon and mangement power backoff for the interface.
	* @param[in]    priv            interface's private data. @see init_intf
	* @param[in]    backoff         management frame tx power backoff
	* @return       0 for Sucessful OR negitive for Fail
	*/
	int (*set_power_backoff)(void *priv, uint8_t backoff);
	/**
	* Ask driver to enable/disable backhaul sta feature
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	enable		enable or disable backhaul sta feature
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*set_backhaul_sta)(void *priv, uint8_t enable);
	/**
	* Ask hostapd to ignore hardware WPS PBC
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	enable		enable or disable ignore hardware WPS PBC
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*ignore_hw_pbc)(void *priv, uint8_t enable);
	/**
	* Ask driver to perform a monitoring for non-associated STA on specified channel
	* @param[in]	priv		interface's private data. @see init_intf
	* @param[in]	channel		channel number
	* @return	0 for Sucessful OR negitive for Fail
	*/
	int (*start_omonitor_ondemand)(void *priv, uint8_t channel);
	/**
	 * * Roam self to target bssid, only valid for STA mode interface.
	 * * @param[in]    priv            intf's private data. @see init_intf
	 * * @param[in]    target          target bssid
	 * * @param[in]    ch              target channel
	 * * @param[in]    opclass         target operation class
	 * * @return       0 for Sucessful OR negitive for Fail
	 * */
	int (*roam)(void *priv, uint8_t *target, uint8_t ch, uint8_t opclass);
} QRPE_DRIVER_OPS_T;

typedef struct {
	char ifname[IFNAMSIZ];
	uint8_t ifmac[ETH_ALEN];
	uint8_t radio_uid[ETH_ALEN]; 	/*!< Intf created on which raido @see QRPE_RADIO_T */
	int ifindex;
#define QPRE_INTF_STATUS_SHIFT		0
#define QPRE_INTF_STATUS_MASK		0x3

#define QPRE_INTF_CAC_STATE_SHIFT	2
#define QPRE_INTF_CAC_STATE_MASK	0x1
	int status;
	QRPE_DRV_INTF_INFO_T info;
	void *priv;
	const QRPE_DRIVER_OPS_T *ops;
} QRPE_INTF_T;

typedef struct {
	char ifname[IFNAMSIZ]; 		/*!< Radio interface name, wifi0 for topaz, wifiX_0 for pearl */
	uint8_t uid[ETH_ALEN]; 		/*!< Radio Unique Identifier, can use mac address as UID */
	uint32_t intf_mask; 		/*!< Indicate which intf belongs to this radio */
	QRPE_DRV_RADIO_INFO_T info; 	/*!< Radio information, can used by CHANGE_CHAN for operation class translate to bandwidth */
	void *priv;			/*!< Radio private context, for QTNA driver, can store the primary interface name for QCSAPI */
	const QRPE_DRIVER_OPS_T *ops; 	/*!< Driver operations */
} QRPE_RADIO_T;

#define QRPE_INTF_SET_STATUS(_intf, _v)		QRPE_SET_BITS((_intf)->status, _v, QPRE_INTF_STATUS_MASK, QPRE_INTF_STATUS_SHIFT)
#define QRPE_INTF_GET_STATUS(_intf)		QRPE_GET_BITS((_intf)->status, QPRE_INTF_STATUS_MASK, QPRE_INTF_STATUS_SHIFT)
#define QRPE_INTF_SET_CAC_STATE(_intf, _v)	QRPE_SET_BITS((_intf)->status, _v, QPRE_INTF_CAC_STATE_MASK, QPRE_INTF_CAC_STATE_SHIFT)
#define QRPE_INTF_GET_CAC_STATE(_intf)		QRPE_GET_BITS((_intf)->status, QPRE_INTF_CAC_STATE_MASK, QPRE_INTF_CAC_STATE_SHIFT)

static inline int qrpe_driver_set_status(QRPE_INTF_T *intf, uint8_t status)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->set_status)
		ret = intf->ops->set_status(intf->priv, status);
	return ret;
}

static inline int qrpe_driver_deauth_sta(QRPE_INTF_T *intf, uint8_t *sta, uint16_t reason)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->deauth_sta)
		ret = intf->ops->deauth_sta(intf->priv, sta, reason);
	return ret;
}

static inline int qrpe_driver_disassoc_sta(QRPE_INTF_T *intf, uint8_t *sta, uint16_t reason)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->disassoc_sta)
		ret = intf->ops->disassoc_sta(intf->priv, sta, reason);
	return ret;
}

static inline int qrpe_driver_filter_sta(QRPE_INTF_T *intf, uint8_t *sta, uint8_t accept)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->filter_sta)
		ret = intf->ops->filter_sta(intf->priv, sta, accept);
	return ret;
}

static inline int qrpe_driver_set_erw(QRPE_INTF_T *intf, uint8_t op, void *erw)
{
	int ret = -1;
	if (intf->ops && intf->ops->set_erw)
		ret = intf->ops->set_erw(intf->priv, op, erw);
	return ret;
}

static inline int qrpe_driver_get_intf_info(QRPE_INTF_T *intf, int sub_cmd, QRPE_DRV_INTF_INFO_T *intf_info)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->get_intf_info)
		ret = intf->ops->get_intf_info(intf->priv, sub_cmd, intf_info);
	return ret;
}

static inline int qrpe_driver_get_sta_stats(QRPE_INTF_T *intf, uint8_t *sta, QRPE_DRV_STA_STATS_T *stats)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->get_sta_stats)
		ret = intf->ops->get_sta_stats(intf->priv, sta, stats);
	return ret;
}

static inline int qrpe_driver_get_monitor_sta_stats(QRPE_INTF_T *intf, uint8_t *sta,
	QRPE_DRV_STA_STATS_T *stats)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->get_monitor_sta_stats)
		ret = intf->ops->get_monitor_sta_stats(intf->priv, sta, stats);
	return ret;
}

static inline int qrpe_driver_start_fat_monitor(QRPE_INTF_T *intf, uint32_t period)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->start_fat_monitor)
		ret = intf->ops->start_fat_monitor(intf->priv, period);
	return ret;
}

static inline int qrpe_driver_start_monitor(QRPE_INTF_T *intf, uint32_t period,
	uint32_t duty_cycle, uint8_t mask)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->start_monitor)
		ret = intf->ops->start_monitor(intf->priv, period, duty_cycle, mask);
	return ret;
}

static inline int qrpe_driver_stop_monitor(QRPE_INTF_T *intf, uint8_t mask)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->stop_monitor)
		ret = intf->ops->stop_monitor(intf->priv, mask);
	return ret;
}

static inline int qrpe_driver_report_associated_stas(QRPE_INTF_T *intf)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->report_associated_stas)
		ret = intf->ops->report_associated_stas(intf->priv);
	return ret;
}

static inline int qrpe_driver_send_btm_req(QRPE_INTF_T *intf, QRPE_DRV_BTM_REQ_T *req)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->send_btm_req)
		ret = intf->ops->send_btm_req(intf->priv, req);
	return ret;
}

static inline int qrpe_driver_send_frame(QRPE_INTF_T *intf,
	uint8_t channel, uint8_t *frame, uint32_t frame_len)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->send_frame)
		ret = intf->ops->send_frame(intf->priv, channel, frame, frame_len);
	return ret;
}

static inline int qrpe_driver_register_frame(QRPE_INTF_T *intf,
	uint8_t subtype, uint8_t *match, uint32_t match_len, uint8_t flags)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->register_frame)
		ret = intf->ops->register_frame(intf->priv, subtype, match, match_len, flags);
	return ret;
}

static inline int qrpe_driver_update_ies(QRPE_INTF_T *intf,
	uint8_t subtype, uint8_t *ies, uint32_t ies_len)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->update_ies)
		ret = intf->ops->update_ies(intf->priv, subtype, ies, ies_len);
	return ret;
}

static inline int qrpe_driver_update_extcap(QRPE_INTF_T *intf,
	uint8_t *extcap, uint8_t *extcap_mask, uint16_t extcap_len)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->update_extcap)
		ret = intf->ops->update_extcap(intf->priv, extcap, extcap_mask, extcap_len);
	return ret;
}

static inline int qrpe_driver_update_3rd_cc(QRPE_INTF_T *intf,
	uint8_t val)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->update_3rd_cc)
		ret = intf->ops->update_3rd_cc(intf->priv, val);
	return ret;
}
#ifdef CONFIG_SUPPORT_QTNA_SPDIA
static inline int qrpe_driver_ctrl_sta_spdia(QRPE_INTF_T *intf, uint8_t *sta, uint16_t period,
	uint8_t spdia_feature, uint8_t ng, uint8_t smooth)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->ctrl_sta_spdia)
		ret = intf->ops->ctrl_sta_spdia(intf->priv, sta, period,
				spdia_feature, ng, smooth);
	return ret;
}
#endif

static inline int qrpe_driver_get_radio_info(QRPE_RADIO_T *radio, QRPE_DRV_RADIO_INFO_T *radio_info)
{
	int ret = -1;
	if (radio->ops && radio->ops->get_radio_info)
		ret = radio->ops->get_radio_info(radio->priv, radio_info);
	return ret;
}

static inline int qrpe_driver_get_chan_status(QRPE_INTF_T *intf, uint8_t chan, uint8_t *status)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->get_chan_status)
		ret = intf->ops->get_chan_status(intf->priv, chan, status);
	return ret;
}

static inline int qrpe_driver_change_chan(QRPE_RADIO_T *radio, uint8_t ch, uint8_t bw)
{
	int ret = -1;
	if (radio->ops && radio->ops->change_chan)
		ret = radio->ops->change_chan(radio->priv, ch, bw);
	return ret;
}

static inline int qrpe_driver_set_power_backoff(QRPE_INTF_T *intf, uint8_t backoff)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->set_power_backoff)
		ret = intf->ops->set_power_backoff(intf->priv, backoff);
	return ret;
}

static inline int qrpe_driver_set_backhaul_sta(QRPE_INTF_T *intf, uint8_t enable)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->set_backhaul_sta)
		ret = intf->ops->set_backhaul_sta(intf->priv, enable);
	return ret;
}

static inline int qrpe_driver_start_omonitor_ondemand(QRPE_INTF_T *intf, uint8_t channel)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->start_omonitor_ondemand)
		ret = intf->ops->start_omonitor_ondemand(intf->priv, channel);
	return ret;
}

static inline int qrpe_driver_ignore_hw_pbc(QRPE_INTF_T *intf, uint8_t enable)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->ignore_hw_pbc)
		ret = intf->ops->ignore_hw_pbc(intf->priv, enable);
	return ret;
}

static inline int qrpe_driver_roam(QRPE_INTF_T *intf, uint8_t *target, uint8_t ch, uint8_t opclass)
{
	int ret = -1;
	if (QRPE_INTF_GET_STATUS(intf) != QRPE_INTF_STATUS_DELETED
		&& intf->ops && intf->ops->roam)
		ret = intf->ops->roam(intf->priv, target, ch, opclass);
	return ret;
}

extern void qrpe_init_drivers(void);
extern void qrpe_deinit_drivers(void);
extern int qrpe_driver_init_fdset(uint8_t type, fd_set *fds);
extern void qrpe_driver_check_fdset(uint8_t type, fd_set *fds);
extern const QRPE_DRIVER_OPS_T *qrpe_driver_probe_intf(const char *ifname);
extern const QRPE_DRIVER_OPS_T *qrpe_driver_probe_radio(const char *ifname);

#ifdef QRPE_SUPPORT_QTNA_DRIVER
extern const QRPE_DRIVER_OPS_T qrpe_qtna_driver_ops;
#ifdef CONFIG_SUPPORT_QTNA_BACKBONE
extern void qrpe_qtna_wds_intf_status_changed(QRPE_INTF_T *intf);
extern int qrpe_qtna_check_first_intf(QRPE_INTF_T *intf);
#endif
#endif

#endif
