/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : qrpe_qtna_driver.h                                         **
**  Description : qrpe qtna driver definitions                               **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#ifndef __QRPE_QTNA_DRIVER_H__
#define __QRPE_QTNA_DRIVER_H__

#ifdef QRPE_QTNA_GENNETLINK
#include <netlink/genl/genl.h>
#include <netlink/genl/ctrl.h>
#include <linux/genetlink.h>
#endif

#define QRPE_QTNA_SYS_CONTROL_NAME	"/sys/devices/qdrv/control"
#define QRPE_QTNA_SYS_OUTDATA_NAME	"/proc/qdrvdata"
#define QRPE_QTNA_WPA_CLI_CMDNAME	"/usr/sbin/wpa_cli"
#define QRPE_QTNA_HOSTAPD_CLI_CMDNAME	"/usr/sbin/hostapd_cli"
#define QRPE_QTNA_CHANBW_BW_MASK	0x0000FFFF
#define QRPE_QTNA_CHANBW_BW_SHIFT	16


#ifdef CONFIG_SUPPORT_QTNA_SPDIA
#define QRPE_QTNA_SPDIA_CMDNAME		"csi_est"
#define QRPE_QTNA_SPDIA_SUBCMD_INTERVAL	"interval"
#define QRPE_QTNA_SPDIA_SUBCMD_STAMAC	"mac"
#define QRPE_QTNA_SPDIA_SUBCMD_STAMAC_ADD	"add"
#define QRPE_QTNA_SPDIA_SUBCMD_STAMAC_REMOVE	"remove"
#define QRPE_QTNA_SPDIA_SUBCMD_MODE		"mode"
#define QRPE_QTNA_SPDIA_SUBCMD_MODE_DATA	"data"
#define QRPE_QTNA_SPDIA_SUBCMD_MODE_NDP		"ndp"
#define QRPE_QTNA_SPDIA_SUBCMD_MODE_NONE	"none"
#define QRPE_QTNA_SPDIA_SUBCMD_NG		"ng"
#define QRPE_QTNA_SPDIA_SUBCMD_REORDER		"reorder"
#define QRPE_QTNA_SPDIA_SUBCMD_SMOOTH		"smooth"
#endif

#define QRPE_DRV_DATA_FORMAT_AGG_NONE		0x0
#define QRPE_DRV_DATA_FORMAT_AMSDU_SHIFT	0
#define QRPE_DRV_DATA_FORMAT_AMPDU_SHIFT	1

#define MASK_AC_DPDUR	0xFF000000
#define QRPE_MASK_AC_DUR(ac)			(MASK_AC_DPDUR >> (8 * ac))
#define QRPE_GET_AC_DUR(_val, _ac)	(((_val & QRPE_MASK_AC_DUR(_ac)) >> (8 * (3 - _ac))) & 0xFF)

#define QRPE_QTNA_CHAN_STATUS_NON_AVAILABLE			(0x1)
#define QRPE_QTNA_CHAN_STATUS_AVAILABLE 			(0x2)
#define QRPE_QTNA_CHAN_STATUS_NOT_AVAILABLE_RADAR_DETECTED	(0x4)
#define QRPE_QTNA_CHAN_STATUS_NOT_AVAILABLE_CAC_REQUIRED	(0x8)

/*macro for multi psk*/
#define HAPDCLI_OUTPUT_LINE_LEN_MAX		64
#define HAPDCLI_CMD_GETKEY "hostapd_cli show_sta_wpa_keyid"

typedef struct {
	int ioctl_sock;
	int rtm_sock;
#ifdef QRPE_QTNA_GENNETLINK
	struct nl_sock *drv_read_nl_sock;
	struct nl_cb *nlcb;
	int drv_read_sock;
#endif

#define QRPE_QTNA_SCAN_MAX_RETRIES	4
	uint8_t scan_retries; /* roam scan times */
	uint64_t tstamp; /* qtna sta roam timestamp */
	QRPE_DRV_ROAM_STATUS_T roam;

	QRPE_DRV_EVENT_CALLBACK_F cb;
} QRPE_QTNA_DRIVER_DATA_T;

typedef struct {
	char ifname[IFNAMSIZ];
	char radio_name[IFNAMSIZ];
} QRPE_QTNA_INTF_DATA_T;

typedef struct {
	char ifname[IFNAMSIZ];
	char qcsapi_ifname[IFNAMSIZ];
	uint8_t radio_id;
} QRPE_QTNA_RADIO_DATA_T;
#endif

