/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : rpecat.h                	                             **
**  Description : rpecat definitions 	 		                     **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#ifndef RPECAT_HEADER
#define REOCAT_HEADER
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <errno.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/param.h>
#include <sys/time.h>
#include <linux/filter.h>
#include <linux/if_ether.h>
#include <net/ethernet.h>
#include <netpacket/packet.h>
#include <fcntl.h>
#include <net/if.h>
#include <netinet/in.h>
#include <netinet/ether.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <sys/file.h>
#include <signal.h>
#include <netdb.h>
#include <sys/ioctl.h>
#include <net/route.h>
#include <endian.h>
#include <byteswap.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include "list.h"
#include "common.h"
#include "version.h"
#include "rpe_message.h"
#ifdef CONFIG_SUPPORT_GENNETLINK
#include "soniq_csm_rpe_comm.h"
#endif

#define RPE_RCVBUF_SIZE		(240 * 1024)
#define RPE_EVENT_PID		(-4000)

#define SET_FLAG(value, flag) (value) |= (flag)
#define CLEAR_FLAG(value, flag) (value) &= (~(flag))
#define FLAG_IS_SET(value, flag) (((value) & (flag)) == (flag))

#define RPECAT_HASH_SIZE	64
#define MAC_HASH_FUNC(mac)	(((mac)[4] ^ (mac)[5]) & (RPECAT_HASH_SIZE - 1))

#define RPECAT_DATA_FRAME	0x01
#define RPECAT_CTRL_FRAME	0x02

#define RAWLINK_PORT_UNKNOW	0x00
#define RAWLINK_PORT_MASTER	0x01
#define RAWLINK_PORT_SLAVE	0x0f

#define RAWLINK_HANDSHAKE_SYNC		0
#define RAWLINK_HANDSHAKE_SYNCACK	1
#define RAWLINK_HANDSHAKE_ACK		2
#define RAWLINK_DATA_ACK		3

#define RAWLINK_ACK_TIMEOUT		1
#define RAWLINK_HANDSHAKE_TIMEOUT	1
#define MAX_RETRY_COUNT			3

struct exthdr {
	uint8_t oui[3];
	uint16_t protocol;
} __attribute__ ((packed));

struct rawlink_hdr {
	struct ethhdr	eth_hdr;
	struct exthdr	ext_hdr;
#if __BYTE_ORDER == __LITTLE_ENDIAN
	uint8_t		port:4;
	uint8_t		type:4;
#elif __BYTE_ORDER == __BIG_ENDIAN
	uint8_t		type:4;
	uint8_t		port:4;
#endif
	uint8_t		payload[0];
} __attribute__ ((packed));

struct rawlink_data_frame {
	uint16_t	seq_num;
	uint16_t	len;
	uint16_t	msg_type;
#if __BYTE_ORDER == __LITTLE_ENDIAN
	uint8_t		retry:1;
	uint8_t		more:1;
	uint8_t		resv:6;
#elif __BYTE_ORDER == __BIG_ENDIAN
	uint8_t		resv:6;
	uint8_t		more:1;
	uint8_t		retry:1;
#endif
	uint8_t		frag_no;
	uint8_t		payload[0];
} __attribute__ ((packed));

struct rawlink_ctrl_frame {
	uint8_t		id;
	uint8_t		version;
	union {
		uint16_t	seq_num; /* only valid for data ack frame */
		uint8_t		port; /* *only valid for handshake frame */
	};
} __attribute__ ((packed));

#define RAWLINK_DATA_FRAME_HDRLEN (sizeof(struct rawlink_hdr) + sizeof(struct rawlink_data_frame))
#define RAWLINK_CTRL_FRAME_HDRLEN (sizeof(struct rawlink_hdr) + sizeof(struct rawlink_ctrl_frame))
#define RAWLINK_HDR(frame) (struct rawlink_hdr *)(frame)
#define RAWLINK_CTRL_HDR(frame) (struct rawlink_ctrl_frame *)(frame + sizeof(struct rawlink_hdr))
#define RAWLINK_DATA_HDR(frame) (struct rawlink_data_frame *)(frame + sizeof(struct rawlink_hdr))

struct frame_node {
	uint8_t *frame;
	struct frame_node *next;
};

struct queue {
	struct frame_node *head;
	struct frame_node *tail;
	pthread_mutex_t lock;
	uint32_t count;
};

#define MAX_RPE	2

#define LINK_FLAG_NETLINK	0x01
#define LINK_FLAG_RAW		0x02
#define LINK_FLAG_CSM		0x04
#define LINK_FLAG_RPE		0x08
#define LINK_FLAG_CONNECTED	0x10
#define LINK_FLAG_GENL		0x80

#define LINK_NAME(link) FLAG_IS_SET(link->flag, LINK_FLAG_RPE) ? "rpe" : "csm"

struct rpecat_link {
	uint8_t		flag;
	int		ro_sock;
	int		rw_sock;
	void		*link_ctx;	/* for genl link context */
	pthread_t 	thread;
	uint8_t		thread_running;
	pthread_cond_t	cond;
	pthread_mutex_t	cond_lock;
	struct queue	queue;
	/* below elements are only valid for rawlink */
	uint8_t		own_addr[ETH_ALEN];
	uint8_t		rmt_addr[ETH_ALEN];
	uint8_t		own_port;
	uint8_t		rmt_port;
	uint16_t	recv_seq_num;
	uint16_t	send_seq_num;
	uint32_t	retry_count;
	uint16_t	packing_seq_num;
	uint8_t		packing_frag_num;
};

struct rpe_map {
	struct list_head lh;
	uint8_t mac[ETH_ALEN];
	struct rpecat_link *rpe;
};

struct rpecat_ctx {
	struct rpecat_link *csm;
	struct rpecat_link *rpe[MAX_RPE];
	int rpe_num;
	struct list_head hash[RPECAT_HASH_SIZE]; /* BSS to rpe mapping list */
	pthread_mutex_t	map_lock;
	int cli_sock;
};

#define RPECAT_UN_PATH	"/tmp/.QTN_RPECAT_AF_UNIX"
#define ETH_P_OUI_EXT	0x88B7
#define QTN_OUI		0x002686
#define QTN_RPECAT_P	0xFB40

#define MIN_FRAME_LEN		64
#define MAX_FRAME_LEN		1400
#define MAX_RECV_BUF		(1024 * 36)
#define MAX_RAW_RECV_BUF	(1500)
#define MAX_CLI_FRAME_LEN	1024

#define MIN_RPEMSG_LEN		sizeof(RPE_MSG_T)
#define RPEMSG_INFO_LEN		128
#define RPEMSG_BIT(id)		(1 << (id - 1))

#define CUR_VERSION 0x01

#define RPECAT_ERROR(fmt, ...) rpecat_printf(LOG_ERR, "[RPECAT] "fmt, ##__VA_ARGS__)
#define RPECAT_WARN(fmt, ...) rpecat_printf(LOG_WARNING, "[RPECAT] "fmt, ##__VA_ARGS__)
#define RPECAT_NOTICE(fmt, ...) rpecat_printf(LOG_NOTICE, "[RPECAT] "fmt, ##__VA_ARGS__)
#define RPECAT_INFO(fmt, ...) rpecat_printf(LOG_INFO, "[RPECAT] "fmt, ##__VA_ARGS__)
#define RPECAT_DEBUG(fmt,...) rpecat_printf(LOG_DEBUG, "[RPECAT] "fmt, ##__VA_ARGS__)

#endif
