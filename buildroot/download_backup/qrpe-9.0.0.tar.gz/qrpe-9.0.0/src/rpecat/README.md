# rpecat - Concatenate CSM and remote RPE

## Why need rpecat
In current framework, CSM comminicate with RPE using netlink, the CSM and RPE must run in same CPU.  
rpecat is implemented to support NPU scenario (CSM is running on NPU, RPE is ruuning on Quantenna standalone chipset).

## How rpecat works
CSM---(netlink)---rpecat...(raw ethernet packet)...rpecat---(netlink)---RPE

## Typical application scenario 1: HGU
QHS840 connect to NPU via RGMII, RPE is running on QHS840, CSM is running on NPU.
Suppose the MAC address of QHS840 is 00:26:86:00:84:00  
QHS840:
```sh
rpecat -c rawlink -r netlink &
```
NPU:
```sh
rpecat -c netlink -r 00:26:86:00:84:00 &
```

## Typical application scenario 2: WFE
Two QHS840 connect to NPU via RGMII, RPE is running on two QHS840, CSM is running on NPU.
Support the MAC address of QHS840 is 00:26:86:00:84:01 and the MAC address of another QHS840 is 00:26:86:00:84:02  
QHS840:
```sh
rpecat -c rawlink -r netlink &
```
NPU:
```sh
rpecat -c netlink -r 00:26:86:00:84:01 -r 00:26:86:00:84:02 &
```

## Typical application scenario 3: QV864 with NPU
QHS860 connect to QHS840 via RGMII, QHS840 connect to NPU via RGMII, RPE is running on QHS860 and QHS840, CSM is running on NPU.
Support the MAC address of QHS860 is 00:26:86:00:86:00 and the MAC address of QHS840 is 00:26:86:00:84:00  
QHS860:
```sh
rpecat -c rawlink -r netlink &
```
QHS840:
```sh
rpecat -c rawlink -r netlink -r 00:26:86:00:86:00 &
```
NPU:
```sh
rpecat -c netlink -r 00:26:86:00:84:00 &
```
