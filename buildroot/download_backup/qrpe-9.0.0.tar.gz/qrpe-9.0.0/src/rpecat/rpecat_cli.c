/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : rpecat_cli.c                	                             **
**  Description : rpecat command line function 		                     **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#include "rpecat.h"

char cli_path[512];

static int cli_sock_open()
{
	int sd;
	struct sockaddr_un addr;
	int path_len;

	path_len = sprintf(cli_path, "%s-cli-%d", RPECAT_UN_PATH, getpid());
	if (path_len >= sizeof(addr.sun_path)) {
		printf("sun_path oversize\n");
		return -1;
	}

	sd = socket(PF_UNIX, SOCK_DGRAM, 0);
	if (sd < 0) {
		printf("Failed to open PF_UNIX socket: %s\n", strerror(errno));
		return -1;
	}

	unlink(cli_path);
	memset(&addr, 0, sizeof(addr));
	addr.sun_family = AF_UNIX;
	strncpy(addr.sun_path, cli_path, sizeof(addr.sun_path) - 1);
	if (bind(sd, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
		printf("Failed to bind to %s: %s\n", addr.sun_path, strerror(errno));
		close(sd);
		return -1;
	}

	return sd;
}

static int cli_req(int sd, char *req, int req_len)
{
	char rep[MAX_CLI_FRAME_LEN] = {0};
	struct timeval timeout;
	struct sockaddr_un addr;
	socklen_t addr_len;

	memset(&addr, 0, sizeof(addr));
	addr.sun_family = AF_UNIX;
	strcpy(addr.sun_path, RPECAT_UN_PATH);
	addr_len = sizeof(addr);

	if (sendto(sd, req, req_len, 0, (struct sockaddr *)&addr, addr_len) < 0) {
		printf("Failed to send cmd to rpecat: %s\n", strerror(errno));
		return 0;
	}

	timeout.tv_sec = 5;
	timeout.tv_usec = 0;
	if (setsockopt(sd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout)) < 0) {
		printf("Failed to set recv timeout: %s\n", strerror(errno));
		return 0;
	}

	if (recvfrom(sd, rep, sizeof(rep), 0, (struct sockaddr *)&addr, &addr_len) < 0) {
		printf("Failed to receive output from rpecat: %s\n", strerror(errno));
		return -2;
	}
	rep[MAX_CLI_FRAME_LEN - 1] = '\0';
	printf("%s", rep);

	return 0;
}

int main(int argc, char *argv[])
{
	int sd, i;
	char req[MAX_CLI_FRAME_LEN] = {0};
	char *pos;

	if (argc > 255) {
		printf("Too many parameters\n");
		return -1;
	}

	sd = cli_sock_open();
	if (sd < 0)
		return -1;

	req[0] = argc;
	pos = &req[1];
	for (i = 0; i < argc; ++i, ++pos)
		pos += snprintf(pos, req + MAX_CLI_FRAME_LEN - pos, "%s", argv[i]);

	cli_req(sd, req, pos - req);

	close(sd);
	unlink(cli_path);

	return 0;
}
