/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : rpecat.c                	                             **
**  Description : rpecat function 					     **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#include "rpecat.h"
#include <stdarg.h>
#include <syslog.h>
#include <getopt.h>

#ifndef QRPE_SUBVERSION
#define QRPE_SUBVERSION	"unknown"
#endif

struct rpecat_ctx rpecat;
int debug_level = LOG_NOTICE;
uint32_t queue_volume = 1024;
int rpecat_running = 1;
uint32_t event_filter = RPEMSG_BIT(EVENT_PROBE_REQ);
uint32_t cmd_filter = 0;

const struct option rpecat_opts[] = {
	{"help", no_argument, NULL, 'h'},
	{"version", no_argument, NULL, 'v'},
	{"dbglevel", required_argument, NULL, 'd'},
	{"interface", required_argument, NULL, 'i'},
	{"csm", required_argument, NULL, 'c'},
	{"rpe", required_argument, NULL, 'r'},
	{NULL, 0, NULL, 0 }
};

const char *event_names[] = {
	"Unknown",
	"EVENT_INTF_STATUS",
	"EVENT_INTF_INFO",
	"EVENT_PROBE_REQ",
	"EVENT_CONNECT_COMPLETE",
	"EVENT_DEAUTH",
	"EVENT_DISASSOC",
	"EVENT_STA_PHY_STATS",
	"EVENT_BSS_TRANS_STATS",
	"EVENT_STA_NONASSOC_STATS",
	"EVENT_AUTH",
	"EVENT_ASSOC_REQ",
	"EVENT_FRAME",
};

const char *cmd_names[] = {
	"Unknown",
	"CMD_INIT",
	"CMD_DEINIT",
	"CMD_GET_INTF_STATUS",
	"CMD_GET_INIT_INFO",
	"CMD_DEAUTH",
	"CMD_STA_MAC_FILTER",
	"CMD_GET_STA_STATS",
	"CMD_BSS_TRANS_REQ",
	"CMD_START_FAT_MONOTOR",
	"CMD_MONITOR_START",
	"CMD_MONITOR_STOP",
	"CMD_GET_NONASSOC_STATS",
	"CMD_FRAME",
	"CMD_REGISTER_FRAME",
	"CMD_SET_USER_CAP",
};

const char *log_names[] = {
	"Error",
	"Warning",
	"Notice",
	"Info",
	"Debug",
	"Dump",
};


void usage_and_exit()
{
	printf(
		"usage: rpecat [OPTIONS]\n"
		"   concatenate CSM and remote RPE\n"
		"   options are:\n"
		"     -h,--help		print this message.\n"
		"     -v,--version	show version of this program.\n"
		"     -d,--dbglevel	assign the debug level(0 ~ 5, 0:ERR 1:WARN 2:NOTICE 3:INFO 4:DEBUG 5:DUMP)\n"
		"     -i,--interface	assign interface name\n"
		"     -c,--csm		assign the link to csm, the parameters can be 'netlink' or 'rawlink'\n"
		"     -r,--rpe		assign the link to rpe, the parameters can be 'netlink' or the MAC address of the slave\n"
		);
	exit(0);
}

int rpemsg_to_str(RPE_MSG_T *rpemsg, uint16_t type, char *buf, int buf_len)
{
	int ret = 0;
	const char *unknow = "Unknown";
	const char *msg_name;
	uint16_t id = le_to_host16(rpemsg->id);

	if (type == RPE_EVENT) {
		if (id > 0 && id < sizeof(event_names) / sizeof(event_names[0])) {
			if (FLAG_IS_SET(event_filter, RPEMSG_BIT(id)))
				ret = -1;
			msg_name = event_names[id];
		} else
			msg_name = unknow;
	} else if (type == RPE_COMMAND) {
		if (id > 0 && id < sizeof(cmd_names)/ sizeof(cmd_names[0])) {
			if (FLAG_IS_SET(cmd_filter, RPEMSG_BIT(id)))
				ret = -1;
			msg_name = cmd_names[id];
		} else
			msg_name = unknow;
	} else {
		msg_name = unknow;
	}

	snprintf(buf, buf_len, "BSSID "MACSTR", %s", MAC2STR(rpemsg->bssid), msg_name);

	return ret;
}

int rpemsg_name_to_id(uint16_t type, char *name)
{
	int i;
	int max;
	const char **names;

	if (type == RPE_EVENT) {
		max = sizeof(event_names) / sizeof(event_names[0]);
		names = event_names;
	} else {
		max = sizeof(cmd_names) / sizeof(cmd_names[0]);
		names = cmd_names;
	}

	for (i = 1; i < max; ++i)
		if (strcmp(names[i], name) == 0)
			return i;
	return -1;
}

const char *handshark_to_str(uint8_t id)
{
	static const char *names[] = {
		"sync",
		"syncack",
		"ack",
	};

	if (id > 2)
		return "unknow";

	return names[id];
}

uint8_t *alloc_rawlink_frame(struct rpecat_link *link, uint8_t type, int len);

inline int is_zero_ether_addr(uint8_t *a)
{
	return !(a[0] | a[1] | a[2] | a[3] | a[4] | a[5]);
}

inline int is_broadcast_ether_addr(uint8_t *a)
{
	return (a[0] & a[1] & a[2] & a[3] & a[4] & a[5]) == 0xff;
}

void rpecat_printf(int level, const char *fmt, ...)
{
	va_list ap;

	if (debug_level < level)
		return;

	va_start(ap, fmt);

	if (level >= LOG_ERR && level <= LOG_DEBUG)
		printf("[%s] ", log_names[level - LOG_ERR]);
	vprintf(fmt, ap);

	va_end(ap);
}

int should_deliver_rpe_event(struct rpecat_link *link, uint16_t id)
{
	if (FLAG_IS_SET(link->flag, LINK_FLAG_RAW) &&
	    !FLAG_IS_SET(link->flag, LINK_FLAG_CONNECTED) &&
	    id == EVENT_PROBE_REQ)
		return 0;
	return 1;
}

void dump_frame(uint8_t *frame, int len, char *prefix)
{
	int i;

	if (debug_level <= LOG_DEBUG)
		return;

	printf("%s frame:", prefix);
	for (i = 0; i < len; ++i) {
		if ((i % 16) == 0){
			printf("\n0x%04x--0x%04x: ", i, i+16);
		}
		printf("%02x ", frame[i]);
	}
	printf("\n");
}

/* map function start */
struct rpecat_link *find_rpe(uint8_t *mac)
{
	struct rpe_map *map = NULL;
	struct rpecat_link *rpe = NULL;
	struct list_head *head = &rpecat.hash[MAC_HASH_FUNC(mac)];

	pthread_mutex_lock(&rpecat.map_lock);
	list_for_each_entry(map, head, lh) {
		if (memcmp(map->mac, mac, ETH_ALEN) == 0) {
			rpe = map->rpe;
			break;
		}
	}
	pthread_mutex_unlock(&rpecat.map_lock);

	return rpe;
}

void map_rpe(uint8_t *mac, struct rpecat_link *rpe)
{
	struct rpe_map *map = NULL;

	if (find_rpe(mac) == NULL) {
		map = calloc(1, sizeof(struct rpe_map));
		if (!map)
			return;
		memcpy(map->mac, mac, ETH_ALEN);
		map->rpe = rpe;
		pthread_mutex_lock(&rpecat.map_lock);
		list_add_tail(&map->lh, &rpecat.hash[MAC_HASH_FUNC(mac)]);
		pthread_mutex_unlock(&rpecat.map_lock);
	}
}

void clean_rpe_map()
{
	struct rpe_map *map, *prev;
	int i;

	for (i = 0; i < RPECAT_HASH_SIZE; ++i) {
		list_for_each_entry_safe(map, prev, &rpecat.hash[i], lh) {
			list_del(&map->lh);
			free(map);
		}
	}
}
/* map function end */

/* packet queue start */
void init_queue(struct queue *queue)
{
	queue->head = NULL;
	queue->tail = NULL;
	queue->count = 0;
	pthread_mutex_init(&queue->lock, NULL);
}

void clean_queue(struct queue *queue)
{
	struct frame_node *head = queue->head;
	struct frame_node *node = NULL;

	while (head) {
		node = head;
		head = node->next;
		free(node->frame);
		free(node);
	}

}

int enqueue(struct rpecat_link *link, uint8_t *frame)
{
	struct queue *queue;
	struct frame_node *node;

	queue = &link->queue;

	if (queue->count > queue_volume) {
		free(frame);
		return -ENOBUFS;
	}

	node = calloc(1, sizeof(struct frame_node));
	if (!node) {
		free(frame);
		return -ENOMEM;
	}

	node->next = NULL;
	node->frame = frame;

	pthread_mutex_lock(&queue->lock);
	if (queue->tail)
		queue->tail->next = node;
	else
		queue->head = node;

	queue->tail = node;
	++queue->count;
	pthread_mutex_unlock(&queue->lock);

	if (pthread_mutex_trylock(&link->cond_lock) == 0) {
		pthread_cond_signal(&link->cond);
		pthread_mutex_unlock(&link->cond_lock);
	}

	return 0;
}

uint8_t *dequeue(struct queue *queue)
{
	struct frame_node *node = NULL;
	uint8_t *frame = NULL;

	pthread_mutex_lock(&queue->lock);
	if (queue->head) {
		node = queue->head;
		queue->head = node->next;
		if (!queue->head)
			queue->tail = NULL;
		--queue->count;
	}
	pthread_mutex_unlock(&queue->lock);

	if (node) {
		frame = node->frame;
		free(node);
	}
	return frame;
}
/* packet queue end */

int retrieve_system_hwaddr(const char *ifname, uint8_t *addr)
{
	static uint8_t own_addr[ETH_ALEN];
	int sd;
	struct ifreq ifr;

	if (ifname) {
		sd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
		if (sd < 0)
			return -errno;

		memset(&ifr, 0, sizeof(ifr));
		strncpy(ifr.ifr_name, ifname, sizeof(ifr.ifr_name) - 1);

		if (ioctl(sd, SIOCGIFHWADDR, &ifr) < 0) {
			close(sd);
			return -errno;
		}
		memcpy(own_addr, ifr.ifr_hwaddr.sa_data, ETH_ALEN);
		close(sd);
	}

	if (addr)
		memcpy(addr, own_addr, ETH_ALEN);

	return 0;
}

int retrieve_system_ifindex(const char *ifname)
{
	static int ifindex;
	int sd;
	struct ifreq ifr;

	if (ifname) {
		sd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
		if (sd < 0)
			return -errno;

		memset(&ifr, 0, sizeof(ifr));
		strncpy(ifr.ifr_name, ifname, sizeof(ifr.ifr_name) - 1);

		if (ioctl(sd, SIOCGIFINDEX, &ifr) < 0) {
			close(sd);
			return -errno;
		}
		ifindex = ifr.ifr_ifindex;
		close(sd);
	}

	return ifindex;
}

void enqueue_rpe_msg(struct rpecat_link *link, uint8_t *msg, uint16_t type, uint16_t len)
{
	uint8_t *frame;
	struct rawlink_data_frame *data;

	if (FLAG_IS_SET(link->flag, LINK_FLAG_RAW))
		frame = alloc_rawlink_frame(link, RPECAT_DATA_FRAME, RAWLINK_DATA_FRAME_HDRLEN + NLMSG_ALIGN(len));
	else
		frame = malloc(RAWLINK_DATA_FRAME_HDRLEN + NLMSG_ALIGN(len));
	if (!frame)
		return;

	data = RAWLINK_DATA_HDR(frame);

	data->len = host_to_le16(NLMSG_ALIGN(len));
	data->msg_type = host_to_le16(type);
	memcpy(data->payload, msg, len);

	enqueue(link, frame);
}

void enqueue_cmd_init_rpe_msg(struct rpecat_link *link)
{
	RPE_MSG_T msg;

	msg.id = host_to_le16(COMMAND_INIT);
	msg.api_ver = RPE_API_VER(1);
	msg.coding = RPE_CODING_FIXED;
	memset(msg.bssid, 0xff, ETH_ALEN);
	msg.payload_len = 0;

	enqueue_rpe_msg(link, (uint8_t *)&msg, RPE_COMMAND, sizeof(msg));
}

static void clean_link_sock(struct rpecat_link *link)
{
	if (!(link->flag & LINK_FLAG_GENL)) {
		if (link->ro_sock >= 0)
			close(link->ro_sock);
		if (link->rw_sock >= 0)
			close(link->rw_sock);
#ifdef CONFIG_SUPPORT_GENNETLINK
	} else {
		soniq_destroy_link_context(link->link_ctx);
#endif
	}
}

/* rawlink start */
int send_rawlink_frame(struct rpecat_link *link, uint8_t *frame, int len)
{
	int ret = 0;
	struct rawlink_hdr *hdr = RAWLINK_HDR(frame);

	if (len < MIN_FRAME_LEN)
		len = MIN_FRAME_LEN;
	if (hdr->type == RPECAT_DATA_FRAME)
		dump_frame(frame, len, "rawlink send data");

	ret = send(link->rw_sock, frame, len, MSG_DONTWAIT);

	if (ret < 0)
		RPECAT_ERROR("Failed to send raw frame: %s\n", strerror(errno));

	return ret;
}

static int send_rawlink_data(struct rpecat_link *link, uint8_t *frame)
{
	int ret = 0;
	uint8_t frag_no = 0;
	uint8_t *head = frame;
	struct rawlink_data_frame *data;
	uint16_t rpemsg_len;

	do {
		data = RAWLINK_DATA_HDR(frame);
		rpemsg_len = le_to_host16(data->len);

		data->resv = 0;
		data->frag_no = frag_no++;
		if (rpemsg_len + RAWLINK_DATA_FRAME_HDRLEN
			<= MAX_FRAME_LEN) {
			data->more = 0;
			data->len = host_to_le16(rpemsg_len);
			return send_rawlink_frame(link, frame,
				rpemsg_len + RAWLINK_DATA_FRAME_HDRLEN);
		} else {
			data->more = 1;
			data->len = host_to_le16(MAX_FRAME_LEN
				- RAWLINK_DATA_FRAME_HDRLEN);
			if ((ret = send_rawlink_frame(link, frame,
				MAX_FRAME_LEN)) < 0)
				return ret;
		}

		frame = data->payload + (MAX_FRAME_LEN - RAWLINK_DATA_FRAME_HDRLEN);
		frame -= RAWLINK_DATA_FRAME_HDRLEN;
		memcpy(frame, head, RAWLINK_DATA_FRAME_HDRLEN);

		data = RAWLINK_DATA_HDR(frame);
		data->len = host_to_le16(rpemsg_len - (MAX_FRAME_LEN - RAWLINK_DATA_FRAME_HDRLEN));
	} while (1);
}

uint8_t *alloc_rawlink_frame(struct rpecat_link *link, uint8_t type, int len)
{
	uint8_t *frame;
	struct rawlink_hdr *hdr;
	uint32_t oui;

	if (len < MIN_FRAME_LEN)
		len = MIN_FRAME_LEN;

	frame = malloc(len);
	if (!frame)
		return NULL;

	hdr = RAWLINK_HDR(frame);
	hdr->eth_hdr.h_proto = htons(ETH_P_OUI_EXT);
	oui = htonl(QTN_OUI);
	memcpy(hdr->ext_hdr.oui, (uint8_t *)&oui + 1, 3);
	hdr->ext_hdr.protocol = htons(QTN_RPECAT_P);
	hdr->type = type;
	memcpy(hdr->eth_hdr.h_source, link->own_addr, ETH_ALEN);
	memcpy(hdr->eth_hdr.h_dest, link->rmt_addr, ETH_ALEN);
	hdr->port = link->rmt_port;

	return frame;
}

int recv_rawlink_ctrl_frame(int sock, uint8_t *buf, int len, int waittime, int cont)
{
	int nread;
	fd_set rfds;
	static struct timeval timeout;
	struct rawlink_ctrl_frame *ctrl = RAWLINK_CTRL_HDR(buf);

	if (!cont) {
		timeout.tv_sec = waittime;
		timeout.tv_usec = 0;
	}

__retry:
	FD_ZERO(&rfds);
	FD_SET(sock, &rfds);
	if (select(sock + 1, &rfds, 0, 0, &timeout) < 0) {
		if (errno == EAGAIN || errno == EINTR)
			goto __retry;

		return -1;
	}

	if (!FD_ISSET(sock, &rfds))
		return -1;

	nread = recvfrom(sock, buf, len, MSG_DONTWAIT, NULL, NULL);

	if (nread < 0) {
		RPECAT_DEBUG("Failed to receive ctrl frame from rawlink rw socket: %s\n", strerror(errno));
		return -1;
	}

	if (nread < RAWLINK_CTRL_FRAME_HDRLEN) {
		RPECAT_DEBUG("Received frame from rawlink rw socket is invalid\n");
		return -1;
	}

	if (ctrl->version != CUR_VERSION) {
		RPECAT_DEBUG("Received unrecognized frame from rawlink rw socket\n");
		return -1;
	}

	return nread;
}

int recv_rawlink_handshark(struct rpecat_link *link,  uint8_t id, uint8_t *rmt_addr, uint8_t *rmt_port)
{
	uint8_t buf[128];
	struct rawlink_hdr *hdr = RAWLINK_HDR(buf);
	struct rawlink_ctrl_frame *ctrl = RAWLINK_CTRL_HDR(buf);

	if (recv_rawlink_ctrl_frame(link->rw_sock, buf, sizeof(buf), RAWLINK_HANDSHAKE_TIMEOUT, 0) < 0)
		return -1;

	if (ctrl->id != id) {
		RPECAT_DEBUG("Received frame is not expected\n");
		return -1;
	}
	RPECAT_INFO("Receivec handshark %s from "MACSTR" rmt_port %d\n", handshark_to_str(id), MAC2STR(hdr->eth_hdr.h_source), ctrl->port);
	if (rmt_addr)
		memcpy(rmt_addr, hdr->eth_hdr.h_source, ETH_ALEN);
	if (rmt_port)
		*rmt_port = ctrl->port;

	return 1;
}

int recv_rawlink_ack(struct rpecat_link *link, uint16_t seq_num)
{
	uint8_t buf[128];
	struct rawlink_ctrl_frame *ctrl = RAWLINK_CTRL_HDR(buf);
	uint16_t seq_num_recv;
	int cont = 0;

__retry:
	if (recv_rawlink_ctrl_frame(link->rw_sock, buf, sizeof(buf), RAWLINK_ACK_TIMEOUT, cont) < 0)
		return -1;
	cont = 1;

	if (ctrl->id != RAWLINK_DATA_ACK) {
		RPECAT_DEBUG("Received frame is not ack\n");
		goto __retry;
	}

	seq_num_recv = le_to_host16(ctrl->seq_num);
	if (seq_num_recv != seq_num) {
		RPECAT_WARN("seq_num in the ack is %u, expect %u\n", seq_num_recv, seq_num);
		goto __retry;
	}

	return 1;
}


int send_rawlink_handshark(struct rpecat_link *link, uint8_t id)
{
	uint8_t *frame;
	struct rawlink_ctrl_frame *ctrl;
	int frame_len = RAWLINK_CTRL_FRAME_HDRLEN;
	int ret;

	frame = alloc_rawlink_frame(link, RPECAT_CTRL_FRAME, frame_len);
	if (!frame) {
		RPECAT_WARN("%s failed due to cannot alloc memory\n", __func__);
		return -1;
	}

	ctrl = RAWLINK_CTRL_HDR(frame);
	ctrl->id = id;
	ctrl->version = CUR_VERSION;
	ctrl->port = link->own_port;

	RPECAT_INFO("Send handshark %s to "MACSTR" own_port %d, rmt_port %d\n", handshark_to_str(id), MAC2STR(link->rmt_addr), link->own_port, link->rmt_port);
	ret = send_rawlink_frame(link, frame, frame_len);
	free(frame);

	return ret;
}

int send_rawlink_ack(struct rpecat_link *link, uint16_t seq_num)
{
	uint8_t *frame;
	struct rawlink_ctrl_frame *ctrl;
	int frame_len = RAWLINK_CTRL_FRAME_HDRLEN;
	int ret;

	frame = alloc_rawlink_frame(link, RPECAT_CTRL_FRAME, frame_len);
	if (!frame) {
		RPECAT_WARN("%s failed due to cannot alloc memory\n", __func__);
		return -1;
	}

	ctrl = RAWLINK_CTRL_HDR(frame);
	ctrl->id = RAWLINK_DATA_ACK;
	ctrl->version = CUR_VERSION;
	ctrl->seq_num = host_to_le16(seq_num);

	RPECAT_DEBUG("send ack for sequence %u to "MACSTR"\n", seq_num, MAC2STR(link->rmt_addr));
	ret = send_rawlink_frame(link, frame, frame_len);
	free(frame);

	return ret;
}

int send_rawlink_data_frame(struct rpecat_link *link, uint8_t *frame)
{
	struct rawlink_hdr *hdr = RAWLINK_HDR(frame);
	struct rawlink_data_frame *data = RAWLINK_DATA_HDR(frame);
	uint16_t rpemsg_len = le_to_host16(data->len);
	uint16_t rpemsg_type = le_to_host16(data->msg_type);
	RPE_MSG_T *rpemsg;
	char rpemsg_info[RPEMSG_INFO_LEN];
	uint16_t seq_num = link->send_seq_num++;
	int i, sendout = 0, valid_rpemsg_info = 0;

	/* some rpe message was add to queue before the rawlink connection is established */
	memcpy(hdr->eth_hdr.h_dest, link->rmt_addr, ETH_ALEN);
	hdr->port = link->rmt_port;

	data->retry = 0;
	data->seq_num = host_to_le16(seq_num);

	rpemsg = (RPE_MSG_T *)data->payload;
	if (rpemsg_to_str(rpemsg, rpemsg_type, rpemsg_info, sizeof(rpemsg_info)) == 0) {
		valid_rpemsg_info = 1;
		RPECAT_INFO("Send %d bytes rpe message to   %s via rawlink - %s\n", rpemsg_len, LINK_NAME(link), rpemsg_info);
	}

	for (i = 0; i < MAX_RETRY_COUNT; ++i) {
		if (send_rawlink_data(link, frame) < 0)
			continue;
		sendout++;
		if (recv_rawlink_ack(link, seq_num) < 0) {
			link->retry_count++;
			data->retry = 1;
			RPECAT_INFO("Don't receive ack for sequence %u in %d seconds from "MACSTR"\n",
					seq_num, RAWLINK_ACK_TIMEOUT, MAC2STR(link->rmt_addr));
			continue;
		} else {
			free(frame);
			return 0;
		}
	}

	if (sendout == 0) {
		if (valid_rpemsg_info)
			RPECAT_NOTICE("Failed to send %d bytes rpe message to %s via rawlink - %s\n", rpemsg_len, LINK_NAME(link), rpemsg_info);
		free(frame);
		return 0;
	}

	free(frame);
	CLEAR_FLAG(link->flag, LINK_FLAG_CONNECTED);
	RPECAT_NOTICE("rawlink connection to %s ("MACSTR") disconnected\n", LINK_NAME(link), MAC2STR(link->rmt_addr));

	return -1;
}

static int enqueue_frame_from_rawlink(struct rpecat_link *link,
	uint8_t *frame, uint32_t len)
{
	uint8_t *frame_clone;
	struct rawlink_data_frame *data = RAWLINK_DATA_HDR(frame);
	struct rpecat_link *dest;
	RPE_MSG_T *rpemsg = (RPE_MSG_T *)data->payload;
	int i;
	char rpemsg_info[RPEMSG_INFO_LEN];

	if (rpemsg_to_str(rpemsg, le_to_host16(data->msg_type), rpemsg_info, sizeof(rpemsg_info)) == 0)
		RPECAT_INFO("Recv %d bytes rpe message from %s via rawlink - %s\n", le_to_host16(data->len), LINK_NAME(link), rpemsg_info);
	if (FLAG_IS_SET(link->flag, LINK_FLAG_CSM)) {
		if (is_broadcast_ether_addr(rpemsg->bssid)) {
			for (i = 1; i < rpecat.rpe_num; ++i) {
				frame_clone = malloc(len);
				if (!frame_clone)
					break;
				memcpy(frame_clone, frame, len);
				enqueue(rpecat.rpe[i], frame_clone);
			}
			enqueue(rpecat.rpe[0], frame);
			return 0;
		} else {
			dest = find_rpe(rpemsg->bssid);
			if (dest) {
				enqueue(dest, frame);
				return 0;
			} else {
				RPECAT_DEBUG("Cannot find RPE link for BSSID "MACSTR"\n", MAC2STR(rpemsg->bssid));
			}
		}

	} else if (FLAG_IS_SET(link->flag, LINK_FLAG_RPE)) {
		map_rpe(rpemsg->bssid, link);
		dest = rpecat.csm;
		if (should_deliver_rpe_event(dest, le_to_host16(rpemsg->id))) {
			enqueue(dest, frame);
			return 0;
		} else {
			RPECAT_DEBUG("rpe message(%s) from rawlink is droped\n", rpemsg_info);
		}
	}

	return -1;
}

static uint8_t *g_frame = NULL;
static uint32_t g_offset = 0;
int recv_rawlink_data_frame(struct rpecat_link *link)
{
	int nread, ret = -1;
	uint8_t *frame;
	struct rawlink_data_frame *data;
	uint16_t seq_num;
	uint32_t payload_len;

	frame = malloc(MAX_RAW_RECV_BUF);
	if (!frame)
		return -ENOMEM;

	data = RAWLINK_DATA_HDR(frame);

	nread = recvfrom(link->ro_sock, frame, MAX_RAW_RECV_BUF, 0, NULL, NULL);

	if (nread < 0) {
		RPECAT_DEBUG("Failed to receive data frame from raw ro socket: %s\n", strerror(errno));
		goto __free;
	}

	if (!FLAG_IS_SET(link->flag, LINK_FLAG_CONNECTED)) {
		RPECAT_DEBUG("Drop data frame from raw ro socket: connection is not established\n");
		goto __free;
	}


	if (nread < RAWLINK_DATA_FRAME_HDRLEN) {
		RPECAT_DEBUG("Received data frame from raw ro socket is invalid: less than raw head len\n");
		goto __free;
	}
	payload_len = le_to_host16(data->len);
	if (nread < RAWLINK_DATA_FRAME_HDRLEN + payload_len) {
		RPECAT_DEBUG("Received data frame from raw ro socket is invalid: less than payload len\n");
		goto __free;
	}

	seq_num = le_to_host16(data->seq_num);
	dump_frame(frame, nread, "rawlink recv data");

	ret = 0;
	if (seq_num == link->recv_seq_num) {
		/* this frame already enqueue */
		send_rawlink_ack(link, seq_num);
		goto __free;
	}

	/* first fragment */
	if (0 == data->frag_no) {
		/* and more data, alloc max buf for assembling */
		if (data->more) {
			if (g_frame)
				free(g_frame);
			g_offset = 0;
			g_frame = malloc(MAX_RECV_BUF);
			if (g_frame) {
				g_offset = RAWLINK_DATA_FRAME_HDRLEN + payload_len;
				memcpy(g_frame, frame, g_offset);
			}
			link->packing_seq_num = seq_num;
		}
		/* only one data, just enqueue this frame */
		else {
			send_rawlink_ack(link, seq_num);
			link->recv_seq_num = seq_num;
			ret = enqueue_frame_from_rawlink(link, frame,
				payload_len + RAWLINK_DATA_FRAME_HDRLEN);
			if (ret >= 0)
				frame = NULL;
		}
	}
	/* ordering fragment with same seq no */
	else if (link->packing_seq_num == seq_num
		&& link->packing_frag_num + 1 == data->frag_no
		&& g_frame){
		memcpy(g_frame + g_offset, data->payload, payload_len);
		g_offset += payload_len;
		/* last fragment, enqueue this frame */
		if (!data->more) {
			struct rawlink_data_frame *frm;

			send_rawlink_ack(link, seq_num);
			link->recv_seq_num = seq_num;

			frm = RAWLINK_DATA_HDR(g_frame);
			frm->len = host_to_le16(g_offset - RAWLINK_DATA_FRAME_HDRLEN);

			ret = enqueue_frame_from_rawlink(link, g_frame, g_offset);
			if (ret >= 0)
				g_frame = NULL;
		}
	}
	link->packing_frag_num = data->frag_no;

__free:
	if (frame)
		free(frame);
	return ret;
}

int is_rawlink_connected(struct rpecat_link *link)
{
	uint8_t rmt_port;
	if (FLAG_IS_SET(link->flag, LINK_FLAG_CONNECTED))
		return 1;
	if (FLAG_IS_SET(link->flag, LINK_FLAG_CSM)) {
		/* wait for master */
		if (recv_rawlink_handshark(link, RAWLINK_HANDSHAKE_SYNC, link->rmt_addr, &rmt_port) < 0)
			return 0;
		link->rmt_port = rmt_port;
		send_rawlink_handshark(link, RAWLINK_HANDSHAKE_SYNCACK);
		if (recv_rawlink_handshark(link, RAWLINK_HANDSHAKE_ACK, NULL, NULL) < 0)
			return 0;
	} else if (FLAG_IS_SET(link->flag, LINK_FLAG_RPE)) {
		/* connect to slave */
		send_rawlink_handshark(link, RAWLINK_HANDSHAKE_SYNC);
		if (recv_rawlink_handshark(link, RAWLINK_HANDSHAKE_SYNCACK, NULL, NULL) < 0)
			return 0;
		send_rawlink_handshark(link, RAWLINK_HANDSHAKE_ACK);
		enqueue_cmd_init_rpe_msg(link);
	}

	RPECAT_NOTICE("rawlink connection to %s ("MACSTR") connected\n", LINK_NAME(link), MAC2STR(link->rmt_addr));
	SET_FLAG(link->flag, LINK_FLAG_CONNECTED);
	return 1;
}

void *rawlink_thread(void *ctx)
{
	struct rpecat_link *link = (struct rpecat_link *)ctx;
	uint8_t *frame;
	struct timespec timeout;
	struct timeval now;

	link->thread_running = 1;
	while (rpecat_running) {
		while (1) {
			if (is_rawlink_connected(link))
				break;
		}

		if (gettimeofday(&now, NULL) >= 0) {
			timeout.tv_sec = now.tv_sec + 1;
			timeout.tv_nsec = now.tv_usec * 1000;
		} else {
			timeout.tv_sec = 0;
			timeout.tv_nsec = 0;
		}

		pthread_mutex_lock(&link->cond_lock);
		pthread_cond_timedwait(&link->cond, &link->cond_lock, &timeout);
		while (1) {
			frame = dequeue(&link->queue);
			if (!frame)
				break;
			if (send_rawlink_data_frame(link, frame) < 0)
				break;
		}
		pthread_mutex_unlock(&link->cond_lock);
	}

	link->thread_running = 0;
	return NULL;
}

int set_raw_sock_filter(int sd, uint8_t port, uint8_t type)
{
	struct sock_filter filter[] = {
		BPF_STMT(BPF_LD + BPF_H + BPF_ABS, ETH_ALEN * 2),	/* read Ethertype */
		BPF_JUMP(BPF_JMP + BPF_JEQ + BPF_K,
			ETH_P_OUI_EXT, 0, 5),

		BPF_STMT(BPF_LD + BPF_W + BPF_ABS, ETH_HLEN),		/* read OUI + high byte of protocol */
		BPF_JUMP(BPF_JMP + BPF_JEQ + BPF_K,
			(QTN_OUI << 8) | (QTN_RPECAT_P >> 8), 0, 3),

		BPF_STMT(BPF_LD + BPF_H + BPF_ABS, ETH_HLEN + 4),	/* read low byte of protocol + port + type */
		BPF_JUMP(BPF_JMP + BPF_JEQ + BPF_K,
			((QTN_RPECAT_P << 8) & 0xff00) | (type << 4) | port, 0, 1),

		BPF_STMT(BPF_RET + BPF_K, ETH_FRAME_LEN),		/* accept packet */
		BPF_STMT(BPF_RET + BPF_K, 0)				/* ignore packet */
	};
	struct sock_fprog fp;

	fp.filter = filter;
	fp.len = sizeof(filter) / sizeof(filter[0]);

	if (setsockopt(sd, SOL_SOCKET, SO_ATTACH_FILTER, &fp, sizeof(fp)) < 0)
		return -1;

	return 0;
}

int open_raw_sock(uint8_t port, uint8_t type)
{
	int sd;
	struct sockaddr_ll addr;

	sd = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_OUI_EXT));
	if (sd < 0)
		return -errno;

	memset(&addr, 0, sizeof(addr));
	addr.sll_family = PF_PACKET;
	addr.sll_ifindex = retrieve_system_ifindex(NULL);
	addr.sll_protocol = htons(ETH_P_OUI_EXT);
	if (bind(sd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		close(sd);
		return -errno;
	}

	if (set_raw_sock_filter(sd, port, type) < 0) {
		RPECAT_WARN("Failed to set filter for raw socket: %s", strerror(errno));
	}

	return sd;
}

int setup_rawlink(struct rpecat_link *link, char *addr)
{
	static uint8_t master_port = RAWLINK_PORT_MASTER;

	if (strcmp(addr, "rawlink") == 0) {
		retrieve_system_hwaddr(NULL, link->own_addr);
		link->own_port = RAWLINK_PORT_SLAVE;
		link->rmt_port = RAWLINK_PORT_UNKNOW;
	} else {
		ether_aton_r(addr, (struct ether_addr *)link->rmt_addr);
		retrieve_system_hwaddr(NULL, link->own_addr);
		link->own_port = master_port++; /* one master support multiple slave, use port to isolate */
		link->rmt_port = RAWLINK_PORT_SLAVE;
	}
	link->ro_sock = -1;
	link->rw_sock = -1;
	link->recv_seq_num = -1;
	link->send_seq_num = 0;
	link->ro_sock = open_raw_sock(link->own_port, RPECAT_DATA_FRAME);
	if (link->ro_sock < 0) {
		RPECAT_ERROR("Failed to create raw read-only socket: %s\n", strerror(errno));
		goto fail;
	}
	link->rw_sock = open_raw_sock(link->own_port, RPECAT_CTRL_FRAME);
	if (link->rw_sock < 0) {
		RPECAT_ERROR("Failed to create raw read-write socket: %s\n", strerror(errno));
		goto fail;
	}
	init_queue(&link->queue);
	pthread_cond_init(&link->cond, NULL);
	pthread_mutex_init(&link->cond_lock, NULL);
	if (pthread_create(&link->thread, NULL, rawlink_thread, link)) {
		RPECAT_ERROR("Failed to create netlink thread: %s\n", strerror(errno));
		goto fail;
	}
	return 0;
fail:
	clean_link_sock(link);
	return -1;
}
/* rawlink end */

/* netlink start */

static void process_netlink_frame(struct rpecat_link *link, uint16_t rpemsg_type, uint8_t *msg, uint32_t rpemsg_len)
{
	RPE_MSG_T *rpemsg;
	char rpemsg_info[RPEMSG_INFO_LEN];
	struct rpecat_link *dest;
	if (rpemsg_len < MIN_RPEMSG_LEN) {
		RPECAT_WARN("Receive invalid rpe message\n");
		return;
	}

	rpemsg = (RPE_MSG_T *)msg;
	if (rpemsg_to_str(rpemsg, rpemsg_type, rpemsg_info, sizeof(rpemsg_info)) == 0)
		RPECAT_INFO("Recv %d bytes rpe message from %s via netlink - %s\n", rpemsg_len, LINK_NAME(link), rpemsg_info);

	if (FLAG_IS_SET(link->flag, LINK_FLAG_CSM)) {
		if (is_broadcast_ether_addr(rpemsg->bssid)) {
			int i;
			for (i = 0; i < rpecat.rpe_num; ++i)
				enqueue_rpe_msg(rpecat.rpe[i], msg, rpemsg_type, rpemsg_len);
		} else {
			dest = find_rpe(rpemsg->bssid);
			if (dest)
				enqueue_rpe_msg(dest, msg, rpemsg_type, rpemsg_len);
			else
				RPECAT_DEBUG("Cannot find RPE link for BSSID "MACSTR"\n", MAC2STR(rpemsg->bssid));
		}
	} else if (FLAG_IS_SET(link->flag, LINK_FLAG_RPE)) {
		map_rpe(rpemsg->bssid, link);
		dest = rpecat.csm;
		if (should_deliver_rpe_event(dest, rpemsg->id))
			enqueue_rpe_msg(dest, msg, rpemsg_type, rpemsg_len);
		else
			RPECAT_DEBUG("rpe message(%s) from netlink is droped\n", rpemsg_info);

	}
}

int recv_rt_netlink_frame(struct rpecat_link *link)
{
	char *buf;
	int len;
	struct nlmsghdr *nlh;
	uint8_t *msg;
	uint16_t rpemsg_len;
	uint16_t rpemsg_type;

	buf = malloc(MAX_RECV_BUF);
	if (!buf)
		return -ENOMEM;

	len = recvfrom(link->ro_sock, buf, MAX_RECV_BUF, MSG_DONTWAIT, NULL, NULL);
	if (len < 0) {
		if (errno != EINTR && errno != EAGAIN)
			RPECAT_WARN("netlink: recvfrom failed: %s", strerror(errno));
		free(buf);
		return -1;
	}

	for (nlh = (struct nlmsghdr *)buf; NLMSG_OK(nlh, len); nlh = NLMSG_NEXT(nlh, len)) {
		msg = (uint8_t*)NLMSG_DATA(nlh);
		rpemsg_len = NLMSG_PAYLOAD(nlh, 0);
		rpemsg_type = nlh->nlmsg_type;

		if (!((rpemsg_type == RPE_EVENT && FLAG_IS_SET(link->flag, LINK_FLAG_RPE)) ||
		      (rpemsg_type == RPE_COMMAND && FLAG_IS_SET(link->flag, LINK_FLAG_CSM))))
			continue;

		process_netlink_frame(link, rpemsg_type, msg, rpemsg_len);
	}

	if (len > 0)
		RPECAT_DEBUG("%d extra bytes in the end of netlink message\n", len);

	free(buf);
	return 0;
}

int recv_netlink_frame(struct rpecat_link *link)
{
	int ret;

	if (!(link->flag & LINK_FLAG_GENL))
		ret = recv_rt_netlink_frame(link);
#ifdef CONFIG_SUPPORT_GENNETLINK
	else
		ret = soniq_recv_message(link->link_ctx);
#endif

	if (ret < 0)
		RPECAT_WARN("Recv message failed, ret %d\n", ret);

	return ret;
}

int send_netlink_frame(struct rpecat_link *link, uint8_t *frame)
{
	struct rawlink_data_frame *data = RAWLINK_DATA_HDR(frame);
	uint16_t rpemsg_len = le_to_host16(data->len);
	uint16_t rpemsg_type = le_to_host16(data->msg_type);
	RPE_MSG_T *rpemsg;
	char rpemsg_info[RPEMSG_INFO_LEN];

	rpemsg = (RPE_MSG_T *)data->payload;
	if (rpemsg_to_str(rpemsg, rpemsg_type, rpemsg_info, sizeof(rpemsg_info)) == 0)
		RPECAT_INFO("Send %d bytes rpe message to   %s via netlink - %s\n", rpemsg_len, LINK_NAME(link), rpemsg_info);

	if (!(link->flag & LINK_FLAG_GENL)) {
		struct iovec iov;
		struct sockaddr_nl dest_addr;
		struct msghdr msg;
		struct nlmsghdr *nlh = (struct nlmsghdr *)(data->payload - NLMSG_LENGTH(0));
		memset(nlh, 0, NLMSG_LENGTH(0));
		nlh->nlmsg_len = NLMSG_LENGTH(rpemsg_len);
		nlh->nlmsg_pid = getpid();
		nlh->nlmsg_type = rpemsg_type;
		nlh->nlmsg_flags = NLM_F_REQUEST;

		memset(&dest_addr, 0, sizeof(dest_addr));
		dest_addr.nl_family = AF_NETLINK;
#ifndef CONFIG_RTNETLINK_EVENT_MULTICAST
		if (FLAG_IS_SET(link->flag, LINK_FLAG_CSM))
			dest_addr.nl_pid = RPE_EVENT_PID;
		else
#endif
		dest_addr.nl_groups = RTMGRP_NOTIFY;

		iov.iov_base = (void *)nlh;
		iov.iov_len = nlh->nlmsg_len;

		dump_frame((uint8_t *)nlh, nlh->nlmsg_len, "netlink send msg");

		memset(&msg, 0, sizeof(msg));
		msg.msg_name = (void *)&dest_addr;
		msg.msg_namelen = sizeof(dest_addr);
		msg.msg_iov = &iov;
		msg.msg_iovlen = 1;

		if (sendmsg(link->rw_sock, &msg, 0) < 0)
#ifdef CONFIG_RTNETLINK_EVENT_MULTICAST
			RPECAT_WARN("netlink sendmsg failed reason=%s\n", strerror(errno));
#else
			RPECAT_DEBUG("netlink sendmsg failed reason=%s\n", strerror(errno));
#endif
#ifdef CONFIG_SUPPORT_GENNETLINK
	} else {
		if(soniq_send_message(link->link_ctx, (uint8_t *)rpemsg, rpemsg_len) < 0)
			RPECAT_WARN("netlink sendmsg failed reason=%s\n", strerror(errno));
#endif
	}
	free(frame);

	return 0;
}

void *netlink_thread(void *ctx)
{
	struct rpecat_link *link = (struct rpecat_link *)ctx;
	uint8_t *frame;
	struct timespec timeout;
	struct timeval now;

	link->thread_running = 1;
	while (rpecat_running) {
		if (gettimeofday(&now, NULL) >= 0) {
			timeout.tv_sec = now.tv_sec + 1;
			timeout.tv_nsec = now.tv_usec * 1000;
		} else {
			timeout.tv_sec = 0;
			timeout.tv_nsec = 0;
		}

		pthread_mutex_lock(&link->cond_lock);
		pthread_cond_timedwait(&link->cond, &link->cond_lock, &timeout);
		while (1) {
			frame = dequeue(&link->queue);
			if (!frame)
				break;
			send_netlink_frame(link, frame);
		}
		pthread_mutex_unlock(&link->cond_lock);
	}

	link->thread_running = 0;
	return NULL;
}

int open_netlink_sock(int pid)
{
	int sd;
	struct sockaddr_nl local;

	sd = socket(PF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
	if (sd < 0)
		return -errno;

	memset(&local, 0, sizeof(local));
	local.nl_family = AF_NETLINK;
	local.nl_pid = pid;
	local.nl_groups = RTMGRP_NOTIFY;

	if (bind(sd, (struct sockaddr *)&local, sizeof(local)) < 0) {
		close(sd);
		return -errno;
	}

	return sd;
}

#ifdef CONFIG_SUPPORT_GENNETLINK
static void process_genl_message(void *ctx, const unsigned char *msg, unsigned int len)
{
	struct rpecat_link *link = (struct rpecat_link *)ctx;
	uint16_t rpemsg_type;

	if (FLAG_IS_SET(link->flag, LINK_FLAG_RPE))
		rpemsg_type = RPE_EVENT;
	else
		rpemsg_type = RPE_COMMAND;

	process_netlink_frame(link, rpemsg_type, (uint8_t *)msg, len);
}

static int setup_genl_with_peer(struct rpecat_link *link, int role)
{
	SONIQ_LINK_PARAM_T param;
	param.link_role = role;
	param.link_type = LINK_TYPE_GENNETLINK;
	param.max_buffer_size = SONIQ_LINK_MAX_BUFFER_SIZE;

	link->link_ctx = soniq_create_link_context(&param);
	if(NULL == link->link_ctx) {
		RPECAT_ERROR("Create link context failed\n");
		return -1;
	}

	if(soniq_register_process_message(link->link_ctx, process_genl_message, link)) {
		RPECAT_ERROR("Register message process callback failed\n");
		return -1;
	}

	return 0;
}
#endif

int setup_netlink(struct rpecat_link *link)
{
	int rxbuf = RPE_RCVBUF_SIZE;

	link->ro_sock = -1;
	link->rw_sock = -1;
	if (!(link->flag & LINK_FLAG_GENL)) {
#ifndef CONFIG_RTNETLINK_EVENT_MULTICAST
		if (FLAG_IS_SET(link->flag, LINK_FLAG_RPE))
			link->ro_sock = open_netlink_sock(RPE_EVENT_PID);
		else
#endif
		link->ro_sock = open_netlink_sock(0);
		link->rw_sock = open_netlink_sock(0);
		if (link->rw_sock < 0) {
			RPECAT_ERROR("Failed to create netlink write-only socket: %s\n", strerror(errno));
			goto fail;
		}
#ifdef CONFIG_SUPPORT_GENNETLINK
	} else {
		int ret = 0;
		if (FLAG_IS_SET(link->flag, LINK_FLAG_RPE))
			ret = setup_genl_with_peer(link, LINK_ROLE_CSM);
		else
			ret = setup_genl_with_peer(link, LINK_ROLE_RPE);
		if (ret < 0) {
			RPECAT_ERROR("Failed to create netlink context\n");
			goto fail;
		}
		link->ro_sock = soniq_get_readfd(link->link_ctx);
#endif
	}

	if (link->ro_sock < 0) {
		RPECAT_ERROR("Failed to create netlink read-only socket: %s\n", strerror(errno));
		goto fail;
	}

	if (setsockopt(link->ro_sock, SOL_SOCKET,
		SO_RCVBUF, &rxbuf, sizeof(rxbuf)) < 0)
		RPECAT_WARN("Failed to set nl sock rcvbuf to %u: %s",
			rxbuf, strerror(errno));

	init_queue(&link->queue);
	pthread_cond_init(&link->cond, NULL);
	pthread_mutex_init(&link->cond_lock, NULL);
	if (pthread_create(&link->thread, NULL, netlink_thread, link)) {
		RPECAT_ERROR("Failed to create netlink thread: %s\n", strerror(errno));
		goto fail;
	}
	return 0;
fail:
	clean_link_sock(link);

	return -1;
}
/* netlink end */

/* cli socket start */
int print_rpecat_cli_usage(char *cli, char *rep, int rep_len)
{
	return snprintf(rep, rep_len,
		"Usage: %s <command> [<parameter>] [<value>]\n"
		"Commands:\n"
		"	filter set <RPEMSG>       : set rpe msg display filter\n"
		"	filter unset <RPEMSG>     : unset rpe msg display filter\n"
		"	filter clear              : clear rpe msg display filter\n"
		"	dbglevel <level>          : set debug level\n"
		"	show_status               : show status\n", basename(cli)
	);
}

int print_link_status(struct rpecat_link *link, char *rep, int rep_len)
{
	if (FLAG_IS_SET(link->flag, LINK_FLAG_NETLINK))
		return snprintf(rep, rep_len, "%s: %s\n", LINK_NAME(link), FLAG_IS_SET(link->flag, LINK_FLAG_GENL)?"genl":"netlink");
	else if (FLAG_IS_SET(link->flag, LINK_FLAG_RAW)) {
		if (FLAG_IS_SET(link->flag, LINK_FLAG_CONNECTED))
			return snprintf(rep, rep_len, "%s: %s (connected to "MACSTR" port:%d), total retry count:%u\n",
					LINK_NAME(link), "rawlink", MAC2STR(link->rmt_addr), link->rmt_port, link->retry_count);
		else {
			if (FLAG_IS_SET(link->flag, LINK_FLAG_CSM))
				return snprintf(rep, rep_len, "csm: rawlink (wait for connecting)\n");
			else
				return snprintf(rep, rep_len, "rpe: rawlink (connecting to "MACSTR" port:%d )\n",
						MAC2STR(link->rmt_addr), link->rmt_port);
		}
	}
	return snprintf(rep, rep_len, "\n");
}

int handle_cli_cmd(char *req, char *rep, int rep_len)
{
	int argc;
	char *argv[256] = {NULL};
	int i, id;
	char *pos, *end;
	uint32_t *filter;

	argc = req[0];

	pos = &req[1];
	end = req + MAX_CLI_FRAME_LEN;
	for (i = 0; i < argc && pos < end; ++i, ++pos) {
		argv[i] = pos;
		while(*pos && pos < end)
			++pos;
	}

	if (argc <= 1)
		return print_rpecat_cli_usage(argv[0], rep, rep_len);

	pos = rep;
	end = rep + rep_len;
	if (strcmp("show_status", argv[1]) == 0) {
		pos += print_link_status(rpecat.csm, pos, end - pos);
		for (i = 0; i < rpecat.rpe_num; ++i)
			pos += print_link_status(rpecat.rpe[i], pos, end - pos);
		pos += snprintf(pos, end - pos, "event display filter: %08x\n", event_filter);
		pos += snprintf(pos, end - pos, "command display filter: %08x\n", cmd_filter);
		pos += snprintf(pos, end - pos, "debug level: %d(%s)\n", debug_level - LOG_ERR, log_names[debug_level - LOG_ERR]);
	} else if (strcmp("filter", argv[1]) == 0) {
		if (argc < 3)
			return print_rpecat_cli_usage(argv[0], rep, rep_len);
		if (strcmp("clear", argv[2]) == 0) {
			cmd_filter = 0;
			event_filter = 0;
			return snprintf(rep, rep_len, "success\n");
		}
		if (argc < 4)
			return print_rpecat_cli_usage(argv[0], rep, rep_len);
		if (strncmp(argv[3], "CMD", 3) == 0) {
			id = rpemsg_name_to_id(RPE_COMMAND, argv[3]);
			filter = &cmd_filter;
		} else if (strncmp(argv[3], "EVENT", 5) == 0) {
			id = rpemsg_name_to_id(RPE_EVENT, argv[3]);
			filter = &event_filter;
		} else
			return snprintf(rep, rep_len, "Don't support rpemsg %s\n", argv[2]);
		if (strcmp("set", argv[2]) == 0)
			SET_FLAG(*filter, RPEMSG_BIT(id));
		else if (strcmp("set", argv[2]) == 0)
			CLEAR_FLAG(*filter, RPEMSG_BIT(id));
		else
			return print_rpecat_cli_usage(argv[0], rep, rep_len);
	} else if (strcmp("dbglevel", argv[1]) == 0) {
		if (argc != 3)
			return print_rpecat_cli_usage(argv[0], rep, rep_len);
		i = atoi(argv[2]);
		if (i < 0 || i > 5)
			return snprintf(rep, rep_len, "debug level must be 0 ~ 5, 0:ERR 1:WARN 2:NOTICE 3:INFO 4:DEBUG 5:DUMP");
		debug_level = i + LOG_ERR;
		return snprintf(rep, rep_len, "success\n");
	} else
		return print_rpecat_cli_usage(argv[0], rep, rep_len);
	return pos - rep;
}

int cli_sock_open()
{
	int sd;
	struct sockaddr_un addr;

	sd = socket(PF_UNIX, SOCK_DGRAM, 0);
	if (sd < 0)
		return -1;

	unlink(RPECAT_UN_PATH);
	memset(&addr, 0, sizeof(addr));
	addr.sun_family = AF_UNIX;
	strcpy(addr.sun_path, RPECAT_UN_PATH);
	if (bind(sd, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
		close(sd);
		return -1;
	}

	return sd;
}

int recv_cli_frame()
{
	int nread, rep_len;
	struct sockaddr_un addr;
	socklen_t addr_len;
	char req[MAX_CLI_FRAME_LEN] = {0};
	char rep[MAX_CLI_FRAME_LEN] = {0};

	memset(&addr, 0, sizeof(addr));
	addr_len = sizeof(addr);
	nread = recvfrom(rpecat.cli_sock, req, sizeof(req), 0, (struct sockaddr *)&addr, &addr_len);

	if (nread < 0) {
		RPECAT_INFO("Failed to receive frame from cli socket: %s\n", strerror(errno));
		return -1;
	}

	rep_len = handle_cli_cmd(req, rep, sizeof(rep));

	if (sendto(rpecat.cli_sock, rep, rep_len, 0, (struct sockaddr *)&addr, addr_len) < 0) {
		RPECAT_INFO("Failed to send frame to cli socket: %s\n", strerror(errno));
		return -1;
	}

	return 0;
}
/* cli socket end */

void destory_link(struct rpecat_link *link)
{
	if (!link)
		return;
	if (link->thread_running)
		pthread_join(link->thread, NULL);

	clean_link_sock(link);

	clean_queue(&link->queue);
}

struct rpecat_link *create_csm(char *addr)
{
	struct rpecat_link *link = calloc(1, sizeof(struct rpecat_link));

	if (!link)
		return NULL;

	if (strcmp(addr, "netlink") == 0
#ifdef CONFIG_SUPPORT_GENNETLINK
		|| strcmp(addr, "genl") == 0
#endif
		) {
		SET_FLAG(link->flag, LINK_FLAG_NETLINK | LINK_FLAG_CSM);
#ifdef CONFIG_SUPPORT_GENNETLINK
		if (strcmp(addr, "genl") == 0)
			SET_FLAG(link->flag, LINK_FLAG_GENL);
#endif
		if (setup_netlink(link) < 0) {
			free(link);
			return NULL;
		}
	} else {
		SET_FLAG(link->flag, LINK_FLAG_RAW | LINK_FLAG_CSM);
		if (setup_rawlink(link, addr) < 0) {
			free(link);
			return NULL;
		}
	}

	return link;
}

struct rpecat_link *create_rpe(char *addr)
{
	struct rpecat_link *link = calloc(1, sizeof(struct rpecat_link));

	if (!link)
		return NULL;

	if (strcmp(addr, "netlink") == 0
#ifdef CONFIG_SUPPORT_GENNETLINK
		|| strcmp(addr, "genl") == 0
#endif
		) {
		SET_FLAG(link->flag, LINK_FLAG_NETLINK | LINK_FLAG_RPE);
#ifdef CONFIG_SUPPORT_GENNETLINK
		if (strcmp(addr, "genl") == 0)
			SET_FLAG(link->flag, LINK_FLAG_GENL);
#endif
		if (setup_netlink(link) < 0) {
			free(link);
			return NULL;
		}
	} else {
		SET_FLAG(link->flag, LINK_FLAG_RAW | LINK_FLAG_RPE);
		if (setup_rawlink(link, addr) < 0) {
			free(link);
			return NULL;
		}
	}

	return link;
}

void rpecat_recv_frame(struct rpecat_link *link)
{
	if (FLAG_IS_SET(link->flag, LINK_FLAG_RAW))
		recv_rawlink_data_frame(link);
	else if (FLAG_IS_SET(link->flag, LINK_FLAG_NETLINK))
		recv_netlink_frame(link);
}

#define FD_SET_ADV(fd, set) \
	do {\
		FD_SET(fd, set);\
		if (fd >= max_fd)\
			max_fd = fd + 1;\
	} while (0)

int main(int argc, char *argv[])
{
	fd_set readset;
	int i, max_fd = 0;
	int opt;
	char *if_name = "br0";
	char *csm = "rawlink";
#ifdef CONFIG_SUPPORT_GENNETLINK
	char *rpe[MAX_RPE] = {"netlink", "genl"};
	int rpe_num = 2;
#else
	char *rpe[MAX_RPE] = {"netlink"};
	int rpe_num = 1;
#endif
	int rpe_assign = 0;
	int netlink_rpe_num = 0;
#ifdef CONFIG_SUPPORT_GENNETLINK
	int genl_rpe_num = 0;
#endif
	uint8_t mac[ETH_ALEN];

	while((opt = getopt_long(argc, argv, "hvd:i:c:r:", rpecat_opts, NULL)) > 0) {
		switch(opt) {
		case 'h':
			usage_and_exit();
			break;
		case 'v':
			printf("rpecat: protocol v1.0; version %s-%s\n", QRPE_VERSION, QRPE_SUBVERSION);
			return 0;
		case 'd':
			debug_level = atoi(optarg);
			if (debug_level < 0 || debug_level > 5) {
				fprintf(stderr, "Error: debug level must be in 0 ~ 5\n");
				return -1;
			}
			debug_level += LOG_ERR;
			break;
		case 'i':
			if_name = optarg;
			break;
		case 'c':
			csm = optarg;
			break;
		case 'r':
			if (rpe_assign >= MAX_RPE) {
				fprintf(stderr, "Error: only support up to %d rpe\n", MAX_RPE);
				return -1;
			}
			rpe[rpe_assign++] = optarg;
			rpe_num = rpe_assign;
			break;
		default:
			usage_and_exit();
			break;
		}
	}

	if (optind < argc) {
		fprintf(stderr, "Error: too many arguments.\n");
		usage_and_exit();
	}

	if (strcmp(csm, "rawlink") != 0
#ifdef CONFIG_SUPPORT_GENNETLINK
		&& strcmp(csm, "genl") != 0
#endif
		&& strcmp(csm, "netlink") != 0) {
		fprintf(stderr, "Error: csm link only support rawlink, netlink and genl.\n");
		return -1;
	}

	for (i = 0; i < rpe_num; ++i) {
#ifdef CONFIG_SUPPORT_GENNETLINK
		if ((strcmp(csm, "netlink") == 0 || strcmp(csm, "genl") == 0)
			&& (strcmp(rpe[i], "netlink") == 0 || strcmp(rpe[i], "genl") == 0)) {
#else
		if ((strcmp(csm, "netlink") == 0)
			&& (strcmp(rpe[i], "netlink") == 0)) {
#endif
			fprintf(stderr, "Error: csm and rpe cannot be netlink/genl at the same time.\n");
			return -1;

		}

		if (strcmp(rpe[i], "netlink") == 0)
			++netlink_rpe_num;
#ifdef CONFIG_SUPPORT_GENNETLINK
		else if (strcmp(rpe[i], "genl") == 0)
			++genl_rpe_num;
#endif
		else {
			if (!ether_aton_r(rpe[i], (struct ether_addr *)mac)) {
				fprintf(stderr, "Error: rpe can only be 'netlink', 'genl'"
					"or hex-digits-and-colons notation unicast MAC address\n");
				return -1;
			}
			if (is_zero_ether_addr(mac) || is_broadcast_ether_addr(mac)) {
				fprintf(stderr, "Error: rpe can only be 'netlink', 'genl'"
					"or hex-digits-and-colons notation unicast MAC address\n");
				return -1;
			}
		}
	}

	if (netlink_rpe_num > 1
#ifdef CONFIG_SUPPORT_GENNETLINK
		|| genl_rpe_num > 1
#endif
		) {
		fprintf(stderr, "Error: netlink/genl rpe duplicates.\n");
		return -1;
	}

	if (retrieve_system_hwaddr(if_name, NULL) < 0) {
		fprintf(stderr, "Error: interface %s does not exist.\n", if_name);
		return -1;
	}
	retrieve_system_ifindex(if_name);

	memset(&rpecat, 0, sizeof(rpecat));

	for (i = 0; i < RPECAT_HASH_SIZE; ++i)
		list_head_init(&rpecat.hash[i]);

	pthread_mutex_init(&rpecat.map_lock, NULL);

	rpecat.csm = create_csm(csm);
	if (!rpecat.csm)
		goto out;
	for (i = 0; i < rpe_num; ++i) {
		rpecat.rpe[i] = create_rpe(rpe[i]);
		if (!rpecat.rpe[i])
			goto out;
	}
	rpecat.rpe_num = rpe_num;

	rpecat.cli_sock = cli_sock_open();
	if (rpecat.cli_sock < 0)
		goto out;

	while (rpecat_running) {
		FD_ZERO(&readset);
		FD_SET_ADV(rpecat.csm->ro_sock, &readset);
		for (i = 0; i < rpecat.rpe_num; ++i) {
			FD_SET_ADV(rpecat.rpe[i]->ro_sock, &readset);
		}
		FD_SET_ADV(rpecat.cli_sock, &readset);

		if (select(max_fd, &readset, 0, 0, NULL) < 0) {
			if (errno == EINTR || errno == EAGAIN)
				continue;
			RPECAT_WARN("select: %s", strerror(errno));
			break;
		}

		if (FD_ISSET(rpecat.csm->ro_sock, &readset))
			rpecat_recv_frame(rpecat.csm);
		for (i = 0; i < rpecat.rpe_num; ++i) {
			if (FD_ISSET(rpecat.rpe[i]->ro_sock, &readset))
				rpecat_recv_frame(rpecat.rpe[i]);
		}
		if (FD_ISSET(rpecat.cli_sock, &readset))
			recv_cli_frame();
	}

	close(rpecat.cli_sock);
	unlink(RPECAT_UN_PATH);

out:
	rpecat_running = 0;
	destory_link(rpecat.csm);

	for (i = 0; i < rpe_num; ++i)
		destory_link(rpecat.rpe[i]);

	clean_rpe_map();
	return 0;
}


