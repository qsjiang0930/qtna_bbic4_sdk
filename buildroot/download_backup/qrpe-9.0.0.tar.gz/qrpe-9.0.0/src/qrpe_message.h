/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : qrpe_message.h                                             **
**  Description : qrpe event and command definitions                         **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#ifndef __QRPE_MESSAGE_H__
#define __QRPE_MESSAGE_H__

#define QRPE_MAX_MSG_LEN	(1024 * 36)
#define QRPE_IFNAMSIZ		19
#define QRPE_MAX_SSID_LEN	32
#define HT_CAP_LEN		28
#define HT_OP_LEN		24
#define VHT_CAP_LEN		14
#define VHT_OP_LEN		8
#define IEEE80211_FRAME_MIN_LEN	24

#define HE_CAP_MAXLEN	57 /* HE capabilities element fixed max length(32) + PPE variable max length(25) */
#define HE_OP_MAXLEN	13 /* HE operation max length */
#define QRPE_IEEE80211_ELEMID_EXT	255
#define QRPE_IEEE80211_ELEMID_EXT_HECAP	35
#define QRPE_IEEE80211_ELEMID_EXT_HEOP	36

#define RPE_VERSION		(6)

typedef struct {
	uint16_t id;
	uint8_t coding;
	uint8_t api_ver;
	uint8_t mac[ETH_ALEN];
	uint16_t payload_len;
	uint8_t payload[0];
}__attribute__((packed)) QRPE_MSG_T;

typedef QRPE_MSG_T	QRPE_EVENT_T;
typedef QRPE_MSG_T	QRPE_COMMAND_T;

enum {
	INTF_STATUS_INVALID =		0,
	INTF_STATUS_DOWN =		1,
	INTF_STATUS_UP =		2,
	INTF_STATUS_DELETED =		3,
	INTF_STATUS_NONAVAILABLE =	4,
	INTF_STATUS_MAX,
};

#define QRPE_DRV_FRAME_COPY 	0
#define QRPE_DRV_FRAME_BYPASS 	1

#define QRPE_DRIVER_SUPPORT_BTM_SHIFT		0
#define QRPE_DRIVER_SUPPORT_HT_SHIFT		1
#define QRPE_DRIVER_SUPPORT_VHT_SHIFT		2
#define QRPE_DRIVER_SUPPORT_MONITOR_SHIFT	3
#define QRPE_DRIVER_SUPPORT_ERW_SHIFT		4
#define QRPE_DRIVER_SUPPORT_SPDIA_SHIFT         5
#define QRPE_DRIVER_SUPPORT_DISASSOC_SHIFT 	6
#define QRPE_DRIVER_SUPPORT_OMONITOR_SHIFT 	7

#define QRPE_EXTCAP_SUPPORT_SPDIA_MULTISTA_SHIFT        7

#define QRPE_EXTCAP_SUPPORT_SET_CC3RD_SHIFT 		0
#define QRPE_EXTCAP_SUPPORT_PMF_MFPR_SHIFT		1
#define QRPE_EXTCAP_SUPPORT_PMF_MFPC_SHIFT		2
#define QRPE_EXTCAP_SUPPORT_BACKHAUL_STA_SHIFT		16

#define QRPE_DRIVER_SPDIA_REORDER_SHIFT	0
#define QRPE_DRIVER_SPDIA_MODE_SHIFT	1

#define QRPE_SPDIA_OPERATION_MODE_MASK			0x03

typedef struct {
	uint8_t ifname_size;
	char ifname[QRPE_IFNAMSIZ];
	uint32_t status;
}__attribute__((packed)) QRPE_EVENT_INTF_STATUS_T;

#define QRPE_STACAPB_BANDWIDTH_SHIFT		0
#define QRPE_STACAPB_BANDWIDTH_MASK		0x07
#define QRPE_STACAPB_SUPPORT_11V_SHIFT		3
#define QRPE_STACAPB_SUPPORT_11V_MASK		0x01
#define QRPE_STACAPB_SUPPORT_VHT_SHIFT		4
#define QRPE_STACAPB_SUPPORT_VHT_MASK		0x01
#define QRPE_STACAPB_MUMIMO_SHIFT		5
#define QRPE_STACAPB_MUMIMO_MASK		0x03
#define QRPE_STACAPB_11AX_SHIFT 		7
#define QRPE_STACAPB_11AX_MASK			0x01
typedef struct {
	uint8_t peer_mac[ETH_ALEN];
	uint16_t curr_band;
	int32_t rssi;
	uint16_t rx_ss_info;
	uint16_t max_phy_rate;
	uint64_t tstamp;
	uint8_t channel;
	uint8_t sta_capab;
	uint16_t cookie_len;
	uint8_t cookie[0];
}__attribute__((packed)) QRPE_EVENT_PROBE_REQ_T;

typedef struct {
	uint8_t peer_mac[ETH_ALEN];
	uint8_t curr_band;
	uint8_t channel;
	int32_t rssi;
	uint64_t tstamp;
	uint16_t reserved1;
	uint16_t cookie_len;
	uint8_t cookie[0];
}__attribute__((packed)) QRPE_EVENT_AUTH_T;

typedef QRPE_EVENT_PROBE_REQ_T QRPE_EVENT_ASSOC_T;

typedef enum {
	QRPE_NODE_TYPE_UNKNOW	= 0,
	QRPE_NODE_TYPE_VAP,
	QRPE_NODE_TYPE_STA,
	QRPE_NODE_TYPE_WDS,
	QRPE_NODE_TYPE_TDLS,
	QRPE_NODE_TYPE_REPEATER,
	QRPE_NODE_TYPE_NOTWIFI,
} QRPE_NODE_TYPE_E;

typedef struct {
	uint8_t peer_mac[ETH_ALEN];
	uint16_t rx_ss_info;
	uint16_t max_phy_rate;
	uint8_t node_type;
	uint8_t curr_band;
	uint8_t channel;
	uint8_t sta_capab;
	uint16_t cookie_len;
	uint8_t cookie[0];
}__attribute__((packed)) QRPE_EVENT_CONNECT_T;

typedef struct {
	uint8_t sta_mac[ETH_ALEN];
	uint16_t status_code;
}__attribute__((packed)) QRPE_EVENT_TRANS_STATUS_T;

typedef struct {
	uint8_t peer_mac[ETH_ALEN];
	uint16_t reason_code;
	uint8_t direction;
}__attribute__((packed)) QRPE_EVENT_DISASSOC_T;

typedef struct {
	uint8_t ifname_size;
	char ifname[QRPE_IFNAMSIZ];
	uint32_t cmd_spec;
}__attribute__((packed)) QRPE_COMMAND_INTF_INFO_T;

typedef struct {
	uint8_t sta_mac[ETH_ALEN];
	uint16_t reason;
}__attribute__((packed)) QRPE_COMMAND_DEAUTH_T;

typedef struct {
	uint8_t sta_mac[ETH_ALEN];
	uint16_t reason;
}__attribute__((packed)) QRPE_COMMAND_DISASSOC_T;

#define QRPE_FILTER_DENY	1
#define QRPE_FILTER_ALLOW	2
typedef struct {
	uint8_t sta_mac[ETH_ALEN];
	uint16_t action;
}__attribute__((packed)) QRPE_COMMAND_STA_FILTER_T;

/* T525 byte1 */
#define QRPE_ERW_OP_SHIFT	(0)
#define QRPE_ERW_OP_MASK	0x1
#define QRPE_ERW_MINRSSI_SHIFT	(1)
#define QRPE_ERW_MINRSSI_MASK	0x1
#define QRPE_ERW_MAXRSSI_SHIFT	(2)
#define QRPE_ERW_MAXRSSI_MASK	0x1
#define QRPE_ERW_NR_CLR_SHIFT	(3)
#define QRPE_ERW_NR_CLR_MASK	0x1

/* T525 byte2 */
#define QRPE_ERW_PROBE_RESP_SHIFT	(0)
#define QRPE_ERW_PROBE_RESP_MASK	0x1
#define QRPE_ERW_ASSOC_RESP_SHIFT	(1)
#define QRPE_ERW_ASSOC_RESP_MASK	0x1
#define QRPE_ERW_AUTH_RESP_SHIFT	(2)
#define QRPE_ERW_AUTH_RESP_MASK		0x1

#define QRPE_ERW_REJECT_WITH_NR		82

#define QRPE_SPDIA_BW_SHIFT	(0)
#define QRPE_SPDIA_BW_MASK	0x0f
#define QRPE_SPDIA_MODE_SHIFT	(4)
#define QRPE_SPDIA_MODE_MASK	0x0f

#define QRPE_CHANS_PREF_MIN		(0x0)
#define QRPE_CHANS_PREF_MAX 		(0xF)
#define QRPE_CHANS_PREF_SHIFT		(4)
#define QRPE_CHANS_PREF_MASK		(0x0F)
#define QRPE_CHANS_REASON_UNSPEC 		(0x0)
#define QRPE_CHANS_REASON_NONWIFI_INTERFERER 	(0x1)
#define QRPE_CHANS_REASON_INTRA_OBSS_MGMT 	(0x2)
#define QRPE_CHANS_REASON_EXTER_OBSS_MGMT 	(0x3)
#define QRPE_CHANS_REASON_REDUCED_COVERAGE 	(0x4)
#define QRPE_CHANS_REASON_REDUCED_THROUGPUT	(0x5)
#define QRPE_CHANS_REASON_INDEV_INTERFERER 	(0x6)
#define QRPE_CHANS_REASON_DISALLOWED_RADAR 	(0x7)
#define QRPE_CHANS_REASON_BACKHAUL_PREVENT 	(0x8)
#define QRPE_CHANS_REASON_DFS_AVAILABLE 	(0x9)
#define QRPE_CHANS_REASON_DFS_STATE_UNKNOWN 	(0xA)
#define QRPE_CHANS_REASON_SHIFT		(0)
#define QRPE_CHANS_REASON_MASK		(0x0F)

typedef struct {
	uint8_t sta_mac[ETH_ALEN];
	uint16_t timer;
	uint8_t mode;
	uint8_t validity;
	uint8_t bssid[ETH_ALEN];
	uint32_t bssid_info;
	uint8_t opclass;
	uint8_t channel;
	uint8_t phytype;
	uint8_t subel_len;
	uint8_t subels[0];
} __attribute__ ((packed)) QRPE_COMMAND_TRANS_REQ_T;

typedef struct {
	uint8_t ifname_size;
	char ifname[QRPE_IFNAMSIZ];
	uint32_t period;
}__attribute__((packed)) QRPE_COMMAND_FAT_MONITOR_START_T;

typedef struct {
	uint8_t ifname_size;
	char ifname[QRPE_IFNAMSIZ];
	uint16_t period;
	uint16_t duty_cycle;
}__attribute__((packed)) QRPE_COMMAND_MONITOR_START_T;

#define QRPE_APPIE_FOR_PROBE	(0x0100)
#define QRPE_APPIE_FOR_ASSOC	(0x0200)
#define QRPE_APPIE_FOR_AUTH	(0x0400)
#define QRPE_APPIE_FOR_BEACON	(0x0800)
typedef struct {
	uint8_t peer_mac[ETH_ALEN];
	uint16_t period;
	uint8_t	spdia_feature;
	uint8_t	spdia_ng;
	uint8_t	spdia_smooth;
	uint8_t reserved;
}__attribute__((packed)) QRPE_COMMAND_SPDIA_CTRL_T;

#define QRPE_CODING_FIXED	0x00
#define QRPE_CODING_TLV		0x01

#define QRPE_API_VER(_a)	(_a)

#define QRPE_INTF_SUBCMD_INFO	(0)
#define QRPE_INTF_SUBCMD_FAT	(3)

typedef enum {
	QRPE_EVENT_INTF_STATUS = 1,
	QRPE_EVENT_INTF_INFO = 2,
	QRPE_EVENT_PROBE_REQ = 3,
	QRPE_EVENT_CONNECT_COMPLETE = 4,
	QRPE_EVENT_DEAUTH = 5,
	QRPE_EVENT_DISASSOC = 6,
	QRPE_EVENT_STA_PHY_STATS = 7,
	QRPE_EVENT_BSS_TRANS_STATUS = 8,
	QRPE_EVENT_STA_NONASSOC_STATS = 9,
	QRPE_EVENT_AUTH = 10,
	QRPE_EVENT_ASSOC_REQ = 11,
	QRPE_EVENT_FRAME = 12,
	QRPE_EVENT_RADIO_INFO = 13,
	QRPE_EVENT_RADIO_STATUS = 14,
	QRPE_EVENT_ROAM_FAIL = 15,
	QRPE_EVENT_ASSOC_ADDITIONAL_INFO = 16,

	QRPE_EVENT_SPDIA_INFO = 0x0101,
	/* private event between driver and bsa */
	QRPE_EVENT_INTF_UPDATE_NOTIFY = 0x8001,
	QRPE_EVENT_RADIO_PWRSAVE = 0x8002,
	QRPE_EVENT_CHAN_STATE_CAC = 0x8003,
	QRPE_EVENT_CHAN_STATE_UPDATE = 0x8004,
} QRPE_EVENT_ID_E;

typedef enum {
	QRPE_CMD_INIT = 0x0001,
	QRPE_CMD_DEINIT = 0x0002,
	QRPE_CMD_GET_INTF_STATUS = 0x0003,
	QRPE_CMD_GET_INTF_INFO = 0x0004,
	QRPE_CMD_DEAUTHENTICATE = 0x0005,
	QRPE_CMD_STA_MAC_FILTER	= 0x0006,
	QRPE_CMD_GET_STA_STATS = 0x0007,
	QRPE_CMD_BSS_TRANS_REQ = 0x0008,
	QRPE_CMD_FAT_MONITOR_START = 0x0009,
	QRPE_CMD_MONITOR_START = 0x000a,
	QRPE_CMD_MONITOR_STOP = 0X000b,
	QRPE_CMD_GET_NONASSOC_STATS = 0x000c,
	QRPE_CMD_FRAME = 0x000d,
	QRPE_CMD_REGISTER_FRAME = 0x000e,
	QRPE_CMD_SET_USER_CAP = 0x000f,
	QRPE_CMD_DISASSOC = 0x0010,
	QRPE_CMD_RADIO_CHANGE_CHAN = 0x0011,
	QRPE_CMD_ROAM = 0x0012,
	QRPE_CMD_CTRL_INTF_FEAT = 0x0013,

	QRPE_CMD_SPDIA_CTRL = 0x0101,
} QRPE_COMMAND_ID_E;

typedef enum {
	TLVTYPE_IFNAME = 500,
	TLVTYPE_RADIO_IFNAME = 5500,
	TLVTYPE_BSSID_MDID = 501,
	TLVTYPE_RADIO_MACADDR = 6501,
	TLVTYPE_PEER_MACADDR = 7501,
	TLVTYPE_CHANNEL_BAND = 502,
	TLVTYPE_CHANNEL_BAND_CC = 5502,
	TLVTYPE_STA_MAC = 503,
	TLVTYPE_RX_PHYRATE = 504,
	TLVTYPE_RX_PHYRATE_BW = 5504,
	TLVTYPE_TX_PHYRATE = 505,
	TLVTYPE_TX_PHYRATE_BW = 5505,
	TLVTYPE_TS_LAST_RX = 506,
	TLVTYPE_AGE_LAST_RX = 5506,
	TLVTYPE_TS_LAST_TX = 507,
	TLVTYPE_AGE_LAST_TX = 5507,
	TLVTYPE_AVERAGE_FAT = 508,
	TLVTYPE_INTERFACE_CAPABILITY = 509,
	TLVTYPE_RSSI = 510,
	TLVTYPE_RSSI_ADV = 5510,
	TLVTYPE_PSK_KEYID = 5511,
	TLVTYPE_SSID = 511,
	TLVTYPE_STA_AIRTIME = 512,
	TLVTYPE_BEACON_INTERVAL = 518,
	TLVTYPE_PKTS = 520,
	TLVTYPE_INTERFACE_TYPE = 522,
	TLVTYPE_FRAME = 523,
	TLVTYPE_FRAME_RX_SEL = 524,
	TLVTYPE_FRAME_TX_SEL = 5524,
	TLVTYPE_BL_MASK = 526,
	TLVTYPE_ADDIES = 5526,
	TLVTYPE_STATUS_CODE = 527,
	TLVTYPE_NRIE_INDEX = 528,
	TLVTYPE_EXT_INTF_CAPABILITY = 529,
	TLVTYPE_EXTCAP_SETS = 532,
	TLVTYPE_THIRD_CC = 534,
	TLVTYPE_REG_MGMT_FRAME_RX = 536,
	TLVTYPE_REG_MGMT_FRAME_TX = 5536,
	TLVTYPE_IE_EDIT_ALLOWED = 537,
	TLVTYPE_EXTCAP_EDIT_ALLOWED = 538,

	TLVTYPE_TXPOWER_BACKOFF = 543,
	TLVTYPE_RADIO_INFO = 544,
	TLVTYPE_OPCLASS_INFO_BW_EIRP = 545,
	TLVTYPE_OPCLASS_INFO = 5545,
	TLVTYPE_OPCLASS_NON_OPERABLE_CHANS = 546,
	TLVTYPE_OPCLASS_CHANS_MIN_FREQ_SEPARA = 547,
	TLVTYPE_OPCLASS_CHANS_PREF_REASON = 5547,
	TLVTYPE_CHAN_CHANGE_INFO = 548,
	TLVTYPE_LINK_STATS = 549,
	TLVTYPE_ESPI_FIELD = 550,
	TLVTYPE_ROAM_FAIL = 551,
	TLVTYPE_RADIO_STATE = 552,
	TLVTYPE_INTF_DRIVER_CFG = 553,
	TLVTYPE_MONITOR_CFG = 554,
	TLVTYPE_OMONITOR_CFG = 555,

	TLVTYPE_NRIE = 52,
	TLVTYPE_HT_CAPABILITY = 45,
	TLVTYPE_HT_OPERATION = 61,
	TLVTYPE_VHT_CAPABILITY = 191,
	TLVTYPE_VHT_OPERATION = 192,

	TLVTYPE_RSSI_VECTOR = 601,
	TLVTYPE_NOISE = 602,
	TLVTYPE_SPDIA_CONF = 603,
	TLVTYPE_SPDIA_TONES = 604,
	TLVTYPE_SPDIA_DETAILS = 605,
	TLVTYPE_SPDIA_PAYLOAD = 606,
	TLVTYPE_SPDIA_SUPPORTED_FEATURES = 607,
	TLVTYPE_SPDIA_CAPABILITIES = 608,

	TLVTYPE_HE_CAPABILITY = (255 << 8) + 35,
	TLVTYPE_HE_OPERATION = (255 << 8) + 36,
} TLVTYPE_E;

#define QRPE_IE_LEN(_l)	(((_l) + 3) & (~3))
typedef struct {
	uint16_t type;
	uint16_t len;
	uint8_t value[0];
}__attribute__((packed)) TLV_T;

#define QRPE_IE_GET_VALUE(_frm)		(((TLV_T *)(_frm))->value)
#define QRPE_IE_GET_LEN(_frm)		(le_to_host16(((TLV_T *)(_frm))->len))
#define QRPE_IE_GET_UINT8(_frm, _offset)	*(QRPE_IE_GET_VALUE(_frm) + (_offset))
#define QRPE_IE_GET_UINT16(_frm, _offset)	(uint16_t)(*(QRPE_IE_GET_VALUE(_frm) + (_offset)) \
						| ((*(QRPE_IE_GET_VALUE(_frm) + (_offset) + 1)) << 8))
#define QRPE_IE_GET_UINT32(_frm, _offset)	(uint32_t)(*(QRPE_IE_GET_VALUE(_frm) + (_offset)) \
						| ((*(QRPE_IE_GET_VALUE(_frm) + (_offset) + 1)) << 8)	\
						| ((*(QRPE_IE_GET_VALUE(_frm) + (_offset) + 2)) << 16)	\
						| ((*(QRPE_IE_GET_VALUE(_frm) + (_offset) + 3)) << 24))

extern void qrpe_report_event_from_driver(uint8_t *mac, uint32_t id, void *event);
extern void qrpe_message_loop(void);
#ifdef CONFIG_SUPPORT_GENNETLINK
extern int qrpe_recv_message_from_app_by_gennetlink(struct nl_msg *nlmsg, void *arg);
#endif
extern void qrpe_process_rtm_message(void (*cb)(struct ifinfomsg *ifi, uint8_t *buf, size_t len),
	struct nlmsghdr *h);
#endif
