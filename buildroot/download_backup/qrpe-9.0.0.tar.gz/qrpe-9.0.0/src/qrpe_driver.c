/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : qrpe_driver.c                                              **
**  Description : qrpe driver functions                                      **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#include "common.h"
#include "qrpe_message.h"
#include "qrpe_driver.h"
#include "qrpe_debug.h"

static const QRPE_DRIVER_OPS_T *g_driver_ops[] = {
#ifdef QRPE_SUPPORT_QTNA_DRIVER
	&qrpe_qtna_driver_ops,
#endif
#ifdef QRPE_SUPPORT_XXXX_DRIVER
	&qrpe_xxxx_driver_ops,
#endif
};

#define QRPE_SUPPORTED_DRIVERS	(sizeof(g_driver_ops) / sizeof(g_driver_ops[0]))

void qrpe_init_drivers(void)
{
	int i;
	for (i = 0; i < QRPE_SUPPORTED_DRIVERS; i++) {
		if (g_driver_ops[i] && g_driver_ops[i]->init) {
			QRPE_DEBUG("Init %s driver", g_driver_ops[i]->name);
			g_driver_ops[i]->init(qrpe_report_event_from_driver);
		}
	}
}

void qrpe_deinit_drivers(void)
{
	int i;
	for (i = 0; i < QRPE_SUPPORTED_DRIVERS; i++) {
		if (g_driver_ops[i] && g_driver_ops[i]->deinit) {
			QRPE_DEBUG("Deinit %s driver", g_driver_ops[i]->name);
			g_driver_ops[i]->deinit();
		}
	}
}

const QRPE_DRIVER_OPS_T *qrpe_find_driver_ops(const char *name)
{
	int i;
	if (!name)
		return NULL;

	for (i = 0; i < QRPE_SUPPORTED_DRIVERS; i++) {
		if (g_driver_ops[i]
			&& 0 == strcmp(name, g_driver_ops[i]->name))
			return g_driver_ops[i];
	}
	return NULL;
}

int qrpe_driver_init_fdset(uint8_t type, fd_set *fds)
{
	int i;
	int max_fd = -1;
	if (!fds)
		return max_fd;

	for (i = 0; i < QRPE_SUPPORTED_DRIVERS; i++) {
		int fd;
		if (g_driver_ops[i] && g_driver_ops[i]->init_fdset) {
			fd = g_driver_ops[i]->init_fdset(type, fds);
			if (fd > max_fd)
				max_fd = fd;
		}
	}
	return max_fd;
}

static inline void qrpe_driver_process_message(const QRPE_DRIVER_OPS_T *ops, uint8_t type, fd_set *fds)
{
	if (ops && ops->check_and_process_fdset)
		ops->check_and_process_fdset(type, fds);
}

void qrpe_driver_check_fdset(uint8_t type, fd_set *fds)
{
	int i;
	if (!fds)
		return;

	for (i = 0; i < QRPE_SUPPORTED_DRIVERS; i++)
		qrpe_driver_process_message(g_driver_ops[i], type, fds);
}

const QRPE_DRIVER_OPS_T *qrpe_driver_probe_intf(const char *ifname)
{
	int i;
	if (!ifname)
		return NULL;

	for (i = 0; i < QRPE_SUPPORTED_DRIVERS; i++) {
		if (g_driver_ops[i]
			&& g_driver_ops[i]->probe_intf
			&& g_driver_ops[i]->probe_intf(ifname) >= 0)
			return g_driver_ops[i];
	}
	return NULL;
}

const QRPE_DRIVER_OPS_T *qrpe_driver_probe_radio(const char *ifname)
{
	int i;
	if (!ifname)
		return NULL;

	for (i = 0; i < QRPE_SUPPORTED_DRIVERS; i++) {
		if (g_driver_ops[i]
			&& g_driver_ops[i]->probe_radio
			&& g_driver_ops[i]->probe_radio(ifname) >= 0)
			return g_driver_ops[i];
	}
	return NULL;
}
