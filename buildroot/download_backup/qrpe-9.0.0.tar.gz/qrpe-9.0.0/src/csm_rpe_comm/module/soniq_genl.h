/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : soniq_genl.h                	       		             **
**  Description : soniq generic netlink definitions 	  		     **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#ifndef _SONIQ_GENL_H_
#define _SONIQ_GENL_H_

#define SONIQ_GENL_VERSION		1
#define SONIQ_MAX_NETLINK_MSG_SIZ	2048

#define SONIQ_DRIVER_EVENT	"qrpe_drv_event"
#define SONIQ_APP_COMMAND	"qrpe_app_cmd"
#define SONIQ_PEER_EVENT	"qrpe_app_event"

#define SONIQ_FAMILY_NAME	"qrpe_family"
enum {
	SONIQ_GENL_DRV_EVENT		= 0x11,
	SONIQ_GENL_APP_CMD		= 0x12,
	SONIQ_GENL_DRV_APP_CMD		= 0x13,
	SONIQ_GENL_PEER_EVENT		= 0x14,
	SONIQ_GENL_DRV_PEER_EVENT	= 0x15,
};

enum nl80211_attrs {
	SONIQ_ATTR_UNSPEC,
	SONIQ_ATTR_MSG_TYPE,
	SONIQ_ATTR_EVENT_DATA,
	SONIQ_ATTR_TX_APP_COMMAND,
	SONIQ_ATTR_RX_APP_COMMAND,
	SONIQ_ATTR_TX_PEER_EVENT,
	SONIQ_ATTR_RX_PEER_EVENT,

	__SONIQ_ATTR_AFTER_LAST,
	NUM_SONIQ_ATTR = __SONIQ_ATTR_AFTER_LAST,
};

/* multicast groups */
enum nl80211_multicast_groups {
	SONIQ_MCGRP_DRV_EVENT,
	SONIQ_MCGRP_BSA_COMMAND,
	SONIQ_MCGRP_BSA_PEER_EVENT,
};

#endif
