/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : soniq_genl.c                	       		             **
**  Description : soniq generic netlink function 	  		     **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#include <linux/version.h>
#include <linux/module.h>
#include <linux/kmod.h>
#include <net/genetlink.h>

#include "soniq_genl.h"

static struct nla_policy soniq_peer_genl_policy[NUM_SONIQ_ATTR] = {
	[SONIQ_ATTR_MSG_TYPE] = { .type = NLA_NUL_STRING },
	[SONIQ_ATTR_EVENT_DATA] = { .type = NLA_BINARY,
		.len = SONIQ_MAX_NETLINK_MSG_SIZE },
	[SONIQ_ATTR_TX_APP_COMMAND] = { .type = NLA_BINARY,
		.len = SONIQ_MAX_NETLINK_MSG_SIZE },
	[SONIQ_ATTR_RX_APP_COMMAND] = { .type = NLA_BINARY,
		.len = SONIQ_MAX_NETLINK_MSG_SIZE },
	[SONIQ_ATTR_TX_PEER_EVENT] = { .type = NLA_BINARY,
		.len = SONIQ_MAX_NETLINK_MSG_SIZE },
	[SONIQ_ATTR_RX_PEER_EVENT] = { .type = NLA_BINARY,
		.len = SONIQ_MAX_NETLINK_MSG_SIZE },
};

static struct genl_multicast_group soniq_mcgrps[] = {
	[SONIQ_MCGRP_DRV_EVENT] = { .name = SONIQ_DRIVER_EVENT},
	[SONIQ_MCGRP_BSA_COMMAND] = { .name = SONIQ_APP_COMMAND},
	[SONIQ_MCGRP_BSA_PEER_EVENT] = {.name = SONIQ_PEER_EVENT},
};

/* SONIQ genl family definition */
static struct genl_family soniq_family = {
	.id = GENL_ID_GENERATE,
	.hdrsize = 0,
	.name = SONIQ_FAMILY_NAME,
	.version = SONIQ_GENL_VERSION, /* no significance as of now*/
	.maxattr = NUM_SONIQ_ATTR,
	.netnsok = true,
};

static int soniq_send_genl_app_command(struct sk_buff *skb_1, struct genl_info *info)
{
	struct sk_buff *skb;
	int len, error;
	void *msg_head;
	const u8 *buffer;

	if (info == NULL)
		return -EINVAL;

	if (!info->attrs[SONIQ_ATTR_TX_APP_COMMAND])
		return -EINVAL;

	buffer = nla_data(info->attrs[SONIQ_ATTR_TX_APP_COMMAND]);
	len = nla_len(info->attrs[SONIQ_ATTR_TX_APP_COMMAND]);

	skb = genlmsg_new(NLMSG_GOODSIZE, GFP_KERNEL);
	if (skb == NULL)
		return -ENOMEM;

	msg_head = genlmsg_put(skb, 0, info->snd_seq + 1, &soniq_family, 0, SONIQ_GENL_DRV_APP_CMD);
	if (msg_head  ==  NULL) {
		nlmsg_free(skb);
		return -ENOMEM;
	}

	error = nla_put(skb, SONIQ_ATTR_RX_APP_COMMAND, len, buffer);
	if (error) {
		pr_err("nla_put() failed: %d\n", error);
		nlmsg_free(skb);
		return -1;
	}

	genlmsg_end(skb, msg_head);

	if (genlmsg_multicast_allns(skb, 0, soniq_mcgrps[SONIQ_MCGRP_BSA_COMMAND].id, GFP_KERNEL))
		return -1;

	return 0;
}

static int soniq_send_genl_peer_event(struct sk_buff *skb_1, struct genl_info *info)
{
	struct sk_buff *skb;
	int len, error;
	void *msg_head;
	const u8 *buffer;

	if (info == NULL)
		return -EINVAL;

	if (!info->attrs[SONIQ_ATTR_TX_PEER_EVENT])
		return -EINVAL;

	buffer = nla_data(info->attrs[SONIQ_ATTR_TX_PEER_EVENT]);
	len = nla_len(info->attrs[SONIQ_ATTR_TX_PEER_EVENT]);

	skb = genlmsg_new(NLMSG_GOODSIZE, GFP_KERNEL);
	if (skb == NULL)
		return -ENOMEM;

	msg_head = genlmsg_put(skb, 0, info->snd_seq + 1, &soniq_family, 0, SONIQ_GENL_DRV_PEER_EVENT);
	if (msg_head  ==  NULL) {
		nlmsg_free(skb);
		return -ENOMEM;
	}

	error = nla_put(skb, SONIQ_ATTR_RX_PEER_EVENT, len, buffer);
	if (error) {
		pr_err("nla_put() failed: %d\n", error);
		nlmsg_free(skb);
		return -1;
	}

	genlmsg_end(skb, msg_head);

	if (genlmsg_multicast_allns(skb, 0, soniq_mcgrps[SONIQ_MCGRP_BSA_PEER_EVENT].id, GFP_KERNEL))
		return -1;

	return 0;
}

static int soniq_send_genl_multicast_event(unsigned int group, unsigned char *buffer, int length)
{
	struct sk_buff *skb;
	void *msg_head;
	int error;

	skb = genlmsg_new(NLMSG_GOODSIZE, GFP_KERNEL);
	if (!skb) {
		pr_err("genlmsg_new() failed.\n");
		goto end;
	}

	msg_head = genlmsg_put(skb, 0, 0, &soniq_family, 0, SONIQ_GENL_DRV_EVENT);
	if (!msg_head) {
		pr_err("genlmsg_put() failed.\n");
		kfree_skb(skb);
		goto end;
	}

	error = nla_put(skb, SONIQ_ATTR_EVENT_DATA, length, buffer);
	if (error) {
		pr_err("nla_put() failed: %d\n", error);
		kfree_skb(skb);
		goto end;
	}

	genlmsg_end(skb, msg_head);

	error = genlmsg_multicast_allns(skb, 0, soniq_mcgrps[group].id, GFP_KERNEL);
	if (error) {
		/*This mostly means no one is listening; so need not print anything here*/
		goto end;
	}

	return 0;
end:
	return -1;
}

int soniq_send_driver_event(unsigned char *buffer, int length)
{
	if (unlikely(!buffer) || unlikely(!length))
		return -1;

	return soniq_send_genl_multicast_event(SONIQ_MCGRP_DRV_EVENT, buffer, length);
}
EXPORT_SYMBOL(soniq_send_driver_event);

static struct genl_ops soniq_ops[] = {
	{
		.cmd = SONIQ_GENL_APP_CMD,
		.doit = soniq_send_genl_app_command,
		.dumpit = NULL,
		.done = NULL,
		.policy = soniq_peer_genl_policy,
	},
	{
		.cmd = SONIQ_GENL_PEER_EVENT,
		.doit = soniq_send_genl_peer_event,
		.dumpit = NULL,
		.done = NULL,
		.policy = soniq_peer_genl_policy,
	},
};

MODULE_AUTHOR("Quantenna");
MODULE_DESCRIPTION("SONiQ genl family protocol support");
#ifdef MODULE_VERSION
MODULE_VERSION("v0.1");
#endif
#ifdef MODULE_LICENSE
MODULE_LICENSE("Dual BSD/GPL");
#endif

static int __init init_soniq_genl(void)
{
	int i;
	genl_register_family_with_ops(&soniq_family, soniq_ops, ARRAY_SIZE(soniq_ops));
	
	for (i = 0; i < ARRAY_SIZE(soniq_mcgrps); i++) {
		int ret;
		ret = genl_register_mc_group(&soniq_family, &soniq_mcgrps[i]);
		if (ret) {
			printk("ERROR ON REGISTER GROUP\n");
			genl_unregister_family(&soniq_family);
			return -1;
		}
		printk("register multi group %s\n", soniq_mcgrps[i].name);
	}
	
	printk(KERN_INFO "%s general netlink family module: v%u, loaded\n", SONIQ_FAMILY_NAME, SONIQ_GENL_VERSION);
	return 0;
}
module_init(init_soniq_genl);

static void __exit exit_soniq_genl(void)
{
	genl_unregister_family(&soniq_family);
	printk(KERN_INFO "%s general netlink family module: v%u, unloaded\n", SONIQ_FAMILY_NAME, SONIQ_GENL_VERSION);
}
module_exit(exit_soniq_genl);

