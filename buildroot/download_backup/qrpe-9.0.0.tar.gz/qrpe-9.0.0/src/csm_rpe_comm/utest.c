/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : utest.c                	                             **
**  Description : unit test function 	 		                     **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>
#include <errno.h>
#include <time.h>

#include "soniq_csm_rpe_comm.h"

static void *link_ctx = NULL;

#define MESSAGE_LEN 64
static unsigned char g_message[MESSAGE_LEN];

static void message_dump(const char *title, const unsigned char *buf, int len)
{
	int i;
	printf("%010lu %s (len = %u)", time(NULL), title, len);
	for (i = 0; i < len; i++) {
		if ((i & 0xf) == 0)
			printf("\n");
		else if ((i & 0x7) == 0)
			printf("    ");
		printf("%02x ", buf[i]);
	}
	printf("\n\n");
}

static void message_build(unsigned char index)
{
	memset(g_message, index, MESSAGE_LEN);
}

static int recved = 0;
static void soniq_process_message(void *context, const unsigned char *msg, unsigned int len)
{
	unsigned int ping = *((unsigned int *)context);

	message_dump("RX", msg, len);
	if(0 == ping) {
		if(soniq_send_message(link_ctx, msg, len)) {
			printf("send message failed\n");
			return;
		}
		message_dump("TX", msg, len);
	}
	recved = 1;
}

int main(int argc, char *argv[])
{
	int c, res = 0, fd = -1;
	unsigned int ping = 0, counts = 10;
	fd_set readset;
	struct timeval timeout;

	SONIQ_LINK_PARAM_T param;
	param.link_role = LINK_ROLE_RPE;
	param.link_type = LINK_TYPE_GENNETLINK;

	while ((c = getopt(argc, argv, "r:t:c:p")) != -1) {
		switch (c) {
		case 'r':
			if(0 == strcmp(optarg, "csm"))
				param.link_role = LINK_ROLE_CSM;
			else if(0 == strcmp(optarg, "rpe"))
				param.link_role = LINK_ROLE_RPE;
			break;

		case 't':
			if(0 == strcmp(optarg, "rtnl"))
				param.link_type = LINK_TYPE_RTNETLINK;
			else if(0 == strcmp(optarg, "genl"))
				param.link_type = LINK_TYPE_GENNETLINK;
			break;

		case 'p':
			ping = 1;
			break;

		case 'c':
			counts = atoi(optarg);
			break;

		default:
			break;
		}
	}

	printf("role %u, type %u, ping %u, counts %u\n",
		param.link_role, param.link_type, ping, counts);

	link_ctx = soniq_create_link_context(&param);
	if(NULL == link_ctx) {
		printf("create link context failed\n");
		return -1;
	}

	if(soniq_register_process_message(link_ctx, soniq_process_message, &ping)) {
		printf("register message process callback failed\n");
		res = -1;
		goto __return;;
	}

	if((fd = soniq_get_readfd(link_ctx)) < 0) {
		printf("get invalid fd\n");
		res = -1;
		goto __return;;
	}

	while(0 == ping || counts > 0) {
		int ret;

		if(ping) {
			message_build((unsigned char)(counts & 0xff));
			counts--;

			if(soniq_send_message(link_ctx, g_message, MESSAGE_LEN)) {
				printf("send message failed\n");
			}

			message_dump("TX", g_message, MESSAGE_LEN);

			timeout.tv_sec = 3;
			timeout.tv_usec = 0;

			recved = 0;
		}

__retry:
		FD_ZERO(&readset);
		FD_SET(fd, &readset);
		if ((ret = select(fd + 1, &readset, 0, 0, ping ? &timeout : NULL)) < 0) {
			if (errno == EINTR || errno == EAGAIN)
				continue;
			printf("select failed %s", strerror(errno));
			break;
		}

		if(0 == ret) {
			printf("recv timeout\n");
		} else if (FD_ISSET(fd, &readset)) {
			if(0 != (ret = soniq_recv_message(link_ctx))) {
				printf("recv message failed, ret %d\n", ret);
				break;
			}

			if(ping && 0 == recved)
				goto __retry;
		}

	}

__return:
	soniq_destroy_link_context(link_ctx);
	return res;
}
