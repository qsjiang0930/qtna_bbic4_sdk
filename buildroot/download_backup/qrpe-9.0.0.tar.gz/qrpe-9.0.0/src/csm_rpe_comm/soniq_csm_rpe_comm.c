/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : soniq_csm_rpe_comm.c                	                     **
**  Description : soniq csm rpe communication function  		     **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <errno.h>
#include <netlink/genl/genl.h>
#include <netlink/genl/ctrl.h>
#include <linux/genetlink.h>

#include "soniq_csm_rpe_comm.h"
#include "soniq_genl.h"

//#define _DEBUG

#ifdef _DEBUG
#define SONIQ_DEBUG(fmt, ...)      \
		printf("%s[%u]: " fmt, __func__, __LINE__, ##__VA_ARGS__)
#else
#define SONIQ_DEBUG(fmt, ...)
#endif

#define SONIQ_RTNL_EVENT		0xFE
#define SONIQ_RTNL_COMMAND		0xFF

typedef struct {
#define SONIC_LINK_INIT_MAGIC	(0xc5c55c5c)
	unsigned int magic;

	SONIQ_LINK_PARAM_T param;

	struct nl_sock *send_sock;
	struct nl_sock *sock;
	struct nl_cb *nlcb;
	int genl_fam_id;

	soniq_process_cb_pt cb_func;
	void *cb_ctx;
} SONIQ_LINK_CONTEXT_T;

static int soniq_link_check_param(SONIQ_LINK_PARAM_T *param)
{
	if(NULL == param)
		return 0;

	if(param->link_type < 0
		|| param->link_type >= LINK_TYPE_MAX)
		return -1;

	if(param->link_role < 0
		|| param->link_role >= LINK_ROLE_MAX)
		return -1;

	return 0;
}

static int soniq_link_check_context(SONIQ_LINK_CONTEXT_T *context)
{
	if(NULL == context)
		return -1;

	if(context->magic != SONIC_LINK_INIT_MAGIC)
		return -1;

	if(soniq_link_check_param(&context->param) < 0)
		return -1;

	if(NULL == context->sock)
		return -1;

	return 0;
}

static int soniq_process_received_message_by_rtnl(SONIQ_LINK_CONTEXT_T *context,
	struct nl_msg *nlmsg)
{
	unsigned short nlmsg_type;
	struct nlmsghdr *nlh = nlmsg_hdr(nlmsg);
	if(LINK_ROLE_CSM == context->param.link_role) {
		nlmsg_type = SONIQ_RTNL_EVENT;
	} else if(LINK_ROLE_RPE == context->param.link_role) {
		nlmsg_type = SONIQ_RTNL_COMMAND;
	} else
		return NL_STOP;

	if(nlh->nlmsg_type != nlmsg_type)
		return NL_SKIP;

	SONIQ_DEBUG("calling cb function by rtnl\n");
	context->cb_func(context->cb_ctx, (const unsigned char *)nlmsg_data(nlh), nlmsg_datalen(nlh));

	return NL_OK;
}

static int soniq_process_received_message_by_genl(SONIQ_LINK_CONTEXT_T *context,
	struct nl_msg *nlmsg)
{
	struct genlmsghdr *gnlh;
	struct nlattr *tb[NUM_SONIQ_ATTR + 1];
	unsigned char cmd;
	int attr_type;

	if(LINK_ROLE_CSM == context->param.link_role) {
		cmd = SONIQ_GENL_DRV_PEER_EVENT;
		attr_type = SONIQ_ATTR_RX_PEER_EVENT;
	} else if(LINK_ROLE_RPE == context->param.link_role) {
		cmd = SONIQ_GENL_DRV_APP_CMD;
		attr_type = SONIQ_ATTR_RX_APP_COMMAND;
	} else
		return NL_STOP;

	gnlh = nlmsg_data(nlmsg_hdr(nlmsg));
	if(gnlh->cmd != cmd)
		return NL_SKIP;

	nla_parse(tb, NUM_SONIQ_ATTR, genlmsg_attrdata(gnlh, 0),
			genlmsg_attrlen(gnlh, 0), NULL);
	if(tb[attr_type]) {
		SONIQ_DEBUG("calling cb function by genl\n");
		context->cb_func(context->cb_ctx, (const unsigned char *)nla_data(tb[attr_type]),
			nla_len(tb[attr_type]));
	}

	return NL_OK;
}

static int soniq_process_received_message(struct nl_msg *nlmsg, void *arg)
{
	SONIQ_LINK_CONTEXT_T *context = (SONIQ_LINK_CONTEXT_T *)arg;

	if(NULL == nlmsg
		|| NULL == arg) {
		return NL_STOP;
	}

	if(NULL == context->cb_func)
		return NL_STOP;

	if(LINK_TYPE_RTNETLINK == context->param.link_type) {
		return soniq_process_received_message_by_rtnl(context, nlmsg);
	} else if(LINK_TYPE_GENNETLINK == context->param.link_type) {
		return soniq_process_received_message_by_genl(context, nlmsg);
	}

	return NL_STOP;
}

static void soniq_link_deinit(SONIQ_LINK_CONTEXT_T *context)
{
	if(context->nlcb)
		nl_cb_put(context->nlcb);

	if(context->sock)
		nl_socket_free(context->sock);

	if(context->send_sock)
		nl_socket_free(context->send_sock);

	context->nlcb = NULL;
	context->sock = NULL;
	context->send_sock = NULL;
}

static int soniq_link_connect(SONIQ_LINK_CONTEXT_T *context)
{
	int protocol;
	int res;

	if(LINK_TYPE_GENNETLINK == context->param.link_type) {
		protocol = NETLINK_GENERIC;
	} else if(LINK_TYPE_RTNETLINK == context->param.link_type) {
		protocol = NETLINK_ROUTE;
	} else
		return -1;

	res = nl_connect(context->sock, protocol);
	if(res) {
		SONIQ_DEBUG("nl connect failed\n");
		return res;
	}
	return nl_connect(context->send_sock, protocol);
}

static int soniq_link_add_memberships(SONIQ_LINK_CONTEXT_T *context)
{
	int group_event, group_command;
	struct nl_sock *sock_event, *sock_command;

	if(LINK_TYPE_GENNETLINK == context->param.link_type) {
		group_event =
			genl_ctrl_resolve_grp(context->sock, SONIQ_FAMILY_NAME, SONIQ_PEER_EVENT);
		group_command =
			genl_ctrl_resolve_grp(context->sock, SONIQ_FAMILY_NAME, SONIQ_APP_COMMAND);

		if (group_event < 0 || group_command < 0) {
			SONIQ_DEBUG("nl resolve group failed\n");
			return -1;
		}

		if(LINK_ROLE_CSM == context->param.link_role) {
			sock_event = context->sock;
			sock_command = context->send_sock;
		} else {
			sock_event = context->send_sock;
			sock_command = context->sock;
		}
	} else if(LINK_TYPE_RTNETLINK == context->param.link_type) {
		group_event = group_command = RTMGRP_NOTIFY;
		sock_event = context->sock;
		sock_command = context->send_sock;

		nl_socket_set_peer_groups(context->send_sock, RTMGRP_NOTIFY);
		nl_socket_set_peer_port(context->send_sock, 0);
	} else
		return -1;

	if(nl_socket_add_memberships(sock_event, group_event, 0) < 0) {
		SONIQ_DEBUG("nl add memberships failed\n");
		return -1;
	}

	if(nl_socket_add_memberships(sock_command, group_command, 0) < 0) {
		SONIQ_DEBUG("nl add memberships failed\n");
		return -1;
	}

	return 0;
}

static int soniq_link_init(SONIQ_LINK_CONTEXT_T *context)
{
	context->nlcb = nl_cb_alloc(NL_CB_DEFAULT);
	if(NULL == context->nlcb) {
		SONIQ_DEBUG("nl alloc cb failed\n");
		return -1;
	}

	context->sock = nl_socket_alloc_cb(context->nlcb);
	if(NULL == context->sock) {
		SONIQ_DEBUG("nl alloc sock failed\n");
		goto __fail;
	}

	context->send_sock = nl_socket_alloc();
	if(NULL == context->send_sock) {
		SONIQ_DEBUG("nl alloc sock failed\n");
		goto __fail;
	}

	nl_socket_disable_seq_check(context->sock);
	nl_socket_disable_seq_check(context->send_sock);

	if (context->param.max_buffer_size>0)
		nl_socket_set_msg_buf_size(context->sock, context->param.max_buffer_size);

	if(nl_socket_modify_cb(context->sock, NL_CB_VALID, NL_CB_CUSTOM,
		soniq_process_received_message, context)) {
		SONIQ_DEBUG("modify nl callback failed\n");
		goto __fail;
	}

	if (soniq_link_connect(context)) {
		SONIQ_DEBUG("nl connect failed\n");
		goto __fail;
	}

	nl_socket_set_nonblocking(context->sock);
	nl_socket_set_nonblocking(context->send_sock);

	if(soniq_link_add_memberships(context) < 0) {
		SONIQ_DEBUG("soniq add memberships failed\n");
		goto __fail;
	}

	if(LINK_TYPE_GENNETLINK == context->param.link_type) {
		context->genl_fam_id =
			genl_ctrl_resolve(context->sock, SONIQ_FAMILY_NAME);
		if (context->genl_fam_id < 0) {
			SONIQ_DEBUG("gen nl not find family id for %s\n", SONIQ_FAMILY_NAME);
			goto __fail;
		}
	}

	return 0;

__fail:
	soniq_link_deinit(context);
	return -1;
}

void *soniq_create_link_context(SONIQ_LINK_PARAM_T *param)
{
	SONIQ_LINK_CONTEXT_T *context = NULL;
	int ret;

	if(soniq_link_check_param(param) < 0) {
		SONIQ_DEBUG("invalid param value\n");
		return NULL;
	}

	if(NULL == (context = (SONIQ_LINK_CONTEXT_T *) malloc(sizeof(SONIQ_LINK_CONTEXT_T)))) {
		SONIQ_DEBUG("can not alloc memory for link context\n");
		return NULL;
	}

	memset(context, 0, sizeof(SONIQ_LINK_CONTEXT_T));
	context->param.link_type = LINK_TYPE_GENNETLINK;
	context->param.link_role = LINK_ROLE_RPE;
	if(NULL != param) {
		memcpy(&context->param, param, sizeof(SONIQ_LINK_PARAM_T));
	}

	ret = soniq_link_init(context);
	if(ret < 0) {
		SONIQ_DEBUG("init link failed %d\n", ret);
		free(context);
		return NULL;
	}

	context->cb_func = NULL;
	context->cb_ctx = NULL;
	context->magic = SONIC_LINK_INIT_MAGIC;

	return (void *)context;
}

int soniq_register_process_message(void *link, soniq_process_cb_pt cb, void *ctx)
{
	SONIQ_LINK_CONTEXT_T *context = (SONIQ_LINK_CONTEXT_T *)link;

	if(soniq_link_check_context(context) < 0) {
		SONIQ_DEBUG("invalid param value\n");
		return -1;
	}

	context->cb_func = cb;
	context->cb_ctx = ctx;

	return 0;
}

int soniq_get_readfd(void *link)
{
	SONIQ_LINK_CONTEXT_T *context = (SONIQ_LINK_CONTEXT_T *)link;

	if(soniq_link_check_context(context) < 0) {
		SONIQ_DEBUG("invalid param value\n");
		return -1;
	}

	return nl_socket_get_fd(context->sock);
}

static int soniq_genl_construct_message(SONIQ_LINK_CONTEXT_T *context,
		struct nl_msg *nlmsg, const unsigned char *msg, unsigned int len)
{
	unsigned char cmd;
	int attr_type;

	if(LINK_ROLE_CSM == context->param.link_role) {
		cmd = SONIQ_GENL_APP_CMD;
		attr_type = SONIQ_ATTR_TX_APP_COMMAND;
	} else if(LINK_ROLE_RPE == context->param.link_role) {
		cmd = SONIQ_GENL_PEER_EVENT;
		attr_type = SONIQ_ATTR_TX_PEER_EVENT;
	} else
		return -1;

	if(NULL == genlmsg_put(nlmsg, 0, 0, context->genl_fam_id, 0, 0, cmd, 0)) {
		SONIQ_DEBUG("gen nl msg put failed\n");
		return -1;
	}

	if(nla_put(nlmsg, attr_type, len, msg) < 0) {
		SONIQ_DEBUG("gen nl attr put failed\n");
		return -1;
	}

	return 0;
}

static int soniq_rtnl_construct_message(SONIQ_LINK_CONTEXT_T *context,
		struct nl_msg *nlmsg, const unsigned char *msg, unsigned int len)
{
	int nlmsg_type;
	struct nlmsghdr *nlh;

	if(LINK_ROLE_CSM == context->param.link_role) {
		nlmsg_type = SONIQ_RTNL_COMMAND;
	} else if(LINK_ROLE_RPE == context->param.link_role) {
		nlmsg_type = SONIQ_RTNL_EVENT;
	} else
		return -1;

	if(NULL == nlmsg_put(nlmsg, getpid(), 0, nlmsg_type, len, 0)) {
		SONIQ_DEBUG("nl msg put failed\n");
		return -1;
	}

	nlh = nlmsg_hdr(nlmsg);
	memcpy(nlmsg_data(nlh), msg, len);

	return 0;
}

int soniq_send_message(void *link, const unsigned char *msg, unsigned int len)
{
	int ret = -1;
	struct nl_msg *nlmsg = NULL;
	uint32_t maxlen = nlmsg_total_size(nla_total_size(len)) + nlmsg_total_size(0);

	SONIQ_LINK_CONTEXT_T *context = (SONIQ_LINK_CONTEXT_T *)link;

	if(soniq_link_check_context(context) < 0
		|| NULL == msg
		|| 0 == len) {
		SONIQ_DEBUG("invalid param value\n");
		return -EINVAL;
	}

	if(NULL == (nlmsg = nlmsg_alloc_size(maxlen))) {
		SONIQ_DEBUG("nl msg \n");
		return -1;
	}

	if(LINK_TYPE_GENNETLINK == context->param.link_type) {
		ret = soniq_genl_construct_message(context, nlmsg, msg, len);
	} else {
		ret = soniq_rtnl_construct_message(context, nlmsg, msg, len);
	}

	if(ret < 0) {
		SONIQ_DEBUG("build nl msg failed\n");
		ret = -1;
		goto __return;
	}

	if(nl_send_auto(context->send_sock, nlmsg) <= 0) {
		SONIQ_DEBUG("nl send failed\n");
		ret = -1;
	}

__return:
	if(nlmsg)
		nlmsg_free(nlmsg);

	return ret;
}

int soniq_recv_message(void *link)
{
	int res = 0;
	SONIQ_LINK_CONTEXT_T *context = (SONIQ_LINK_CONTEXT_T *)link;

	if(soniq_link_check_context(context) < 0) {
		SONIQ_DEBUG("invalid param value\n");
		return -EINVAL;
	}

	res = nl_recvmsgs(context->sock, context->nlcb);
	if(res)
		nl_perror(res, "nl_recvmsgs");

	return res;
}

void soniq_destroy_link_context(void *link)
{
	SONIQ_LINK_CONTEXT_T *context = (SONIQ_LINK_CONTEXT_T *)link;

	if(soniq_link_check_context(context) < 0) {
		SONIQ_DEBUG("invalid param value\n");
		return;
	}

	soniq_link_deinit(context);

	free(context);
}
