/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : soniq_csm_rpe_comm.h                	                     **
**  Description : soniq csm rpe communication definitions 		     **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#ifndef __SONIC_CSM_RPE_COMM_H__
#define __SONIC_CSM_RPE_COMM_H__

#define SONIQ_LINK_MAX_BUFFER_SIZE (36*1024) /* for 8x8 SPDIA */
/**
 * @brief enumeration of link type
 */
typedef enum {
	LINK_TYPE_RTNETLINK = 0,	/*!< Route netlink */
	LINK_TYPE_GENNETLINK,		/*!< General netlink */

	LINK_TYPE_MAX
} SONIQ_LINK_TYPE_E;

/**
 * @brief enumeration of link role
 */
typedef enum {
	LINK_ROLE_CSM = 0,		/*!< csm role */
	LINK_ROLE_RPE,			/*!< rpe role */

	LINK_ROLE_MAX
} SONIQ_LINK_ROLE_E;

/**
 * @brief paramters for creating the context
 */
typedef struct {
	SONIQ_LINK_TYPE_E link_type;	/*!< link type */
	SONIQ_LINK_ROLE_E link_role;	/*!< link role */
	int max_buffer_size; /*!< buffer size 0 for using default */
} SONIQ_LINK_PARAM_T;

/**
 * @brief prototype of the receving message's callback function
 */
typedef void (*soniq_process_cb_pt)(void *context, const unsigned char *msg, unsigned int len);

/**
 * Initiate the communication link context
 * @param[in] param		parameters
 * @return Link context or NULL.
 * @note If param is null, will create by (LINK_TYPE_GENNETLINK, LINK_ROLE_RPE).
 */
void *soniq_create_link_context(SONIQ_LINK_PARAM_T *param);

/**
 * Register receive message callback function
 * @param[in] link		link context returned by soniq_create_link_context
 * @param[in] cb		callback function
 * @param[in] ctx		callback function's first parameter
 * @return 0 on sucess or a negative error code.
 */
int soniq_register_process_message(void *link, soniq_process_cb_pt cb, void *ctx);

/**
 *  Return the file descriptor of the backing socket
 * @param[in] link		link context returned by soniq_create_link_context
 * @return File descriptor or -1 if not available.
 * @note Only valid after calling soniq_create_link_context().
 */
int soniq_get_readfd(void *link);

/**
 * Send message to peer on given link context
 * @param[in] link		link context returned by soniq_create_link_context
 * @param[in] msg		payload buffer
 * @param[in] len		payload len
 * @return 0 on sucess or a negative error code.
 * @note Only valid after calling soniq_create_link_context().
 */
int soniq_send_message(void *link, const unsigned char *msg, unsigned int len);

/**
 * Recv message from peer on given link context
 * @param[in] link		link context returned by soniq_create_link_context
 * @return 0 on sucess or a negative error code.
 * @note Only valid after calling soniq_create_link_context().
 */
int soniq_recv_message(void *link);

/**
 * Destroy the link context
 * @param[in] link		link context returned by soniq_create_link_context
 * @note Only valid after calling soniq_create_link_context().
 */
void soniq_destroy_link_context(void *link);

#endif
