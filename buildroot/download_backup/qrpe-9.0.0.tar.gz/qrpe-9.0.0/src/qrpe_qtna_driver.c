/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : qrpe_qtna_driver.c                                         **
**  Description : RPE of QTN driver handler definitions                      **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#include "common.h"
#include "qrpe_message.h"
#include "qrpe_driver.h"
#include "qrpe.h"
#include "qrpe_debug.h"

#include <net80211/ieee80211_ioctl.h>
#include <net80211/ieee80211_qrpe.h>
#include "qtn/shared_defs.h"
#include "qtn/qcsapi.h"
#ifdef CONFIG_SUPPORT_QTNA_SPDIA
#include "qtn/qspdia_proto.h"
#endif
#include "qtn/qtn_monitor.h"
#include "wireless_copy.h"
#include "qrpe_qtna_driver.h"

#if IEEE80211_QRPE_H_VERSION != 0x0001
#warning The driver qrpe version is not 0x0001
#endif

static QRPE_QTNA_DRIVER_DATA_T g_data;

#ifdef QRPE_QTNA_GENNETLINK
static int qrpe_qtna_receive_genl_message(struct nl_msg *nlmsg, void *arg);
#endif

//#define QRPE_QTNA_DUMP_IOCTL_MODE 1
#ifdef QRPE_QTNA_DUMP_IOCTL_MODE
#ifdef CONFIG_SUPPORT_QTNA_ERW
static void qrpe_qtna_dump_subio_erw_entry_set_req(struct ieee80211_qrpe_req_erw *erw, uint16_t len)
{
	int i;
	struct ieee80211_req_erw_entry_list *list = (struct ieee80211_req_erw_entry_list *)erw->data;

	QRPE_PRINT("ERW: request for setting entries");
	if (len < sizeof(struct ieee80211_qrpe_req_erw) + sizeof(struct ieee80211_req_erw_entry_list)
		|| len < sizeof(struct ieee80211_qrpe_req_erw) + sizeof(struct ieee80211_req_erw_entry_list)
			+ list->num * sizeof(struct ieee80211_req_erw_entry)) {
		QRPE_PRINT("ERW: len(%u) of request for setting entries is too small for %u entries", len, list->num);
		return;
	}

	QRPE_PRINT("ERW: set %u entries", list->num);
	for (i = 0; i < list->num; i++) {
		QRPE_PRINT("ERW: ind %03u, sta " MACSTR ", op %s, mode %s, mask %02x, rssi %d, reject_mode %u, nr_mask 0x%08x",
			i, MAC2STR(list->erw_entry[i].mac_addr),
			list->erw_entry[i].op == IEEE80211_ERW_ENTRY_OP_ADD ? "+" : "-",
			list->erw_entry[i].rssi_mode == IEEE80211_ERW_RSSI_MODE_NONE ? "NONE" :
				(list->erw_entry[i].rssi_mode == IEEE80211_ERW_RSSI_MODE_MAX ? "MAX " : "MIN " ),
			list->erw_entry[i].frame_select,
			list->erw_entry[i].rssi_mode == IEEE80211_ERW_RSSI_MODE_NONE ? 0 :
				(list->erw_entry[i].rssi_mode == IEEE80211_ERW_RSSI_MODE_MAX ?
					list->erw_entry[i].rssi_thrd_max : list->erw_entry[i].rssi_thrd_min),
			list->erw_entry[i].reject_mode, list->erw_entry[i].idx_mask);
	}
}

static void qrpe_qtna_dump_subio_erw_entry_set_nr_req(struct ieee80211_qrpe_req_erw *erw, uint16_t len)
{
	struct ieee80211_req_erw_nr_entry_list *list = (struct ieee80211_req_erw_nr_entry_list *)erw->data;
	struct ieee80211_req_erw_nr_entry *entry;
	uint8_t *pos;
	int i;

	QRPE_PRINT("ERW: request for setting nr entries");
	if (len < sizeof(struct ieee80211_qrpe_req_erw) + sizeof(struct ieee80211_req_erw_nr_entry_list)
		|| len < sizeof(struct ieee80211_qrpe_req_erw) + sizeof(struct ieee80211_req_erw_nr_entry_list)
			+ list->num * sizeof(*entry)) {
		QRPE_PRINT("ERW: len(%u) of request for setting nr entries is too small for %u entries", len, list->num);
		return;
	}

	QRPE_PRINT("ERW: set %u nr entries", list->num);

	pos = (uint8_t *)(list->erw_nr_entry);
	len -= (sizeof(struct ieee80211_qrpe_req_erw) + sizeof(struct ieee80211_req_erw_nr_entry_list));
	for (i = 0; i < list->num; i++) {
		entry = (struct ieee80211_req_erw_nr_entry *)pos;
		if (IEEE80211_ERW_NR_ENTRY_OP_ADD == entry->op) {
			QRPE_PRINT("ERW: ind %03u, add nr index %03u, nr payload len %03u", i, entry->id, entry->nr_ie_len);
			QRPE_DUMP_F("ERW NR payload", entry->nr_ie, entry->nr_ie_len);
			if (entry->nr_ie_len < QRPE_NRIE_MIN_LEN)
				QRPE_PRINT("ERW: nr payload is error: len(%u) is too small", entry->nr_ie_len);
			else if (entry->nr_ie_len != entry->nr_ie[1] + 2)
				QRPE_PRINT("ERW: nr payload is error: len(%u) is not equal (%u + 2)", entry->nr_ie_len, entry->nr_ie[1]);
			else if (entry->nr_ie[0] !=  QRPE_NRIE_EID)
				QRPE_PRINT("ERW: nr payload is error: eid(%u) is wrong", entry->nr_ie[0]);
		} else {
			QRPE_PRINT("ERW: ind %03u, del nr index %03u", i, entry->id);
			if (entry->nr_ie_len)
				QRPE_PRINT("ERW: del nr index %03u request is wrong: len(%u) is not zero", entry->id, entry->nr_ie_len);
		}
		pos += QRPE_IE_LEN(entry->nr_ie_len + sizeof(*entry));
	}
}

static void qrpe_qtna_dump_subio_erw_entry(const char *ifname,
	void *param, uint16_t len)
{
	struct ieee80211_qrpe_req_erw *erw = (struct ieee80211_qrpe_req_erw *)param;

	QRPE_PRINT("SUB-IOCTL- set ERW for qtna interface %s, len %u", ifname, len);
	QRPE_DUMP_F("ERW subio data", (uint8_t *)param, len);
	if (len < sizeof(struct ieee80211_qrpe_req_erw)) {
		QRPE_PRINT("ERW: len %u is too small", len);
		return;
	}

	if (len != sizeof(struct ieee80211_qrpe_req_erw) + erw->data_len) {
		QRPE_PRINT("ERW: len %u is wrong, not equal %u: subio %u", len,
			sizeof(struct ieee80211_qrpe_req_erw) + erw->data_len, erw->req);
		return;
	}

	switch (erw->req) {
	case IEEE80211_ERW_REQ_SET:
		qrpe_qtna_dump_subio_erw_entry_set_req(erw, len);
		break;

	case IEEE80211_ERW_REQ_CLEAR:
		QRPE_PRINT("ERW: request for clearing all erw entries");
		break;

	case IEEE80211_ERW_NR_REQ_SET:
		qrpe_qtna_dump_subio_erw_entry_set_nr_req(erw, len);
		break;

	default:
		QRPE_PRINT("ERW: unexpected request %u", erw->req);
		break;
	}
}
#endif	/* CONFIG_SUPPORT_QTNA_ERW */

//#define CONFIG_SUPPORT_WFA_MBO
#ifdef CONFIG_SUPPORT_WFA_MBO
static void qrpe_qtna_dump_subio_set_reg_mgmt(const char *ifname, void *param, uint16_t len)
{
	struct ieee80211_mfr_cmd *frame = (struct ieee80211_mfr_cmd *)param;

	QRPE_PRINT("SUB-IOCTL- register frame for qtna interface %s, len %u", ifname, len);
	QRPE_DUMP_F("register mgmt subio data", (uint8_t *)param, len);
	if (len < sizeof(struct ieee80211_mfr_cmd)) {
		QRPE_PRINT("register frame: len %u is too small", len);
		return;
	}
	if (len != sizeof(struct ieee80211_mfr_cmd)
			+ frame->match_len) {
		QRPE_PRINT("register frame: len %u is wrong, not equal %u", len,
			sizeof(struct ieee80211_mfr_cmd) + frame->match_len);
		return;
	}
}

static void qrpe_qtna_dump_subio_send_frame(const char *ifname, void *param, uint16_t len)
{
	struct app_action_frame_buf *send_frame = (struct app_action_frame_buf *)param;

	QRPE_PRINT("SUB-IOCTL- send frame for qtna interface %s, len %u", ifname, len);
	QRPE_DUMP_F("send frame subio data", (uint8_t *)param, len);
	if (len < sizeof(struct app_action_frame_buf)) {
		QRPE_PRINT("send frame: len %u is too small", len);
		return;
	}
	if (len != sizeof(struct app_action_frame_buf)
			+ send_frame->frm_payload.length) {
		QRPE_PRINT("send frame: len %u is wrong, not equal %u", len,
			sizeof(struct app_action_frame_buf) + send_frame->frm_payload.length);
		return;
	}

}

static void qrpe_qtna_dump_subio_update_ies(const char *ifname, void *param, uint16_t len)
{
	struct ieee80211req_getset_appiebuf *app_ies = (struct ieee80211req_getset_appiebuf *)param;

	QRPE_PRINT("SUB-IOCTL- update ies for qtna interface %s, len %u", ifname, len);
	QRPE_DUMP_F("update ies subio data", (uint8_t *)param, len);
	if (len < sizeof(struct ieee80211req_getset_appiebuf)) {
		QRPE_PRINT("update ies: len %u is too small", len);
		return;
	}
	if (len != sizeof(struct ieee80211req_getset_appiebuf) + app_ies->app_buflen) {
		QRPE_PRINT("update ies: len %u is wrong, not equal %u", len,
			sizeof(struct ieee80211req_getset_appiebuf) + app_ies->app_buflen);
		return;
	}
}

static void qrpe_qtna_dump_subio_set_extcap(const char *ifname, void *param, uint16_t len)
{
	struct ieee80211_config_extcap *extcap = (struct ieee80211_qrpe_update_extcap *)param;

	QRPE_PRINT("SUB-IOCTL- update extcap for qtna interface %s, len %u", ifname, len);
	QRPE_DUMP_F("set extcap subio data", (uint8_t *)param, len);
}

static void qrpe_qtna_dump_subio_update_3rd_cc(const char *ifname, void *param, uint16_t len)
{
	struct ieee80211_qrpe_3rd_cc_env *code = (struct ieee80211_qrpe_3rd_cc_env *)param;

	QRPE_PRINT("SUB-IOCTL- update 3rd cc for qtna interface %s, len %u", ifname, len);
	QRPE_DUMP_F("update 3rd subio data", (uint8_t *)param, len);
}
#endif

static int qrpe_qtna_dump_sub_command(const char *ifname, int16_t sub_cmd,
	void *param, uint16_t len)
{
	int dumped = 0;

	switch (sub_cmd) {
#ifdef CONFIG_SUPPORT_QTNA_ERW
	case SIOCDEV_SUBIO_ERW_ENTRY:
		qrpe_qtna_dump_subio_erw_entry(ifname, param, len);
		dumped = 1;
		break;
#endif

#ifdef CONFIG_SUPPORT_WFA_MBO
	case SIOCDEV_SUBIO_SET_MFR:
		qrpe_qtna_dump_subio_set_reg_mgmt(ifname, param, len);
		dumped = 1;
		break;

	case SIOCDEV_SUBIO_SEND_ACTION_FRAME:
		qrpe_qtna_dump_subio_send_frame(ifname, param, len);
		dumped = 1;
		break;

	case SIOCDEV_SUBIO_SET_EXTCAP_IE:
		qrpe_qtna_dump_subio_set_extcap(ifname, param, len);
		dumped = 1;
		break;

	case IEEE80211_PARAM_COUNTRY_STR_ENV:
		qrpe_qtna_dump_subio_update_3rd_cc(ifname, param, len);
		dumped = 1;
		break;
#endif
	default:
		break;
	}

	return dumped;
}

#if QRPE_QTNA_DUMP_IOCTL_MODE
#define QRPE_QTNA_DUMP_SUB_COMMAND(_i, _c, _p, _l)	do {\
		int _ret = qrpe_qtna_dump_sub_command(_i, _c, _p, _l);\
		if (_ret) (_c) = 0xffff;/* using invalid sub_cmd for dump only */\
	} while(0)
#else
#define QRPE_QTNA_DUMP_SUB_COMMAND(_i, _c, _p, _l)	qrpe_qtna_dump_sub_command(_i, _c, _p, _l)
#endif

#else	/* QRPE_QTNA_DUMP_IOCTL_MODE */
#define QRPE_QTNA_DUMP_SUB_COMMAND(_i, _c, _p, _l)
#endif

static int qrpe_qtna_set_iwpriv(int sock, const char *ifname, int op, void *data, int len)
{
	struct iwreq iwr;
	int do_inline = (len < IFNAMSIZ);
	int retval = 0;

	QRPE_DEBUG("IOCTL- set for qtna interface %s: op = %#x", ifname, op);

	memset(&iwr, 0, sizeof(iwr));
	strncpy(iwr.ifr_name, ifname, IFNAMSIZ - 1);
	/* certain ioctls must use the non-inlined method */
	if (op == IEEE80211_IOCTL_SET_APPIEBUF)
		do_inline = 0;
	if (do_inline) {
		memcpy(iwr.u.name, data, len);
	} else {
		iwr.u.data.pointer = data;
		iwr.u.data.length = len;
	}

	if (ioctl(sock, op, &iwr ) < 0) {
		QRPE_WARN("Failed to set private ioctl for qtna interface %s: op = %#x, err = %s", ifname, op, strerror(errno));
		retval = -errno;
	}

	return retval;
}

static int qrpe_qtna_get_param(int sock, const char *ifname, int op, uint32_t *p_target_value)
{
	struct iwreq iwr;
	int retval = 0;

	QRPE_DEBUG("IOCTL- get param(%#d) for qtna interface %s", op, ifname);

	memset(&iwr, 0, sizeof(iwr));
	strncpy(iwr.ifr_name, ifname, IFNAMSIZ - 1);

	iwr.u.mode = op & 0xffff;
	if (ioctl(sock, IEEE80211_IOCTL_GETPARAM, &iwr ) < 0) {
		QRPE_WARN("Failed to get param(%d) for qtna interface %s: err = %s", op, ifname, strerror(errno));
		return -errno;
	}
	*p_target_value = iwr.u.mode;
	return retval;
}

static int qrpe_qtna_set_param(int sock, const char *ifname, int op, uint32_t value)
{
	struct iwreq iwr;
	int retval = 0;

	QRPE_DEBUG("IOCTL- set param(%#x:%u) for qtna interface %s", op, value, ifname);

	memset(&iwr, 0, sizeof(iwr));
	strncpy(iwr.ifr_name, ifname, IFNAMSIZ - 1);
	iwr.u.data.pointer = (void *)op;
	*(uint32_t *)&iwr.u.data.length = value;

	if (ioctl(sock, IEEE80211_IOCTL_SETPARAM, &iwr ) < 0) {
		QRPE_WARN("Failed to set param(%#x:%u) for qtna interface %s: err = %s", op, value, ifname, strerror(errno));
		retval = -errno;
	}

	return retval;
}

static int qrpe_qtna_sub_command(int sock, const char *ifname, uint16_t sub_cmd,
	void *param, uint16_t len)
{
	struct iwreq iwr;
	int retval = 0;

	QRPE_DEBUG("IOCTL- set sub command(%u) for qtna interface %s", sub_cmd, ifname);

	QRPE_QTNA_DUMP_SUB_COMMAND(ifname, sub_cmd, param, len);

	memset(&iwr, 0, sizeof(iwr));
	strncpy(iwr.ifr_name, ifname, IFNAMSIZ - 1);
	iwr.u.data.flags = sub_cmd;
	iwr.u.data.pointer = param;
	iwr.u.data.length = len;

	if (ioctl(sock, IEEE80211_IOCTL_EXT, &iwr) < 0) {
		QRPE_INFO("Failed to set sub command(%u) for qtna interface %s: err = %s", sub_cmd, ifname, strerror(errno));
		retval = -errno;
	}

	return retval;
}

#ifdef CONFIG_SUPPORT_QTNA_SPDIA
static int qrpe_qtna_sys_control(char *cmd, char *data, uint32_t len)
{
	FILE *wfd = NULL, *rfd = NULL;
	int retval = 0, data_len = 0;

	wfd = fopen(QRPE_QTNA_SYS_CONTROL_NAME, "w");
	if (!wfd) {
		QRPE_WARN("Failed to open %s to send %s for control: err = %s",
			QRPE_QTNA_SYS_CONTROL_NAME, cmd, strerror(errno));
		retval = -errno;
		goto __out;
	}

	if (fputs(cmd, wfd) < 0) {
		QRPE_WARN("Failed to put %s to %s for control: err = %s",
			cmd, QRPE_QTNA_SYS_CONTROL_NAME, strerror(errno));
		retval = -errno;
		goto __out;
	}

	if (data && len) {
		rfd = fopen(QRPE_QTNA_SYS_OUTDATA_NAME, "r");
		if (!rfd) {
			QRPE_WARN("Failed to open %s to get result of %s: err = %s",
				QRPE_QTNA_SYS_OUTDATA_NAME, cmd, strerror(errno));
			retval = -errno;
			goto __out;
		}

		while (len > data_len + 1
			&& fgets(data + data_len, len - data_len, rfd))
			data_len = strlen(data);
	}

__out:
	if (wfd)
		fclose(wfd);
	if (rfd)
		fclose(rfd);

	return retval;
}
#endif

static int qrpe_qtna_probe_intf(const char *ifname)
{
	if (!ifname)
		return -1;
	/* wifiX for topaz, wifiX_Y for pearl */
	if (strncmp(ifname, "wifi", 4)
		|| strchr(ifname, '.'))
		return -1;
#ifdef QRPE_SUPPORT_QTNA_PEARL_DRIVER
	if (!strchr(ifname, '_'))
		return -1;
#endif
	/* TODO: if needed, we can use the ioctl to check the ifname is belong to this driver */

	return 0;
}

static int qrpe_qtna_probe_radio(const char *ifname)
{
	if (!ifname)
		return -1;
	/* wifiX for topaz radio, wifiX_0 for pearl radio */
#ifdef QRPE_SUPPORT_QTNA_TOPAZ_DRIVER
	if (strncmp(ifname, "wifi0", 5)
		|| strchr(ifname, '.'))
		return -1;
#endif
#ifdef QRPE_SUPPORT_QTNA_PEARL_DRIVER
	if (strncmp(ifname, "wifi", 4)
		|| !strstr(ifname, "_0")
		|| strchr(ifname, '.'))
		return -1;
#endif
	return 0;
}

static void qrpe_qtna_driver_deinit(void)
{
	if (g_data.ioctl_sock)
		close(g_data.ioctl_sock);
	if (g_data.rtm_sock)
		close(g_data.rtm_sock);
#ifdef QRPE_QTNA_GENNETLINK
	if(g_data.nlcb)
		nl_cb_put(g_data.nlcb);
	if(g_data.drv_read_nl_sock)
		nl_socket_free(g_data.drv_read_nl_sock);
#endif
}

static int qrpe_qtna_driver_init_read_sockets(void)
{
	int rxbuf = QRPE_RCVBUF_SIZE;
	struct sockaddr_nl addr;
#ifdef QRPE_QTNA_GENNETLINK
	int group;
#endif
	g_data.rtm_sock = socket(PF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
	if (g_data.rtm_sock < 0) {
		QRPE_ERROR("Failed to open rtnetlink socket for qtna driver event: %s", strerror(errno));
		return -1;
	}

	memset(&addr, 0, sizeof(addr));
	addr.nl_family = AF_NETLINK;
	addr.nl_groups = RTMGRP_LINK;

	if (bind(g_data.rtm_sock, (struct sockaddr *)&addr, sizeof(addr)) < 0)	{
		QRPE_ERROR("Failed to bind rtnetlink socket for qtna driver event: %s", strerror(errno));
		return -1;
	}

#ifdef QRPE_QTNA_RTNETLINK
	if (setsockopt(g_data.rtm_sock, SOL_SOCKET,
		SO_RCVBUF, &rxbuf, sizeof(rxbuf)) < 0)
		QRPE_WARN("Failed to set nl sock rcvbuf to %u for qtna driver event: %s",
			rxbuf, strerror(errno));

#elif defined QRPE_QTNA_GENNETLINK
	g_data.nlcb = nl_cb_alloc(NL_CB_DEFAULT);
	if(NULL == g_data.nlcb) {
		QRPE_ERROR("Failed to alloc nl cb for qtna driver event: %s", strerror(errno));
		return -1;
	}

	g_data.drv_read_nl_sock = nl_socket_alloc_cb(g_data.nlcb);
	if(NULL == g_data.drv_read_nl_sock) {
		QRPE_ERROR("Failed to alloc nl sock for qtna driver event: %s", strerror(errno));
		return -1;
	}
	nl_socket_disable_seq_check(g_data.drv_read_nl_sock);
	if(nl_socket_modify_cb(g_data.drv_read_nl_sock, NL_CB_VALID, NL_CB_CUSTOM,
		qrpe_qtna_receive_genl_message, NULL)) {
		QRPE_ERROR("Failed to modify nl callback for qtna driver event: %s", strerror(errno));
		return -1;
	}
	if (genl_connect(g_data.drv_read_nl_sock)) {
		QRPE_ERROR("Failed to connect nl sock for qtna driver event: %s", strerror(errno));
		return -1;
	}
	group = genl_ctrl_resolve_grp(g_data.drv_read_nl_sock, QRPE_FAMILY_NAME, QRPE_DRIVER_EVENT);
	if (group < 0) {
		QRPE_ERROR("Failed to resolve nl group for qtna driver event: %s", strerror(errno));
		return -1;
	}

	g_data.drv_read_sock = nl_socket_get_fd(g_data.drv_read_nl_sock);
	if (g_data.drv_read_sock < 0) {
		QRPE_ERROR("Failed to get sock from nl for qtna driver event: %s", strerror(errno));
		return -1;
	}

	if (nl_socket_add_memberships(g_data.drv_read_nl_sock, group, 0) < 0) {
		QRPE_ERROR("Failed to add membership for qtna driver event: %s", strerror(errno));
		return -1;
	}

	if (setsockopt(g_data.drv_read_sock, SOL_SOCKET,
		SO_RCVBUF, &rxbuf, sizeof(rxbuf)) < 0)
		QRPE_WARN("Failed to set nl sock rcvbuf to %u for qtna driver event: %s",
			rxbuf, strerror(errno));
#endif

	return 0;
}

static int qrpe_qtna_driver_init(QRPE_DRV_EVENT_CALLBACK_F cb)
{
	g_data.cb = cb;
	g_data.ioctl_sock = socket(PF_INET, SOCK_DGRAM, 0);
	if (g_data.ioctl_sock < 0) {
		QRPE_WARN("Failed to create IOCTL socket for qtna driver");
		goto _fail;
	}

	g_data.rtm_sock = -1;
#ifdef QRPE_QTNA_GENNETLINK
	g_data.drv_read_sock = -1;
#endif
	if (qrpe_qtna_driver_init_read_sockets() < 0) {
		QRPE_WARN("Failed to init socket for qtna driver");
		goto _fail;
	}
	g_data.tstamp = 0;
	g_data.scan_retries = 0;
	memset(&g_data.roam, 0, sizeof(QRPE_DRV_ROAM_STATUS_T));
	return 0;
_fail:
	qrpe_qtna_driver_deinit();
	return -1;
}

static void qrpe_qtna_deinit_intf(void *priv)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	if (!data)
		return;
	QRPE_FREE(data);
}

static void *qrpe_qtna_init_intf(const char *ifname)
{
	QRPE_QTNA_INTF_DATA_T *data = QRPE_CALLOC(1, sizeof(QRPE_QTNA_INTF_DATA_T));
	if (!data)
		return NULL;

	strncpy(data->ifname, ifname, IFNAMSIZ - 1);
	strncpy(data->radio_name, ifname, IFNAMSIZ - 1);
	if (data->radio_name[strlen(ifname) - 1] != '0')
		data->radio_name[strlen(ifname) - 1] = '0';
	return data;
}

static void qrpe_qtna_deinit_radio(void *priv)
{
	QRPE_QTNA_RADIO_DATA_T *data = (QRPE_QTNA_RADIO_DATA_T *)priv;
	if (!data)
		return;
	QRPE_FREE(data);
}

static void *qrpe_qtna_init_radio(const char *ifname)
{
	QRPE_QTNA_RADIO_DATA_T *data = QRPE_CALLOC(1, sizeof(QRPE_QTNA_RADIO_DATA_T));
	if (!data)
		return NULL;

	data->radio_id = atoi(&ifname[4]);
	strncpy(data->ifname, ifname, IFNAMSIZ - 1);
	strncpy(data->qcsapi_ifname, ifname, IFNAMSIZ - 1);
#ifdef QRPE_SUPPORT_QTNA_PEARL_DRIVER
	if (qcsapi_radio_verify_repeater_mode(data->radio_id) == 1) {
#else
	if (qcsapi_wifi_verify_repeater_mode() == 1) {
#endif
		if (ifname[strlen(ifname) - 1] == '0')
			data->qcsapi_ifname[strlen(ifname) - 1] = '1';
	}

	return data;
}

static int qrpe_qtna_init_fdset(uint8_t type, fd_set *fds)
{
	int max_sock = g_data.rtm_sock;

	if (QRPE_FDSET_TYPE_READ != type
		|| !fds)
		return -1;
	FD_SET(g_data.rtm_sock, fds);
#ifdef QRPE_QTNA_GENNETLINK
	FD_SET(g_data.drv_read_sock, fds);
	if (max_sock < g_data.drv_read_sock)
		max_sock = g_data.drv_read_sock;
#endif

	return max_sock;
}

static void qrpe_qtna_report_event_probe_req_or_assoc(uint16_t event_id, uint8_t *bssid, uint8_t *data, uint16_t len)
{
	struct ieee80211_qrpe_event_probe_req *drv_probe_req =
		(struct ieee80211_qrpe_event_probe_req *)data;
	QRPE_DRV_PROBE_REQ_T *probe_req;
	uint32_t id = QRPE_DRV_EVENT_PROBE_REQ;

#ifdef CONFIG_SUPPORT_QTNA_ASSOC_EVENT
	if (IEEE80211_QRPE_EVENT_ASSOC_REQ == event_id)
		id = QRPE_DRV_EVENT_ASSOC_REQ;
#endif

	if (len < sizeof(struct ieee80211_qrpe_event_probe_req)) {
		QRPE_WARN("Skip probe req/assoc event from driver: len(%d) too small", len);
		return;
	}

	if ((sizeof(QRPE_DRV_PROBE_REQ_T) + drv_probe_req->cookie_len)
		> IEEE80211_QRPE_MAX_LEN) {
		QRPE_WARN("Skip probe req/assoc event from driver: cookie len(%d) too large ", drv_probe_req->cookie_len);
		return;
	}

	if (NULL == (probe_req = QRPE_CALLOC(1, sizeof(QRPE_DRV_PROBE_REQ_T) + drv_probe_req->cookie_len)))
		return;

	memcpy(probe_req->peer_mac, drv_probe_req->mac, ETH_ALEN);
	probe_req->curr_band = drv_probe_req->band;
	probe_req->rssi = drv_probe_req->rssi;
	probe_req->rx_ss_info = drv_probe_req->nss;
	probe_req->max_phy_rate = drv_probe_req->max_phy_rate;
	probe_req->tstamp = get_reltime();
	probe_req->channel = drv_probe_req->channel;
	probe_req->band_width = drv_probe_req->band_width;
	probe_req->support_vht = drv_probe_req->support_vht;
	probe_req->support_ht = drv_probe_req->support_ht;
	probe_req->support_11v = drv_probe_req->support_11v;
	probe_req->mumimo_capab = drv_probe_req->mumimo_capab;
	probe_req->cookie_len = drv_probe_req ->cookie_len;
	memcpy(probe_req->cookie, drv_probe_req->cookie, drv_probe_req->cookie_len);

	g_data.cb(bssid, id, probe_req);
	QRPE_FREE(probe_req);
}

#ifdef CONFIG_SUPPORT_QTNA_AUTH_EVENT
static void qrpe_qtna_report_event_auth(uint8_t *bssid, uint8_t *data, uint16_t len)
{
	struct ieee80211_qrpe_event_auth *drv_auth =
		(struct ieee80211_qrpe_event_auth *)data;
	QRPE_DRV_AUTH_T *auth;

	if (len < sizeof(struct ieee80211_qrpe_event_auth)) {
		QRPE_WARN("Skip auth event from driver: len(%d) too small", len);
		return;
	}

	if ((sizeof(QRPE_DRV_AUTH_T) + drv_auth->cookie_len)
		> IEEE80211_QRPE_MAX_LEN) {
		QRPE_WARN("Skip auth event from driver: cookie len(%d) too large ", drv_auth->cookie_len);
		return;
	}

	if (NULL == (auth = QRPE_CALLOC(1, sizeof(QRPE_DRV_AUTH_T) + drv_auth->cookie_len)))
		return;

	memcpy(auth->peer_mac, drv_auth->mac, ETH_ALEN);
	auth->curr_band = drv_auth->band;
	auth->rssi = drv_auth->rssi;
	auth->tstamp = get_reltime();
	auth->channel = drv_auth->channel;
	auth->cookie_len = drv_auth->cookie_len;
	memcpy(auth->cookie, drv_auth->cookie, drv_auth->cookie_len);

	g_data.cb(bssid, QRPE_DRV_EVENT_AUTH, auth);
	QRPE_FREE(auth);
}
#endif

static int qrpe_qtna_get_keyid_from_hostapd(uint8_t *sta_mac, uint8_t *keyid)
{
	FILE *fp = NULL;
	char tmp[HAPDCLI_OUTPUT_LINE_LEN_MAX] = {0}, mac_str[32] = {0};
	char *p_keyid = NULL;
	uint16_t len_keyid = 0;

	if (NULL == sta_mac) {
		QRPE_ERROR("qrpe_qtna_get_keyid_from_hostapd:: STA_MAC is NULL");
		return 0;
	}

	fp = popen(HAPDCLI_CMD_GETKEY, "r");
	if (!fp) {
		QRPE_ERROR("qrpe_qtna_get_keyid_from_hostapd:: get pipe failed!");
		return 0;
	}

	sprintf(mac_str, MACSTR, MAC2STR(sta_mac));
	while(NULL != fgets(tmp, HAPDCLI_OUTPUT_LINE_LEN_MAX, fp)) {
		if (0 == strncasecmp(tmp, mac_str, strlen(mac_str))) {
			p_keyid = tmp + strlen(mac_str) +1; /*we have one blankspace in the cli output*/
			len_keyid = strlen(p_keyid);
			if (len_keyid)
				snprintf((char *)keyid, PSK_KEYID_LEN_MAX, "%s", p_keyid);
			if (len_keyid > PSK_KEYID_LEN_MAX)
				len_keyid = PSK_KEYID_LEN_MAX;
			break;
		}
	}
	pclose(fp);
	return len_keyid;
}

static void qrpe_qtna_report_assoc_additional_info(uint8_t *bssid, uint8_t *sta_mac)
{
	QRPE_DRV_ASSOC_ADDITIONAL_INFO additional_info;

	additional_info.len_keyid = qrpe_qtna_get_keyid_from_hostapd(sta_mac, additional_info.keyid);
	memcpy(additional_info.sta_mac, sta_mac, ETH_ALEN);
	if (additional_info.len_keyid)
		g_data.cb(bssid, QRPE_DRV_EVENT_ASSOC_ADDITIONAL_INFO, &additional_info);
}

static void qrpe_qtna_report_event_connect_complete(uint8_t *bssid, uint8_t *data, uint16_t len)
{
	struct ieee80211_qrpe_event_connect_compl *drv_connect =
		(struct ieee80211_qrpe_event_connect_compl *)data;
	QRPE_DRV_CONNECT_T *connect;

	if (len < sizeof(struct ieee80211_qrpe_event_connect_compl)) {
		QRPE_WARN("Skip connect complete event from driver: len(%d) too small", len);
		return;
	}

	if ((sizeof(QRPE_DRV_CONNECT_T) + drv_connect->cookie_len)
		> IEEE80211_QRPE_MAX_LEN) {
		QRPE_WARN("Skip probe req event from driver: cookie len(%d) too large ", drv_connect->cookie_len);
		return;
	}

	if (NULL == (connect = QRPE_CALLOC(1, sizeof(QRPE_DRV_CONNECT_T) + drv_connect->cookie_len)))
		return;

	memcpy(connect->peer_mac, drv_connect->mac, ETH_ALEN);
	connect->rx_ss_info = drv_connect->nss;
	connect->max_phy_rate = drv_connect->max_phy_rate;
	connect->node_type = drv_connect->node_type;
	connect->curr_band = drv_connect->band;
	connect->channel = drv_connect->channel;
	connect->band_width = drv_connect->band_width;
	connect->support_vht = drv_connect->support_vht;
	connect->support_ht = drv_connect->support_ht;
	connect->support_11v = drv_connect->support_11v;
	connect->mumimo_capab = drv_connect->mumimo_capab;
	connect->cookie_len = drv_connect->cookie_len;
	memcpy(connect->cookie, drv_connect->cookie, drv_connect->cookie_len);

	g_data.cb(bssid, QRPE_DRV_EVENT_CONNECT_COMPL, connect);
	QRPE_FREE(connect);

	qrpe_qtna_report_assoc_additional_info(bssid, drv_connect->mac);
}

static void qrpe_qtna_report_event_trans_status(uint8_t *bssid, uint8_t *data, uint16_t len)
{
	struct ieee80211_qrpe_event_btm_status *drv_btm_status =
		(struct ieee80211_qrpe_event_btm_status *)data;
	QRPE_DRV_TRANS_STATUS_T status;

	if (len < sizeof(struct ieee80211_qrpe_event_btm_status)) {
		QRPE_WARN("Skip btm status event from driver: len(%d) too small", len);
		return;
	}

	memcpy(status.sta_mac, drv_btm_status->mac, ETH_ALEN);
	status.status_code = drv_btm_status->status;

	g_data.cb(bssid, QRPE_DRV_EVENT_BSS_TRANS_STATUS, &status);
}

static void qrpe_qtna_report_event_disassoc(uint8_t *bssid, uint8_t *data, uint16_t len)
{
	struct ieee80211_qrpe_event_disconn *drv_disassoc =
		(struct ieee80211_qrpe_event_disconn *)data;
	QRPE_DRV_DISASSOC_T disassoc;

	if (len < sizeof(struct ieee80211_qrpe_event_disconn)) {
		QRPE_WARN("Skip disassoc/deauth event from driver: len(%d) too small", len);
		return;
	}

	memcpy(disassoc.peer_mac, drv_disassoc->mac, ETH_ALEN);
	disassoc.reason_code = drv_disassoc->reason;
	disassoc.direction = drv_disassoc->direction;

	g_data.cb(bssid, QRPE_DRV_EVENT_DISASSOC, &disassoc);
}

static inline void qrpe_qtna_fill_sta_phy_stats(QRPE_DRV_STA_STATS_ENTRY_T *stat,
	struct ieee80211_qrpe_sta_stats_entry *stat_from_drv)
{
	memcpy(stat->sta, stat_from_drv->mac, ETH_ALEN);
	stat->assoc_stats.age_last_rx_pkt = stat_from_drv->age_last_rx_pkt;
	stat->assoc_stats.age_last_tx_pkt = stat_from_drv->age_last_tx_pkt;
	stat->assoc_stats.rx_phy_rate = stat_from_drv->rx_phy_rate;
	stat->assoc_stats.rx_bandwidth = stat_from_drv->rx_bw;
	stat->assoc_stats.tx_phy_rate = stat_from_drv->tx_phy_rate;
	stat->assoc_stats.tx_bandwidth = stat_from_drv->tx_bw;
	stat->assoc_stats.pkts_per_sec = stat_from_drv->pkts_per_sec;
	stat->assoc_stats.avg_airtime = stat_from_drv->avg_airtime;
	stat->assoc_stats.rssi_dbm = stat_from_drv->rssi;
}

static inline void qrpe_qtna_fill_sta_link_stats(QRPE_DRV_STA_STATS_ENTRY_T *stat,
	struct ieee80211req_sta_stats *link_stats)
{
	stat->assoc_stats.stats.tx_packets = link_stats->is_stats.ns_tx_data;
	stat->assoc_stats.stats.tx_bytes = link_stats->is_stats.ns_tx_bytes;
	stat->assoc_stats.stats.rx_packets = link_stats->is_stats.ns_rx_data;
	stat->assoc_stats.stats.rx_bytes = link_stats->is_stats.ns_rx_bytes;
	stat->assoc_stats.stats.tx_errs = link_stats->is_stats.ns_tx_dropped;
	stat->assoc_stats.stats.rx_errs = link_stats->is_stats.ns_tx_errors;
	stat->assoc_stats.stats.tx_retries = link_stats->is_stats.ns_tx_allretries;
}

static inline int qrpe_qtna_get_and_fill_sta_link_stats(const char *ifname,
		QRPE_DRV_STA_STATS_ENTRY_T *stats)
{
	struct ieee80211req_sta_stats drv_linkstats;
	int ret = 0;

	if (g_data.ioctl_sock < 0)
		return -EINVAL;

	QRPE_DEBUG("QRPE get sta link stats for qtna interface %s", ifname);

	memcpy(drv_linkstats.is_u.macaddr, stats->sta, ETH_ALEN);
	ret = qrpe_qtna_set_iwpriv(g_data.ioctl_sock, ifname,
		IEEE80211_IOCTL_STA_STATS, &drv_linkstats, sizeof(struct ieee80211req_sta_stats));
	if (ret >= 0)
		qrpe_qtna_fill_sta_link_stats(stats, &drv_linkstats);

	return ret;
}

static void qrpe_qtna_report_event_sta_phy_stats(uint8_t *bssid, uint8_t *data, uint16_t len)
{
	uint16_t nums;
	struct ieee80211_qrpe_sta_stats *drv_stats = (struct ieee80211_qrpe_sta_stats *)data;
	QRPE_DRV_STA_STATS_T *stats;
	QRPE_INTF_T *intf;
	int i;

	intf = qrpe_find_intf_by_ifmac(bssid);
	if (!intf)
		return;
	nums = drv_stats->num;
	if (!nums)
		return;
	if (nums > MAX_DRV_STA_ENTRY)
		nums = MAX_DRV_STA_ENTRY;

	if (NULL == (stats = QRPE_CALLOC(1, sizeof(QRPE_DRV_STA_STATS_T))))
		return;

	for (i = 0; i < nums; i++) {
		qrpe_qtna_fill_sta_phy_stats(stats->entries + i, drv_stats->entries + i);
		qrpe_qtna_get_and_fill_sta_link_stats((const char *)intf->ifname,
				stats->entries + i);
	}
	stats->num_sta = nums;

	g_data.cb(bssid, QRPE_DRV_EVENT_STA_PHY_STATS, stats);
	QRPE_FREE(stats);
}

static void qrpe_qtna_report_event_frame(uint8_t *bssid,
	uint8_t *data, uint16_t len)
{
	struct ieee80211_qrpe_event_recv_frame *drv_frm =
		(struct ieee80211_qrpe_event_recv_frame *)data;
	QRPE_DRV_FRAME_T *frame;

	if (len < sizeof(struct ieee80211_qrpe_event_recv_frame)
		|| len < (sizeof(struct ieee80211_qrpe_event_recv_frame)
			+ drv_frm->data_len)) {
		QRPE_WARN("Skip event frame from driver: len(%d) too small", len);
		return;
	}

	if (NULL == (frame = QRPE_CALLOC(1, sizeof(QRPE_DRV_FRAME_T) + drv_frm->data_len)))
		return;

	frame->rssi_dbm = drv_frm->rssi;
	frame->channel = drv_frm->chan;
	frame->erw_result = drv_frm->driver_process;
	frame->frame_len = drv_frm->data_len;
	memcpy(frame->frame, drv_frm->data, drv_frm->data_len);

#if 0
	QRPE_DUMP_F("dump frame received from driver",
			(uint8_t *)frame->frame, frame->frame_len);
#endif
	g_data.cb(bssid, QRPE_DRV_EVENT_FRAME, frame);
	QRPE_FREE(frame);
}

static void qrpe_qtna_report_event_radio_status_pwrsave(uint8_t *bssid, uint8_t *data, uint16_t len)
{

	struct ieee80211_qrpe_event_ps_state *drv_ps =
		(struct ieee80211_qrpe_event_ps_state *)data;
	QRPE_DRV_RADIO_PWRSAVE_STATUS_T ps;

	if (len < sizeof(struct ieee80211_qrpe_event_ps_state)) {
		QRPE_WARN("Skip powersave state event from driver: len(%d) too small", len);
		return;
	}

	ps.ps_state = drv_ps->pm_state;
	g_data.cb(bssid, QRPE_DRV_EVENT_RADIO_PWRSAVE, &ps);
}

static uint8_t qrpe_qtna_map_radio_chan_status(uint8_t status)
{
       uint8_t chan_status = 0xff;

	if (status & IEEE80211_QRPE_CHAN_STATUS_INACTIVE)
		chan_status = QRPE_DRV_CHAN_STATUS_NON_OPERABLE;
	else if (status & IEEE80211_QRPE_CHAN_STATUS_NOT_AVAILABLE_RADAR_DETECTED)
		chan_status = QRPE_DRV_CHAN_STATUS_RADAR_DETECTED;
	else if (status & IEEE80211_QRPE_CHAN_STATUS_NOT_AVAILABLE_CAC_REQUIRED)
		chan_status = QRPE_DRV_CHAN_STATUS_CAC_REQUIRED;
	else if ((status & IEEE80211_QRPE_CHAN_STATUS_DFS)
		&& !(status & IEEE80211_QRPE_CHAN_STATUS_NOT_AVAILABLE))
		chan_status = QRPE_DRV_CHAN_STATUS_CAC_VALID;
	else if (!(status & IEEE80211_QRPE_CHAN_STATUS_DFS)
		&& !(status & IEEE80211_QRPE_CHAN_STATUS_NOT_AVAILABLE))
		chan_status = QRPE_DRV_CHAN_STATUS_AVAILABLE;

	return chan_status;
}

static void qrpe_qtna_report_event_update_chan_state(uint8_t *bssid, uint8_t *data, uint16_t len)
{
	struct ieee80211_qrpe_update_chan_state *ch_state =
		(struct ieee80211_qrpe_update_chan_state *)data;
	QRPE_DRV_CHAN_ENTRY_T ch;
	int i = 0;

	if (len < sizeof(struct ieee80211_qrpe_update_chan_state)) {
		QRPE_WARN("Skip channel state event from driver: len(%d) too small", len);
		return;
	}

	while (i < IEEE80211_CHAN_MAX && ch_state->chaninfo_set[i].chan_no != 0) {
		ch.chan = ch_state->chaninfo_set[i].chan_no;
		ch.status = qrpe_qtna_map_radio_chan_status(ch_state->chaninfo_set[i].chan_status);

		g_data.cb(bssid, QRPE_DRV_EVENT_CHAN_STATE_UPDATE, &ch);
		i++;
	}
}

#ifdef CONFIG_SUPPORT_QTNA_SPDIA
static void qrpe_qtna_report_event_spdia_info(uint8_t *bssid, uint8_t *data, uint16_t len)
{
	int retval;
	uint8_t *spdia_buf = NULL;
	struct qspdia_csi_report *drv_spdia = NULL;
	QRPE_DRV_SPDIA_INFO_T spdia;
	struct ieee80211_qrpe_event_spdia *drv_event
		= (struct ieee80211_qrpe_event_spdia *)data;
	QRPE_INTF_T *intf = qrpe_find_intf_by_ifmac(bssid);
	if (!intf)
		return;

	if (NULL == (spdia_buf = QRPE_MALLOC(QSPDIA_BUCKET_SIZE)))
		return;

	memcpy(spdia_buf, drv_event, sizeof(*drv_event));

	retval = qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)intf->ifname,
		SIOCDEV_SUBIO_GET_SPDIA_STATS, spdia_buf, QSPDIA_BUCKET_SIZE);
	if (retval < 0)
		goto __out;

	drv_spdia = (struct qspdia_csi_report *)spdia_buf;
	if (drv_spdia->hdr.size < sizeof(*drv_spdia))
		goto __out;

	memset(&spdia, 0, sizeof(spdia));
	memcpy(spdia.peer_mac, drv_spdia->macaddr, ETH_ALEN);
	spdia.timestamp = drv_spdia->timestamp;
#ifdef QRPE_SUPPORT_QTNA_PEARL_DRIVER
	spdia.chains = 8;
#else
	spdia.chains = 4;
#endif
	memcpy(spdia.rssis, drv_spdia->rssi, spdia.chains * sizeof(int32_t));
	spdia.hw_noise = drv_spdia->hw_noise;
	spdia.bf_mode = drv_spdia->bf_mode;
	spdia.nc = drv_spdia->nc;
	spdia.nr = drv_spdia->nr;
	spdia.ng = drv_spdia->ng;
	spdia.bw = drv_spdia->bw;
	spdia.chan = drv_spdia->chan;
	spdia.mcs = drv_spdia->mcs;
	spdia.mcs_ss = drv_spdia->nss;
	spdia.ntones = drv_spdia->ntones;
	spdia.payload_len = drv_spdia->hdr.size - sizeof(*drv_spdia);
	if (drv_spdia->hdr.size > QSPDIA_BUCKET_SIZE)
		spdia.payload_len = QSPDIA_BUCKET_SIZE - sizeof(*drv_spdia);
	spdia.payload = (uint8_t *)drv_spdia->h_mat;

	g_data.cb(bssid, QRPE_DRV_EVENT_SPDIA_INFO, &spdia);

__out:
	QRPE_FREE(spdia_buf);
}
#endif

static int qrpe_qtna_check_in_roaming(void)
{
	uint64_t now = get_reltime();
	if (g_data.tstamp
		&& now - g_data.tstamp < g_conf.qtna_roam_period)
		return 1;

	return 0;
}

static int qrpe_qtna_start_sta_roaming(char *ifname, uint8_t *target)
{
	char cmd[128];
	int ret;

	if (access(QRPE_QTNA_WPA_CLI_CMDNAME, X_OK) != 0)
		return -1;

	ret = snprintf(cmd, sizeof(cmd), "%s -i %s roam " MACSTR "",
		QRPE_QTNA_WPA_CLI_CMDNAME, ifname, MAC2STR(target));
	if (ret >= sizeof(cmd))
		return -1;

	ret = system(cmd);
	if (ret)
		return -1;

	return 0;
}

static void qrpe_qtna_report_event_sta_roam_fail(uint8_t *bssid, uint8_t reason)
{
	QRPE_DEBUG("report station roam fail, reason(%u)", reason);

	g_data.roam.reason = reason;
	if (g_data.cb)
		g_data.cb(bssid, QRPE_DRV_EVENT_ROAM_FAIL, &g_data.roam);

	memset(&g_data.roam, 0, sizeof(QRPE_DRV_ROAM_STATUS_T));
}

static int qrpe_qtna_scan_sub_command(const char *ifname, uint8_t *target,
		uint8_t ch, uint8_t opclass);
static void qrpe_qtna_report_event_roam_scan_result(uint8_t *bssid,
		uint8_t *data, uint16_t len)
{
	struct ieee80211_qrpe_event_scan_result *drv_event
		= (struct ieee80211_qrpe_event_scan_result *)data;
	QRPE_INTF_T *intf;
	int ret;

	if (len < sizeof(struct ieee80211_qrpe_event_scan_result)) {
		QRPE_WARN("Skip scan result event from driver: len(%d) too small", len);
		return;
	}

	if (memcmp(g_data.roam.target, drv_event->se_bssid, ETH_ALEN)
		|| g_data.roam.channel != drv_event->se_ch) {
		QRPE_WARN("Skip scan result event from driver:"
			"target BSSID" MACSTR " or channel(%u) not match",
			MAC2STR(drv_event->se_bssid), drv_event->se_ch);
		return;
	}

	if ((ret = qrpe_qtna_check_in_roaming()) == 0) {
		QRPE_WARN("Skip scan result event from driver: expired in this period");
		return;
	}

	if (NULL == (intf = qrpe_find_intf_by_ifmac(bssid)))
		return;

	g_data.roam.reason = QRPE_DRV_ROAM_REASON_NO_PROBE_RESP;
	if (drv_event->found == 1) {
		ret = qrpe_qtna_start_sta_roaming(intf->ifname, g_data.roam.target);
		if (ret >= 0)
			return;

		QRPE_ERROR("execute STA roaming command failed");
		g_data.roam.reason = QRPE_DRV_ROAM_REASON_UNKNOWN_FAILURE;
	}
	if (g_data.scan_retries < QRPE_QTNA_SCAN_MAX_RETRIES) {
		g_data.scan_retries += 1;
		qrpe_qtna_scan_sub_command(intf->ifname, g_data.roam.target,
			g_data.roam.channel, g_data.roam.opclass);
		return;
	}

	qrpe_qtna_report_event_sta_roam_fail(bssid, g_data.roam.reason);
}

static void qrpe_qtna_report_event_intf_update_notify(uint8_t *bssid, uint8_t *data, uint16_t len)
{
	g_data.cb(bssid, QRPE_DRV_EVENT_INTF_UPDATE_NOTIFY, NULL);
}

static void qrpe_qtna_process_event_from_driver(uint8_t *data, int len)
{
	struct ieee80211_qrpe_event_data *drv_event = (struct ieee80211_qrpe_event_data *)data;

	if (!g_data.cb)
		return;

	if(len < sizeof(struct ieee80211_qrpe_event_data)
		|| strncmp(drv_event->name, IEEE80211_QRPE_EVENT_GROUP_NAME,
		strlen(IEEE80211_QRPE_EVENT_GROUP_NAME)))
		return;

	QRPE_INFO("recv event(%u) from qtna driver", drv_event->event_id);
	switch(drv_event->event_id) {
	case IEEE80211_QRPE_EVENT_PROBE_REQ:
#ifdef CONFIG_SUPPORT_QTNA_ASSOC_EVENT
	case IEEE80211_QRPE_EVENT_ASSOC_REQ:
#endif
		qrpe_qtna_report_event_probe_req_or_assoc(drv_event->event_id, drv_event->bssid,
			drv_event->event, drv_event->len);
		break;

#ifdef CONFIG_SUPPORT_QTNA_AUTH_EVENT
	case IEEE80211_QRPE_EVENT_AUTH:
		qrpe_qtna_report_event_auth(drv_event->bssid,
			drv_event->event, drv_event->len);
		break;
#endif

	case IEEE80211_QRPE_EVENT_CONNECT_COMPL:
		qrpe_qtna_report_event_connect_complete(drv_event->bssid,
			drv_event->event, drv_event->len);
		break;

	case IEEE80211_QRPE_EVENT_BTM_STATUS:
		qrpe_qtna_report_event_trans_status(drv_event->bssid,
			drv_event->event, drv_event->len);
		break;

	case IEEE80211_QRPE_EVENT_DEAUTH:
	case IEEE80211_QRPE_EVENT_DISASSOC:
		qrpe_qtna_report_event_disassoc(drv_event->bssid,
			drv_event->event, drv_event->len);
		break;

	case IEEE80211_QRPE_EVENT_STA_STATS:
		qrpe_qtna_report_event_sta_phy_stats(drv_event->bssid,
			drv_event->event, drv_event->len);
		break;

#ifdef CONFIG_SUPPORT_QTNA_SPDIA
	case IEEE80211_QRPE_EVENT_SPDIA_STATS:
		qrpe_qtna_report_event_spdia_info(drv_event->bssid,
			drv_event->event, drv_event->len);
		break;
#endif

	case IEEE80211_QRPE_EVENT_INTF_UPDATE_NOTIFY:
		qrpe_qtna_report_event_intf_update_notify(drv_event->bssid,
			drv_event->event, drv_event->len);
		break;

	case IEEE80211_QRPE_EVENT_RECV_MGMT_FRAME:
		qrpe_qtna_report_event_frame(drv_event->bssid,
			drv_event->event, drv_event->len);
		break;

	case IEEE80211_QRPE_EVENT_INTF_POWERSAVE_STATE:
		qrpe_qtna_report_event_radio_status_pwrsave(drv_event->bssid,
			drv_event->event, drv_event->len);
		break;

	case IEEE80211_QRPE_EVENT_SCAN_RESULT:
		qrpe_qtna_report_event_roam_scan_result(drv_event->bssid,
			drv_event->event, drv_event->len);
		break;

	case IEEE80211_QRPE_EVENT_UPDATE_CHAN_STATE:
		qrpe_qtna_report_event_update_chan_state(drv_event->bssid,
			drv_event->event, drv_event->len);
		break;

	default:
		QRPE_WARN("Skip event(%u) from driver", drv_event->event_id);
		break;
	}
}

static uint8_t g_qtna_buff[QRPE_MAX_MSG_LEN];

static void qrpe_qtna_report_event_intf_status(uint8_t *bssid, int type, int status)
{
	QRPE_DRV_INTF_STATUS_T drv_status;
	drv_status.type = type;
	drv_status.status = status;
	drv_status.all_bss = 1;

	if (g_data.cb)
		g_data.cb(bssid, QRPE_DRV_EVENT_INTF_STATUS, &drv_status);
}

#define QRPE_QTNA_CAC_START_EVENT	"RADAR: CAC started"
#define QRPE_QTNA_CAC_STOP_EVENT	"RADAR: CAC stopped"
#define QRPE_QTNA_CAC_COMP_EVENT	"RADAR: CAC completed"
#define QRPE_QTNA_CAC_CONT_EVENT	"RADAR: CAC continue"

static void qrpe_qtna_check_and_process_cac_event_from_driver(char *ifname, char *data, int len)
{
	int status;
	struct ifreq ifr;
	if (len > strlen(QRPE_QTNA_CAC_START_EVENT)
		&& !strncmp(data, QRPE_QTNA_CAC_START_EVENT, strlen(QRPE_QTNA_CAC_START_EVENT)))
		status = QRPE_INTF_CAC_STATE_RUNNING;
	else if (len > strlen(QRPE_QTNA_CAC_STOP_EVENT)
		&& !strncmp(data, QRPE_QTNA_CAC_STOP_EVENT, strlen(QRPE_QTNA_CAC_STOP_EVENT)))
		status = QRPE_INTF_CAC_STATE_NOTRUNNING;
	else if (len > strlen(QRPE_QTNA_CAC_COMP_EVENT)
		&& !strncmp(data, QRPE_QTNA_CAC_COMP_EVENT, strlen(QRPE_QTNA_CAC_COMP_EVENT)))
		status = QRPE_INTF_CAC_STATE_NOTRUNNING;
	else if (len > strlen(QRPE_QTNA_CAC_CONT_EVENT)
		&& !strncmp(data, QRPE_QTNA_CAC_CONT_EVENT, strlen(QRPE_QTNA_CAC_CONT_EVENT)))
		status = QRPE_INTF_CAC_STATE_RUNNING;
	else
		return;

	strncpy(ifr.ifr_name, ifname, IFNAMSIZ - 1);
	if (ioctl(g_data.ioctl_sock, SIOCGIFHWADDR, &ifr) >= 0)
		qrpe_qtna_report_event_intf_status((uint8_t *)ifr.ifr_hwaddr.sa_data, QRPE_INTF_STATUS_TYPE_CAC, status);
}

static uint8_t qrpe_qtna_check_event_is_radar(char *data, int len)
{
	if ((len > strlen(QRPE_QTNA_CAC_START_EVENT)
		&& !strncmp(data, QRPE_QTNA_CAC_START_EVENT, strlen(QRPE_QTNA_CAC_START_EVENT)))
	    || (len > strlen(QRPE_QTNA_CAC_STOP_EVENT)
		&& !strncmp(data, QRPE_QTNA_CAC_STOP_EVENT, strlen(QRPE_QTNA_CAC_STOP_EVENT)))
	    || (len > strlen(QRPE_QTNA_CAC_COMP_EVENT)
		&& !strncmp(data, QRPE_QTNA_CAC_COMP_EVENT, strlen(QRPE_QTNA_CAC_COMP_EVENT)))
	    || (len > strlen(QRPE_QTNA_CAC_CONT_EVENT)
		&& !strncmp(data, QRPE_QTNA_CAC_CONT_EVENT, strlen(QRPE_QTNA_CAC_CONT_EVENT))))
		return 1;
	else
		return 0;
}

static uint8_t qrpe_qtna_get_radar_channel(char *str)
{
	char *start;
	uint8_t i = 0, chan = 0;

	start = strstr(str, "channel") + strlen("channel");
	while (*start && i++ < 4) {
		if (isdigit(*start) && isdigit(*(start + 1)))
			chan = (uint8_t)strtoul(start, &start, 10);
		else
			start++;
	}
	return chan;
}

static uint8_t qrpe_qtna_convert_chan_status(uint8_t chan_status)
{
	uint8_t status = 0xff;

	switch(chan_status) {
	case QRPE_QTNA_CHAN_STATUS_NON_AVAILABLE:
		status = QRPE_DRV_CHAN_STATUS_NON_OPERABLE;
		break;
	case QRPE_QTNA_CHAN_STATUS_AVAILABLE:
		status = QRPE_DRV_CHAN_STATUS_CAC_VALID;
		break;
	case QRPE_QTNA_CHAN_STATUS_NOT_AVAILABLE_RADAR_DETECTED:
		status = QRPE_DRV_CHAN_STATUS_RADAR_DETECTED;
		break;
	case QRPE_QTNA_CHAN_STATUS_NOT_AVAILABLE_CAC_REQUIRED:
		status = QRPE_DRV_CHAN_STATUS_CAC_REQUIRED;
		break;
	default:
		break;
	}

	return status;
}

static int qrpe_qtna_get_chan_status_sub_command(char *ifname, uint8_t chan, uint8_t *status);
static int qrpe_qtna_check_and_process_cac_event_for_radio(char *ifname, char *data, int len)
{
	QRPE_DRV_CHAN_ENTRY_T cac;
	struct ifreq ifr;
	int ret = -1;

	if (!ifname || g_data.ioctl_sock < 0)
		return -EINVAL;
	if ((0 == qrpe_qtna_check_event_is_radar(data, len))
		|| ((cac.chan = qrpe_qtna_get_radar_channel(data)) <= 0))
		return -EINVAL;

	ret = qrpe_qtna_get_chan_status_sub_command(ifname, cac.chan, &cac.status);
	if (ret < 0)
		return -1;

	strncpy(ifr.ifr_name, ifname, IFNAMSIZ - 1);
	if (ioctl(g_data.ioctl_sock, SIOCGIFHWADDR, &ifr) < 0)
		return -EINVAL;

	QRPE_DEBUG("cac status update:chan(%u)-status(%u) for interface %s",
		cac.chan, cac.status, ifname);
	if (g_data.cb)
		g_data.cb((uint8_t *)ifr.ifr_hwaddr.sa_data,
			QRPE_DRV_EVENT_CHAN_STATE_CAC, &cac);

	return ret;
}

static int qrpe_qtna_get_and_check_sta_roam_event(char *data)
{
	char *macstr;
	uint8_t bssid[ETH_ALEN];
	int ret;

	macstr = strstr(data, "addr=") + strlen("addr=");
	if (NULL == ether_aton_r(macstr, (struct ether_addr *)bssid)) {
		QRPE_WARN("must be hex-digits-and-colons notation unicast MAC address");
		return -1;
	}

	if ((ret = qrpe_qtna_check_in_roaming()) == 0) {
		QRPE_DEBUG("check sta roam event expired in this period");
		return -1;
	}

	if (memcmp(g_data.roam.target, bssid, ETH_ALEN)) {
		QRPE_WARN("check sta roam target address " MACSTR " not matching", MAC2STR(bssid));
		return -1;
	}

	return 0;
}

#define QRPE_QTNA_STA_DISCONNECT	"STA-DISCONNECT"
#define QRPE_QTNA_STA_CONNECT_FAIL	"STA-CONNECT-FAIL"
static void qrpe_qtna_check_and_process_sta_roam_connect_event(char *ifname, char *data, int len)
{
	uint8_t reason;
	struct ifreq ifr;
	int ret;

	if (len > strlen(QRPE_QTNA_STA_DISCONNECT)
		&& !strncmp(data, QRPE_QTNA_STA_DISCONNECT, strlen(QRPE_QTNA_STA_DISCONNECT)))
		reason = QRPE_DRV_ROAM_REASON_CONNECT_KEYWRONG;
	else if (len > strlen(QRPE_QTNA_STA_CONNECT_FAIL)
		&& !strncmp(data, QRPE_QTNA_STA_CONNECT_FAIL, strlen(QRPE_QTNA_STA_CONNECT_FAIL)))
		reason = QRPE_DRV_ROAM_REASON_NO_ASSOC_RESP;
	else
		return;

	QRPE_DEBUG("recevie event %s, target is " MACSTR "", data, MAC2STR(g_data.roam.target));
	if ((ret = qrpe_qtna_get_and_check_sta_roam_event(data)) < 0)
		return;

	strncpy(ifr.ifr_name, ifname, IFNAMSIZ - 1);
	if (ioctl(g_data.ioctl_sock, SIOCGIFHWADDR, &ifr) >= 0)
		qrpe_qtna_report_event_sta_roam_fail((uint8_t *)ifr.ifr_hwaddr.sa_data, reason);
}

static void qrpe_qtna_process_iwcustom_event(char *ifname, char *data, int len)
{
#ifdef QRPE_QTNA_RTNETLINK
	if (len >= strlen(IEEE80211_QRPE_EVENT_GROUP_NAME)
		&& !strncmp(data, IEEE80211_QRPE_EVENT_GROUP_NAME,
			strlen(IEEE80211_QRPE_EVENT_GROUP_NAME)))
		qrpe_qtna_process_event_from_driver((uint8_t *)data, len);
#endif

	qrpe_qtna_check_and_process_cac_event_for_radio(ifname, data, len);
	qrpe_qtna_check_and_process_cac_event_from_driver(ifname, data, len);
	qrpe_qtna_check_and_process_sta_roam_connect_event(ifname, data, len);
}

static void qrpe_qtna_process_wireless_event(char *ifname, char *data, int len)
{
	struct iw_event iwe_buf, *iwe = &iwe_buf;
	char *pos, *end, *custom;

	pos = data;
	end = data + len;

	while (pos + IW_EV_LCP_LEN <= end) {

		memcpy(&iwe_buf, pos, IW_EV_LCP_LEN);

		if (iwe->len <= IW_EV_LCP_LEN)
			return;

		custom = pos + IW_EV_POINT_LEN;

		if ((iwe->cmd == IWEVCUSTOM)) {
			char *dpos = (char *) &iwe_buf.u.data.length;
			int dlen = dpos - (char *) &iwe_buf;
			memcpy(dpos, pos + IW_EV_LCP_LEN, sizeof(struct iw_event) - dlen);
		} else {
			memcpy(&iwe_buf, pos, sizeof(struct iw_event));
			custom += IW_EV_POINT_OFF;
		}
		switch (iwe->cmd) {
		case IWEVCUSTOM:
			if (custom + iwe->u.data.length > end)
				return;
			qrpe_qtna_process_iwcustom_event(ifname, custom, iwe->u.data.length);
			break;
		default:
			break;
		}
		pos += iwe->len;
	}
}

static void qrpe_qtna_process_rtm_newlink_message(struct ifinfomsg *ifi, uint8_t *buf, size_t len)
{
	int attrlen, rta_len;
	struct rtattr *attr;
	char ifname[IFNAMSIZ + 1] = {0};
	attrlen = len;
	attr = (struct rtattr *) buf;
	rta_len = RTA_ALIGN(sizeof(struct rtattr));

	if_indextoname(ifi->ifi_index, ifname);
	while (RTA_OK(attr, attrlen)) {
		switch(attr->rta_type) {
		case  IFLA_WIRELESS:
			qrpe_qtna_process_wireless_event(ifname, ((char *) attr) + rta_len,
				attr->rta_len -	rta_len);
			break;
		}
		attr = RTA_NEXT(attr, attrlen);
	}
}

static void qrpe_qtna_process_rtnetlink_message(const unsigned char *msg, unsigned int len)
{
	struct nlmsghdr *h;

	h = (struct nlmsghdr *)msg;
	while (NLMSG_OK(h, len)) {
		switch (h->nlmsg_type) {
			case RTM_NEWLINK:
				qrpe_process_rtm_message(qrpe_qtna_process_rtm_newlink_message, h);
				break;
		}

		h = NLMSG_NEXT(h, len);
	}

	if (len > 0)
		QRPE_WARN("Extra %u bytes in the end of netlink message", len);
}

static void qrpe_qtna_receive_message(int sock)
{
	int len;

	len = recvfrom(sock, g_qtna_buff, QRPE_MAX_MSG_LEN, MSG_DONTWAIT,
		NULL, NULL);
	if (len < 0) {
		if (errno != EINTR && errno != EAGAIN)
			QRPE_WARN("Failed receive from driver: %s", strerror(errno));
		return;
	}

	qrpe_qtna_process_rtnetlink_message(g_qtna_buff, len);
}
#ifdef QRPE_QTNA_GENNETLINK
static int qrpe_qtna_receive_genl_message(struct nl_msg *nlmsg, void *arg)
{
	struct genlmsghdr *gnlh;
	struct nlattr *tb[NUM_QRPE_ATTR + 1];

	gnlh = nlmsg_data(nlmsg_hdr(nlmsg));
	if(gnlh->cmd != QRPE_GENL_DRV_EVENT)
		return NL_SKIP;

	nla_parse(tb, NUM_QRPE_ATTR, genlmsg_attrdata(gnlh, 0),
			genlmsg_attrlen(gnlh, 0), NULL);
	if(tb[QRPE_ATTR_EVENT_DATA])
		qrpe_qtna_process_event_from_driver(
			(uint8_t *)nla_data(tb[QRPE_ATTR_EVENT_DATA]),
			nla_len(tb[QRPE_ATTR_EVENT_DATA]));

	return NL_OK;
}
#endif

static void qrpe_qtna_check_and_process_fdset(uint8_t type, fd_set *fds)
{
	if (g_data.rtm_sock < 0)
		return;
#ifdef QRPE_QTNA_GENNETLINK
	if (g_data.drv_read_sock < 0)
		return;
#endif

	if (QRPE_FDSET_TYPE_READ != type
		|| !fds)
		return;

	if (FD_ISSET(g_data.rtm_sock, fds))
		qrpe_qtna_receive_message(g_data.rtm_sock);
#ifdef QRPE_QTNA_GENNETLINK
	if (FD_ISSET(g_data.drv_read_sock, fds))
		nl_recvmsgs(g_data.drv_read_nl_sock, g_data.nlcb);
#endif
}

static int qrpe_qtna_set_status(void *priv, uint8_t status)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	enum ieee80211_qrpe_status drv_status = IEEE80211_QRPE_STATUS_INACTIVE;
	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	QRPE_DEBUG("QRPE set status(%d) to driver for qtna interface %s", status, data->ifname);

	if (status == QRPE_INTF_ENABLE)
		drv_status = IEEE80211_QRPE_STATUS_ACTIVE;

	return qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)data->ifname,
		SIOCDEV_SUBIO_SET_BSA_STATUS, &drv_status, sizeof(drv_status));
}

static int qrpe_qtna_deauth_sta(void *priv, uint8_t *sta, uint16_t reason)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	struct ieee80211req_mlme mlme_req;

	if (!data || g_data.ioctl_sock < 0 || !sta)
		return -EINVAL;

	QRPE_DEBUG("QRPE deauth sta " MACSTR " associated with qtna interface %s",
		MAC2STR(sta), data->ifname);

	memcpy(mlme_req.im_macaddr, sta, ETH_ALEN);
	mlme_req.im_op = IEEE80211_MLME_DEAUTH;
	mlme_req.im_reason = reason;

	return qrpe_qtna_set_iwpriv(g_data.ioctl_sock, data->ifname, IEEE80211_IOCTL_SETMLME,
		&mlme_req, sizeof(mlme_req));
}

static int qrpe_qtna_disassoc_sta(void *priv, uint8_t *sta, uint16_t reason)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	struct ieee80211req_mlme mlme_req;

	if (!data || g_data.ioctl_sock < 0 || !sta)
		return -EINVAL;

	QRPE_DEBUG("QRPE disassoc sta " MACSTR " associated with qtna interface %s",
		MAC2STR(sta), data->ifname);

	memcpy(mlme_req.im_macaddr, sta, ETH_ALEN);
	mlme_req.im_op = IEEE80211_MLME_DISASSOC;
	mlme_req.im_reason = reason;

	return qrpe_qtna_set_iwpriv(g_data.ioctl_sock, data->ifname, IEEE80211_IOCTL_SETMLME,
		&mlme_req, sizeof(mlme_req));
}

static int qrpe_qtna_filter_sta(void *priv, uint8_t *sta, uint8_t accept)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	struct ieee80211_qrpe_mac_filter mac_filter;

	if (!data || g_data.ioctl_sock < 0 || !sta)
		return -EINVAL;

	QRPE_DEBUG("QRPE filter sta " MACSTR " in qtna interface %s: %s",
		MAC2STR(sta), data->ifname, accept ? "accept" : "deny");

	memcpy(mac_filter.mac, sta, ETH_ALEN);
	if (accept)
		mac_filter.action = IEEE80211_QRPE_FILTER_ACTION_ALLOW;
	else
		mac_filter.action = IEEE80211_QRPE_FILTER_ACTION_DENY;

	return qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)data->ifname,
		SIOCDEV_SUBIO_UPDATE_MACFILTER_LIST, &mac_filter, sizeof(mac_filter));
}

#ifdef CONFIG_SUPPORT_QTNA_ERW
static void qrpe_qtna_erw_fill_entry(struct ieee80211_req_erw_entry *drv_entry, QRPE_DRV_ERW_ENTRY_T *entry)
{
	memcpy(drv_entry->mac_addr, entry->sta, ETH_ALEN);
	if (entry->erw_op == QRPE_DRV_ERW_OP_ADD)
		drv_entry->op = IEEE80211_ERW_ENTRY_OP_ADD;
	else
		drv_entry->op = IEEE80211_ERW_ENTRY_OP_DEL;

	if (entry->erw_mode == QRPE_DRV_ERW_MODE_MIN) {
		drv_entry->rssi_mode = IEEE80211_ERW_RSSI_MODE_MIN;
		drv_entry->rssi_thrd_min = entry->rssi;
	} else if (entry->erw_mode == QRPE_DRV_ERW_MODE_MAX) {
		drv_entry->rssi_mode = IEEE80211_ERW_RSSI_MODE_MAX;
		drv_entry->rssi_thrd_max = entry->rssi;
	} else {
		drv_entry->rssi_mode = IEEE80211_ERW_RSSI_MODE_NONE;
	}
	drv_entry->frame_select = 0;
	if (entry->erw_probe_resp)
		drv_entry->frame_select |= IEEE80211_ERW_PROBE_RESP;
	if (entry->erw_assoc_resp)
		drv_entry->frame_select |= (IEEE80211_ERW_ASSOC_RESP | IEEE80211_ERW_REASSOC_RESP);
	if (entry->erw_auth_resp)
		drv_entry->frame_select |= IEEE80211_ERW_AUTH_RESP;

	drv_entry->reject_mode = entry->reject_mode;
	drv_entry->idx_mask = entry->reject_nrie_mask[0];
}

static void qrpe_qtna_erw_build_set_entries(QRPE_QTNA_INTF_DATA_T *data,
	struct ieee80211_qrpe_req_erw *drv_erw, QRPE_DRV_ERW_T *erw)
{
	int i;
	struct ieee80211_req_erw_entry_list *drv_erw_list;

	QRPE_DEBUG("QRPE build setting erw(entries %u) request for qtna interface %s",
		erw->num_sta, data->ifname);

	drv_erw->req = IEEE80211_ERW_REQ_SET;
	drv_erw_list = (struct ieee80211_req_erw_entry_list *)(drv_erw->data);
	for (i = 0; i < erw->num_sta; i++)
		qrpe_qtna_erw_fill_entry(drv_erw_list->erw_entry + i, erw->entries + i);
	drv_erw_list->num = erw->num_sta;
	drv_erw->data_len = sizeof(struct ieee80211_req_erw_entry_list)
		+ erw->num_sta * sizeof(struct ieee80211_req_erw_entry);
}

static void qrpe_qtna_erw_build_remove_all_entries(QRPE_QTNA_INTF_DATA_T *data,
	struct ieee80211_qrpe_req_erw *drv_erw)
{
	QRPE_DEBUG("QRPE build removing all erw entries request for qtna interface %s",
		data->ifname);

	drv_erw->req = IEEE80211_ERW_REQ_CLEAR;
	drv_erw->data_len = 0;
}

static uint32_t qrpe_qtna_erw_fill_nr_entry(QRPE_QTNA_INTF_DATA_T *data,
	struct ieee80211_req_erw_nr_entry *drv_entry, QRPE_DRV_ERW_NRIE_ENTRY_T *entry, uint8_t sub_op)
{
	if (entry->index >= IEEE80211_MAX_NEIGH_BSS) {
		QRPE_WARN("Discard the NR request for %u: over the max nr number(%u) for qtna interface %s",
			entry->index, IEEE80211_MAX_NEIGH_BSS, data->ifname);
		return 0;
	}

	drv_entry->op = sub_op;
	drv_entry->id = entry->index;
	if (sub_op == IEEE80211_ERW_NR_ENTRY_OP_ADD) {
		drv_entry->nr_ie_len = entry->len;
		if (entry->len < QRPE_NRIE_MIN_LEN)
			QRPE_WARN("Discard the NR ie for index %u: the len(%u) is less than %u",
				entry->index, entry->len, QRPE_NRIE_MIN_LEN);
		else
			memcpy(drv_entry->nr_ie, entry->nrie, entry->len);
	} else {
		drv_entry->nr_ie_len = 0;
	}
	return (sizeof(*drv_entry) + entry->len);
}

static void qrpe_qtna_erw_build_update_nrie_entries(QRPE_QTNA_INTF_DATA_T *data,
	struct ieee80211_qrpe_req_erw *drv_erw, QRPE_DRV_ERW_NRIE_T *erw_nrie)
{
	uint32_t i, len, nums = 0;
	struct ieee80211_req_erw_nr_entry_list *drv_erw_nr_list;
	struct ieee80211_req_erw_nr_entry *entry;
	uint8_t *pos;

	QRPE_DEBUG("QRPE build updating erw nr(entries %u) request for qtna interface %s",
		erw_nrie->num, data->ifname);

	drv_erw->req = IEEE80211_ERW_NR_REQ_SET;
	drv_erw_nr_list = (struct ieee80211_req_erw_nr_entry_list *)(drv_erw->data);
	pos = (uint8_t *)(drv_erw_nr_list->erw_nr_entry);
	for (i = 0; i < erw_nrie->num; i++) {
		entry = (struct ieee80211_req_erw_nr_entry *)pos;
		len = qrpe_qtna_erw_fill_nr_entry(data, entry,
			erw_nrie->entries + i, IEEE80211_ERW_NR_ENTRY_OP_ADD);
		if (len) {
			nums++;
			pos += QRPE_IE_LEN(len);
		}
	}

	drv_erw->data_len = sizeof(*drv_erw_nr_list)
		+ (pos - ((uint8_t *)drv_erw_nr_list->erw_nr_entry));
	drv_erw_nr_list->num = nums;
}

static void qrpe_qtna_erw_build_delete_nrie_entries(QRPE_QTNA_INTF_DATA_T *data,
	struct ieee80211_qrpe_req_erw *drv_erw, QRPE_DRV_ERW_NRIE_MASK_T *erw_nrie_mask)
{
	struct ieee80211_req_erw_nr_entry_list *drv_erw_nr_list;
	struct ieee80211_req_erw_nr_entry *entry;
	QRPE_DRV_ERW_NRIE_ENTRY_T nrie_entry;
	uint32_t i, index = 0, mask, nums = 0, len;

	QRPE_DEBUG("QRPE build deleting erw nr(0x%08x) request for qtna interface %s",
		(*erw_nrie_mask)[0], data->ifname);

	drv_erw->req = IEEE80211_ERW_NR_REQ_SET;
	drv_erw_nr_list = (struct ieee80211_req_erw_nr_entry_list *)(drv_erw->data);
	entry = (struct ieee80211_req_erw_nr_entry *)drv_erw_nr_list->erw_nr_entry;

	for (i = 0; i < QRPE_DRV_NRIE_MASK_NUMS; i++) {
		mask = (*erw_nrie_mask)[i];
		index = i * QRPE_UINT32_BITS;

		while (mask) {
			if (mask & 0x1) {
				nrie_entry.index = index;
				len = qrpe_qtna_erw_fill_nr_entry(data, entry + nums,
					&nrie_entry, IEEE80211_ERW_NR_ENTRY_OP_DEL);
				if (len)
					nums++;
			}
			mask >>= 1;
			index++;

			if (nums >= IEEE80211_MAX_NEIGH_BSS)
				goto __end;
		}

	}

__end:
	drv_erw->data_len = sizeof(*drv_erw_nr_list) + nums * sizeof(*entry);
	drv_erw_nr_list->num = nums;
}

static uint32_t qrpe_qtna_erw_get_space_for_set_entries(QRPE_DRV_ERW_T *erw)
{
	if (!erw || erw->num_sta > MAX_DRV_STA_ENTRY)
		return 0;

	return (sizeof(struct ieee80211_qrpe_req_erw)
		+ sizeof(struct ieee80211_req_erw_entry_list)
		+ erw->num_sta * sizeof(struct ieee80211_req_erw_entry));
}

static uint32_t qrpe_qtna_erw_get_space_for_update_nr_entries(QRPE_DRV_ERW_NRIE_T *erw_nrie)
{
	uint32_t space;
	int i;

	if (!erw_nrie || erw_nrie->num > MAX_DRV_NR_ENTRY)
		return 0;

	space = sizeof(struct ieee80211_qrpe_req_erw)
		+ sizeof(struct ieee80211_req_erw_nr_entry_list)
		+ sizeof(struct ieee80211_req_erw_nr_entry) * erw_nrie->num;

	for (i = 0; i < erw_nrie->num; i++)
		space += QRPE_IE_LEN(erw_nrie->entries[i].len);

	return space;
}

static uint32_t qrpe_qtna_erw_get_space(QRPE_QTNA_INTF_DATA_T *data, uint8_t op, void *erw)
{
	uint32_t space = 0;
	switch (op) {
	case QRPE_DRV_ERW_OP_SET_ENTRIES:
		space = qrpe_qtna_erw_get_space_for_set_entries((QRPE_DRV_ERW_T *)erw);
		break;

	case QRPE_DRV_ERW_OP_REMOVE_ALL:
		space = sizeof(struct ieee80211_qrpe_req_erw);
		break;

	case QRPE_DRV_ERW_OP_UPDATE_NRIE_ENTRIES:
		space = qrpe_qtna_erw_get_space_for_update_nr_entries((QRPE_DRV_ERW_NRIE_T *)erw);
		break;

	case QRPE_DRV_ERW_OP_DELETE_NRIE_ENTRIES:
		space = sizeof(struct ieee80211_qrpe_req_erw)
			+ sizeof(struct ieee80211_req_erw_nr_entry_list)
			+ sizeof(struct ieee80211_req_erw_nr_entry) * IEEE80211_MAX_NEIGH_BSS;
		break;

	default:
		break;
	}

	return space;
}
#endif

static int qrpe_qtna_set_erw(void *priv, uint8_t op, void *erw)
{
#ifdef CONFIG_SUPPORT_QTNA_ERW
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	struct ieee80211_qrpe_req_erw *drv_erw;
	uint32_t space = 0;
	int ret = -1;

	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	if (QRPE_DRV_ERW_OP_REMOVE_ALL != op
		&& !erw)
		return -EINVAL;

	space = qrpe_qtna_erw_get_space(data, op, erw);
	if (!space)
		return -EINVAL;

	if (NULL == (drv_erw = QRPE_CALLOC(1, space)))
		return -ENOMEM;

	switch (op) {
	case QRPE_DRV_ERW_OP_SET_ENTRIES:
		qrpe_qtna_erw_build_set_entries(data, drv_erw, (QRPE_DRV_ERW_T *)erw);
		break;

	case QRPE_DRV_ERW_OP_REMOVE_ALL:
		qrpe_qtna_erw_build_remove_all_entries(data, drv_erw);
		break;

	case QRPE_DRV_ERW_OP_UPDATE_NRIE_ENTRIES:
		qrpe_qtna_erw_build_update_nrie_entries(data, drv_erw, (QRPE_DRV_ERW_NRIE_T *)erw);
		break;

	case QRPE_DRV_ERW_OP_DELETE_NRIE_ENTRIES:
		qrpe_qtna_erw_build_delete_nrie_entries(data, drv_erw, (QRPE_DRV_ERW_NRIE_MASK_T *)erw);
		break;

	default:
		break;
	}

	ret = qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)data->ifname,
		SIOCDEV_SUBIO_ERW_ENTRY, drv_erw, sizeof(*drv_erw) + drv_erw->data_len);
	QRPE_FREE(drv_erw);

	return ret;
#else
	QRPE_WARN("QRPE qtna driver donot support ERW feature");
	return 0;
#endif
}

static uint16_t qrpe_qtna_get_mdid(const char *ifname)
{
	string_16 value = {0};
	uint16_t mdid_val = 0;
	uint8_t mdid[2];
	if (qcsapi_wifi_get_ieee80211r_mobility_domain(ifname, &value[0]) >= 0
		&& strlen(value) >= 4) {
		value[4] = '\0';
		mdid_val = strtoul(value, NULL, 16);
	}

	mdid[1] = mdid_val & 0xff;
	mdid[0] = (mdid_val >> 8) & 0xff;
	return *((uint16_t *)mdid);
}

static void qrpe_qtna_get_cc_alpha(uint8_t *cc_alpha)
{
	char region_name[8] = {'u','s'};
	char ifname[IFNAMSIZ];
	int ret = 0;

	if ((ret = qcsapi_get_primary_interface(ifname, IFNAMSIZ - 1)) >= 0) {
		if ((ret = qcsapi_wifi_get_regulatory_region(ifname,
			region_name)) < 0) {
			QRPE_WARN("can't get regulatory region for %s, error %d",
				ifname, ret);
			return;
		}
	} else
		QRPE_WARN("get primary interface error %d", ret);

	if (strncasecmp(region_name, "none", 4) == 0) {
		QRPE_WARN("get intf:%s regulatory region is none", ifname);
		return;
	}
	memcpy(cc_alpha, (uint8_t *)region_name, 2);
}

static uint32_t qrpe_qtna_build_supp_frame(uint8_t *match, uint8_t *supp_mgmt,
		uint32_t supp_mgmt_num, uint8_t *supp_action, uint32_t supp_action_num)
{
	/*
	* build tx/rx frame match format:
	*   non-action(3 Bytes): subtype + skb_copy + match_len(0)
	*   action(4 Bytes): subtype + bypass + match_len(1) + match[]
	* */
#define QRPE_QTNA_MGMT_MATCH_LEN 	3
#define QRPE_QTNA_ACTION_MATCH_LEN 	4
	uint8_t *start = match;
	uint8_t i, j;
	uint32_t space;

	space = QRPE_QTNA_MGMT_MATCH_LEN * supp_mgmt_num
			+ QRPE_QTNA_ACTION_MATCH_LEN * supp_action_num;
	if (space > MAX_DRV_REG_FRAME_LEN) {
		QRPE_ERROR("QRPE only support %d reg frame length for each interface",
			MAX_DRV_REG_FRAME_LEN);
		return 0;
	}

	for (i = 0; i < supp_mgmt_num; i++) {
		if (QRPE_SUBTYPE_ACTION == supp_mgmt[i]) {
			for (j = 0; j < supp_action_num; j++) {
				*match++ = supp_mgmt[i];
				*match++ = QRPE_DRV_FRAME_BYPASS;
				*match++ = 1;
				*match++ = supp_action[j];
			}
		} else {
			*match++ = supp_mgmt[i];
			*match++ = QRPE_DRV_FRAME_COPY;
			*match++ = 0;
		}
	}
	return (match - start);
}

static uint32_t qrpe_qtna_vap_mode_mapto_intftype(uint8_t vap_mode)
{
	uint32_t intftype = QRPE_NODE_TYPE_UNKNOW;

	switch(vap_mode) {
	case IEEE80211_M_STA:
		intftype = QRPE_NODE_TYPE_STA;
		break;
	case IEEE80211_M_WDS:
		intftype = QRPE_NODE_TYPE_WDS;
		break;
	case IEEE80211_M_HOSTAP:
		intftype = QRPE_NODE_TYPE_VAP;
		break;
	default:
		break;
	}
	return intftype;
}

static void qrpe_qtna_get_espi(void *priv, QRPE_DRV_ESPI_T *espi)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	uint32_t dis_ampdu = 0, en_amsdu = 0, ba_max = 0, ppdu_dur = 0;
	uint32_t data_format = QRPE_DRV_DATA_FORMAT_AGG_NONE;
	int ret, i;

	ret = qrpe_qtna_get_param(g_data.ioctl_sock, data->ifname, IEEE80211_PARAM_DISABLE_TX_BA, &dis_ampdu);

	if (ret >= 0)
		ret = qrpe_qtna_get_param(g_data.ioctl_sock, data->ifname, IEEE80211_PARAM_VAP_TX_AMSDU, &en_amsdu);

	if (ret >= 0)
		ret = qrpe_qtna_get_param(g_data.ioctl_sock, data->ifname, IEEE80211_PARAM_BA_MAX_WIN_SIZE, &ba_max);

	if (ret >= 0)
		ret = qrpe_qtna_get_param(g_data.ioctl_sock, data->ifname, IEEE80211_PARAM_MAX_DPDUR, &ppdu_dur);

	if (ret >= 0) {
		if (!dis_ampdu)
			data_format |= 1 << QRPE_DRV_DATA_FORMAT_AMPDU_SHIFT;

		if (en_amsdu)
			data_format |= 1 << QRPE_DRV_DATA_FORMAT_AMSDU_SHIFT;

		for (i = 0; i < QRPE_DRV_AC_MAXNUM; i++)
		{
			espi[i].ac = i;
			espi[i].duration = (uint8_t)QRPE_GET_AC_DUR(ppdu_dur, i);
			espi[i].format = data_format;
			espi[i].window = ba_max;
		}
	}
	return;
}

static int qrpe_qtna_get_intf_info(void *priv, int sub_cmd, QRPE_DRV_INTF_INFO_T *intf_info)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	struct ieee80211_qrpe_intf_info intf_req;
	struct ieee80211_qrpe_intf_fat intf_fat_req;
	uint8_t index, mask = 0;
	int cnt, retval = 0;

	if (!data || g_data.ioctl_sock < 0 || !intf_info)
		return -EINVAL;

	QRPE_DEBUG("QRPE get interface info(%u) for qtna interface %s", sub_cmd, data->ifname);

	switch(sub_cmd) {
	case QRPE_INTF_SUBCMD_INFO:
		retval = qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)data->ifname,
			SIOCDEV_SUBIO_GET_BSA_INTF_INFO, &intf_req, sizeof(intf_req));
		if (retval < 0)
			return -1;

		memcpy(intf_info->radio_name, data->radio_name, IFNAMSIZ);
		memcpy(intf_info->ssid, intf_req.ssid, QRPE_MAX_SSID_LEN);
		intf_info->ssid_len = (intf_req.ssid_len > QRPE_MAX_SSID_LEN) ?
			QRPE_MAX_SSID_LEN : intf_req.ssid_len;
		memcpy(intf_info->bssid, intf_req.bssid, ETH_ALEN);
		if (intf_req.mdid)
			intf_info->mdid = intf_req.mdid;
		else
			intf_info->mdid = qrpe_qtna_get_mdid((const char *)data->ifname);
		intf_info->channel = intf_req.channel;
		intf_info->band = intf_req.band;

		intf_info->support_set_cc3rd = intf_req.driver_capab_mask &
			IEEE80211_QRPE_CAP_COUNTRY_ENV;
		qrpe_qtna_get_cc_alpha(&(intf_info->cc_alpha[0]));
		QRPE_DEBUG("get cc_alpha:%c%c",intf_info->cc_alpha[0],intf_info->cc_alpha[1]);

		intf_info->opclass = intf_req.opclass;
		intf_info->phytype = intf_req.phytype;
		intf_info->support_btm = intf_req.support_btm;
		intf_info->support_ht = intf_req.support_ht;
		intf_info->support_vht = intf_req.support_vht;
		intf_info->support_monitor = intf_req.support_monitor;
		intf_info->support_omonitor = 1;
#ifdef CONFIG_SUPPORT_QTNA_ERW
		intf_info->support_erw = intf_req.support_erw;
#else
		intf_info->support_erw = 0;
#endif
		intf_info->support_pmf_mfpr = intf_req.pmfr;
		intf_info->support_pmf_mfpc = intf_req.pmfc;

#ifdef CONFIG_SUPPORT_QTNA_SPDIA
		intf_info->support_spdia = intf_req.support_spdia;
		intf_info->spdia_feature_support = intf_req.spdia_feature_support;
		intf_info->spdia_sta_support_count = intf_req.spdia_support_sta_num;
#else
		intf_info->support_spdia = 0;
#endif
		intf_info->support_backhaul_sta = 1;

		intf_info->capinfo = intf_req.capinfo;
		intf_info->bintval = intf_req.bintval;
		memcpy(intf_info->htcap, &intf_req.htcap, sizeof(intf_req.htcap));
		memcpy(intf_info->htop, &intf_req.htop, sizeof(intf_req.htop));
		memcpy(intf_info->vhtcap, &intf_req.vhtcap, sizeof(intf_req.vhtcap));
		memcpy(intf_info->vhtop, &intf_req.vhtop, sizeof(intf_req.vhtop));

		memset(intf_info->supp_elemid_mask, 0, MAX_DRV_EID_MASK_LEN);
		for (cnt = 0; cnt < intf_req.ie_add_support_len; cnt++) {
			index = intf_req.ie_add_support[cnt] / 8;
			mask = intf_req.ie_add_support[cnt] % 8;
			intf_info->supp_elemid_mask[index] |= (1 << mask);
		}

		memset(intf_info->supp_extcap, 0, MAX_DRV_EXTCAP_LEN);
		memcpy(intf_info->supp_extcap, &intf_req.ext_cap_support,
			MIN(sizeof(intf_req.ext_cap_support), MAX_DRV_EXTCAP_LEN));

		intf_info->reg_tx_frm_len =
			qrpe_qtna_build_supp_frame(intf_info->reg_tx_frame,
				intf_req.tx_frame_support, intf_req.tx_frame_support_len,
				intf_req.tx_action_frame_support, intf_req.tx_action_frame_support_len);

		intf_info->reg_rx_frm_len =
			qrpe_qtna_build_supp_frame(intf_info->reg_rx_frame,
				intf_req.rx_frame_support, intf_req.rx_frame_support_len,
				intf_req.rx_action_frame_support, intf_req.rx_action_frame_support_len);

		intf_info->intf_type = qrpe_qtna_vap_mode_mapto_intftype(intf_req.vap_mode);
		intf_info->intf_type_1905 = 0xffff; /* unknown media */

#ifdef QRPE_SUPPORT_QTNA_PEARL_DRIVER
		memcpy(intf_info->hecap, intf_req.hecap, HE_CAP_MAXLEN);
		memcpy(intf_info->heop, &intf_req.heop, HE_OP_MAXLEN);
#else
		memset(intf_info->hecap, 0, HE_CAP_MAXLEN);
		memset(intf_info->heop, 0, HE_OP_MAXLEN);
#endif
		qrpe_qtna_get_espi(priv, &(intf_info->espi[0]));
		qrpe_qtna_get_param(g_data.ioctl_sock, data->ifname,
			IEEE80211_PARAM_BEACON_POWER_BACKOFF, &intf_info->bcnpwr_backoff);
		break;

	case QRPE_INTF_SUBCMD_FAT:
		retval = qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)data->ifname,
			SIOCDEV_SUBIO_GET_BSA_FAT_INFO, &intf_fat_req, sizeof(intf_fat_req));
		if (retval < 0)
			return -1;

		intf_info->channel = intf_fat_req.channel;
		intf_info->band = intf_fat_req.band;
		intf_info->avg_fat = intf_fat_req.avg_fat;
		break;

	default:
		QRPE_WARN("Unknown interface info command %u for qtna interface %s",
			sub_cmd, data->ifname);
		return -1;
	}
	return 0;
}

static int qrpe_qtna_get_radio_info(void *priv, QRPE_DRV_RADIO_INFO_T *radio_info)
{
	QRPE_QTNA_RADIO_DATA_T *data = (QRPE_QTNA_RADIO_DATA_T *)priv;
	struct ieee80211_qrpe_region_opclass region_opclass;
	int max_bsses = 0;
	int i, j = 0, ret = 0;

	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	QRPE_DEBUG("get radio info for qtna interface %s", data->ifname);
	if ((ret = qcsapi_wifi_get_parameter((const char *)data->qcsapi_ifname,
		qcsapi_wifi_param_max_bss_num, &max_bsses)) < 0)
		QRPE_WARN("can't get max bss number for %s, error %d",
			data->qcsapi_ifname, ret);

	radio_info->max_bsses = max_bsses;
	radio_info->ps_status = 0;

	memset(&region_opclass, 0, sizeof(region_opclass));
	region_opclass.radio_id = data->radio_id;
	if ((ret = qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)data->ifname,
		SIOCDEV_SUBIO_GET_OPCLASS_INFO, &region_opclass,
		sizeof(region_opclass))) < 0) {
		QRPE_WARN("can't get region operating class");
		return -1;
	}

	radio_info->opclass_nums = region_opclass.opclass_num;
	for (i = 0; i < region_opclass.opclass_num
		&& i < QRPE_DRV_OPCLASS_MAXNUM; i++) {
		radio_info->opclass[i].global_opclass = region_opclass.opclass_set[i].global_index;
		radio_info->opclass[i].bandwidth = region_opclass.opclass_set[i].bandwidth;
		radio_info->opclass[i].max_power = region_opclass.opclass_set[i].reg_max_tx_power;
		j = 0;
		QRPE_DEBUG("opclass(%u):", radio_info->opclass[i].global_opclass);
		while (region_opclass.opclass_set[i].chaninfo_set[j].chan_no
			&& j < QRPE_DRV_CHAN_MAXNUM_PER_OPCLASS) {
			radio_info->opclass[i].chans[j].chan =
				region_opclass.opclass_set[i].chaninfo_set[j].chan_no;
			radio_info->opclass[i].chans[j].status =
				qrpe_qtna_map_radio_chan_status(
					region_opclass.opclass_set[i].chaninfo_set[j].chan_status);
			QRPE_DEBUG("chan(%u)-status(%u)-drv_chan_status(%u)",
				radio_info->opclass[i].chans[j].chan,
				radio_info->opclass[i].chans[j].status,
				region_opclass.opclass_set[i].chaninfo_set[j].chan_status);
			j++;
		}
		radio_info->opclass[i].chan_nums = j;
	}

	return 0;
}

static int qrpe_qtna_get_chan_status_sub_command(char *ifname, uint8_t chan,
		uint8_t *status)
{
	struct ieee80211req_scs scs_req;
	struct ieee80211req_scs_ranking_rpt rpt;
	struct ieee80211req_scs_ranking_rpt_chan *rpt_chan;
	uint32_t reason;
	int i, ret = -1;

	memset(&rpt, 0, sizeof(rpt));
	memset(&scs_req, 0, sizeof(scs_req));
	scs_req.is_op = IEEE80211REQ_SCS_GET_RANKING_RPT;
	scs_req.is_status = &reason;
	scs_req.is_data = (void *)&rpt;
	scs_req.is_data_len = sizeof(rpt);
	if ((ret = qrpe_qtna_sub_command(g_data.ioctl_sock, ifname,
		SIOCDEV_SUBIO_SCS, &scs_req, sizeof(scs_req))) < 0)
		return -EINVAL;
	for (i = 0; i < rpt.isr_num; i++) {
		rpt_chan = &rpt.isr_chans[i];
		if (chan == rpt_chan->isrc_chan) {
			*status = qrpe_qtna_convert_chan_status(rpt_chan->isrc_chan_avail_status);
			QRPE_DEBUG("get chan status: chan(%u) status(%u) drv_chan_status(%u)",
				chan, *status, rpt_chan->isrc_chan_avail_status);
		}
	}

	return 0;
}

static int qrpe_qtna_get_chan_status(void *priv, uint8_t chan, uint8_t *status)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;

	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	QRPE_DEBUG("QRPE get channel status for qtna interface %s", data->ifname);

	return qrpe_qtna_get_chan_status_sub_command(data->ifname,
			chan, status);
}

static int qrpe_qtna_get_sta_stats(void *priv, uint8_t *sta, QRPE_DRV_STA_STATS_T *stats)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	struct ieee80211_qrpe_sta_stats *sta_stats;
	int i = 0;
	int retval = 0;

	if (!data || g_data.ioctl_sock < 0 || !stats || !sta)
		return -EINVAL;

	QRPE_DEBUG("QRPE get sta stats for qtna interface %s", data->ifname);

	if (NULL == (sta_stats = QRPE_CALLOC(1, sizeof(struct ieee80211_qrpe_sta_stats))))
		return -1;

	retval = qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)data->ifname,
		SIOCDEV_SUBIO_GET_BSA_STA_STATS, sta_stats, sizeof(struct ieee80211_qrpe_sta_stats));
	if (retval < 0) {
		QRPE_FREE(sta_stats);
		return -1;
	}

	stats->num_sta = sta_stats->num;
	if (stats->num_sta > MAX_DRV_STA_ENTRY)
		stats->num_sta = MAX_DRV_STA_ENTRY;
	for (i = 0; i < stats->num_sta; i++) {
		qrpe_qtna_fill_sta_phy_stats(stats->entries + i, sta_stats->entries + i);
		qrpe_qtna_get_and_fill_sta_link_stats((const char *)data->ifname,
				stats->entries + i);
	}
	QRPE_FREE(sta_stats);

	return 0;
}

static int qrpe_qtna_get_monitor_sta_stats(void *priv, uint8_t *sta, QRPE_DRV_STA_STATS_T *stats)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	struct ieee80211_nac_stats_report *report;
	int retval = 0, i = 0;

	if (!data || g_data.ioctl_sock < 0 || !stats || !sta)
		return -EINVAL;

	QRPE_DEBUG("QRPE get monitor sta stats for qtna interface %s", data->ifname);

	if (NULL == (report = QRPE_CALLOC(1, sizeof(struct ieee80211_nac_stats_report))))
		return -1;

	retval = qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)data->ifname,
		SIOCDEV_SUBIO_GET_NAC_STATS, report, sizeof(struct ieee80211_nac_stats_report));
	if (retval < 0) {
		QRPE_FREE(report);
		return -1;
	}

	stats->num_sta = report->nac_entries;
	if (stats->num_sta > MAX_DRV_STA_ENTRY)
		stats->num_sta = MAX_DRV_STA_ENTRY;

	for (i = 0; i < stats->num_sta; i++) {
		memcpy(stats->entries[i].sta, report->nac_stats[i].nac_txmac, ETH_ALEN);
		stats->entries[i].monitor_stats.age = report->nac_stats[i].nac_age;
		stats->entries[i].monitor_stats.rssi_dbm = report->nac_stats[i].nac_avg_rssi;
		stats->entries[i].monitor_stats.channel = report->nac_stats[i].nac_channel;
	}
	QRPE_FREE(report);
	return 0;
}

static int qrpe_qtna_start_fat_monitor(void *priv, uint32_t period)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	struct ieee80211_qrpe_fat_mon fat_mon;

	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	QRPE_DEBUG("QRPE start fat monitor qtna interface %s: period %u",
		data->ifname, period);

	fat_mon.period = period;
/* topaz always enabled fat monitor */
#ifdef QRPE_SUPPORT_QTNA_PEARL_DRIVER
	return qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)data->ifname,
		SIOCDEV_SUBIO_BSA_START_FAT_MON, &fat_mon, sizeof(fat_mon));
#endif
	return 0;
}

static int qrpe_qtna_start_omonitor_ondemand(void *priv, uint8_t chan)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	int ret = 0;

	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	QRPE_DEBUG("QRPE start off-channel(%u) nac monitor for interface %s",
		chan, data->ifname);

	ret = qrpe_qtna_set_param(g_data.ioctl_sock, data->ifname,
		IEEE80211_PARAM_START_OCS_NAC_MON, chan);

	return ret;
}

#ifndef IEEE80211_SCS_PARAM_VALUE
#define IEEE80211_SCS_PARAM_VALUE(_cmd, _val)   ((((_cmd) & IEEE80211_SCS_COMMAND_M) << IEEE80211_SCS_COMMAND_S) \
            | (((_val) & IEEE80211_SCS_VALUE_M) << IEEE80211_SCS_VALUE_S))
#endif
static int qrpe_qtna_start_monitor(void *priv, uint32_t period,
		uint32_t duty_cycle, uint8_t mask)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	uint32_t value = MONITOR_MAKE_CYCLE_PERIOD(period) | MONITOR_MAKE_ON_PERIOD(duty_cycle) | MONITOR_MAKE_ENABLE(1);
	int retval = 0;

	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	QRPE_DEBUG("QRPE start monitor qtna interface %s: period %u, cycle %u, mask %u",
		data->ifname, period, duty_cycle, mask);

	if (mask & QRPE_DRV_MONITOR_MASK)
		retval = qrpe_qtna_set_param(g_data.ioctl_sock, data->ifname,
			IEEE80211_PARAM_NAC_MONITOR_MODE, value);

	if (mask & QRPE_DRV_OMONITOR_MASK) {
		value = IEEE80211_SCS_PARAM_VALUE(IEEE80211_SCS_SET_NAC_MONITOR_MODE, 1);
		retval = qrpe_qtna_set_param(g_data.ioctl_sock, data->ifname,
			IEEE80211_PARAM_SCS, value);
	}
	return retval;
}

static int qrpe_qtna_stop_monitor(void *priv, uint8_t mask)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	uint32_t value = 0;
	int retval = 0;

	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	QRPE_DEBUG("QRPE stop monitor qtna interface %s mask %u",
		data->ifname, mask);

	if (mask & QRPE_DRV_MONITOR_MASK)
		retval = qrpe_qtna_set_param(g_data.ioctl_sock, data->ifname,
			IEEE80211_PARAM_NAC_MONITOR_MODE, value);

	if (mask & QRPE_DRV_OMONITOR_MASK) {
		value = IEEE80211_SCS_PARAM_VALUE(IEEE80211_SCS_SET_NAC_MONITOR_MODE, 0);
		retval = qrpe_qtna_set_param(g_data.ioctl_sock, data->ifname,
			IEEE80211_PARAM_SCS, value);
	}

	return retval;
}

static int qrpe_qtna_report_associated_stas(void *priv)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;

	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	QRPE_DEBUG("QRPE report associated sta for qtna interface %s", data->ifname);

	return qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)data->ifname,
		SIOCDEV_SUBIO_GET_BSA_ASSOC_STA_STATS, NULL, 0);
}

static int qrpe_qtna_send_btm_req(void *priv, QRPE_DRV_BTM_REQ_T *req)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	struct ieee80211_qrpe_btm_req btm_req;

	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	QRPE_DEBUG("QRPE send btm req for qtna interface %s", data->ifname);

	memcpy(btm_req.mac, req->sta_mac, ETH_ALEN);
	btm_req.disassoc_timer = req->disassoc_timer;
	btm_req.req_mode = req->req_mode;
	btm_req.val_intvl = req->val_intvl;
	memcpy(btm_req.bssid, req->bssid, ETH_ALEN);
	btm_req.bssid_info = req->bssid_info;
	btm_req.opclass = req->opclass;
	btm_req.channel = req->channel;
	btm_req.phytype = req->phytype;
	btm_req.subel_len = 0;

	return qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)data->ifname,
		SIOCDEV_SUBIO_SEND_BTM_REQ_FRM, &btm_req, sizeof(btm_req));
}

static int qrpe_qtna_send_frame(void *priv,
	uint8_t channel, uint8_t *frame, uint16_t frame_len)
{
#define QRPE_REG_FLAG_OTHER_APP 0x8000
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	struct app_action_frame_buf *action_frm;
	struct ieee80211_frame *hdr;
	uint32_t space = 0;
	uint16_t payload_len = 0;
	int ret = -1;

	if (!data || g_data.ioctl_sock < 0
		|| !frame)
		return -EINVAL;
	if (frame_len <= sizeof(*hdr) + 2) {
		QRPE_ERROR("QRPE send frame length less mac header(24) + cat/action(2)");
		return -EINVAL;
	}
	hdr = (struct ieee80211_frame *)frame;
	if ((hdr->i_fc[0] & IEEE80211_FC0_SUBTYPE_MASK)
		!= IEEE80211_FC0_SUBTYPE_ACTION) {
		QRPE_ERROR("QRPE only support send action, frame subtype:0x%x", hdr->i_fc[0]);
		return -EINVAL;
	}
	space = sizeof(struct app_action_frame_buf) + frame_len;
	if (NULL == (action_frm = QRPE_CALLOC(1, space)))
		return -ENOMEM;

	QRPE_DEBUG("QRPE send frame:[ch:%u frame_len:%u]", channel, frame_len);

	/* extract dst mac address and strip mac header */
	memcpy(action_frm->dst_mac_addr,
		frame + offsetof(struct ieee80211_frame, i_addr1), ETH_ALEN);
	frame = (uint8_t *)(hdr + 1);

	/* the first two byte of the frame is action frame category and action */
	action_frm->cat = *frame;
	action_frm->action = *(frame + 1);

	payload_len = frame_len - sizeof(struct ieee80211_frame);
	action_frm->frm_payload.length = payload_len;
	memcpy(action_frm->frm_payload.data, frame, payload_len);

	ret = qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)data->ifname,
		SIOCDEV_SUBIO_SEND_ACTION_FRAME | QRPE_REG_FLAG_OTHER_APP, action_frm,
		sizeof(struct app_action_frame_buf) + payload_len);
	QRPE_FREE(action_frm);

	return ret;
}

#define QRPE_QTNA_REG_FRAME_FLAGS(_flags, _drv_flags, _n)	\
	do { if ((_flags) & (QRPE_DRV_REG_FLAG_##_n))		\
		(_drv_flags) |= (IEEE80211_MFR_FLAG_##_n);	\
	} while(0)

static int qrpe_qtna_register_frame(void *priv,
	uint8_t subtype, uint8_t *match, uint8_t match_len, uint8_t flags)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	struct ieee80211_mfr_cmd *reg_frm = NULL;
	uint32_t space = 0;
	uint8_t drv_flags = 0;
	int ret = -1;

	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	QRPE_DEBUG("QRPE register frame's subtype:0x%x", subtype);

	if (!match)
		match_len = 0;

	space = sizeof(struct ieee80211_mfr_cmd) + match_len;
	if (NULL == (reg_frm = QRPE_CALLOC(1, space)))
		return -ENOMEM;

	QRPE_QTNA_REG_FRAME_FLAGS(flags, drv_flags, BYPASS);
	QRPE_QTNA_REG_FRAME_FLAGS(flags, drv_flags, SKB_COPY);
	QRPE_QTNA_REG_FRAME_FLAGS(flags, drv_flags, RECV);
	QRPE_QTNA_REG_FRAME_FLAGS(flags, drv_flags, XMIT);
	QRPE_QTNA_REG_FRAME_FLAGS(flags, drv_flags, DEL_ALL);
	/* default is adding, if not set DEL_ALL */
	if (!(drv_flags & IEEE80211_MFR_FLAG_DEL_ALL))
		drv_flags |= IEEE80211_MFR_FLAG_ADD;

	reg_frm->subtype = subtype;
	reg_frm->match_len = match_len;
	reg_frm->flags = drv_flags;
	if (match_len)
		memcpy(reg_frm->match, match, match_len);

	ret = qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)data->ifname,
		SIOCDEV_SUBIO_SET_MFR, reg_frm, space);

	QRPE_FREE(reg_frm);

	return ret;
}

static uint32_t qrpe_qtna_subtype_mapto_frmtype(uint8_t subtype)
{
	uint32_t frmtype = 0xff;

	switch(subtype) {
	case QRPE_SUBTYPE_BEACON:
		frmtype = IEEE80211_APPIE_FRAME_BEACON;
		break;
	case QRPE_SUBTYPE_PROBE_RESP:
		frmtype = IEEE80211_APPIE_FRAME_PROBE_RESP;
		break;
	case QRPE_SUBTYPE_AUTH:
		//frmtype = IEEE80211_APPIE_FRAME_AUTH;
		break;
	case QRPE_SUBTYPE_ASSOC_RESP:
	case QRPE_SUBTYPE_REASSOC_RESP:
		frmtype = IEEE80211_APPIE_FRAME_ASSOC_RESP;
		break;

	default:
		break;
	}
	return frmtype;
}

static int qrpe_qtna_update_ies(void *priv,
	uint8_t subtype, uint8_t *ies, uint32_t ies_len)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	struct ieee80211req_getset_appiebuf *app_ies;
	uint32_t space;
	int ret = -1;

	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	if (!ies)
		ies_len = 0;

	QRPE_DEBUG("QRPE update ies length = %u for qtna interface %s",
		ies_len, data->ifname);

	space = sizeof(struct ieee80211req_getset_appiebuf) + ies_len;
	if (NULL == (app_ies = QRPE_CALLOC(1, space)))
		return -ENOMEM;

	app_ies->app_frmtype = qrpe_qtna_subtype_mapto_frmtype(subtype);
	app_ies->app_buflen = ies_len;
	app_ies->flags = F_QTN_IEEE80211_RPE_APPIE;

	if (ies_len)
		memcpy(app_ies->app_buf, ies, ies_len);

	ret = qrpe_qtna_set_iwpriv(g_data.ioctl_sock, data->ifname,
		IEEE80211_IOCTL_SET_APPIEBUF, app_ies, space);

	QRPE_FREE(app_ies);

	return ret;
}

static int qrpe_qtna_update_extcap(void *priv,
	uint8_t *extcap, uint8_t *extcap_mask, uint16_t extcap_len)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	struct ieee80211_extcap_ie_buf *cfg_extcap;
	uint32_t len, space;
	int ret = -1;

	QRPE_DEBUG("QRPE update extcap");

	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	if (!extcap || !extcap_mask)
		extcap_len = 0;

	len = MIN(extcap_len, IEEE80211_EXTCAP_IE_LEN);
	space = sizeof(struct ieee80211_extcap_ie_buf) + len + len;
	if (NULL == (cfg_extcap = QRPE_CALLOC(1, space)))
		return -ENOMEM;
	if (len) {
		memcpy(cfg_extcap->extcap_info, extcap_mask, len);
		memcpy(cfg_extcap->extcap_info + len, extcap, len);
	}
	cfg_extcap->extcap_len = len + len;

	ret = qrpe_qtna_sub_command(g_data.ioctl_sock, (const char *)data->ifname,
		SIOCDEV_SUBIO_SET_EXTCAP_IE, cfg_extcap, space);

	QRPE_FREE(cfg_extcap);

	return ret;
}

static int qrpe_qtna_update_3rd_cc(void *priv, uint8_t country_env)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;

	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	QRPE_DEBUG("QRPE update 3rd contry code(0x%x)", country_env);

	return qrpe_qtna_set_param(g_data.ioctl_sock, data->ifname,
		IEEE80211_PARAM_COUNTRY_STR_ENV, country_env);
}

#ifdef CONFIG_SUPPORT_QTNA_SPDIA
static int qrpe_qtna_ctrl_sta_spdia(void *priv, uint8_t *sta, uint16_t period,
	uint8_t spdia_feature, uint8_t ng, uint8_t smooth)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	char cmd[64];
	char mode[8];
	uint8_t reorder, mode_data, mode_ndp;

	if (!data || g_data.ioctl_sock < 0
		|| !sta)
		return -EINVAL;

	QRPE_DEBUG("QRPE ctrl spdia for " MACSTR
		" on qtna interface %s", MAC2STR(sta), data->ifname);

	if (period == 0) {
		snprintf(cmd, 64, "%s " MACSTR " %s\n", QRPE_QTNA_SPDIA_CMDNAME,
			MAC2STR(sta), QRPE_QTNA_SPDIA_SUBCMD_STAMAC_REMOVE);
		qrpe_qtna_sys_control(cmd, NULL, 0);
		return 0;
	}

	snprintf(cmd, 64, "%s " MACSTR " %s\n", QRPE_QTNA_SPDIA_CMDNAME,
		 MAC2STR(sta), QRPE_QTNA_SPDIA_SUBCMD_STAMAC_ADD);
	qrpe_qtna_sys_control(cmd, NULL, 0);

	snprintf(cmd, 64, "%s " MACSTR " %s %u\n", QRPE_QTNA_SPDIA_CMDNAME,
		MAC2STR(sta), QRPE_QTNA_SPDIA_SUBCMD_INTERVAL, period);
	qrpe_qtna_sys_control(cmd, NULL, 0);

	reorder = (spdia_feature & QRPE_DRIVER_SPDIA_REORDER) ? 1 : 0;
	snprintf(cmd, 64, "%s " MACSTR " %s %d\n", QRPE_QTNA_SPDIA_CMDNAME,
		 MAC2STR(sta), QRPE_QTNA_SPDIA_SUBCMD_REORDER, reorder);
	qrpe_qtna_sys_control(cmd, NULL, 0);

	mode_data = (spdia_feature & QRPE_DRIVER_SPDIA_MODE_DATA);
	mode_ndp = (spdia_feature & QRPE_DRIVER_SPDIA_MODE_NDP);

	if (mode_ndp) {
		snprintf(mode, sizeof(mode),"%s", QRPE_QTNA_SPDIA_SUBCMD_MODE_NDP);
		if (mode_data)
			QRPE_WARN("QRPE config the mode to NDP due to mode DATA and NTP are not coexistent");
	} else if (mode_data) {
		snprintf(mode, sizeof(mode),"%s", QRPE_QTNA_SPDIA_SUBCMD_MODE_DATA);
	} else {
		snprintf(mode, sizeof(mode),"%s", QRPE_QTNA_SPDIA_SUBCMD_MODE_NONE);
	}

	snprintf(cmd, 64, "%s " MACSTR " %s %s\n", QRPE_QTNA_SPDIA_CMDNAME,
		 MAC2STR(sta), QRPE_QTNA_SPDIA_SUBCMD_MODE, mode);
	qrpe_qtna_sys_control(cmd, NULL, 0);

	snprintf(cmd, 64, "%s " MACSTR " %s %d\n", QRPE_QTNA_SPDIA_CMDNAME,
		 MAC2STR(sta), QRPE_QTNA_SPDIA_SUBCMD_NG, ng);
	qrpe_qtna_sys_control(cmd, NULL, 0);

	snprintf(cmd, 64, "%s " MACSTR " %s %s\n", QRPE_QTNA_SPDIA_CMDNAME,
			 MAC2STR(sta), QRPE_QTNA_SPDIA_SUBCMD_SMOOTH,
			 (smooth == 0) ? "none" : ((smooth == 1) ? "ramp" : "en"));
	qrpe_qtna_sys_control(cmd, NULL, 0);

	return 0;
}
#endif

static int qrpe_qtna_change_chan(void *priv, uint8_t ch, uint8_t bw)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	uint32_t ch_bw_value;

	ch_bw_value = ((uint32_t)ch & QRPE_QTNA_CHANBW_BW_MASK) | ((uint32_t)bw << QRPE_QTNA_CHANBW_BW_SHIFT);

	if (!data || g_data.ioctl_sock < 0)
		return -EINVAL;

	return qrpe_qtna_set_param(g_data.ioctl_sock, data->ifname,
		IEEE80211_PARAM_SET_CHAN_BW, ch_bw_value);
}

static int qrpe_qtna_set_power_backoff(void *priv, uint8_t backoff)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T*)priv;
	int ret = -1;

	if ( g_data.ioctl_sock < 0)
		return -EINVAL;

	ret = qrpe_qtna_set_param(g_data.ioctl_sock, data->ifname,
		IEEE80211_PARAM_BEACON_POWER_BACKOFF, backoff);
	if (ret < 0)
		QRPE_WARN("set bcn pwr_backoff failed.");

	ret = qrpe_qtna_set_param(g_data.ioctl_sock, data->ifname,
		IEEE80211_PARAM_MGMT_POWER_BACKOFF, backoff);
	if (ret < 0)
		QRPE_WARN("set mgmt pwr_backoff failed.");

	return ret;
}

static int qrpe_qtna_set_backhaul_sta(void *priv, uint8_t enable)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	int ret = 0;

	if (!data)
		return -EINVAL;

	QRPE_DEBUG("QRPE set interface backhaul sta(%u)", enable);

	if ((ret = qcsapi_wifi_set_parameter((const char *)data->ifname,
			qcsapi_wifi_param_multiap_backhaul_sta, enable)) < 0)
		QRPE_WARN("QRPE set backhaul sta feature failed");

	return ret;
}

static int qrpe_qtna_hostapd_ignore_hwpbc(char *ifname, uint8_t enable)
{
	char cmd[128];
	int ret = 0;

	if (access(QRPE_QTNA_HOSTAPD_CLI_CMDNAME, X_OK) != 0)
		return -1;

	ret = snprintf(cmd, sizeof(cmd), "%s -i %s ignore_hw_pbc %u",
		QRPE_QTNA_HOSTAPD_CLI_CMDNAME, ifname, enable);
	if (ret >= sizeof(cmd))
		return -1;

	ret = system(cmd);
	if (ret)
		return -1;

	return 0;
}

static int qrpe_qtna_ignore_hw_pbc(void *priv, uint8_t enable)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	int ret = 0;

	QRPE_DEBUG("QRPE ignore hostapd hardware WPS PBC(%u)", enable);

	ret = qrpe_qtna_hostapd_ignore_hwpbc(data->ifname, enable);
	if (ret < 0) {
		QRPE_ERROR("execute hostapd ignore WPS PBC failed");
		return ret;
	}

	return 0;
}

/* lightweight function to convert a channel number to a frequency (in Mhz) */
#ifdef QRPE_SUPPORT_QTNA_TOPAZ_DRIVER
static int qrpe_qtna_channel_to_freq(int chan)
{
	if (chan <= 0)
		return 0; /* not supported */
	if (chan == 14)
		return 2484;
	else if (chan < 14)
		return 2407 + chan * 5;
	else if (chan >= 182 && chan <= 196)
		return 4000 + chan * 5;
	else if (chan >= 36)
		return 5000 + chan * 5;

	return 0; /* not supported */
}

static int qrpe_qtna_set_scan_channel(const char *ifname, uint8_t chan)
{
	struct iwreq iwr;
	struct ieee80211_scan_freqs *scan_freqs;
	uint32_t len;

	if (g_data.ioctl_sock < 0)
		return -EINVAL;

	len = sizeof(*scan_freqs) + sizeof(scan_freqs->freqs[0]);
	scan_freqs = QRPE_CALLOC(1, len);
	if (!scan_freqs)
		return -ENOMEM;

	scan_freqs->num = 1;
	scan_freqs->freqs[0] = qrpe_qtna_channel_to_freq(chan);

	memset(&iwr, 0, sizeof(iwr));
	strncpy(iwr.ifr_name, ifname, IFNAMSIZ - 1);

	iwr.u.data.flags |= SIOCDEV_SUBIO_SET_SCAN_FREQS;
	iwr.u.data.pointer = (void *)scan_freqs;
	iwr.u.data.length = len;

	if (ioctl(g_data.ioctl_sock, IEEE80211_IOCTL_EXT, &iwr) < 0) {
		QRPE_WARN("failed to set scan freqs");
		return -1;
	}

	QRPE_FREE(scan_freqs);
	return 0;
}
#endif

static int qrpe_qtna_scan_sub_command(const char *ifname, uint8_t *target,
		uint8_t ch, uint8_t opclass)
{
	struct iwreq iwr;
	struct iw_scan_req req;

	if (g_data.ioctl_sock < 0)
		return -EINVAL;

	g_data.roam.channel = ch;
	g_data.roam.opclass = opclass;
	memcpy(g_data.roam.target, target, ETH_ALEN);

	memset(&iwr, 0, sizeof(iwr));
	strncpy(iwr.ifr_name, ifname, IFNAMSIZ - 1);

	memset(&req, 0, sizeof(req));
#ifdef QRPE_SUPPORT_QTNA_PEARL_DRIVER
	req.channel_list[0].m = ch;
	req.num_channels = 1;
#endif
#ifdef QRPE_SUPPORT_QTNA_TOPAZ_DRIVER
	qrpe_qtna_set_scan_channel(ifname, ch);
#endif
	memcpy(req.bssid.sa_data, target, ETH_ALEN);

	iwr.u.data.flags |= IW_SCAN_THIS_FREQ;
	iwr.u.data.pointer = (void *)&req;
	iwr.u.data.length = sizeof(req);

	if (ioctl(g_data.ioctl_sock, SIOCSIWSCAN, &iwr) < 0) {
		QRPE_WARN("start specified channel scan failed");
		return -1;
	}

	return 0;
}

static int qrpe_qtna_roam_scan(void *priv, uint8_t *target, uint8_t ch, uint8_t opclass)
{
	QRPE_QTNA_INTF_DATA_T *data = (QRPE_QTNA_INTF_DATA_T *)priv;
	int ret;

	if (!data)
		return -EINVAL;

	if ((ret = qrpe_qtna_check_in_roaming()) == 1) {
		QRPE_WARN("only can execute roam scan once in this period(%u)",
			g_conf.qtna_roam_period);
		return -1;
	}

	g_data.tstamp = get_reltime();
	g_data.scan_retries = 1;
	if ((ret = qrpe_qtna_scan_sub_command((const char *)data->ifname,
			target, ch, opclass) < 0)) {
		QRPE_WARN("start scan sub command failed");
		return -1;
	}

	return 0;
}

const QRPE_DRIVER_OPS_T qrpe_qtna_driver_ops = {
	.name = "QTNA",
	.desc = "QTNA TOPAZ/PEARL",
	.probe_radio = qrpe_qtna_probe_radio,
	.probe_intf = qrpe_qtna_probe_intf,
	.init = qrpe_qtna_driver_init,
	.deinit = qrpe_qtna_driver_deinit,
	.init_fdset = qrpe_qtna_init_fdset,
	.check_and_process_fdset = qrpe_qtna_check_and_process_fdset,
	.init_radio = qrpe_qtna_init_radio,
	.deinit_radio = qrpe_qtna_deinit_radio,
	.init_intf = qrpe_qtna_init_intf,
	.deinit_intf = qrpe_qtna_deinit_intf,
	.set_status = qrpe_qtna_set_status,
	.deauth_sta = qrpe_qtna_deauth_sta,
	.disassoc_sta = qrpe_qtna_disassoc_sta,
	.filter_sta = qrpe_qtna_filter_sta,
	.set_erw = qrpe_qtna_set_erw,
	.get_intf_info = qrpe_qtna_get_intf_info,
	.get_radio_info = qrpe_qtna_get_radio_info,
	.get_chan_status = qrpe_qtna_get_chan_status,
	.get_sta_stats = qrpe_qtna_get_sta_stats,
	.get_monitor_sta_stats = qrpe_qtna_get_monitor_sta_stats,
	.start_fat_monitor = qrpe_qtna_start_fat_monitor,
	.start_monitor = qrpe_qtna_start_monitor,
	.stop_monitor = qrpe_qtna_stop_monitor,
	.report_associated_stas = qrpe_qtna_report_associated_stas,
	.send_btm_req = qrpe_qtna_send_btm_req,
	.send_frame = qrpe_qtna_send_frame,
	.register_frame = qrpe_qtna_register_frame,
	.update_ies = qrpe_qtna_update_ies,
	.update_extcap = qrpe_qtna_update_extcap,
	.update_3rd_cc = qrpe_qtna_update_3rd_cc,
#ifdef CONFIG_SUPPORT_QTNA_SPDIA
	.ctrl_sta_spdia = qrpe_qtna_ctrl_sta_spdia,
#endif
	.change_chan = qrpe_qtna_change_chan,
	.set_power_backoff = qrpe_qtna_set_power_backoff,
	.set_backhaul_sta = qrpe_qtna_set_backhaul_sta,
	.start_omonitor_ondemand = qrpe_qtna_start_omonitor_ondemand,
	.ignore_hw_pbc = qrpe_qtna_ignore_hw_pbc,
	.roam = qrpe_qtna_roam_scan,
};

#ifdef CONFIG_SUPPORT_QTNA_BACKBONE
static void qrpe_qtna_report_event_connect_complete_for_mbs(char *ifname, uint8_t *bssid)
{
	struct iwreq wrq;

	strncpy(wrq.ifr_name, ifname, IFNAMSIZ - 1);
	if (ioctl(g_data.ioctl_sock, SIOCGIWAP, &wrq) >= 0) {
		QRPE_DRV_CONNECT_T connect;
		memset(&connect, 0, sizeof(connect));
		memcpy(connect.peer_mac, wrq.u.ap_addr.sa_data, ETH_ALEN);
		connect.node_type = IEEE80211_QRPE_NODETYPE_WDS;
		if (g_data.cb)
			g_data.cb(bssid, QRPE_DRV_EVENT_CONNECT_COMPL, &connect);
	}
}

static void qrpe_qtna_report_event_disassoc_for_mbs(char *ifname, uint8_t *bssid)
{
	struct iwreq wrq;

	strncpy(wrq.ifr_name, ifname, IFNAMSIZ - 1);
	if (ioctl(g_data.ioctl_sock, SIOCGIWAP, &wrq) >= 0) {
		QRPE_DRV_DISASSOC_T disassoc;
		memset(&disassoc, 0, sizeof(disassoc));
		memcpy(disassoc.peer_mac, wrq.u.ap_addr.sa_data, ETH_ALEN);
		disassoc.reason_code = 1;
		if (g_data.cb)
			g_data.cb(bssid, QRPE_DRV_EVENT_DISASSOC, &disassoc);
	}
}

void qrpe_qtna_wds_intf_status_changed(QRPE_INTF_T *intf)
{
	struct iwreq wrq;
	int status;

	if (!intf || g_data.ioctl_sock < 0)
		return;

	status = QRPE_INTF_GET_STATUS(intf);
	QRPE_DEBUG("QRPE intf %s status change into %d", intf->ifname, status);

	strncpy(wrq.ifr_name, intf->ifname, IFNAMSIZ - 1);
	wrq.u.mode = IEEE80211_PARAM_EXTENDER_ROLE;
	if (ioctl(g_data.ioctl_sock, IEEE80211_IOCTL_GETPARAM, &wrq) >= 0
		&& wrq.u.mode == IEEE80211_EXTENDER_ROLE_MBS) {
		switch(status) {
		case QRPE_INTF_STATUS_UP:
			qrpe_qtna_report_event_connect_complete_for_mbs(intf->ifname, intf->ifmac);
			break;

		case QRPE_INTF_STATUS_DOWN:
			qrpe_qtna_report_event_disassoc_for_mbs(intf->ifname, intf->ifmac);
			break;

		default:
			break;
		}
	}
}

int qrpe_qtna_check_first_intf(QRPE_INTF_T *intf)
{
	if (!intf || !intf->ops)
		return -1;
	if (strcmp(intf->ifname, "wifi0") || strcmp(intf->ops->name, "QTNA"))
		return -1;
	return 0;
}
#endif
