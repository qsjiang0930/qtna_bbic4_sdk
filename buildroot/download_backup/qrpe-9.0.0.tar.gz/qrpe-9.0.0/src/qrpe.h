/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 - 2018 Quantenna Communications Inc            **
**                                                                           **
**  File        : qrpe.h                                                     **
**  Description : qrpe context definitions                                   **
**                                                                           **
*******************************************************************************
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions       **
**  are met:                                                                 **
**  1. Redistributions of source code must retain the above copyright        **
**     notice, this list of conditions and the following disclaimer.         **
**  2. Redistributions in binary form must reproduce the above copyright     **
**     notice, this list of conditions and the following disclaimer in the   **
**     documentation and/or other materials provided with the distribution.  **
**  3. The name of the author may not be used to endorse or promote products **
**     derived from this software without specific prior written permission. **
**                                                                           **
**  Alternatively, this software may be distributed under the terms of the   **
**  GNU General Public License ("GPL") version 2, or (at your option) any    **
**  later version as published by the Free Software Foundation.              **
**                                                                           **
**  In the case this software is distributed under the GPL license,          **
**  you should have received a copy of the GNU General Public License        **
**  along with this software; if not, write to the Free Software             **
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA  **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR       **
**  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES**
**  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  **
**  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,         **
**  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT **
**  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,**
**  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY    **
**  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT      **
**  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF **
**  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.        **
**                                                                           **
*******************************************************************************
*/

#ifndef __QRPE_H__
#define __QRPE_H__

#define QRPE_RCVBUF_SIZE	(240 * 1024)

#define QRPE_SUPPORT_INTFS	16
#define QRPE_SUPPORT_RADIOS	8
typedef struct {
	int ioctl_sock;
	uint32_t intfs;
	QRPE_INTF_T intf_ctx[QRPE_SUPPORT_INTFS];

	uint32_t radios;
	QRPE_RADIO_T radio_ctx[QRPE_SUPPORT_RADIOS];

	int rtm_sock;
	int read_sock;
#ifdef CONFIG_SUPPORT_RTNETLINK
#define QRPE_EVENT_PID		(-4000)
	int write_sock;
#elif defined CONFIG_SUPPORT_GENNETLINK
	struct nl_sock *read_nl_sock;
	struct nl_sock *write_nl_sock;
	struct nl_cb *nlcb;
	int qrpe_fam_id;
#endif
#ifdef CONFIG_SUPPORT_QTNA_BACKBONE
#define QTNA_WDS_MAXNUM		8
	uint32_t wds_intfs;
	QRPE_INTF_T wds_intf_ctx[QTNA_WDS_MAXNUM];
#endif
	int ctrl_sock;

	/* Dose the app ask to init the driver by RPE_CMD_INIT */
	int inited;
} QRPE_CONTEXT_T;

typedef struct {
	int daemonize;
	char *dbg_level;
	char *dbg_output;
	char *pid_file;

	/* QTNA sta CMD_ROAM period */
	int qtna_roam_period;
} QRPE_CONFIG_T;

#define QRPE_PROCNET_DEVS64		"/proc/net/dev64"
#define QRPE_PROCNET_DEVS		"/proc/net/dev"

extern QRPE_CONTEXT_T g_ctx;
extern QRPE_CONFIG_T g_conf;

extern QRPE_INTF_T *qrpe_find_intf_by_ifname(const char *ifname);
extern QRPE_INTF_T *qrpe_find_intf_by_ifmac(uint8_t *mac);
extern QRPE_INTF_T *qrpe_find_intf_by_ifindex(int ifindex);
extern QRPE_RADIO_T *qrpe_find_radio_by_ifname(const char *ifname);
extern QRPE_RADIO_T *qrpe_find_radio_by_uid(uint8_t *radio_uid);
extern void qrpe_update_intf_mac(QRPE_INTF_T *intf, int ifindex);
extern QRPE_INTF_T *qrpe_probe_intf(const char *ifname);
extern QRPE_RADIO_T *qrpe_probe_radio(const char *ifname);

extern void qrpe_deinit_link(void);
extern int qrpe_init_link(void);

extern int qrpe_receive_ctrl_message(int sd);

#ifdef CONFIG_SUPPORT_QTNA_BACKBONE
extern QRPE_INTF_T *qrpe_find_wds_intf_by_ifname(const char *ifname);
extern QRPE_INTF_T *qrpe_find_or_add_wds_intf(const char *ifname);
#endif

#ifdef CONFIG_SUPPORT_RTNETLINK

#define QRPE_RTLINK_EVENT		0xFE
#define QRPE_RTLINK_COMMAND		0xFF

#elif defined CONFIG_SUPPORT_GENNETLINK

#include <net80211/ieee80211_ioctl.h>
#include <net80211/ieee80211_qrpe.h>

#endif

#endif
