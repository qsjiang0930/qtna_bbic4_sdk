/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __HAL_QWE_H
#define __HAL_QWE_H

#include <net/if.h>

#define PRIV(iface) ((struct qwe_priv *)iface->priv)
struct qwe_priv {
	char cfg_name[IFNAMSIZ];
	char act_name[IFNAMSIZ];
	char phy_name[IFNAMSIZ];
	int is_sta;
};

#endif
