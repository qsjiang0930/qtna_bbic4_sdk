/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include "hal_qwe.h"
#include "qharvestd.h"
#include "qh_hal.h"
#include "qh_utils.h"

int hal_qwe_mode(const struct iface *iface, uint32_t *mode)
{
	*mode = (PRIV(iface)->is_sta) ? WIFI_MODE_STA : WIFI_MODE_AP;
	return 0;
}

int hal_qwe_channel(const struct iface *iface, uint32_t *channel)
{
	int chan = execl_get_int(0, GREP(NULL), AWK(0, NULL),
		PATH_QWEACT, PRIV(iface)->phy_name, "status", "channel");
	if (chan < 0)
		return -1;
	*channel = chan;
	return 0;
}

int hal_qwe_txpower(const struct iface *iface, int32_t *txpower)
{
	return -ENOTSUP;
}

int hal_qwe_region(const struct iface *iface, string2 region)
{
	char *str = execl_get_output(0,
		PATH_QWECFG, "getrunning", str32("region.%s", PRIV(iface)->phy_name));
	if (!str)
		return -1;

	if (validate_region(str)) {
		free(str);
		return -1;
	}

	snprintf(region, sizeof(string2), "%s", str);
	free(str);
	return 0;
}

int hal_qwe_bandwidth(const struct iface *iface, uint32_t *bandwidth)
{
	int bw = execl_get_int(0, GREP(NULL), AWK(0, NULL),
		PATH_QWEACT, PRIV(iface)->phy_name, "status", "bandwidth");
	if (bw < 0)
		return -1;
	*bandwidth = bw;
	return 0;
}

int hal_qwe_bandwidth_supp(const struct iface *iface, uint32_t *bandwidth)
{
	return -ENOTSUP;
}

int hal_qwe_protocol(const struct iface *iface, uint32_t *protocol)
{
	int mode = execl_get_int(0, GREP(NULL), AWK(0, NULL),
		PATH_QWECFG, "getrunning", str32("band.%s", PRIV(iface)->phy_name));

	/* Note: even though mode 1 is b/g while mode 0 is g-only,
	 * HAL and MAUI cloud expect here only the best protocol =>
	 * PROTO_11G for both of them. The same is for mode 2 (b/g/n). */

	switch (mode) {
	case 0:
	case 1:
		*protocol = PROTO_11G; break;
	case 2:
		*protocol = PROTO_11N; break;
	default:
		return -1;
	}
	return 0;
}

int hal_qwe_protocol_supp(const struct iface *iface, uint32_t *protocol)
{
	int rate = execl_get_int(F_AT_START, GREP("maxbitrate="), AWK(2, "="),
		PATH_QWEACT, PRIV(iface)->phy_name, "list", "capability");
	if (rate < 0)
		return -1;

	*protocol = PROTO_11B | PROTO_11G; /* assume that 802.11b is supported */
	if (rate > 54)
		*protocol |= PROTO_11N;
	return 0;
}

int hal_qwe_ssid(const struct iface *iface, string32 ssid)
{
	return (execl_buf_output(ssid, sizeof(string32), 0,
		PATH_QWECFG, "getrunning", str32("ssid.%s", PRIV(iface)->cfg_name))) ? 0 : -1;
}

int hal_qwe_bssid(const struct iface *iface, macaddr_t bssid)
{
	char *str = execl_get_output(0,
		PATH_QWEACT, PRIV(iface)->phy_name, "showhwaddr", PRIV(iface)->act_name);
	if (!str)
		return -1;
	str2mac(str, bssid);
	free(str);
	return 0;
}

int hal_qwe_assoc_list(const struct iface *iface, char *halbuf, int *len)
{
	struct assoc_stats *asbuf = (struct assoc_stats *)halbuf;
	struct assoc_stats *as = asbuf - 1;
	char buf[256];
	char *tok;
	FILE *p;

	*len = 0;

	if (PRIV(iface)->is_sta) {
		p = execl_popen(0,
			PATH_QWEACT, PRIV(iface)->phy_name, "status", "rootap");
	} else {
		p = execl_popen(0,
			PATH_QWEACT, PRIV(iface)->phy_name, "stainfo", PRIV(iface)->act_name);
	}
	if (!p)
		return -1;

	while (fgets(buf, sizeof(buf), p)) {
		if (strstr(buf, "not-associated"))
			continue;
		if (halbuf == NULL) {
			/* only count associations */
			if (tok = gettok(buf, "mac:", 1, SPACE))
				(*len)++;
			continue;
		}

		if (tok = gettok(buf, "mac:", 1, SPACE)) {
			if (hal_buf_check_clear(halbuf, *len, sizeof(*as)))
				break;
			as++;
			(*len)++;
			str2mac(tok, as->macaddr);
			as->macaddr_set = 1;
		} else if (tok = gettok(buf, "rssi:", 1, SPACE)) {
			int rssi = atoi(tok);
			FLDSET(as->rssi, (rssi < 0) ? rssi : rssi - 100);
		} else if (tok = gettok(buf, "bandwidth:", 1, SPACE)) {
			FLDSET(as->bandwidth, atoi(tok));
		} else if (tok = gettok(buf, "duration:", 1, SPACE)) {
			FLDSET(as->time, atoi(tok));
		} else if (tok = gettok(buf, "rx_phyrate:", 1, SPACE)) {
			FLDSET(as->rx_rate, atoi(tok) * 1024);
		} else if (tok = gettok(buf, "tx_phyrate:", 1, SPACE)) {
			FLDSET(as->tx_rate, atoi(tok) * 1024);
		} else if (tok = gettok(buf, "rx_max_phyrate:", 1, SPACE)) {
			FLDSET(as->rx_max_rate, atoi(tok) * 1024);
		} else if (tok = gettok(buf, "rx_ss:", 1, SPACE)) {
			FLDSET(as->rx_streams, atoi(tok));
		}
	}
	execl_pclose(p);
	return 0;
}

int hal_qwe_traffic_list(const struct iface *iface, char *halbuf, int *len)
{
	struct traffic_stats *tsbuf = (struct traffic_stats *)halbuf;
	struct traffic_stats *ts = tsbuf - 1;
	char buf[256];
	char *tok;
	FILE *p;

	*len = 0;

	if (PRIV(iface)->is_sta) {
		p = execl_popen(0,
			PATH_QWEACT, PRIV(iface)->phy_name, "status", "rootap");
	} else {
		p = execl_popen(0,
			PATH_QWEACT, PRIV(iface)->phy_name, "stainfo", PRIV(iface)->act_name);
	}
	if (!p)
		return -1;

	while (fgets(buf, sizeof(buf), p)) {
		if (strstr(buf, "not-associated"))
			continue;
		if (tok = gettok(buf, "mac:", 1, SPACE)) {
			if (hal_buf_check_clear(halbuf, *len, sizeof(*ts)))
				break;
			ts++;
			(*len)++;
			str2mac(tok, ts->macaddr);
			ts->macaddr_set = 1;
		} else if (tok = gettok(buf, "rx_bytes:", 1, SPACE)) {
			FLDSET(ts->rx_bytes, atoll(tok));
		} else if (tok = gettok(buf, "tx_bytes:", 1, SPACE)) {
			FLDSET(ts->tx_bytes, atoll(tok));
		}
	}
	execl_pclose(p);
	return 0;
}

int hal_qwe_phy_stats(const struct iface *iface, struct phy_stats *halps)
{
	char buf[256];
	char *tok;
	FILE *p;
	uint32_t channel;
	int len;

	p = execl_popen(0, PATH_QWEACT, PRIV(iface)->phy_name, "stats", PRIV(iface)->act_name);
	if (!p)
		return -1;

	while (fgets(buf, sizeof(buf), p)) {
		if (tok = gettok(buf, "rx_pkts:", 1, SPACE)) {
			FLDSET(halps->rx_packets, atoi(tok));
		} else if (tok = gettok(buf, "tx_pkts:", 1, SPACE)) {
			FLDSET(halps->tx_packets, atoi(tok));
		}
	}
	execl_pclose(p);

	if (hal_qwe_channel(iface, &channel) == 0)
		FLDSET(halps->channel, channel);

	if (hal_qwe_assoc_list(iface, NULL, &len) == 0)
		FLDSET(halps->assoc, len);

	return 0;
}

int hal_qwe_cca_stats(const struct iface *iface, struct cca_stats *cca)
{
	return -ENOTSUP;
}

int hal_qwe_channel_list(const struct iface *iface, char *halbuf, int *len)
{
	struct channel_desc *chd = (struct channel_desc *)halbuf;
	string2 region;
	int channel;
	int last_ch;

	if (hal_qwe_region(iface, region))
		return -1;

	last_ch = execl_get_int(F_AT_START | F_IGN_CASE, GREP(region), AWK(2, "-"),
		PATH_QWEACT, PRIV(iface)->phy_name, "list", "allchannels");
	if (last_ch <= 0)
		return -1;

	for (channel = 1; channel <= last_ch; channel++, chd++) {
		if (hal_buf_check_clear(halbuf, channel - 1, sizeof(*chd)))
				break;
		FLDSET(chd->channel, channel);
	}
	*len = channel - 1;
	return 0;
}

#define SCAN_DURATION 10 /* it is about 5 seconds for RTL, but let's apply a margin of safety */
int hal_qwe_scan_start(const struct iface *iface, const int force)
{
	return (execl_run_bg(F_DEV_NULL,
		PATH_QCSAPI, "qwe", "qweaction", PRIV(iface)->phy_name, "ap_num")) ? -1 : 0;
}

int hal_qwe_scan_duration(const struct iface *iface, uint32_t *duration)
{
	*duration = SCAN_DURATION;
	return 0;
}

int hal_qwe_scan_status(const struct iface *iface, uint32_t *status)
{
	return -ENOTSUP;
}

int hal_qwe_scan_list(const struct iface *iface, char *halbuf, int *len)
{
	struct scan_stats *ss = (struct scan_stats *)halbuf;
	char buf[256];
	char *tok;
	FILE *p;
	int i;

	if (iface != iface->phy)
		return -1;

	for (i = 0;; i++, ss++) {
		if (hal_buf_check_clear(halbuf, i, sizeof(*ss)))
			break;
		p = execl_popen(0, PATH_QCSAPI, "qwe", "qweaction",
			PRIV(iface)->phy_name, "ap_info", str16("%d", i + 1));
		if (!p)
			return -1;

		while (fgets(buf, sizeof(buf), p)) {
			if ((tok = strstr(buf, "ssid: ")) && tok == buf) {
				tok += 6;
				tok = strtok(tok, "\n");
				strncpy(ss->ssid, tok, sizeof(string32) - 1);
				ss->ssid_set = 1;
			} else if (tok = gettok(buf, "mac:", 1, SPACE)) {
				str2mac(tok, ss->bssid);
				ss->bssid_set = 1;
			} else if (tok = gettok(buf, "rssi:", 1, SPACE)) {
				int rssi = atoi(tok);
				FLDSET(ss->rssi, (rssi < 0) ? rssi : rssi - 100);
			} else if (tok = gettok(buf, "channel:", 1, SPACE)) {
				FLDSET(ss->channel, atoi(tok));
			}
		}
		execl_pclose(p);
		if (ss->bssid_set == 0) /* call_qcsapi returned error message */
			break;
	}
	*len = i;
	return 0;
}

int hal_qwe_set_channel(const struct iface *iface, uint32_t channel)
{
	if (execl_run(F_DEV_NULL, PATH_QWECFG,
		"set", str32("channel.%s", PRIV(iface)->phy_name), str16("%d", channel)))
		return -1;
	return execl_run(F_DEV_NULL, PATH_QWEACT, PRIV(iface)->phy_name, "commit") ? -1 : 0;
}

int hal_qwe_set_txpower(const struct iface *iface, int32_t txpower)
{
	return -ENOTSUP;
}

int hal_qwe_set_ssid(const struct iface *iface, char *ssid)
{
	if (execl_run(F_DEV_NULL, PATH_QWECFG,
		"set", str32("ssid.%s", PRIV(iface)->cfg_name), ssid))
		return -1;
	return execl_run(F_DEV_NULL, PATH_QWEACT, PRIV(iface)->phy_name, "commit") ? -1 : 0;
}

int hal_qwe_set_bandwidth(const struct iface *iface, uint32_t bandwidth)
{
	if (execl_run(F_DEV_NULL, PATH_QWECFG,
		"set", str32("bandwidth.%s", PRIV(iface)->phy_name), str16("%d", bandwidth)))
		return -1;
	return execl_run(F_DEV_NULL, PATH_QWEACT, PRIV(iface)->phy_name, "commit") ? -1 : 0;
}

struct hal_ops hal_qwe_ops = {
	.name = "qwe",

	.init = NULL,
	.reinit = NULL,
	.probe = NULL,

	.mode = hal_qwe_mode,
	.channel = hal_qwe_channel,
	.txpower = hal_qwe_txpower,
	.region = hal_qwe_region,
	.bandwidth = hal_qwe_bandwidth,
	.bandwidth_supp = hal_qwe_bandwidth_supp,
	.protocol = hal_qwe_protocol,
	.protocol_supp = hal_qwe_protocol_supp,
	.ssid = hal_qwe_ssid,
	.bssid = hal_qwe_bssid,
	.phy_stats = hal_qwe_phy_stats,
	.cca_stats = hal_qwe_cca_stats,
	.channel_list = hal_qwe_channel_list,
	.assoc_list = hal_qwe_assoc_list,
	.traffic_list = hal_qwe_traffic_list,
	.scan_start = hal_qwe_scan_start,
	.scan_duration = hal_qwe_scan_duration,
	.scan_status = hal_qwe_scan_status,
	.scan_list = hal_qwe_scan_list,

	.set_channel = hal_qwe_set_channel,
	.set_txpower = hal_qwe_set_txpower,
	.set_ssid = hal_qwe_set_ssid,
	.set_bandwidth = hal_qwe_set_bandwidth,
};
