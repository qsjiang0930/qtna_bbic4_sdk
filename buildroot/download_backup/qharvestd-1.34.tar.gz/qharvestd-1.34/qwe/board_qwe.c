/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include "qharvestd.h"
#include "qh_hal.h"
#include "qh_utils.h"
#include "hal_qwe.h"

static inline char *idx2vap(int idx, char *buf)
{
	if (idx == 0)
		sprintf(buf, "ap");
	else
		sprintf(buf, "vap%d", idx - 1);
	return buf;
}

int board_qwe_init_iface_list(struct board *board)
{
	struct iface *head = NULL;
	struct iface **next = &head;
	struct iface *iface;
	char ifname[IFNAMSIZ];
	char buf[256];
	int wlan;
	int vap;

	board->ifnum = 0;
	board->head = NULL;

	for (wlan = 0; wlan < 3; wlan++) {
		struct iface *phy = NULL;
		int is_sta = 0;
		int max_vap = 5;

		/* Note: "status ap" has to be used even if we are in STA mode. */
		if (!execl_buf_output(buf, 256, F_DEV_NULL,
			PATH_QWEACT, str16("wlan%d", wlan), "status", "ap")
			|| strcmp(buf, "Up") != 0)
			continue;

		if (execl_run(F_DEV_NULL,
			PATH_QWEACT, str16("wlan%d", wlan), "status", "rootap") == 0) {
			is_sta = 1;
			max_vap = 1;
		}

		for (vap = 0; vap < max_vap; vap++) {
			if (execl_buf_output(buf, 256, 0,
				PATH_QWEACT, str16("wlan%d", wlan), "status",
				idx2vap(vap, ifname)) == NULL || strcmp(buf, "Up") != 0)
				continue;

			*next = iface = xcalloc(1, sizeof(*iface));
			next = &iface->next;
			snprintf(iface->name, sizeof(iface->name), "wlan%d_%d", wlan, vap);
			if (!phy)
				phy = iface;
			iface->phy = phy;
			iface->hal = &hal_qwe_ops;
			iface->board = board;
			iface->up = 1;

			iface->priv = (uintptr_t)xcalloc(1, sizeof(struct qwe_priv));
			PRIV(iface)->is_sta = is_sta;
			snprintf(PRIV(iface)->phy_name, sizeof(PRIV(iface)->phy_name),
				"wlan%d", wlan);
			if (is_sta) {
				snprintf(PRIV(iface)->cfg_name, sizeof(PRIV(iface)->cfg_name),
					"sta.wlan%d", wlan);
				snprintf(PRIV(iface)->act_name, sizeof(PRIV(iface)->act_name),
					"sta");
			} else if (vap) {
				snprintf(PRIV(iface)->cfg_name, sizeof(PRIV(iface)->cfg_name),
					"vap%d.wlan%d", vap - 1, wlan);
				snprintf(PRIV(iface)->act_name, sizeof(PRIV(iface)->act_name),
					"vap%d", vap - 1);
			} else {
				snprintf(PRIV(iface)->cfg_name, sizeof(PRIV(iface)->cfg_name),
					"wlan%d", wlan);
				snprintf(PRIV(iface)->act_name, sizeof(PRIV(iface)->act_name),
					"ap");
			}

			(board->ifnum)++;
		}
	}

	board->head = head;
	return 0;
}

void board_qwe_free_iface(struct iface *iface)
{
	free((void *)iface->priv);
	free(iface);
}

int board_qwe_init(struct board *board)
{
	/* Note: we need neither MAC nor firmware version,
	 * as this "board" is always a slave to QTN board.
	 * Moreover, QWE interface could be used to control
	 * different chips => there is no single firmware. */
	return 0;
}

int board_qwe_upgrade(struct board *board, char *fw_file)
{
	return -ENOTSUP;
}

struct board board_qwe = {
	.name = "qwe",
	.init_iface_list = board_qwe_init_iface_list,
	.free_iface = board_qwe_free_iface,
	.init = board_qwe_init,
	.upgrade = board_qwe_upgrade,
	.firmware_set = 0,
	.kernel_set = 0,
	.platform_set = 0,
	.reboot_cause_set = 0,
	.carrier_id_set = 0,
};
