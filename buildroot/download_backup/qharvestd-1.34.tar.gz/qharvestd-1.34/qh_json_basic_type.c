/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#define _GNU_SOURCE /* for strnlen */
#include <curl/curl.h>
#include <ctype.h>
#include <stdint.h>
#include <string.h>
#include "qharvestd.h"
#include "qh_curl_post.h"
#include "qh_json.h"
#include "qh_event.h"
#include "qh_iface.h"
#include "qh_utils.h"
#include "qh_hal.h"
#include "qcsapi/grabber.h"

JSON *get_json_from_mac(macaddr_t macaddr)
{
	char tmp[20];
	mac2str(macaddr, tmp);
	return JSON_NEW_STRING(tmp);
}

JSON *get_json_timestamp(void)
{
	time_t rawtime;
	struct tm *timeinfo;
	char buf[20];
	time(&rawtime);
	timeinfo = localtime(&rawtime);
	strftime(buf, 20, "%Y-%m-%d %H:%M:%S", timeinfo);
	return JSON_NEW_STRING(buf);
}

static JSON *get_json_static_wifi_macaddr(void)
{
	static JSON *j_wmac_obj = NULL;
	if (j_wmac_obj == NULL)
		j_wmac_obj = get_json_from_mac(g_macaddr);
	return (j_wmac_obj ? JSON_GET_REF(j_wmac_obj) : NULL);
}

static JSON *get_json_wifi_mode(void)
{
	char *mode_str = KEY_WIFI_MODE_UNKNOWN;

	if ((config.debug == 0) || (config.debug_config.mode == NULL)) {
		int mode = get_wifi_mode(WIFI_MODE_UNKNOWN);

		switch (mode) {
		case WIFI_MODE_AP:
			mode_str = KEY_WIFI_MODE_AP;
			break;
		case WIFI_MODE_STA:
			mode_str = KEY_WIFI_MODE_STATION;
			break;
		case WIFI_MODE_WDS:
			mode_str = KEY_WIFI_MODE_WDS;
			break;
		}
	} else {
		mode_str = config.debug_config.mode;
	}
	return JSON_NEW_STRING(mode_str);
}

struct assoc_stats_ext {
	struct assoc_stats assoc_stats;
	int32_t tx_rate_diff;
	int32_t rx_rate_diff;

	uint8_t tx_rate_diff_set : 1;
	uint8_t rx_rate_diff_set : 1;
};

static char *vendor_name(string32 buf, uint16_t vendor_id)
{
	switch (vendor_id) {
	case VENDOR_QUANTENNA:
		snprintf(buf, sizeof(string32), "quantenna");
		break;
	case VENDOR_BROADCOM:
		snprintf(buf, sizeof(string32), "broadcom");
		break;
	case VENDOR_ATHEROS:
		snprintf(buf, sizeof(string32), "atheros");
		break;
	case VENDOR_RALINK:
		snprintf(buf, sizeof(string32), "ralink");
		break;
	case VENDOR_REALTEK:
		snprintf(buf, sizeof(string32), "realtek");
		break;
	case VENDOR_INTEL:
		snprintf(buf, sizeof(string32), "intel");
		break;
	default:
		snprintf(buf, sizeof(string32), "unknown");
		break;
	}
	return buf;
}

static void json_add_assoc_stats(JSON *p, struct assoc_stats_ext *as)
{
	struct assoc_stats *s = &as->assoc_stats;
	string64 buf;

	JSON_ADD_INT_IF_SET(p, KEY_LINK_QUALITY, s->quality);
	JSON_ADD_INT_IF_SET(p, KEY_SNR, s->snr);
	JSON_ADD_INT_IF_SET(p, KEY_RSSI_DBM, s->rssi);
	JSON_ADD_INT_IF_SET(p, KEY_ASSOCIATION_TIME, s->time);
	JSON_ADD_INT_IF_SET(p, KEY_BW, s->bandwidth);
	JSON_ADD_INT_IF_SET(p, KEY_MAX_QUEUED, s->max_queued);
	JSON_ADD_INT_IF_VAL(p, KEY_TX_PHY_RATE, s->tx_rate, s->tx_rate / 1024);
	JSON_ADD_INT_IF_VAL(p, KEY_TX_PHY_RATE_DIFF, as->tx_rate_diff,
		as->tx_rate_diff / 1024);
	JSON_ADD_INT_IF_VAL(p, KEY_TX_ACHIEVABLE_PHY_RATE, s->tx_max_rate,
		s->tx_max_rate / 1024 * 1000);
	JSON_ADD_INT_IF_VAL(p, KEY_RX_PHY_RATE, s->rx_rate, s->rx_rate / 1024);
	JSON_ADD_INT_IF_VAL(p, KEY_RX_PHY_RATE_DIFF, as->rx_rate_diff,
		as->rx_rate_diff / 1024);
	JSON_ADD_INT_IF_VAL(p, KEY_RX_ACHIEVABLE_PHY_RATE, s->rx_max_rate,
		s->rx_max_rate / 1024 * 1000);
	JSON_ADD_INT_IF_SET(p, KEY_PROTOCOL, s->protocol);
	JSON_ADD_INT_IF_SET(p, KEY_RX_STREAMS, s->rx_streams);
	JSON_ADD_INT_IF_SET(p, KEY_TX_STREAMS, s->tx_streams);
	JSON_ADD_INT_IF_SET(p, KEY_RX_MCS, s->rx_mcs);
	JSON_ADD_INT_IF_SET(p, KEY_TX_MCS, s->tx_mcs);
	if (s->vendor_set)
		JSON_ADD_STRING_FIELD(p, KEY_VENDOR, vendor_name(buf, s->vendor));
	if (s->htcaps_set)
		JSON_ADD_STRING_FIELD(p, KEY_HT_CAPS,
			encode64(buf, sizeof(buf), s->htcaps, HAL_HTCAP_LEN));
	if (s->vhtcaps_set)
		JSON_ADD_STRING_FIELD(p, KEY_VHT_CAPS,
			encode64(buf, sizeof(buf), s->vhtcaps, HAL_VHTCAP_LEN));
}

static JSON *json_add_traffic_stats(JSON *p, struct traffic_stats *s)
{
	if (p == NULL)
		p = JSON_NEW_OBJ();

	/* In STA case or if a field is not set we just send zeroes
	 * to preserve compatibility with backend's deserializers */

	JSON_ADD_INT_IF_SET(p, KEY_TX_BYTES, s->tx_bytes);
	JSON_ADD_INT_IF_SET(p, KEY_TX_PACKETS, s->tx_packets);
	JSON_ADD_INT_IF_SET(p, KEY_TX_DISCARD, s->tx_discard);
	JSON_ADD_INT_IF_SET(p, KEY_TX_ERROR, s->tx_error);
	JSON_ADD_INT_IF_SET(p, KEY_TX_UNICAST, s->tx_unicast);
	JSON_ADD_INT_IF_SET(p, KEY_TX_MULTICAST, s->tx_multicast);
	JSON_ADD_INT_IF_SET(p, KEY_TX_BROADCAST, s->tx_broadcast);
	JSON_ADD_INT_IF_SET(p, KEY_TX_RETRIES, s->tx_retries);

	JSON_ADD_INT_IF_SET(p, KEY_RX_BYTES, s->rx_bytes);
	JSON_ADD_INT_IF_SET(p, KEY_RX_PACKETS, s->rx_packets);
	JSON_ADD_INT_IF_SET(p, KEY_RX_DISCARD, s->rx_discard);
	JSON_ADD_INT_IF_SET(p, KEY_RX_ERROR, s->rx_error);
	JSON_ADD_INT_IF_SET(p, KEY_RX_UNICAST, s->rx_unicast);
	JSON_ADD_INT_IF_SET(p, KEY_RX_MULTICAST, s->rx_multicast);
	JSON_ADD_INT_IF_SET(p, KEY_RX_BROADCAST, s->rx_broadcast);

	return p;
}

static JSON *get_json_phy_stats(struct iface *iface)
{
	JSON *obj = NULL;
	struct phy_stats phy_stats = { 0 };
	int32_t txpower = 0;

	if (iface->hal->phy_stats(iface, &phy_stats))
		return NULL;

	obj = JSON_NEW_OBJ();

	JSON_ADD_STRING_FIELD(obj, KEY_IFACE, iface->name);

	JSON_ADD_INT_IF_SET(obj, KEY_ASSOC, phy_stats.assoc);
	JSON_ADD_INT_IF_SET(obj, KEY_CHANNEL, phy_stats.channel);
	JSON_ADD_INT_IF_SET(obj, KEY_ATTEN, phy_stats.atten);

	JSON_ADD_INT_IF_SET(obj, KEY_RX_PKTS, phy_stats.rx_packets);
	JSON_ADD_INT_IF_SET(obj, KEY_RX_GAIN, phy_stats.rx_gain);
	JSON_ADD_INT_IF_SET(obj, KEY_RX_CNT_CRC, phy_stats.fcs_err);
	JSON_ADD_INT_IF_SET(obj, KEY_RX_NOISE, phy_stats.rx_noise);

	JSON_ADD_INT_IF_SET(obj, KEY_TX_PKTS, phy_stats.tx_packets);
	JSON_ADD_INT_IF_SET(obj, KEY_TX_DEFERS, phy_stats.tx_deferred);
	JSON_ADD_INT_IF_SET(obj, KEY_TX_RETRIES, phy_stats.tx_retries);

	JSON_ADD_INT_IF_SET(obj, KEY_CNT_SP_FAIL, phy_stats.sp_fail);
	JSON_ADD_INT_IF_SET(obj, KEY_CNT_LP_FAIL, phy_stats.lp_fail);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_RX_MCS, phy_stats.rx_mcs);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_TX_MCS, phy_stats.tx_mcs);

	JSON_ADD_INT_IF_SET(obj, KEY_LAST_RSSI, phy_stats.rssi);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_RSSI_0, phy_stats.rssi0);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_RSSI_1, phy_stats.rssi1);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_RSSI_2, phy_stats.rssi2);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_RSSI_3, phy_stats.rssi3);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_RSSI_4, phy_stats.rssi4);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_RSSI_5, phy_stats.rssi5);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_RSSI_6, phy_stats.rssi6);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_RSSI_7, phy_stats.rssi7);

	JSON_ADD_INT_IF_SET(obj, KEY_LAST_RCPI, phy_stats.rcpi);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_EVM, phy_stats.evm);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_EVM_0, phy_stats.evm0);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_EVM_1, phy_stats.evm1);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_EVM_2, phy_stats.evm2);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_EVM_3, phy_stats.evm3);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_EVM_4, phy_stats.evm4);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_EVM_5, phy_stats.evm5);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_EVM_6, phy_stats.evm6);
	JSON_ADD_INT_IF_SET(obj, KEY_LAST_EVM_7, phy_stats.evm7);

	JSON_ADD_INT_IF_SET(obj, KEY_RF_TEMP, phy_stats.rf_temp);
	JSON_ADD_INT_IF_SET(obj, KEY_BB_TEMP, phy_stats.bb_temp);

	if (iface->hal->txpower(iface, &txpower) == 0)
		JSON_ADD_INT_FIELD(obj, KEY_TXPWR, txpower);

	return obj;
}

static int json_add_cca_stats(JSON *obj, struct cca_stats *cca)
{
	if (!obj)
		return -1;
	JSON_ADD_INT_IF_SET(obj, KEY_CCA_TOTAL, cca->total);
	JSON_ADD_INT_IF_SET(obj, KEY_CCA_TX, cca->tx);
	JSON_ADD_INT_IF_SET(obj, KEY_CCA_RX, cca->rx);
	JSON_ADD_INT_IF_SET(obj, KEY_CCA_RX_TX, cca->rx_tx);
	JSON_ADD_INT_IF_SET(obj, KEY_CCA_RX_CS, cca->rx_cs);
	JSON_ADD_INT_IF_SET(obj, KEY_CCA_CS, cca->cs);
	JSON_ADD_INT_IF_SET(obj, KEY_CCA_ED, cca->ed);
	JSON_ADD_INT_IF_SET(obj, KEY_CCA_INT, cca->cs_ed);
	JSON_ADD_INT_IF_SET(obj, KEY_CCA_IDLE, cca->idle);
	return 0;
}

JSON *add_json_message_header(JSON *obj)
{
	if (obj == NULL) {
		obj = JSON_NEW_OBJ();
	}
	JSON_ADD_INT_FIELD(obj, KEY_VERSION, 3);
	JSON_ADD_FIELD(obj, KEY_MACADDRESS, get_json_static_wifi_macaddr());
	JSON_ADD_FIELD(obj, KEY_TIMESTAMP, get_json_timestamp());
	return obj;
}

static void json_add_firmware_info(JSON *obj)
{
	JSON_ADD_STRING_FIELD(obj, KEY_AGENT, __VERSION);
	if (g_firmware[0] != '\0')
		JSON_ADD_STRING_FIELD(obj, KEY_FW, g_firmware);
	if (g_platform[0] != '\0')
		JSON_ADD_STRING_FIELD(obj, KEY_PLATFORM, g_platform);
#ifdef HAL_QCSAPI
	if (board_qtn.firmware_set)
		JSON_ADD_STRING_FIELD(obj, KEY_QTN_FW, board_qtn.firmware);
	if (board_qtn.platform_set)
		JSON_ADD_STRING_FIELD(obj, KEY_QTN_PLATFORM, board_qtn.platform);
#endif
}

static int get_gateway_mac(macaddr_t mac)
{
	string64 buf;
	macaddr_t macaddr;
	char *ipstr;
	char *macstr;

	ipstr = execl_output_grep_awk(buf, sizeof(buf), F_DEV_NULL | F_AT_START,
		GREP("0.0.0.0"), AWK(2, SPACE), PATH_ROUTE, "-n");
	if (ipstr == NULL)
		return -1;

	macstr = execl_output_grep_awk(buf, sizeof(buf), F_DEV_NULL,
		GREP(NULL), AWK(4, SPACE), PATH_ARP, "-an", ipstr);
	if (macstr == NULL)
		return -1;

	if (str2mac(macstr, macaddr))
		return -1;

	memcpy(mac, macaddr, sizeof(macaddr_t));
	return 0;
}

static void json_add_soniq_topology(JSON *tobj)
{
#if HAVE_SONIQ
	JSON *aobj = NULL;
	string64 buf;
	FILE *p;
	char *tok;

	if (tobj == NULL)
		return;

	p = execl_popen(F_DEV_NULL, PATH_QCOMM_CLI, "show_role");
	if (p == NULL)
		return;

	while (fgets(buf, sizeof(buf), p)) {
		if ((tok = gettok(buf, "role: ", 1, SPACE))) {
			aobj = JSON_NEW_ARRAY();
			JSON_ADD_STRING_FIELD(tobj, KEY_ROLE, tok);
			if ((tok = strtok(NULL, SPACE))) {
				macaddr_t macaddr = { 0 };
				if (str2mac(tok, macaddr))
					continue;
				JSON_ADD_FIELD(tobj, KEY_MACADDRESS, get_json_from_mac(macaddr));
			}
		}
		/* coverity[tainted_data] - 0 <= buf[0] <= 127 => OK for isxdigit() */
		else if (isascii((unsigned char)buf[0]) && isxdigit((unsigned char)buf[0])) {
			macaddr_t macaddr = { 0 };
			if ((tok = strtok(buf, SPACE)) == NULL)
				continue;
			if (str2mac(tok, macaddr))
				continue;
			if (aobj)
				JSON_ADD_ITEM(aobj, get_json_from_mac(macaddr));
		}
	}
	execl_pclose(p);

	if (aobj)
		JSON_ADD_FIELD(tobj, KEY_PEERS, aobj);
#endif
	return;
}

JSON *get_json_polling_message(struct message_control *mctl, int *ret)
{
	JSON *obj = add_json_message_header(NULL);
	JSON *aobj = JSON_NEW_ARRAY();
	JSON *tobj = JSON_NEW_OBJ();
	int uptime = get_uptime();
	macaddr_t mac;
	string64 buf;
	string2 region;
	struct iface *iface;
#ifdef HAL_QCSAPI
	struct board *board = &board_qtn; /* give priority to QTN board */
#else
	struct board *board = boards[0];
#endif
	json_add_firmware_info(obj);
	JSON_ADD_FIELD(obj, KEY_WIFI_MODE, get_json_wifi_mode());
	if (uptime >= 0) {
		JSON_ADD_INT_FIELD(obj, KEY_UPTIME, uptime);
		JSON_ADD_INT_FIELD(obj, KEY_RUNTIME, uptime - g_start_uptime);
	}
	JSON_ADD_INT_FIELD(obj, KEY_REBOOT_CAUSE,
		board->reboot_cause_set ? board->reboot_cause : 0);
	if (board->carrier_id_set)
		JSON_ADD_INT_FIELD(obj, KEY_CARRIER_ID, board->carrier_id);
	if (board->head && board->head->hal->region(board->head, region) == 0)
		JSON_ADD_STRING_FIELD(obj, KEY_REGION, region);

	for (iface = iflist; iface; iface = iface->next) {
		macaddr_t macaddr = { 0 };
		struct JSON *ifobj = JSON_NEW_OBJ();

		JSON_ADD_STRING_FIELD(ifobj, KEY_NAME, iface->name);
		JSON_ADD_STRING_FIELD(ifobj, KEY_PHY, iface->phy->name);
		JSON_ADD_INT_FIELD(ifobj, KEY_UP, iface->up);

		if (iface->hal->bssid(iface, macaddr) == 0)
			JSON_ADD_FIELD(ifobj, KEY_BSSID, get_json_from_mac(macaddr));

		buf[0] = 0;
		if (iface->hal->ssid(iface, buf) == 0)
			JSON_ADD_STRING_FIELD(ifobj, KEY_SSID, buf);

		if (iface == iface->phy) {
			uint32_t ch;
			uint32_t bw;
			uint32_t protocol;

			if (iface->hal->channel(iface, &ch) == 0)
				JSON_ADD_INT_FIELD(ifobj, KEY_CHANNEL, ch);
			if (iface->hal->bandwidth(iface, &bw) == 0)
				JSON_ADD_INT_FIELD(ifobj, KEY_BW, bw);
			if (iface->hal->protocol(iface, &protocol) == 0)
				JSON_ADD_INT_FIELD(ifobj, KEY_PROTOCOL, protocol);
		}
		JSON_ADD_ITEM(aobj, ifobj);
	}
	JSON_ADD_FIELD(obj, KEY_INTERFACES, aobj);

	if (0 == get_gateway_mac(mac))
		JSON_ADD_FIELD(tobj, KEY_GW_MAC, get_json_from_mac(mac));
	json_add_soniq_topology(tobj);
	JSON_ADD_FIELD(obj, KEY_TOPOLOGY, tobj);

	DBG_INFO("health_flags: %x", g_health_flags);
	if (g_health_flags) {
		JSON *stat_obj = JSON_NEW_OBJ();
#define PUBLISH_HEALTH_STAT(key, field) do { \
	if (g_health_flags & 1 << HEALTH_FLAG_##key) { \
		JSON_ADD_INT_FIELD(stat_obj, KEY_##key, g_smoothed_health_stats.field); \
	} } while(0)
		PUBLISH_HEALTH_STAT(CCA_INT, cca_cs_ed);
		PUBLISH_HEALTH_STAT(CCA_IDLE, cca_idle);
		PUBLISH_HEALTH_STAT(CNT_SP_FAIL, sp_fail);
		PUBLISH_HEALTH_STAT(CNT_LP_FAIL, lp_fail);
		PUBLISH_HEALTH_STAT(RSSI, rssi);
		PUBLISH_HEALTH_STAT(TX_PHY_RATE, tx_rate);
		JSON_ADD_FIELD(obj, KEY_HEALTH_METRICS, stat_obj);
	}
	return obj;
}

JSON *get_json_default_message(struct message_control *mctl, int *ret)
{
	JSON *obj = NULL;

	obj = add_json_message_header(obj);
	return obj;
}

JSON *get_json_log_capabilities_message(struct message_control *mctl, int *ret)
{
	JSON *obj = NULL;
	JSON *aobj = NULL;
	JSON *fobj = NULL;
	JSON *chaobj = NULL;
	struct iface *iface;

	if (iflist == NULL)
		return NULL;

	obj = add_json_message_header(obj);
	aobj = JSON_NEW_ARRAY();

	for (iface = iflist; iface; iface = iface->next) {
		uint32_t protocol;
		uint32_t bw;
		int len;
		int i;

		if (iface->phy != iface)
			continue;

		fobj = JSON_NEW_OBJ();
		chaobj = JSON_NEW_ARRAY();

		JSON_ADD_STRING_FIELD(fobj, KEY_IFACE, iface->name);
		if (iface->hal->protocol_supp(iface, &protocol) == 0)
			JSON_ADD_INT_FIELD(fobj, KEY_PROTOCOL, protocol);
		if (iface->hal->bandwidth_supp(iface, &bw) == 0)
			JSON_ADD_INT_FIELD(fobj, KEY_BW, bw);

		if (iface->hal->channel_list(iface, hal_buf, &len))
			goto no_channel;

		for (i = 0; i < len; i++) {
			struct channel_desc *cd = (struct channel_desc *)hal_buf + i;
			JSON *chobj = JSON_NEW_OBJ();

			JSON_ADD_INT_FIELD(chobj, KEY_CHANNEL, cd->channel);
			JSON_ADD_INT_IF_SET(chobj, KEY_TXPWR, cd->txpower);
			JSON_ADD_ITEM(chaobj, chobj);
		}

no_channel:
		JSON_ADD_FIELD(fobj, KEY_CHANNEL_REPORT, chaobj);
		JSON_ADD_ITEM(aobj, fobj);
	}
	JSON_ADD_FIELD(obj, KEY_CAPABILITIES, aobj);
	return obj;
}

int get_assoc_stats(struct assoc_stats_ext **as_array, struct traffic_stats **ts_array,
	int *len_array)
{
	struct iface *iface;
	int ifidx;
	int i;
	int l;

	for (iface = iflist, ifidx = 0; iface; iface = iface->next, ifidx++) {
		if (len_array[ifidx] == 0)
			continue;
		if (iface->hal->assoc_list(iface, hal_buf, &l))
			return -1;
		if (len_array[ifidx] != l)
			return -1;

		for (i = 0; i < len_array[ifidx]; i++) {
			struct assoc_stats *as = (struct assoc_stats *)hal_buf + i;
			memcpy(&as_array[ifidx][i].assoc_stats, as, sizeof(*as));
		}

		if (iface->hal->traffic_list(iface, hal_buf, &l))
			continue;
		if (len_array[ifidx] != l)
			return -1;

		for (i = 0; i < len_array[ifidx]; i++) {
			struct traffic_stats *ts = (struct traffic_stats *)hal_buf + i;
			memcpy(&ts_array[ifidx][i], ts, sizeof(*ts));
		}
	}
	return 0;
}

int get_cca_stats(struct iface *iface, struct cca_stats *cur, struct cca_stats *old)
{
#define CCA_SUBSTRACT(cur, old, field, norm) \
	({ \
		cur->field = (cur->field - old->field) / norm; \
		if (cur->field < 0) \
			cur->field = 0;\
	})

	int ret;
	if (!cur || ((ret = iface->hal->cca_stats(iface, cur)) && ret != -ENOTSUP))
		return -1;

	/* It is OK if some interfaces do not report CCA stats as
	 * we add them to JSON report only if cca_total is set .*/
	if (!cur->total_set)
		return 0;
	if (old && !old->total_set)
		return -1;

	if (old && cur->cumulative) {
		double norm = (cur->total - old->total) / 1000;

		if ((int)(norm * 10) == 0) {
			/* Not enough samples, clear CCA stats as invalid */
			memset(cur, 0, sizeof(*cur));
			memset(old, 0, sizeof(*old));
			return 0;
		}
		if (norm < 0)
			return -1;

		cur->total = 1000;
		CCA_SUBSTRACT(cur, old, rx, norm);
		CCA_SUBSTRACT(cur, old, tx, norm);
		CCA_SUBSTRACT(cur, old, rx_tx, norm);
		CCA_SUBSTRACT(cur, old, rx_cs, norm);
		CCA_SUBSTRACT(cur, old, cs, norm);
		CCA_SUBSTRACT(cur, old, ed, norm);
		CCA_SUBSTRACT(cur, old, cs_ed, norm);
		CCA_SUBSTRACT(cur, old, idle, norm);
	}

	return 0;
}

JSON *get_json_log_bundled_stats_message(struct message_control *mctl, int *ret)
{
	JSON *obj = NULL;
	JSON *aobj = NULL;
	struct assoc_stats_ext *assoc_stats_old[ifnum];
	struct assoc_stats_ext *assoc_stats_new[ifnum];
	struct traffic_stats *node_stats_old[ifnum];
	struct traffic_stats *node_stats_new[ifnum];
	struct cca_stats cca_stats_old[ifnum];
	struct cca_stats cca_stats_new[ifnum];
	int i;
	int len[ifnum];
	int mode = get_wifi_mode(WIFI_MODE_UNKNOWN);
	struct timespec start;
	struct timespec time;
	struct iface *iface;
	int ifidx;

	*ret = -EAGAIN;
	if (ifnum == 0)
		return NULL;

	memset(len, 0, ifnum * sizeof(*len));
	memset(assoc_stats_old, 0, ifnum * sizeof(*assoc_stats_old));
	memset(assoc_stats_new, 0, ifnum * sizeof(*assoc_stats_new));
	memset(node_stats_old, 0, ifnum * sizeof(*node_stats_old));
	memset(node_stats_new, 0, ifnum * sizeof(*node_stats_new));
	memset(cca_stats_old, 0, ifnum * sizeof(*cca_stats_old));
	memset(cca_stats_new, 0, ifnum * sizeof(*cca_stats_new));

	for (iface = iflist, ifidx = 0; iface; iface = iface->next, ifidx++) {
		uint32_t status;

		if (iface->hal->assoc_list(iface, hal_buf, &len[ifidx]))
			continue;

		/* On most QTN firmwares channel reported by phy_stats is incorrect
		 * if scan is in progress => do not report bundled_stats during QTN scan.
		 * QTN STA scans continuously while not associated => do not use
		 * this workaround in this case (anyway channel is not defined then) */
		if (iface == iface->phy && !(mode == WIFI_MODE_STA && len[ifidx] == 0)
		    && strcmp(iface->hal->name, "qcsapi") == 0
		    && iface->hal->scan_status(iface, &status) == 0
		    && status == SCAN_IN_PROGRESS) {
			DBG_INFO("skip bundled stats due to ongoing QTN scan on %s",
				iface->phy->name);
			goto bail;
		}

		if (len[ifidx] == 0)
			continue;

		/* big allocation size, do not use xcalloc */
		assoc_stats_old[ifidx] = calloc(len[ifidx], sizeof(**assoc_stats_old));
		assoc_stats_new[ifidx] = calloc(len[ifidx], sizeof(**assoc_stats_new));
		node_stats_old[ifidx] = calloc(len[ifidx], sizeof(**node_stats_old));
		node_stats_new[ifidx] = calloc(len[ifidx], sizeof(**node_stats_new));
		if (assoc_stats_old[ifidx] == NULL || assoc_stats_new[ifidx] == NULL ||
		    node_stats_old[ifidx] == NULL || node_stats_new[ifidx] == NULL)
			goto bail;
	}

	clock_gettime(CLOCK_MONOTONIC, &start);
	if (get_assoc_stats(assoc_stats_old, node_stats_old, len))
		goto bail;
	for (iface = iflist, ifidx = 0; iface; iface = iface->next, ifidx++) {
		if (get_cca_stats(iface, &cca_stats_old[ifidx], NULL))
			goto bail;
	}

	/* we want the time lapse between get_assoc_stats and
	 * get_node_stats calls for each given association
	 * to be as close to 1 second as possible */
	clock_gettime(CLOCK_MONOTONIC, &time);
	timespec_sub(&time, &time, &start);
	if (time.tv_sec == 0) {
		time.tv_nsec = 1000000000 - time.tv_nsec;
		qh_event_listen_sleep(&time);
	}

	if (get_assoc_stats(assoc_stats_new, node_stats_new, len))
		goto bail;
	for (iface = iflist, ifidx = 0; iface; iface = iface->next, ifidx++) {
		if (get_cca_stats(iface, &cca_stats_new[ifidx], &cca_stats_old[ifidx]))
			goto bail;
	}

	obj = add_json_message_header(obj);
	aobj = JSON_NEW_ARRAY();

	for (iface = iflist, ifidx = 0; iface; iface = iface->next, ifidx++) {
		for (i = 0; i < len[ifidx]; i++) {
			JSON *p;
			struct assoc_stats_ext *aext = &assoc_stats_new[ifidx][i];
			struct assoc_stats *anew = &assoc_stats_new[ifidx][i].assoc_stats;
			struct traffic_stats *tnew = &node_stats_new[ifidx][i];
			struct assoc_stats *aold = &assoc_stats_old[ifidx][i].assoc_stats;
			struct traffic_stats *told = &node_stats_old[ifidx][i];

			if (!anew->macaddr_set)
				continue;
			p = JSON_NEW_OBJ();

			JSON_ADD_STRING_FIELD(p, KEY_IFACE, iface->name);
			JSON_ADD_FIELD(p, KEY_MACADDRESS, get_json_from_mac(anew->macaddr));

			json_add_traffic_stats(p, tnew);

			if (anew->rx_rate_set && aold->rx_rate_set) {
				aext->rx_rate_diff = anew->rx_rate - aold->rx_rate;
				aext->rx_rate_diff_set = 1;
			}
			if (anew->tx_rate_set && aold->tx_rate_set) {
				aext->tx_rate_diff = anew->tx_rate - aold->tx_rate;
				aext->tx_rate_diff_set = 1;
			}
			json_add_assoc_stats(p, aext);

			if (mode == WIFI_MODE_AP) {
				/* It is OK to use the same unsigned int fields for node_stats diff,
				 * because packet counters could only increase as time goes by.
				 * If fields aren't set, here will be just zeroes. */
				tnew->rx_bytes -= told->rx_bytes;
				tnew->tx_bytes -= told->tx_bytes;
				tnew->rx_packets -= told->rx_packets;
				tnew->tx_packets -= told->tx_packets;
				tnew->rx_discard -= told->rx_discard;
				tnew->tx_discard -= told->tx_discard;
				tnew->rx_error -= told->rx_error;
				tnew->tx_error -= told->tx_error;
				tnew->rx_unicast -= told->rx_unicast;
				tnew->tx_unicast -= told->tx_unicast;
				tnew->rx_multicast -= told->rx_multicast;
				tnew->tx_multicast -= told->tx_multicast;
				tnew->rx_broadcast -= told->rx_broadcast;
				tnew->tx_broadcast -= told->tx_broadcast;
				tnew->tx_retries -= told->tx_retries;

				/* We add regular node_stats as separate fields and
				 * encapsulate node_stats_diff fields in an object,
				 * because we want to preserve backward compatibility
				 * with backend's deserializers and at the same time
				 * reuse a code of json_add_node_stats function */
				JSON_ADD_FIELD(p, KEY_NODE_STATS_DIFF,
					json_add_traffic_stats(NULL, tnew));
			}
			JSON_ADD_ITEM(aobj, p);
		}
	}
	JSON_ADD_FIELD(obj, KEY_ASSOC_TABLE, aobj);

	JSON_ADD_FIELD(obj, KEY_WIFI_MODE, get_json_wifi_mode());
	aobj = JSON_NEW_ARRAY();
	for (iface = iflist, ifidx = 0; iface; iface = iface->next, ifidx++) {
		if (iface->phy == iface) {
			JSON * p = get_json_phy_stats(iface);
			json_add_cca_stats(p, &cca_stats_new[ifidx]);
			JSON_ADD_ITEM(aobj, p);
		}
	}
	JSON_ADD_FIELD(obj, KEY_PHY_STATS, aobj);
	*ret = 0;
bail:
	for (iface = iflist, ifidx = 0; iface; iface = iface->next, ifidx++) {
		if (len[ifidx] == 0)
			continue;
		if (assoc_stats_old[ifidx])
			free(assoc_stats_old[ifidx]);
		if (assoc_stats_new[ifidx])
			free(assoc_stats_new[ifidx]);
		if (node_stats_old[ifidx])
			free(node_stats_old[ifidx]);
		if (node_stats_new[ifidx])
			free(node_stats_new[ifidx]);
	}
	if (*ret != 0 && obj) {
		JSON_PUT_REF(obj);
		obj = NULL;
	}
	return obj;
}

JSON *get_json_log_scan_results_message(struct message_control *mctl, int *ret)
{
	JSON *obj = NULL;
	JSON *aobj = NULL;
	JSON *fobj = NULL;
	static struct timespec scanstart = {0, 0};
	uint32_t scan_duration = 0;
	struct iface *iface;
	int num_APs = 0;
	int len;
	int i;

	/* use stored initial scan results if there are any */
	if (mctl->jobj) {
		obj = mctl->jobj;
		mctl->jobj = NULL;
		DBG_INFO("initial scan results were used");
		goto ret;
	}

	for (iface = iflist; iface; iface = iface->next) {
		uint32_t duration;
		if (iface != iface->phy)
			continue;
		if (iface->hal->scan_duration(iface, &duration))
			continue;
		if (duration > scan_duration)
			scan_duration = duration;
	}

	if (scanstart.tv_sec != 0) { /* scan was started on previous call of the function */
		struct timespec time;
		int timediff;

		clock_gettime(CLOCK_MONOTONIC, &time);
		timediff = time.tv_sec - scanstart.tv_sec - scan_duration;
		if (timediff < 0) { /* handle forced scan / timeout updated by poll cases */
			mctl->timeout = -timediff + 1;
			DBG_INFO("scan is in progress, wait %ds for completion",
				mctl->timeout);
			goto ret;
		}
		/* reschedule manually to compensate scan_duration */
		mctl->timeout = mctl->interval - scan_duration;
		if (mctl->timeout <= 0) {
			DBG_INFO("scan interval <= scan duration (%ds)", scan_duration);
			mctl->timeout = 1;
		}
	} else if (!(mctl->flag & FLAG_INITIAL_SCAN)) {
		int scan_started = 0;

		for (iface = iflist; iface; iface = iface->next) {
			if (iface->phy != iface)
				continue;
			if (iface->hal->scan_start(iface, mctl->flag & FLAG_FORCE_SCAN) == 0)
				scan_started = 1;
		}
		if (scan_started) {
			clock_gettime(CLOCK_MONOTONIC, &scanstart);
			/* reschedule scan message by scan_duration */
			mctl->timeout = scan_duration;
			goto ret;
		}
	}

	/* do not send scan message if scan wasn't performed */
	if (scanstart.tv_sec == 0 && !(mctl->flag & FLAG_INITIAL_SCAN))
		goto ret;

	scanstart.tv_sec = 0;
	obj = add_json_message_header(obj);
	aobj = JSON_NEW_ARRAY();

	for (iface = iflist; iface; iface = iface->next) {
		if (iface->phy != iface)
			continue;
		if (iface->hal->scan_list(iface, hal_buf, &len) != 0)
			continue;
		num_APs += len;
		for (i = 0; i < len; i++) {
			struct scan_stats *ss = (struct scan_stats *)hal_buf + i;
			fobj = JSON_NEW_OBJ();

			if (ss->ssid_set) {
				string64 ssid64;
				encode64(ssid64, sizeof(ssid64),
					ss->ssid, strnlen(ss->ssid, sizeof(ss->ssid) - 1));
				JSON_ADD_STRING_FIELD(fobj, KEY_AP_SSID, ssid64);
			}
			if (ss->bssid_set)
				JSON_ADD_FIELD(fobj, KEY_AP_BSSID, get_json_from_mac(ss->bssid));
			if (ss->channel_set)
				JSON_ADD_INT_FIELD(fobj, KEY_AP_CHANNEL, ss->channel);
			if (ss->rssi_set)
				JSON_ADD_INT_FIELD(fobj, KEY_AP_RSSI, ss->rssi);
			if (ss->encrypt_proto_set)
				JSON_ADD_INT_FIELD(fobj, KEY_AP_ENC_PROTO, ss->encrypt_proto);
			if (ss->encrypt_mode_set)
				JSON_ADD_INT_FIELD(fobj, KEY_AP_ENC_MODES, ss->encrypt_mode);
			if (ss->auth_mode_set)
				JSON_ADD_INT_FIELD(fobj, KEY_AP_AUTH_MODE, ss->auth_mode);
			if (ss->max_rate_set)
				JSON_ADD_INT_FIELD(fobj, KEY_AP_RATE, ss->max_rate);
			if (ss->wps_support_set)
				JSON_ADD_INT_FIELD(fobj, KEY_AP_WPS, ss->wps_support);
			if (ss->protocol_set)
				JSON_ADD_INT_FIELD(fobj, KEY_AP_PROTO, ss->protocol);
			if (ss->bandwidth_set)
				JSON_ADD_INT_FIELD(fobj, KEY_BW, ss->bandwidth);

			JSON_ADD_ITEM(aobj, fobj);
		}
	}
	JSON_ADD_INT_FIELD(obj, KEY_NUM_APS, num_APs);
	JSON_ADD_FIELD(obj, KEY_SCAN_RESULTS, aobj);
 ret:
	mctl->flag &= ~(FLAG_INITIAL_SCAN | FLAG_FORCE_SCAN);
	return obj;
}

void do_initial_scan(void)
{
	struct message_control *mctl = get_message_control(KEY_MESSAGE_LOG_SCAN_REQUEST);
	struct iface *iface;
	int elapsed = 0;
	int i;

	for (iface = iflist; iface; iface = iface->next) {
		uint32_t duration;
		uint32_t status;
		if (iface != iface->phy)
			continue;
		if (iface->hal->scan_duration(iface, &duration))
			continue;
		for (; elapsed < duration && iface->hal->scan_status(iface, &status)
		    && status == SCAN_IN_PROGRESS; elapsed++) {
			sleep(1);
		}
	}

	mctl->flag |= FLAG_INITIAL_SCAN;
	mctl->jobj = get_json_log_scan_results_message(mctl, &i);
}

#if HAVE_FW_UPGRADE
JSON *get_json_upgrade_message(struct message_control *mctl, int *ret)
{

	JSON *obj = add_json_message_header(NULL);

	json_add_firmware_info(obj);
	return obj;
}
#endif

JSON *get_json_oauth_message(struct message_control *mctl, int *ret)
{
	char tmp[strlen(config.oauth.client_id) + strlen(config.oauth.device_id) + 2];
	JSON *obj = JSON_NEW_OBJ();

	sprintf(tmp, "%s|%s", config.oauth.client_id, config.oauth.device_id);
	JSON_ADD_STRING_FIELD(obj, KEY_USERNAME, tmp);
	JSON_ADD_STRING_FIELD(obj, KEY_PASSWORD, config.oauth.secret);
	JSON_ADD_STRING_FIELD(obj, KEY_GRANT_TYPE, "password");
	JSON_ADD_STRING_FIELD(obj, KEY_SCOPE, "device");
	return obj;
}

static struct qh_file_list g_config_files[] = {
	{PROC_PID"status", "/tmp/qh_status.tmp"},
	{PROC_PID"cmdline", "/tmp/qh_cmdline.tmp"},
	{QH_CONFIG, NULL},
	{NULL, NULL}
};

struct qh_file_list *get_filelist_config(void)
{
	return g_config_files;
}

static struct qh_file_list g_grabber_files[] = {
	{GINFO_FILE, GINFO_FILE},
	{GRABBER_FILE, GRABBER_FILE},
	{NULL, NULL}
};

struct qh_file_list *get_filelist_grabber(void)
{
	return g_grabber_files;
}
