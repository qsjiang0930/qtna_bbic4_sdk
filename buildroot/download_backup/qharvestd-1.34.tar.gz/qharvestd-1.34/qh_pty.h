#ifndef __QH_PTY_H
#define __QH_PTY_H

#include <sys/types.h>

#ifndef HAVE_PTY
#define HAVE_PTY 0
#endif

typedef struct pty_t {
	pid_t pid;
	int fd;
} pty_t;

static inline void pty_clear(pty_t *pty)
{
	pty->pid = 0;
	pty->fd = 0;
}

static inline int pty_is_open(pty_t *pty)
{
	if (pty->pid || pty->fd > 0)
		return 1;
	return 0;
}

typedef enum {
	PTY_DATA = 0,
	PTY_OPEN,
	PTY_CLOSE,
	PTY_RESIZE,
} pty_cmd_t;

typedef enum {
	PTYE_OK = 0,
	PTYE_MSG,
	PTYE_UNEXP,
	PTYE_OPEN,
	PTYE_RESIZE,
	PTYE_IO,
	PTYE_NOTSUP,
} pty_error_t;

#if HAVE_PTY
void pty_close(void);
#else
#define pty_close()
#endif

int pty_process_ws(char *buf, int len);

#endif
