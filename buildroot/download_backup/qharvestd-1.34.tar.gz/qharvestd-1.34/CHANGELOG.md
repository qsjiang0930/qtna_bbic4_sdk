**QHARVESTD CHANGELOG**
=======================

1.34
----

#### Features:
* **poll: add "up" key to report interface as either up or down.**
* **qcsapi: wl: mtk: report even "down" interfaces.**
* **qcsapi: add initial 802.11ax support.**
* wl: mtk: be compatible with modern ifconfig output.
* poll: report agent runtime to detect agent restarts.
* test: utils: add infrastructure to test utility functions.
* test: utils: add tests for execl_output_grep_awk().
* upgrade: be verbose on firmware upgrade failure.
* websockets: deflate: do not even try to compress very small messages.

#### Fixes:
* websockets: deflate: suppress error if compressed message is bigger than original one.
* wl: suppress expected wl errors during VAPs discovery.


1.33.1
------

#### Features:
* curl: websocket: support case-insensitive HTTP headers.

#### Fixes:
* **event: fix busy loop in async helpers.**
* config: always parse [debug] section.


1.33
----

#### Features:
* **grabber: rework gather_info and config reports, add QTN config grabber support.**
* **qcsapi: add initial WDS and repeater support for QTN.**
* **qcsapi: add support for a call to get reboot_cause from EP.**
* **qtn: give priority to QTN board for reboot_cause, carrier_id and region.**
* **jsonrpc: make RPC commands execution non-blocking.**
* **websockets: deflate: add no-context-takeover compression.**
* websockets: add support for different ws_close codes.
* websockets: honor reconnect timeout provided by WS server.
* scheduler: event: increase responsiveness by eliminating sleeps.
* Makefile: pktlogger: add -rpath to libpkl as already done for libqcsapi.
* qtn: use dedicated fields to report FW and platfrom for QTN board.
* help: print the main information about compiled-in functionality.
* help: print commit hash.

#### Fixes:
* websockets: close connection gracefully, log ws_close messages.
* websockets: discard pending bidicmds on connection close.
* websockets: honor reconnect timeout on connection close if there were pending bidicmds.
* pktlogger: fix config_sync exponential backoff.
* coverity: fix 'unnecessary_header' warning.
* generic: fix ifconfig support for Ubuntu 18.04.


1.32.2
------

#### Features:
* **websockets: ping server and close connection on failure.**
* config: websockets: allow to redefine WSS URL returned by the cloud.
* scan: qcsapi: config: make cca_idle threshold configurable.

#### Fixes:
* **qcsapi: bbic5: use 'wifi0' instead of 'wifi0_0' to get device MAC.**
* **qcsapi: bbic5: try to find other interfaces if 'wifi0_0' doesn't exist.**
* **signal: ignore SIGPIPE.**
* websockets: valgrind: fix invalid read.
* websockets: be compatible with Autobahn WSS.
* help: make qharvestd no longer complain about invalid -h option.


1.32.1
------

#### Features:
* websockets: adjust keepalive idle interval to speed-up reconnect.
* websockets: report qharvestd version in HTTP header.
* websockets: be verbose at connection and disconnection.
* pktlogger: be verbose at discover stage.
* pty: make path to 'login' executable configurable.

#### Fixes:
* **jsonrpc: fix memory leak.**
* utils: fix potential memory leak in execv_get_output_limit_ts().
* utils: clang: get rid of 'potential memory leak' false positive.
* pty: fix handling of execlp(PATH_LOGIN) error after successful fork.


1.32
----

#### Features:
* **jsonrpc: add synchronous RPC support.**
* **version: split firmware version into multiple fields.**
* config: delete no longer used "firmware_ver" debug parameter.
* hal: increase max "platform_id" field length to 32 characters.
* utils: add a function to get return code, stdout, stderr simultaneously.
* OpenWRT: enable PTY support.


1.31
----

#### Features:
* **curl: use non-blocking 'multi' API.**
* **pty: add pseudoterminal support.**
* **No longer use shell and 'tr', 'grep', 'cut' utilities.**
* Allow to provide a full path at compile time to any used program.
* SCS: retrieve 'all' report for all QTN radios.
* SCS: remove support for 'current' and 'autochan' reports.
* QTM: remove QTM/VSP support.
* bidicmd: remove 'cca_threshold' command support.

#### Fixes:
* Makefile: properly pass custom-defined strings in CFLAGS to submake.


1.30.4
------

#### Features:
* **wl: improve compatibility with old wl 5.x.**

#### Fixes:
* **websockets: fix messages getting stuck in CURL buffer (SSL-only, burst-only).**
* websockets: make debugging output more verbose.


1.30.3
------

#### Features:
* **Mainline Mediatek HAL backend (2.4G only).**
* websockets: add randomization to minimum reconnect timeout.
* utils: add \_\_attribute\_\_ 'format' to printf-like functions.
* config: upgrade: add config option to enable/disable upgrade support.
* script: add 'get platform' command support.
* Add -v option to enable verbose output to console.

#### Fixes:
* **qcsapi: flush scan table before scan if possible.**
* qcsapi: bidicmd: add interface parameter support for QTN-only commands.
* qcsapi: bidicmd: fix 'wireless_conf' command for BBIC5.
* qcsapi: bidicmd: disable 'cca_threshold' command for remote QCSAPI case.
* qcsapi: do not report beacon txpower if it is <= 0.
* generic: no longer prefilter interface names with ^w.
* generic: get rid of nl80211-specific code.
* nl80211: replace calls to 'ls' with C stat().
* nl80211: use 'ap-force' flag for iw scan.
* nl80211: fix compilation with LEDE 17.01 (musl libc + libnl-tiny).
* OpenWRT: fix dependencies in recipe.
* OpenWRT: fix customization script for multiple radios case.
* script: mark fw info as available on 'get firmware' success.
* hal: validate regulatory region name.
* json: add missing header (fix compilation with cJSON).
* curl: print websockets request and response if verbose option is set.
* config: report error if line can't be parsed.
* websockets: don't use reconnect timeout for the very first attempt.
* websockets: respect WS_RECONNECT_MIN_INTERVAL not on every 2nd attempt, but always.
* websockets: always stop bidicmd rescheduling if bidicmd gets disabled.
* Makefile: remove unneeded -fgnu89-inline flag.
* Fix invalid format specifiers and parameters of printf-like functions.


1.30.2
------

#### Features:
* **upgrade: add customization script support.**
* upgrade: let platform implementation to decide whether to call reboot.
* OpenWRT: implement and enable upgrade support.
* curl: add options to bind traffic and DNS requests to particular interface.
* curl: add an option to use custom list of DNS servers.
* curl: add an option to skip server's certificate hostname verification.
* qcsapi: use QCSAPI call if available to get platform_id.
* Add compile-time options to enable/disable the following functionality:
  - Firmware upgrade.
  - DNS config (resolv.conf) rereading.
  - 'reboot' bidirectional command.
  - SONiQ topology retrieval.
  - VSP/QTM support.

#### Fixes:
* **qcsapi: fix txpower get/set using new BBIC5 txpower API (new API disables the old one).**
* **qcsapi: fix 'watchdog reset' reboot cause detection.**
* **qcsapi: try 'pci' and 'raw' remote protocols not first but last (QCSAPI bug workaround).**
* **qcsapi: add compile-time option to disable scan in RBS QHop mode (QHop bug workaround).**
* qcsapi: remove unused gather_info/config functionality for remote QCSAPI case.
* qcsapi: remove unused upgrade functionality for remote QCSAPI case.
* qcsapi: fix qcsapi_only_on_AP errors for some QCSAPI calls.
* qcsapi: round float dBm values instead of truncation.
* qcsapi: do not report chip temperature if it is <= 0.
* qcsapi: do not report dBm values in phy_stats if they are unset (= 0).
* json: report RSSI/EVM info for up to 8 antennas.
* **utils: cmd_run: fix reported exit status (fixes customization script support).**
* utils: cmd_run: tune up command execution time monitoring.
* pktlogger: do not send "stop streaming" requests for unsupported stats.
* coverity: fix unchecked return in global MAC initialization.
* coverity: fix unchecked return for reboot commands.
* coverity: suppress 'suspicious_sizeof' false positive for BBIC3 builds.
* Makefile: support version customization with VERSION_SFX variable.
* Makefile: apply LDFLAGS_EXTRA at the very end of link command.
* Fix compilation errors with Clang and musl libc.


1.30.1
------

#### Features:
* **QWE: report phy rate and number of spatial streams.**
* **Makefile: support pktlogger for "out of SDK tree" compilation.**
* Makefile: add an option to link with libpkl statically.
* config: add primary_board option and PRIMARY_BOARD macro.
* curl: add verbose=2 option for more detailed debugging output.

#### Fixes:
* **pktlogger: fix stats reporting (all stats for wifi1_0, wifi2_0
  and some stats for wifi0 / wifi0_0 radios were affected).**
* **websockets: fix continuous reconnect to a buggy server.**
* **SCS: send reports if available, not just when SCS is explicitly enabled.**
* Makefile: always set up SDK-related paths if SDK_DIR is provided
  (not just for compilation within SDK tree).


1.30
----

#### Features:
* **Implement QWE HAL backend (2.4G only).**
* **hal: add support for customization script (bidi + fw version),
   implement sample script for OpenWRT.**
* **Support PCIe and RAW socket protocols, implement protocol autodetection.**
* **Add gateway MAC and SONiQ topology info to poll.**
* **Use HTTP range if firmware download timed out.**
* Notify about first successful initialization of the agent by MAUI cloud.
* pktlogger: enable debugging output if debug level >= 4.
* wl: by default use cur_etheraddr as board MAC ID
* Makefile: optimize executable size by deleting unused symbols.
* Makefile: append commit hash to development version.
* config: do not treat empty string as a valid value => keep to use defaults in this case.
* config: allow only ASCII printable characters.
* json: exit on allocation failures, remove occasional allocation checks.
* For remote QCSAPI always link with -lqscapi_client.
* Report all CCA stats defined by HAL, remove nl80211 CCA workaround.
* Refactor file download to use the same CURL options as the main CURL function.
* Terminate qharvestd on remote connection failure.
* Unify, add and improve generic helper functions in utils.

#### Fixes:
* **Fix errors reported by Coverity, suppress false positives.**
* **Fix normalization for max_rate stats (achievable phy rate).**
* **qcsapi: fix capabilities report for dual-band chips.**
* **Fix initial scan.**
* Fix Makefiles to use $(AR) instead of ar.
* Remove rx_unknown and tx_timeout from HAL as they are QTN-specific
  and not properly initialized by QCSAPI.
* nl80211: fix libnl3 support, use it by default.
* nl80211: fix scan for rare cases when only beacon freq is available.
* nl80211: report phy_stats even if noise level is not available.
* bidicmd: fix buffer overflow if argument is too long.
* Fix validation check of str2mac helper function.


1.29
----

#### Features:
* **Define Wi-Fi HAL layer to support 3-rd party NPU designs.**
  - **Implement QTN HAL backend.**
  - **Implement nl80211 HAL backend, and generic desktop support.**
  - **Implement WL HAL backend (tested with wl 6.30, 6.37 and 7.14 on AsusWRT).**
* **Add pktlogger support.**
* **Add initial support for dual-band chips (RFIC6).**
* **Report current txpower in phy stats (ss=1 bf=0 bw=20 in QTN case).**
* **Introduce -t (pre-init timeout) and -T (first poll delay) flags.**
* **Reread resolv.conf on CURL failure if it was modified.**
* No longer get oauth parameters from qh_get_oauth script (use qharvestd.conf instead).
* Add new event framework and reimplement websockets with it.
* Isolate all QCSAPI-related code in qcsapi subdir.
* Add support for cumulative CCA stats.
* Add example integration files for OpenWRT.
* Report traffic stats for STA if available.
* Add support for modern json-c headers location, retain compatibility with QTN SDK.
* 'make install' now compiles everything only in QTN SDK case. Use 'make' for other cases.
* Makefile: support static linkage with OpenSSL.
* Makefile: support LDFLAGS_EXTRA variable to link with custom libraries if necessary.
* Report device mode as AP if at least one interface is in AP mode.
* Use /etc/qharvestd.conf as default config file location for non QTN SDK cases.
* Add ability to redefine separator of rotated log files suffix.
* Get rid of vsp_config section in qharvestd.conf.
* Add BUILD_BUG_ON macro and ensure that HAL buffer size is enough
  to get certain items of various stats (assoc, scan entries).
* Use getopt to parse command line arguments.
* Make more attempts over longer period to connect to remote QCSAPI server.

#### Fixes:
* **QTN: fix set txpower logic**
  - **use new power APIs where available.**
  - **require values in dBm to be sent by MAUI cloud (instead of offset).**
  - preserve compatibility with BBIC3.
  - Add partial support for region 'none'.
* Do not include VHT capabilities in N mode.
* Fix reported reboot-cause for QTN (apply mask).
* QTN: do not floor, but round bbtemp and rftemp.
* Do not treat POLLHUP as error in output-reading util functions.
* Fix one-time memory leak during interfaces initialization on startup.
* Fix buffer size passed to QTM calls. It fixes remote QCSAPI (RPC) case.
* Ignore errors of qtm_get_config QCSAPI call.
* Fix getting supported bandwidth for BBIC5.
* Websockets: make HTTP parser not to overwrite the first bytes of the following message.
* Websockets: mask all outgoing frames.
* Fix misaligned access error (caused by accessing 16 bit fields with a pointer to integer).
* Check fscanf return value in reboot cause.


1.28
----

#### Features:
* **Add BBIC5 support:**
  - Change default interface name for BBIC5.
  - Properly handle multiple radios.
* No longer require SDK for remote QCSAPI build.


1.27
----

#### Features:
* **Add websockets support for bidirectional commands => make them real-time.**
* **Use TCP keepalive for websockets connection. Requires curl 7.25.0+.**
* **Add "force_poll" bidirectional command.**
* Do not wait until oauth token gets expired, but renew it in advance.
* Refactor log reading logic to be able to reuse it for other files.
* New "force_poll" bidirectional command.
* get_output() logic enhanced to support size and execution time limits.
* Some BBIC5-related changes (not functional yet).
* For security reasons use upgrade feature only for devices owned by Quantenna (carrier_id == 0).

#### Fixes:
* Report reception of "reboot" bidirectional command to the backend.
* Fix base64 encoding:
  - Do not assume null-terminated input.
  - Do not require too much space in output buffer.
  - Treat data as unsigned to fix output with x86 compiler.
* Use conditional compilation to disable functionality not supported by remote QCSAPI.


1.26
----

#### Features:
* **Add oAuth support, use it by default. Sleep forever if misconfigured.**
* **Force HTTPS even if URL in qharvestd.conf says to use HTTP.**
* **Reuse open connection for subsequent requests. Create new connection on error and redirect.**
* **Create unified JSON API and add support for cJSON.**
* **Increase initial poll interval to 8 hours to reduce poll rate from unregistered devices.**
* Log messages refactoring:
  - Support only one syslog file (MAUI cloud supports only one file anyway).
  - Use exponential backoff to handle errors instead of blocking sleeps.
  - Assume atomic log messages (PIPE_BUF == 4096 on Linux).
  - **Use inode instead of ctime. Rely on fact that on tmpfs inode numbers are incremented.**
* poll: use -ERESTART for faster redirect.

#### Fixes:
* **Use exponential backoff in bundled stats if scan is in progress
  to fix false channel changes problem.**
* **Do not force SSLv3 anymore, so TLS could also be used.
  Fixes HTTPS connection to maui.quantenna.com.**
* Fix rare missed lines bug in log messages.
* Fix possible free of garbage pointer in bundled stats.
* Fix various issues reported by Valgrind and CLang-Analyzer.
* Send "capabilities" message even for "none" region.


1.25
----

#### Features:
* **Introduce MBSSID support.**
  - and therefore bump JSON protocol version.
* **Add "capabilities" message.**
* **Add support for json-c 0.11+**
  - No longer use deprecated json_object_object_get() function.
* **Add infrastructure to test QCSAPI capabilities**
  - Add test to differentiate BBIC3 and BBIC4 builds.
  - No more necessity to use -DSTRM_INFO_ASSOC_ID for BBIC3 build.
* **Report bandwidth of neighboring APs if available.**
* **Reschedule bidicmd on success to quickly process series of commands.**
* Use returned throttling interval instead of exponential backoff in a case of HTTP 429.
* Do not send rx/tx bytes in poll.
* Improve QTN support:
  - support new safe QCSAPI calls.
  - do not report deprecated parameters supported only by VSP.
  - add VAP priority, MAC and TID QTM-only parameters.

#### Fixes:
* **Increase poll interval from 120 to 3600 seconds to reduce request frequency from
  unregistered devices.**
* Bundled stats: retry with exponential backoff in a case of association or disassociation
  during data collection.
* Send autochan report even if SCS is disabled.


1.24
----

#### Features:
* **Do not perform initial scan, but try to collect cached scan results if any.**
* **Use cca_idle threshold instead of VSP to determine whether it is safe to do a scan.**
* **Add support for a new reliable bgscan (but on STAs it could only be forced for now).**
* **Do not perform old bgscan on associated STAs, even if it was forced (TXBF workaround).**
* **Minimize time shifts in the scheduler:**
  - Reschedule scan message for scan duration to make its handler non-blocking.
  - Adjust scheduler sleep time to compensate time spent in the last message handler.
* **Add new stats to poll message:**
  - **channel**
  - **bandwidth**
  - **protocol**
  - **region**
* **Add new assoc stats:**
  - **rx_mcs, tx_mcs**
  - **rx_streams, tx_streams**
  - ht, vht
  - vendor
* Do not send scan message if scan was not performed and there are no cached results to send.
* Do not fail early in a case of HTTP error, but process HTTP response payload (JSON) and log it.
* Add RF/BB temperature info to PHY stats.
* Use md5sum applet instead of internal md5 implementation.
* Get rid of default 'Expect: 100-continue' HTTP header in request.

#### Fixes:
* Fix scan message format when there are no scan entries.
* Use int64 int JSON for all integers we send to prevent overflow of uint32 counters.
* Get platform ID using qdrvcmd if platform_id file is absent.
* Fix base64 encoding to correctly work not only with SSID, but any binary data.


1.23
----

#### Features:
* **New makefile properly splitted from SDK buildroot recipe:**
  - Out of SDK tree build possibility (remote qcsapi case).
  - Supports binaries-only distribution.
  - Have a target that prints files to be installed.
* **Dynamic polling.**
* **Exponential backoff.**
* **Unified codebase for BBIC3 and BBIC4.**
  - Use CFLAGS="-DSTRM_INFO_ASSOC_ID" for BBIC3.
* **Merge 'phy stats', 'assoc stats' and 'SCS current' messages into 'bundled stats' message.**
* **Add new bidirectional commands:**
  - **bandwidth**
  - Force scan
  - SCS report-only
  - OCAC
  - CCA threshold
  - MAC filtering
* **Do not check carried ID for upgrade.**
* Send diff stats for phy rate and packet counters.
* Send wifi mode in bundled stats.
* Add –F option for “fast start” – no initial timeouts before scan and poll.
* Add –V flag to print version (also useful for firmware upgrade script).
* Add conditional QTM support (VSP replacement).
* Add remote protocol config option (TCP by default).
* Add log tags at the beginning and at the end of messages processing.
* Heavy refactoring and size optimizations.

#### Fixes:
* **Fix log messages bug (caused HTTP error 400 and qharvestd hangs/restarts).**
* **Fix a way poll profile is applied:**
  - **Timeouts of messages aren't reset on every poll, so messages could get bigger interval
    than poll interval.**
  - Delay is applied only if a message has just been enabled or if it was enabled from
    the very start of qharvestd before the first poll.
  - Both delay and interval respected by poll message (before delay was used as both delay
    and interval).
* Fix REMOTE_QCSAPI build and operation.
* Fix curl_easy_perform error report (no more error = Error reports).
* Fix firmware version determining in qharvestd by fixing reading of proc files.


1.22
----
#### Features:
* **Add bidirectional commands support.**

#### Fixes:
* Add 30 seconds delay before initial scan.
