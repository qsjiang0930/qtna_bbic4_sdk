/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QH_UTILS_H
#define __QH_UTILS_H

#ifndef BUILD_BUG_ON
#define BUILD_BUG_ON(condition) ((void)sizeof(char[1 - 2*!!(condition)]))
#endif

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))
#endif

#define MATCH(field, value) (strcmp(field, value) == 0)

#if defined(__GNUC__) || defined(__clang__)
#define __attr_fmt(stridx, argidx) __attribute__ ((format (printf, stridx, argidx)))
#else
#define __attr_fmt(stridx, argidx)
#endif

#ifndef HAVE_RESOLVCONF_REREAD
#define HAVE_RESOLVCONF_REREAD 1
#endif

#include <syslog.h>
#include <errno.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include "qh_printf.h"

typedef unsigned char macaddr_t[6];

int get_macaddr(char *ifname, macaddr_t mac);
char *sanitize_ifname(char *ifname);
int get_ifup(char *ifname);
int get_uptime(void);

char *str16(const char *fmt, ...) __attr_fmt(1, 2);
char *str32(const char *fmt, ...) __attr_fmt(1, 2);
char *str64(const char *fmt, ...) __attr_fmt(1, 2);

#define MS_U(ms) (ms * 1000)
#define MS_N(ms) (ms * 1000000)
#define SEC_U(s) (s  * 1000000)
#define SEC_N(s) (s  * 1000000000)

/* default time limit for *_limit* commands, if time == NULL */
#define DEFAULT_LIMIT_SEC 10

enum {
	F_DEV_NULL = 1 << 0,
	F_DBL_FORK = 1 << 1,
	F_MOD_FILE = 1 << 2,
	F_AT_START = 1 << 3,
	F_POS_GREP = 1 << 4,
	F_IGN_CASE = 1 << 5,
	F_GREP_ALL = 1 << 6,
	F_FD_WRITE = 1 << 7,
	F_GREP_INV = 1 << 8,
};
#define DEF_ARGV(...) const char *const _argv[] = { __VA_ARGS__, NULL }

#define execl_base(fdout, fderr, flags, pflags, ...) \
	({ DEF_ARGV(__VA_ARGS__); execv_base(fdout, fderr, flags, pflags, _argv); })
pid_t execv_base(int *fdout, int *fderr, int flags, int pipeflags, const char *const argv[]);

#define execv_run_bg(flags, argv) execv_base(NULL, NULL, (flags | F_DBL_FORK), 0, argv)
#define execl_run_bg(flags, ...) ({ DEF_ARGV(__VA_ARGS__); execv_run_bg(flags, _argv); })

#define execv_run(devnull, ...) execv_run_limit(devnull, DEFAULT_LIMIT_SEC, __VA_ARGS__)
#define execl_run(devnull, ...) \
	({ DEF_ARGV(__VA_ARGS__); execv_run(devnull, _argv); })
#define execl_run_limit(devnull, seconds, ...) \
	({ DEF_ARGV(__VA_ARGS__); execv_run_limit(devnull, seconds, _argv); })
int execv_run_limit(int devnull, int seconds, const char *const argv[]);
#define execl_run_limit_ts(devnull, time, ...) \
	({ DEF_ARGV(__VA_ARGS__); execv_run_limit_ts(devnull, time, _argv); })
int execv_run_limit_ts(int devnull, struct timespec *time, const char *const argv[]);

#define execl_run_ext_limit(flags, out, outlen, err, errlen, seconds, ...) \
	({ DEF_ARGV(__VA_ARGS__); \
	execv_run_ext_limit(flags, out, outlen, err, errlen, seconds, _argv); })
int execv_run_ext_limit(int flags, char **out, int *outlen, char **err, int *errlen,
	int seconds, const char *const argv[]);
#define execl_run_ext_limit_ts(flags, out, outlen, err, errlen, time, ...) \
	({ DEF_ARGV(__VA_ARGS__); \
	execv_run_ext_limit_ts(flags, out, outlen, err, errlen, time, _argv); })
int execv_run_ext_limit_ts(int flags, char **out, int *outlen, char **err, int *errlen,
	struct timespec *time, const char *const argv[]);

#define execl_popen(devnull, ...) \
	({ DEF_ARGV(__VA_ARGS__); execv_popen(devnull, _argv); })
FILE *execv_popen(int devnull, const char *const argv[]);
#define execl_pclose(f) execv_pclose(f)
int execv_pclose(FILE *f);

#define execv_get_output(flags, argv) execv_get_output_limit(flags, NULL, DEFAULT_LIMIT_SEC, argv)
#define execl_get_output(flags, ...) ({ DEF_ARGV(__VA_ARGS__); execv_get_output(flags, _argv); })
#define execl_get_output_limit(flags, len, seconds, ...) \
	({ DEF_ARGV(__VA_ARGS__); execv_get_output_limit(flags, len, seconds, _argv); })
char *execv_get_output_limit(int flags, int *len, int seconds, const char *const argv[]);
#define execl_get_output_limit_ts(flags, len, time, ...) \
	({ DEF_ARGV(__VA_ARGS__); execv_get_output_limit_ts(flags, len, time, _argv); })
char *execv_get_output_limit_ts(int flags, int *len, struct timespec *time, const char *const argv[]);

#define execv_buf_output(buf, sz, flags, argv) \
	execv_buf_output_limit(buf, sz, flags, DEFAULT_LIMIT_SEC, argv)
#define execl_buf_output(buf, sz, flags, ...) \
	({ DEF_ARGV(__VA_ARGS__); execv_buf_output(buf, sz, flags, _argv); })
#define execl_buf_output_limit(buf, sz, flags, seconds, ...) \
	({ DEF_ARGV(__VA_ARGS__); execv_buf_output_limit(buf, sz, flags, seconds, _argv); })
char *execv_buf_output_limit(char *buf, int bufsz,
	int flags, int seconds, const char *const argv[]);
#define execl_buf_output_limit_ts(buf, sz, flags, time, ...) \
	({ DEF_ARGV(__VA_ARGS__); execv_buf_output_limit_ts(buf, sz, flags, time, _argv); })
char *execv_buf_output_limit_ts(char *buf, int bufsz,
	int flags, struct timespec *time, const char *const argv[]);

#define GREP(str) str
#define AWK(field, fsep) field, fsep

#define execl_output_grep_awk(buf, sz, flags, grep, awk,  ...) \
	({ DEF_ARGV(__VA_ARGS__); execv_output_grep_awk(buf, sz, flags, grep, awk, _argv); })
char *execv_output_grep_awk(char *outbuf, int outsz, int flags,
	char *grep, unsigned int field, char *fsep, const char *const argv[]);

#define execv_get_int(...) execv_get_int_base(10, __VA_ARGS__)
#define execl_get_int(flags, grep, awk,  ...) \
	({ DEF_ARGV(__VA_ARGS__); execv_get_int(flags, grep, awk, _argv); })
#define execl_get_int_base(base, flags, grep, awk,  ...) \
	({ DEF_ARGV(__VA_ARGS__); execv_get_int_base(base, flags, grep, awk, _argv); })
int execv_get_int_base(int base, int flags,
	char *grep, unsigned int field, char *fsep, const char *const argv[]);

#define execl_write_fd(flags, fdout, fderr, ...) \
	({ DEF_ARGV(__VA_ARGS__); execv_write_fd(flags, fdout, fderr, _argv); })
int execv_write_fd(int flags, int fdout, int fderr, const char *const argv[]);

int kill_and_wait(pid_t pid, int signal, int usec);

char *encode64(char *buf, size_t size, char *data, size_t len);

void *xmalloc(size_t size);
void *xcalloc(size_t nmemb, size_t size);
char *xstrdup(const char *str);

char *check_string(char *str, int (*func)(int));
char *strnstr(const char *haystack, const char *needle, size_t len);
char *strncasestr(const char *haystack, const char *needle, size_t len);

void timespec_add(struct timespec *res, struct timespec *arg1, struct timespec *arg2);
void timespec_sub(struct timespec *res, struct timespec *arg1, struct timespec *arg2);
int timespec_cmp(struct timespec *arg1, struct timespec *arg2);

static inline void timespec_set(struct timespec *dst, struct timespec *src)
{
	if (!dst || !src)
		return;
	dst->tv_sec = src->tv_sec;
	dst->tv_nsec = src->tv_nsec;
}

struct obj_list {
	void *obj;
	struct obj_list *next;
};

void obj_enqueue(void *h, void *obj);
void *obj_dequeue(void *h);

#define SPACE " \t\n"
char *gettok(char *str, char *substr, unsigned int n, char *delim);

void qh_res_init(void);

#endif
