/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QH_EVENT_H
#define __QH_EVENT_H

#include <poll.h>
#include <time.h>
#include <errno.h>

#define EVENT_CURL_NUM 8

enum {
	EVENT_WS = 0,
	EVENT_CURL,
	EVENT_CURL_LAST = EVENT_CURL + EVENT_CURL_NUM - 1,
	EVENT_PKL,
	EVENT_PTY,
	EVENT_GRABBER,
	EVENT_JSONRPC,
	EVENT_MAX,
};

enum {
	EVENTF_SET = 1 << 0,
	EVENTF_ARG_AUTOFREE = 1 << 1,
};

/* Callback return value convention:
 *         0 - Event/message processed.
 *    -EINTR - need to interrupt event polling loop, return to scheduler.
 *  -ENODATA - event poll request (no more data to process).
 * -ENOTCONN - disconnected, stop listen to this event.
 *    -ECOMM - CURL-only. Asks for immediate return to the main CURL 'multi' loop.
 *
 * NOTE:
 * After introduction of CURL multi API, -EINTR no longer means that
 * we immediately stop listening for events and perform rescheduling.
 * Now it means that we will run scheduler ASAP, but proceed to process
 * events if and while HTTP request is in progress. Also -EINTR no longer
 * implies that the scheduler will be started from scratch - we can just
 * return to already running scheduler in the middle of its operation.
 */
typedef int (*qh_cb)(struct pollfd *pfd, void *arg);

void qh_event_init();
struct pollfd *qh_event_get_pollfd(int idx);

void qh_event_set(int idx, int fd, int events);
#define qh_event_set_cb(idx, cb, arg) qh_event_set_cb_ext(idx, cb, arg, 0)
void qh_event_set_cb_ext(int idx, qh_cb cb, void *arg, int autofree);
void qh_event_cleanup(int idx);
int qh_event_is_set(int idx);
int qh_event_listen(struct timespec *time);
/* This function should be used for short time sleeps
 * in process (scheduler) context if CURL is not active. */
void qh_event_listen_sleep(struct timespec *time);

typedef int (*async_f)(void *data);
typedef int (*async_cb)(int status, void *data);
int run_async(int event, async_f func, async_cb cb, void *data);

#endif
