/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __JH_JSON_MESSAGE_H
#define __JH_JSON_MESSAGE_H

#define INITIAL_ENABLE -1 //to set timeout after first poll to delay, not to interval

extern int initial_poll_timeout;
extern struct message_control g_message_control[];
void init_message_controls(void);
int qh_process_message(struct message_control *mctl);
int qh_process_messages(int cnt);
int qh_scheduler(void);
#endif
