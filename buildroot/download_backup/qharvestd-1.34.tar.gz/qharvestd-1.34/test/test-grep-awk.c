/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include <string.h>
#include "test.h"
#include "qh_utils.h"

#define CMP_OUTPUT(pfx, got, exp) ({ \
	int ret = 0; \
	if (got == NULL || strcmp(exp, got)) { \
		DBG_TEST("%s: strings do not match", pfx); \
		DBG_TEST("got: '%s'", got); \
		DBG_TEST("expected: '%s'", exp); \
		ret = -1; \
	} \
	ret; \
})

int test_grep(void)
{
	char *exp = "wlan0";
	char **ifcfg;

	for (ifcfg = ifconfig_list; *ifcfg; ifcfg++) {
		char *out = execl_output_grep_awk(NULL, 0, 0,
			GREP(exp), AWK(1, SPACE":"), *ifcfg);
		if (CMP_OUTPUT(*ifcfg, out, exp))
			return -1;
	}
	return 0;
}

int test_grep_inv(void)
{
	char *exp = "eth0\nlo\nwlan0";
	char **ifcfg;

	for (ifcfg = ifconfig_list; *ifcfg; ifcfg++) {
		char *out = execl_output_grep_awk(NULL, 0, F_AT_START | F_GREP_INV | F_GREP_ALL,
			GREP(" "), AWK(1, SPACE":"), *ifcfg);
		if (CMP_OUTPUT(*ifcfg, out, exp))
			return -1;
	}
	return 0;
}

int test_grep_pos(void)
{
	char *exp = "Ethernet\nLocal\nEthernet";
	char *out = execl_output_grep_awk(NULL, 0, F_GREP_ALL | F_POS_GREP,
		GREP("encap:"), AWK(2, SPACE":"), IFCONFIG_OLD);
	if (CMP_OUTPUT(IFCONFIG_OLD, out, exp))
		return -1;
	return 0;
}

int test_grep_case(void)
{
	char *exp = "1500";
	char **ifcfg;

	for (ifcfg = ifconfig_list; *ifcfg; ifcfg++) {
		char *out = execl_output_grep_awk(NULL, 0, F_IGN_CASE | F_POS_GREP,
			GREP("mtu"), AWK(2, SPACE":"), *ifcfg);
		if (CMP_OUTPUT(*ifcfg, out, exp))
			return -1;
	}
	return 0;
}

int main()
{
	if (test_grep())
		return 1;
	if (test_grep_inv())
		return 1;
	if (test_grep_pos())
		return 1;
	if (test_grep_case())
		return 1;
}
