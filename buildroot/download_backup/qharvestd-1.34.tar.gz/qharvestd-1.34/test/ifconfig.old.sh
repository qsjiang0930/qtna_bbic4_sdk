#!/bin/sh

cat << EOF
eth0      Link encap:Ethernet  HWaddr 06:38:87:c1:b8:54
          inet addr:10.1.1.1  Bcast:10.1.1.255  Mask:255.255.255.0
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:16592727 errors:0 dropped:0 overruns:0 frame:0
          TX packets:14980287 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:0
          RX bytes:14540997514 (14.5 GB)  TX bytes:3021483584 (3.0 GB)

lo        Link encap:Local Loopback
          inet addr:127.0.0.1  Mask:255.0.0.0
          UP LOOPBACK RUNNING  MTU:65536  Metric:1
          RX packets:13855603 errors:0 dropped:0 overruns:0 frame:0
          TX packets:13855603 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:0
          RX bytes:2046585597 (2.0 GB)  TX bytes:2046585597 (2.0 GB)

wlan0     Link encap:Ethernet  HWaddr 40:e2:30:00:b4:dd
          BROADCAST MULTICAST  MTU:1500  Metric:1
          RX packets:0 errors:0 dropped:0 overruns:0 frame:0
          TX packets:0 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:0 (0.0 B)  TX bytes:0 (0.0 B)
EOF
