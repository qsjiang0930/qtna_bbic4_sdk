#!/bin/sh

cat << EOF
eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 192.168.1.2  netmask 255.255.255.0  broadcast 192.168.1.255
        inet6 fe80::af61:d521:cfbc:d3ef  prefixlen 64  scopeid 0x20<link>
        ether 50:7b:9d:e4:38:17  txqueuelen 1000  (Ethernet)
        RX packets 38958  bytes 36099369 (36.0 MB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 33317  bytes 5632758 (5.6 MB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
        device interrupt 16  memory 0xf1300000-f1320000

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0
        inet6 ::1  prefixlen 128  scopeid 0x10<host>
        loop  txqueuelen 1000  (Local Loopback)
        RX packets 3119  bytes 280468 (280.4 KB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 3119  bytes 280468 (280.4 KB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

wlan0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 10.80.12.146  netmask 255.255.255.0  broadcast 10.80.12.255
        inet6 fe80::7acd:4c5d:12c1:cf37  prefixlen 64  scopeid 0x20<link>
        ether 44:85:00:b5:47:a3  txqueuelen 1000  (Ethernet)
        RX packets 97  bytes 8450 (8.4 KB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 100  bytes 12366 (12.3 KB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
EOF
