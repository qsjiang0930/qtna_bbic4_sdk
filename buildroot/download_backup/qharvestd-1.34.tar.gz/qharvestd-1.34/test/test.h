/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QH_TEST_H
#define __QH_TEST_H

#include <stdarg.h>
#include <stdio.h>

#define IFCONFIG_OLD "./ifconfig.old.sh"
#define IFCONFIG_NEW "./ifconfig.new.sh"

char *ifconfig_list[] = {IFCONFIG_OLD, IFCONFIG_NEW, NULL};

#define DBG_TEST(fmt, ...) test_printf(__FILE__, __LINE__, __func__, fmt, ##__VA_ARGS__)

static inline void test_printf(const char *file, const int line, const char *func,
	const char *fmt, ...)
{
	va_list ap;
	char format[256];

	va_start(ap, fmt);
	snprintf(format, 256, "[%16s:%-4d]: %s: %s\n", file, line, func, fmt);
	vprintf(format, ap);
	va_end(ap);
}

#endif
