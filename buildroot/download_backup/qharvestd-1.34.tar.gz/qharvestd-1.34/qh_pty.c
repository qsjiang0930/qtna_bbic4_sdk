#include "qh_curl_ws.h"
#include "qh_event.h"
#include "qh_pty.h"
#include "qh_utils.h"
#include "qharvestd.h"
#include <arpa/inet.h>
#include <errno.h>
#include <pty.h>
#include <stdint.h>
#include <string.h>
#include <signal.h>
#include <termios.h>
#include <unistd.h>

char *pty_error_str[] = {
	"PTYE_OK",
	"PTYE_MSG",
	"PTYE_UNEXP",
	"PTYE_OPEN",
	"PTYE_RESIZE",
	"PTYE_IO",
	"PTYE_NOTSUP",
};

static char *pty_strerror(pty_error_t error)
{
	return pty_error_str[error];
}

static void pty_send_close(pty_error_t error);

#if HAVE_PTY
static int pty_cb(struct pollfd *pfd, void *arg);

pty_t g_pty;

static int pty_fork(pty_t *pty)
{
	int fd;
	pid_t pid;

	if (pty == NULL)
		return -1;

	pid = forkpty(&fd, NULL, NULL, NULL);

	if (pid == 0) {
		errno = 0;
		execlp(PATH_LOGIN, PATH_LOGIN, (char*)NULL);
		printf("Failed to execute '%s': %s\n", PATH_LOGIN, strerror(errno));
		_exit(1);
	} else if (pid > 0) {
		pty->pid = pid;
		pty->fd = fd;
		return 0;
	}
	return -1;
}

static void pty_kill(pty_t *pty)
{
	if (pty == NULL)
		return;
	if (pty->fd > 0)
		close(pty->fd);
	if (pty->pid)
		kill_and_wait(-pty->pid, SIGKILL, 1000000);
}

static int pty_open(void)
{
	if (pty_fork(&g_pty))
		return -1;
	/* If fork() succeeded but execlp() failed, we will
	 * detect it in pty_cb() by receiving POLLHUP. */
	qh_event_set(EVENT_PTY, g_pty.fd, POLLIN);
	qh_event_set_cb(EVENT_PTY, pty_cb, NULL);
	return 0;
}

void pty_close(void)
{
	qh_event_cleanup(EVENT_PTY);
	pty_kill(&g_pty);
	pty_clear(&g_pty);
}

#define PTY_BUFSZ 1024
static int pty_cb(struct pollfd *pfd, void *arg)
{
	char buf[PTY_BUFSZ] = { 0 };
	struct pollfd *ws;
	int error = PTYE_IO;
	int size;

	if (pfd->revents & (POLLERR | POLLHUP | POLLNVAL))
		goto close_pty;

	if (pfd->revents != POLLIN) /* we listen only for POLLIN event */
		return -ENODATA;

	size = read(pfd->fd, buf + 2, PTY_BUFSZ - 2);
	if (size <= 0)
		goto close_pty;

	ws = qh_event_get_pollfd(EVENT_WS);
	if (ws->fd < 0)
		goto close_pty;

	buf[0] = WS_BIN_PTY;
	buf[1] = PTY_DATA;
	if (send_ws_msg(ws->fd, WS_BINARY, buf, size + 2))
		goto close_pty;
	return 0;
close_pty:
	pty_send_close(error);
	pty_close();
	return -1;
}
#endif

static void pty_send_close(pty_error_t error)
{
	struct pollfd *ws = qh_event_get_pollfd(EVENT_WS);
	char buf[3] = { WS_BIN_PTY, PTY_CLOSE, (char)error };

	DBG_INFO("pty: %s (code: %d)", pty_strerror(error), error);
	if (ws == NULL || ws->fd < 0)
		return;
	(void)send_ws_msg(ws->fd, WS_BINARY, buf, 3);
}

int pty_process_ws(char *buf, int len)
{
	int error = 0;

	if (!HAVE_PTY || !config.pty) {
		error = PTYE_NOTSUP;
		goto close_pty;
	}
#if HAVE_PTY
	if (len == 0) {
		error = PTYE_MSG;
		goto close_pty;
	} else if ((buf[0] == PTY_OPEN && pty_is_open(&g_pty)) ||
		   (buf[0] != PTY_OPEN && !pty_is_open(&g_pty))) {
		error = PTYE_UNEXP;
		goto close_pty;
	}

	if (buf[0] == PTY_OPEN) {
		if (pty_open()) {
			error = PTYE_OPEN;
			goto close_pty;
		}
	} else if (buf[0] == PTY_DATA) {
		if (write(g_pty.fd, buf + 1, len - 1) < len - 1) {
			error = PTYE_IO;
			goto close_pty;
		}
	} else if (buf[0] == PTY_RESIZE) {
		struct winsize size = { 0 };

		size.ws_col = (unsigned short)ntohs(*((uint16_t *)(buf + 1)));
		size.ws_row = (unsigned short)ntohs(*((uint16_t *)(buf + 3)));
		if (ioctl(g_pty.fd, TIOCSWINSZ, &size) == -1) {
			error = PTYE_RESIZE;
			goto close_pty;
		}
	} else if (buf[0] == PTY_CLOSE) {
		goto close_pty;
	} else {
		error = PTYE_MSG;
		goto close_pty;
	}
	return 0;
#endif
close_pty:
	pty_send_close(error);
	pty_close();
	return (error) ? -1 : 0;
}
