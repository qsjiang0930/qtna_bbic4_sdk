/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include <ctype.h>
#include <sys/time.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <curl/curl.h>
#include "qharvestd.h"
#include "qh_event.h"
#include "qh_iface.h"
#include "qh_utils.h"
#include "ini.h"
#include "qh_json.h"
#include "qh_json_action.h"
#include "qh_json_basic_type.h"
#include "qh_json_message.h"
#include "qh_curl_post.h"
#include "qh_hal.h"
#include "qh_pty.h"
#include "qcsapi/grabber.h"
#ifdef HAL_QCSAPI
#include "qcsapi/pktlogger.h"
#endif

struct qh_config config = { 0 };
int qh_fast_start = 0;
char hal_buf[HAL_BUF_LEN];
string32 g_firmware = { 0 };
string32 g_platform = { 0 };
int g_start_uptime = 0;

#ifndef PRIMARY_BOARD
#define PRIMARY_BOARD 0
#endif

/* NPU board has to be first => QTN and QWE boards have to be at the end */
struct board *boards[] = {
#ifdef BOARD_GENERIC
	&board_generic,
#endif
#ifdef BOARD_BRCM
	&board_brcm,
#endif
#ifdef HAL_MTK
	&board_mtk,
#endif
#ifdef HAL_QCSAPI
	&board_qtn,
#endif
#ifdef HAL_QWE
	&board_qwe,
#endif
};
const int boards_num = ARRAY_SIZE(boards);

struct hal_ops *hals[] = {
#ifdef HAL_NL80211
	&hal_nl80211_ops,
#endif
#ifdef HAL_WL
	&hal_wl_ops,
#endif
#ifdef HAL_MTK
	&hal_mtk_ops,
#endif
#ifdef HAL_QCSAPI
	&hal_qcsapi_ops,
#endif
#ifdef HAL_QWE
	&hal_qwe_ops,
#endif
};
const int hals_num = ARRAY_SIZE(hals);

static inline void config_set_string(char **field, const char *string)
{
	if (*field)
		free(*field);
	*field = xstrdup(string);
}

static int qh_handler(void *user, const char *section, const char *name, const char *value)
{
	/* do not override default value with empty string */
	if (value[0] == '\0')
		return 1;

	if (MATCH(section, "qharvestd")) {
		if (MATCH(name, "baseurl")) {
			int len;
			config_set_string(&config.base_url, value);
			len = strlen(config.base_url);
			if (len > 0 && config.base_url[len - 1] == '/')
				config.base_url[len - 1] = 0;
		} else if (MATCH(name, "syslog")) {
			config.syslog = atoi(value);
		} else if (MATCH(name, "debug")) {
			if (config.debug == 0) /* do not overwrite cmdline -v */
				config.debug = atoi(value);
		} else if (MATCH(name, "interface")) {
			config_set_string(&config.main_interface_name, value);
		} else if (MATCH(name, "mac_interface")) {
			config_set_string(&config.mac_interface_name, value);
		} else if (MATCH(name, "logfile")) {
			config.logfile = xstrdup(value);
		} else if (MATCH(name, "script")) {
			config.script = xstrdup(value);
		} else if (MATCH(name, "primary_board")) {
			config.primary_board = atoi(value);
		} else if (MATCH(name, "upgrade")) {
			config.upgrade = atoi(value);
		} else if (MATCH(name, "pty")) {
			config.pty = atoi(value);
		}
#ifdef REMOTE_QCSAPI
		else if (MATCH(name, "remote")) {
			config_set_string(&config.remote, value);
		} else if (MATCH(name, "remote_protocol")) {
			config_set_string(&config.remote_proto, value);
		} else if (MATCH(name, "remote_interface") || MATCH(name, "remote_iface")) {
			config_set_string(&config.remote_iface, value);
		}
#endif
	} else if (MATCH(section, "curl")) {
		if (MATCH(name, "ca_file")) {
			config_set_string(&config.curl_config.ca_file, value);
		} else if (MATCH(name, "bind_iface")) {
			config_set_string(&config.curl_config.bind_iface, value);
		} else if (MATCH(name, "dns_iface")) {
			config_set_string(&config.curl_config.dns_iface, value);
		} else if (MATCH(name, "dns_list")) {
			config_set_string(&config.curl_config.dns_list, value);
		} else if (MATCH(name, "ssl_version")) {
			config.curl_config.ssl_version = atoi(value);
		} else if (MATCH(name, "verbose")) {
			config.curl_config.verbose = atoi(value);
		} else if (MATCH(name, "verify_peer")) {
			config.curl_config.verify_peer = atoi(value);
		} else if (MATCH(name, "verify_host")) {
			config.curl_config.verify_host = atoi(value);
		} else if (MATCH(name, "encrypt")) {
			config.curl_config.encrypt = atoi(value);
		} else if (MATCH(name, "easy")) {
			config.curl_config.easy = atoi(value);
		}
	} else if (MATCH(section, "websockets")) {
		if (MATCH(name, "url")) {
			config_set_string(&config.ws.url, value);
		} else if (MATCH(name, "ping")) {
			config.ws.ping = atoi(value);
		} else if (MATCH(name, "compress")) {
			config.ws.compress = (HAVE_ZLIB) ? atoi(value) : 0;
		} else if (MATCH(name, "verbose")) {
			config.ws.verbose = atoi(value);
		}
	} else if (MATCH(section, "oauth")) {
		if (MATCH(name, "enabled")) {
			config.oauth.enabled = atoi(value);
		} else if (MATCH(name, "client_id")) {
			config_set_string(&config.oauth.client_id, value);
		} else if (MATCH(name, "device_id")) {
			config_set_string(&config.oauth.device_id, value);
		} else if (MATCH(name, "secret")) {
			config_set_string(&config.oauth.secret, value);
		} else if (MATCH(name, "token")) {
			config_set_string(&config.oauth.token, value);
		}
	} else if (MATCH(section, "debug")) {
		if (MATCH(name, "console_print")) {
			if (config.debug_config.console_print == 0) /* do not overwrite cmdline -v */
				config.debug_config.console_print = atoi(value);
		} else if (MATCH(name, "http")) {
			config.debug_config.http = atoi(value);
		} else if (MATCH(name, "pktlogger")) {
			config.debug_config.pktlogger = atoi(value);
		} else if (MATCH(name, "scan_threshold")) {
			config.debug_config.scan_threshold = atoi(value);
		} else if (MATCH(name, "curl_debug_file")) {
			config_set_string(&config.debug_config.curl_debug_file, value);
		} else if (MATCH(name, "mac")) {
			config_set_string(&config.debug_config.mac, value);
		} else if (MATCH(name, "mode")) {
			config_set_string(&config.debug_config.mode, value);
		}
	}

	return 1;
}

/* Signal function */
static void signal_handler(int sig)
{
	config.running = 0;
	exit(0);
}

static inline char *alloc_https_url(const char *url)
{
	int len = strlen(url) + 2;
	char *ret = xcalloc(1, len);

	if (config.debug_config.http == 0 && strstr(url, "http:")) {
		snprintf(ret, len, "%s%s", "https:", url + 5);
	} else {
		strcpy(ret, url);
	}
	return ret;
}

#ifndef CONFIG_PTY_DEFAULT
#define CONFIG_PTY_DEFAULT 0
#endif

static int qh_init_config()
{
	int error;

	config.running = 1;
	config.base_url = xstrdup(BASE_URL_DEFAULT);
	config.logfile = LOGFILE;

	BUILD_BUG_ON(PRIMARY_BOARD >= ARRAY_SIZE(boards));
	config.primary_board = PRIMARY_BOARD;

	config.request_timeout = MESSAGE_TIMEOUT_DEFAULT;
	config.upgrade = HAVE_FW_UPGRADE;
	config.pty = CONFIG_PTY_DEFAULT;

	config.curl_config.ssl_version = CURL_SSLVERSION_DEFAULT;
	config.curl_config.verify_host = 1;
	config.curl_config.encrypt = 1;

	config.ws.ping = 45;
	config.ws.compress = HAVE_ZLIB;

	config.oauth.enabled = 1;

	config.debug_config.pktlogger = 1;
	config.debug_config.scan_threshold = -1;

	if (config.conf_file == NULL)
		config.conf_file = xstrdup(CONF_FILE_DEFAULT);
	error = ini_parse(config.conf_file, qh_handler, NULL);
	if (error < 0) {
		printf("Can't load '%s'\n", config.conf_file);
		return -1;
	} else if (error > 0) {
		printf("Can't parse line %d of '%s'\n", error, config.conf_file);
		printf("Note: only printable ASCII characters are allowed.\n");
		return -1;
	}

	if (config.base_url) {
		char *https_url = alloc_https_url(config.base_url);
		free(config.base_url);
		config.base_url = https_url;
	}

	return 0;

}

static int is_oauth_acceptable(int c) {
	return (int)(isascii(c) && isgraph(c) && c != '|');
}

static int qh_init_oauth()
{
	char *tmp;
	if (!config.oauth.enabled)
		return 0;

	if (!config.oauth.device_id) {
		char buf[20];
		config.oauth.device_id = xstrdup(mac2str(g_macaddr, buf));
	}
	if (!config.oauth.secret)
		config.oauth.secret = "";

	if (!config.oauth.client_id || check_string(config.oauth.client_id, isdigit)) {
		DBG_ERROR("client-id: not set or not numeric");
		return -1;
	}
	if ((tmp = check_string(config.oauth.device_id, is_oauth_acceptable))) {
		DBG_ERROR("device-id: invalid character (code 0x%02x)", (uint8_t)(*tmp));
		return -1;
	}
	if ((tmp = check_string(config.oauth.secret, is_oauth_acceptable))) {
		DBG_ERROR("secret: invalid character (code 0x%02x)", (uint8_t)(*tmp));
		return -1;
	}
	return 0;
}

static void qh_print_usage()
{
	int i;
#define PRINT_STR(name) ({ printf("%s: %s\n", #name, name); })
#define PRINT_INT(name) ({ printf("%s: %d\n", #name, name); })
#define PRINT_HAVE(name) PRINT_INT(HAVE_##name)

	printf("(qharvestd v%s) Usage: qharvestd [-cCONF_FILE] [-F] [-v] [-V] [-tINIT_TIMEOUT] [-TPOLL_TIMEOUT]\n\n", __VERSION);

	PRINT_STR(COMMIT_HASH);
	PRINT_STR(CONF_FILE_DEFAULT);
#if HAVE_PTY
	PRINT_INT(CONFIG_PTY_DEFAULT);
#endif
	PRINT_HAVE(BIDICMD_REBOOT);
	PRINT_HAVE(CURL_MULTI);
	PRINT_HAVE(FW_UPGRADE);
	PRINT_HAVE(GRABBER);
	PRINT_HAVE(PKTLOGGER);
	PRINT_HAVE(PTY);
	PRINT_HAVE(RESOLVCONF_REREAD);
	PRINT_HAVE(SONIQ);
	PRINT_HAVE(ZLIB);
	PRINT_STR(LOGFILE);
	PRINT_INT(PRIMARY_BOARD);
	for (i = 0; i < boards_num; i++)
		printf("BOARD[%d]: %s\n", i, boards[i]->name);
}

int main(int argc, char *argv[])
{
	int i;
	int init_timeout = 0;

	signal(SIGINT, signal_handler);
	signal(SIGHUP, signal_handler);
	signal(SIGSEGV, signal_handler);
	signal(SIGTERM, signal_handler);
	signal(SIGABRT, signal_handler);
	signal(SIGPIPE, SIG_IGN);

	openlog(MY_NAME, LOG_CONS | LOG_PID | LOG_NDELAY, LOG_LOCAL1);

	while ((i = getopt(argc, argv, "c:FhT:t:vV")) != -1) {
		switch (i) {
		case 'c':
			config.conf_file = xstrdup(optarg);
			break;
		case 'F':
			initial_poll_timeout = 1;
			break;
		case 'T':
			initial_poll_timeout = atoi(optarg);
			break;
		case 't':
			init_timeout = atoi(optarg);
			break;
		case 'v':
			config.debug = 4; /* LOG_INFO */
			config.debug_config.console_print = 1;
			break;
		case 'V':
			printf("%s\n", __VERSION);
			exit(0);
		default:
			qh_print_usage();
			exit(-1);
		}
	}

	if (init_timeout < 0 || initial_poll_timeout < 0)
		exit(-1);

	g_start_uptime = get_uptime();
	if (g_start_uptime < 0) {
		DBG_ERROR("failed to get uptime");
		goto bail;
	}

	if (qh_init_config()) {
		goto bail;
	}

	DBG_NOTICE("qharvestd v%s started", __VERSION);

	sleep(init_timeout);

	qh_event_init();
	rotate_info_init(&rinfo_log, config.logfile, is_whole_logmsg);

	init_message_controls();

	if (config.base_url == NULL)
		goto bail;

	for (i = 0; i < hals_num; i++) {
		if (hals[i]->init && hals[i]->init()) {
			DBG_ERROR("failed to initialize %s '%s'", "hal", hals[i]->name);
			goto bail;
		}
	}

	for (i = 0; i < boards_num; i++) {
		if (boards[i]->init && boards[i]->init(boards[i])) {
			DBG_ERROR("failed to initialize %s '%s'", "board", boards[i]->name);
			goto bail;
		}
	}

	if (boards_num > 0) {
		if (boards[0]->firmware_set)
			snprintf(g_firmware, sizeof(g_firmware), "%s", boards[0]->firmware);
		if (boards[0]->platform_set)
			snprintf(g_platform, sizeof(g_platform), "%s", boards[0]->platform);
	}
	if (config.script) {
		(void)execl_buf_output(g_firmware, sizeof(g_firmware), 0,
			config.script, "get", "firmware");
		(void)execl_buf_output(g_platform, sizeof(g_platform), 0,
			config.script, "get", "platform");
	}

	if (config.primary_board >= ARRAY_SIZE(boards) ||
	    init_global_mac_addr(boards[config.primary_board])) {
		DBG_ERROR("failed to get device MAC address");
		goto bail;
	}

	if (qh_init_oauth())
		g_message_control->enable = 0;

	srand((unsigned int)(time(NULL) + g_macaddr[5])); //initialize pseudo-random generator

	iflist = get_iface_list(&ifnum);
	do_initial_scan();

#if HAVE_PKTLOGGER
	if (config.debug_config.pktlogger)
		config.debug_config.pktlogger = !pktlogger_discover();
#endif

	qh_scheduler();

 bail:
	DBG_NOTICE("qharvest terminated");
	closelog();
	return 1;
}
