/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "qharvestd.h"
#include "qh_event.h"
#include "qh_iface.h"
#include "qh_utils.h"
#include "qh_json.h"
#include "qh_json_basic_type.h"
#include "qh_json_message.h"
#include "qh_json_action.h"
#include "qh_curl_post.h"
#include "qh_curl_ws.h"
#include "qcsapi/grabber.h"
#ifdef HAL_QCSAPI
#include "qcsapi/qtn_only.h"
#include "qcsapi/pktlogger.h"
#endif

#define INITIAL_POLL_INTERVAL 28800
#define WS_MAX_ADJUST_NSECONDS (500 * 1000000)
#define BACKOFF_MIN_SCALE 3
#define BACKOFF_MAX_SCALE 15
int initial_poll_timeout = 120;

/* Poll message has to be the first one and the most
 * time consuming messages have to be at the end.
 */
struct message_control g_message_control[] = {
	{KEY_MESSAGE_POLL_REQUEST, BASE_URL_MESSAGE_POLLING, NULL, 0, 0, 0,
			get_json_polling_message, NULL, do_poll, 0, 0, NULL},
	{KEY_MESSAGE_PING_WS, NULL, NULL, 0, 0, 0,
			NULL, NULL, do_ping_ws, 0, 0, NULL},
	{KEY_MESSAGE_CONFIG_REQUEST, BASE_URL_MESSAGE_CONFIG, NULL, 0, 0, 0,
			get_json_default_message, get_filelist_config, NULL, 0, 0,
			NULL},
#ifdef HAL_QCSAPI
#if HAVE_GRABBER
	{KEY_MESSAGE_LOG_GATHER_INFO_REQUEST, BASE_URL_MESSAGE_LOG_GATHER_INFO, NULL, 0, 0, 0,
			get_json_grabber_message, get_filelist_grabber,
			NULL, 0, 0, NULL},
#endif
#if HAVE_PKTLOGGER
	{KEY_MESSAGE_CONFIG_PKTLOGGER_REQUEST, BASE_URL_MESSAGE_CONFIG_PKTLOGGER, NULL, 0, 0, 0,
			get_json_config_pktlogger_message, NULL, do_pktlogger_config, 0, 0, NULL},
#endif
	{KEY_MESSAGE_LOG_SCS_REPORT_ALL_REQUEST, BASE_URL_MESSAGE_LOG_SCS_REPORT_ALL, NULL, 0, 0, 0,
			get_json_log_scs_report_all_message, NULL, NULL, 0, 0, NULL},
#endif
	{KEY_MESSAGE_LOG_SCAN_REQUEST, BASE_URL_MESSAGE_LOG_SCAN_RESULTS, NULL, 0, 0, 0,
			get_json_log_scan_results_message, NULL, NULL, 0, 0, NULL},
	/* Bidirectional message is used to connect to websockets server and to send command
	 * return code back to the server. The command itself is received through websockets.
	 * Schedule of this message is no longer determined by MAUI server. */
	{KEY_MESSAGE_LOG_BIDICMD_REQUEST, BASE_URL_MESSAGE_LOG_BIDICMD, NULL, 0, 0, 0,
			NULL, NULL, do_bidicmd, 0, 0, NULL},
#if HAVE_FW_UPGRADE
	{KEY_MESSAGE_UPGRADE_REQUEST, BASE_URL_MESSAGE_UPGRADE, NULL, 0, 0, 0,
			get_json_upgrade_message, NULL, do_firmware_upgrade, 0, 0, NULL},
#endif
	{KEY_MESSAGE_CHECK_HEALTH, NULL, NULL, 0, 0, 0,
			NULL, NULL, do_check_health, 0, 0, NULL},
	{KEY_MESSAGE_LOG_CAPABILITIES_REQUEST, BASE_URL_MESSAGE_LOG_CAPABILITIES,
			NULL, 0, 0, 0, get_json_log_capabilities_message, NULL,
			NULL, 0, 0, NULL},
	{KEY_MESSAGE_LOG_BUNDLED_STATS_REQUEST, BASE_URL_MESSAGE_LOG_BUNDLED_STATS,
			NULL, 0, 0, 0, get_json_log_bundled_stats_message, NULL,
			NULL, 0, 0, NULL},
	{KEY_MESSAGE_LOG_MESSAGES_REQUEST, BASE_URL_MESSAGE_LOG_MESSAGES, NULL, 0, 0, 0,
			get_json_default_message, NULL, NULL, 0,
			FLAG_ROTATION, &rinfo_log},
	/* oauth message is never scheduled on its own */
	{KEY_MESSAGE_OAUTH, BASE_URL_MESSAGE_OAUTH, NULL, 0, 0, 0,
			get_json_oauth_message, NULL, do_oauth, 0,
			FLAG_OAUTH, NULL},
	{NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, 0, 0, NULL}
};

static long adjust_ms = 0;

void init_message_controls(void)
{
	struct message_control *mctl = g_message_control;
	while (mctl->name) {
		if (mctl->url)
			free(mctl->url);
		if ((mctl->base_url) && (config.base_url)) {
			mctl->url =
				(char *)xmalloc(strlen(config.base_url) +
				strlen(mctl->base_url) + 2);
			mctl->url[0] = 0;
			sprintf(mctl->url, "%s/%s", config.base_url,
				mctl->base_url);
		}
		if (mctl == g_message_control) {
			//first message => POLL
			mctl->enable = INITIAL_ENABLE;
			mctl->timeout = initial_poll_timeout;
			mctl->interval = INITIAL_POLL_INTERVAL; //if first poll fails
		} else {
			mctl->enable = 0;
			mctl->timeout = 0;
		}
		mctl->backoff = 0;

		mctl++;
	}
}

struct message_control *get_message_control(const char *name)
{
	struct message_control *tmp = g_message_control;
	while (tmp->name != NULL) {
		if (strcmp(name, tmp->name) == 0) {
			return tmp;
		}
		tmp++;
	}
	return NULL;
}

static void reset_message_control(struct message_control *mctl)
{
	if (!mctl->enable) {
		mctl->timeout = 0;
		return;
	}
	if (mctl->timeout <= 0) {
		mctl->timeout = mctl->interval;
		if (mctl->backoff) {
			unsigned int scale = mctl->backoff + BACKOFF_MIN_SCALE - 1;
			unsigned int backoff_interval;
			if (scale > BACKOFF_MAX_SCALE)
				scale = BACKOFF_MAX_SCALE;
			DBG_INFO("%s: exponential backoff scale is %d", mctl->name, scale);
			/* coverity[dont_call] - it is safe to use rand() here */
			backoff_interval = (1<<scale) + rand() % (1<<scale);
			if (backoff_interval < mctl->interval)
				mctl->timeout = backoff_interval;
		}
	}
	DBG_INFO("next %s will be in %d seconds", mctl->name, mctl->timeout);
}

int qh_process_message(struct message_control *mctl)
{
	int ret = 0;
	struct timespec before;
	struct timespec after;
	long ms;

	if (config.oauth.enabled && !config.oauth.token)
		mctl = get_message_control(KEY_MESSAGE_OAUTH);

	clock_gettime(CLOCK_MONOTONIC, &before);
	DBG_INFO("start %s processing at %d.%09ld", mctl->name, (int)before.tv_sec, before.tv_nsec);
	if ((mctl->url) && (mctl->get_json)) {
		JSON *obj = NULL;
		JSON *robj = NULL;

		obj = mctl->get_json(mctl, &ret);
		if (obj && ret == 0) {
			ret = qh_curl_post_json(mctl, obj, &robj);

			if (ret == 0 && mctl->action)
				ret = mctl->action(mctl, obj, robj);

			JSON_PUT_REF(obj);
			if (robj)
				JSON_PUT_REF(robj);
		}
	} else if (mctl->action) {
		ret = mctl->action(mctl, NULL, NULL);
	}
	clock_gettime(CLOCK_MONOTONIC, &after);
	ms = (after.tv_nsec - before.tv_nsec) / 1000000;
	ms += (after.tv_sec - before.tv_sec) * 1000;
	DBG_INFO("finish %s processing at %d.%09ld (in %ldms)", mctl->name,
		(int)after.tv_sec, after.tv_nsec, ms);
	/* Store processing time of the last message. We do not accumulate the time
	 * of all "simultaneously" processed messages, because it will lead to early
	 * requests (from the backend's perspective) for all of them except
	 * the first one => it could conflict with throttling policy on the backend.
	 */
	adjust_ms = ms;
	return ret;
}

int qh_process_messages(int cnt)
{
	int min_timeout = INT_MAX;

	struct message_control *mctl;
	/* decrease timeouts right now, because we have already slept
	 * for 'cnt' seconds: we want to have up-to-date timeouts in mctl
	 */
	for (mctl = g_message_control; mctl->name; mctl++) {
		if (mctl->enable)
			mctl->timeout -= cnt;
	}
	for (mctl = g_message_control; mctl->name; mctl++) {
		/* Even though poll handler is altering timing properties
		 * of other messages, we can proceed to process them
		 * because poll message is processed first.
		 */
		if (mctl->enable) {
			if (mctl->timeout <= 0) {
				int ret = qh_process_message(mctl);
				if (ret == -ERESTART) {
					ret = qh_process_message(mctl);
					if (ret == -ERESTART)
						ret = -EAGAIN;
				}
				if (ret == -EACCES) {
					/* oauth authorization failed */
					if (g_message_control->enable != INITIAL_ENABLE)
						init_message_controls();
					else
						ret = -EAGAIN;
				}
				if (ret == -EAGAIN)
					mctl->backoff++;
				else
					mctl->backoff = 0;
				/* Reschedule messages here instead of doing it
				 * in every message handler.
				 * NOTE: reset_message_control will not touch
				 * positive timeouts, so custom rescheduling
				 * for special cases (ex. do_poll redirect)
				 * still could be done in message handlers.
				 */
				reset_message_control(mctl);
			}
		}
	}
	for (mctl = g_message_control; mctl->name; mctl++) {
		/* Since timeout of some message could be changed by
		 * handler of any other message (forcing), min_timeout
		 * has to be computed after all qh_process_message calls.
		 */
		if ((mctl->enable) && (mctl->timeout < min_timeout))
			min_timeout = (mctl->timeout > 0) ? mctl->timeout : 0;
	}
	return min_timeout;
}

void check_oauth_token(int t)
{
	if (config.oauth.expire > 0)
		config.oauth.expire -= t;
	if (config.oauth.expire <= 0 && config.oauth.token != NULL) {
		free(config.oauth.token);
		config.oauth.token = NULL;
	}
}

int qh_scheduler(void)
{
	int t = 0;
	struct timespec time;

	while (config.running) {
		free_iface_list(iflist, &ifnum);
		iflist = get_iface_list(&ifnum);
		adjust_ms = 0;
		check_oauth_token(t);
		t = qh_process_messages(t);
		time.tv_sec = t;
		time.tv_nsec = 0;
		while (adjust_ms >= 1000 && time.tv_sec >= 1) {
			adjust_ms -= 1000;
			time.tv_sec -= 1;
		}
		if (adjust_ms > 0 && time.tv_sec >= 1) {
			time.tv_sec -= 1;
			time.tv_nsec = 1000000000 - adjust_ms * 1000000;
		}
		DBG_INFO("rest for %ds (%lds %ldms after adjustment)",
			t, time.tv_sec, time.tv_nsec / 1000000);
		if (qh_event_listen(&time)) {
			t = t - time.tv_sec;
			time.tv_sec = 0;
			/* Do not sleep for more than WS_MAX_ADJUST_NSECONDS. It is a compromise
			 * between schedule shifting and responsiveness. */
			if (time.tv_nsec > WS_MAX_ADJUST_NSECONDS)
				time.tv_nsec = WS_MAX_ADJUST_NSECONDS;
			DBG_INFO("reschedule in %ldms", time.tv_nsec / 1000000);
		}
		qh_event_listen_sleep(&time);
	}
	return -1;
}
