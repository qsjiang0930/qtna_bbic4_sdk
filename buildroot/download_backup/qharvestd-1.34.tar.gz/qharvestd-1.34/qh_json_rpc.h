/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QH_JSON_RPC_H
#define __QH_JSON_RPC_H

int do_jsonrpc(JSON *jobj);

#endif
