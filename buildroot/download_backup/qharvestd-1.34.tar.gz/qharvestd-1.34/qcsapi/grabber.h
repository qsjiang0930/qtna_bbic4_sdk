/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __GRABBER_H
#define __GRABBER_H

#ifdef HAL_QCSAPI
/* This header is also included from the outside of qcsapi directory,
 * and therefore has not to depend on headers that include qcsapi_caps.h,
 * as it is present only in make dependencies of qcsapi directory files
 * => qcsapi_caps.h could be still absent and cause build failure. */
#include <qcsapi_rpc/generated/qcsapi_rpc.h>
#endif

#ifndef HAVE_GRABBER
#if defined(HAL_QCSAPI) && QCSAPI_GRAB_CONFIG_REMOTE
#define HAVE_GRABBER 2
#elif defined(HAL_QCSAPI) && !defined(REMOTE_QCSAPI)
#define HAVE_GRABBER 1
#else
#define HAVE_GRABBER 0
#endif
#endif

#include "qh_json.h"

#define GINFO_FILE "/tmp/gather_info.txt"
#define GRABBER_FILE "/tmp/grabber.blob"

#if HAVE_GRABBER
JSON *get_json_grabber_message(struct message_control *mctl, int *ret);
#endif
#endif
