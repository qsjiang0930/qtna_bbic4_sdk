/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include "qharvestd.h"
#include "qh_hal.h"
#include "qcsapi_utils.h"
#include "qh_utils.h"
#include <net80211/ieee80211.h> /* must be included after <qcsapi.h> */
#if QCSAPI_WIFI_GET_EXTENDER_PARAMS_REMOTE && defined QTN_RBS_NO_SCAN
#include <net80211/ieee80211_ioctl.h>
#endif
#include <math.h>

#if HAVE_EXT_ASSOC_API
static void parse_max_mimo(char *str, int *rx, int *tx)
{
	char *p;
	*rx = 0;
	*tx = 0;
	strtok(str, ": ");
	p = strtok(NULL, ": ");
	if (!p)
		return;
	*rx = atoi(p);
	strtok(NULL, ": ");
	p = strtok(NULL, ": ");
	if (!p)
		return;
	*tx = atoi(p);
	return;
}
#endif

int hal_qcsapi_init(void)
{
	int qcsapi_ret;
#ifdef REMOTE_QCSAPI
	if (connect_qcsapi_client(5) < 0)
		return -1;
#endif
	qcsapi_ret = qcsapi_init();
	if (qcsapi_ret < 0) {
		DBG_WARNING("qcsapi_init error %d, some qcsapi functions may not work",
			qcsapi_ret);
	}
	if (!config.main_interface_name)
		config.main_interface_name = xstrdup(INTERFACE_DEFAULT);
	if (!config.mac_interface_name)
		config.mac_interface_name = xstrdup(MAC_INTERFACE_DEFAULT);
	return 0;
}

int hal_qcsapi_reinit(void)
{
#ifdef REMOTE_QCSAPI
	if (connect_qcsapi_client(1) < 0)
		return -1;
#endif
	return 0;
}

int hal_qcsapi_mode(const struct iface *iface, uint32_t *mode)
{
	return hal_qcsapi_iface_mode(iface->name, mode, 0);
}

int hal_qcsapi_channel(const struct iface *iface, uint32_t *channel)
{
	int qret;
	/* Suppress qcsapi_iface_error on down interfaces on BBIC3 boards. This error
	 * is not used on BBIC4/BBIC5 boards for this call, so it is safe to do it. */
	CALL_QCSAPI_IGNORE(wifi_get_channel, qret, -qcsapi_iface_error,, iface->phy->name, channel);
	return (qret) ? -1 : 0;
}

int hal_qcsapi_txpower(const struct iface *iface, int32_t *txpower)
{
	uint32_t channel;

	if (hal_qcsapi_channel(iface, &channel))
		return -1;
	return get_qcsapi_beacon_txpower(iface->phy->name, channel, txpower);
}

int hal_qcsapi_region(const struct iface *iface, string2 region)
{
	string16 buf;
	if (get_qcsapi_region(iface->phy->name, buf))
		return -1;
	if (!strcmp(buf, "none")) {
		/* We need to send 2-characters string, "no" region already exists */
		strcpy(buf, "--");
	}
	if (validate_region(buf))
		return -1;
	snprintf(region, sizeof(string2), "%s", buf);
	return 0;
}

int hal_qcsapi_bandwidth(const struct iface *iface, uint32_t *bandwidth)
{
	int qret;
	qcsapi_unsigned_int bw;
	CALL_QCSAPI(wifi_get_bw, qret, return -1, iface->phy->name, &bw);
/*	bw = bw_num_to_bitmask(bw);
	if (bw < 0)
		return -1;
*/
	*bandwidth = bw;
	return 0;
}

int hal_qcsapi_bandwidth_supp(const struct iface *iface, uint32_t *bandwidth)
{
	uint32_t bw;
	uint32_t ch;
	uint8_t band, bwi;
	power_t txpower = { 0 };

	if (get_qcsapi_band_supp(iface->phy->name, &band) < 0)
		return -1;
	ch = (band & BAND_11B) ? 1 : 36;

	if (get_qcsapi_configured_txpower(iface->phy->name, ch, txpower, CFGPOWER_BW))
		return -1;

	for (bw = 10, bwi = 0; bwi < BW_NUM; bw *= 2, bwi++) {
		if (txpower[PWRIDX(bwi, 0, 0, 0)] <= 0)
			break;
	}

	/* workaround for tetum 24103 */
	if ((band & BAND_11B) && bw > 40)
		bw = 40;

	*bandwidth = (bw >= 20) ? bw : 20;
	return 0;
}

int hal_qcsapi_protocol(const struct iface *iface, uint32_t *protocol)
{
#if QCSAPI_WIFI_GET_PHY_MODE_REMOTE
	string16 buf = { 0 };
	int qret;
	CALL_QCSAPI(wifi_get_phy_mode, qret, return -1, iface->name, buf);
	buf[4] = 0; /* keep only "11xy" part of the output */
	*protocol = proto_str2bitmask(buf, PROTO_SINGLE);
	return 0;
#else
	return -ENOTSUP;
#endif
}

int hal_qcsapi_protocol_supp(const struct iface *iface, uint32_t *protocol)
{
	uint8_t band;
	uint32_t bw;

	if (get_qcsapi_band_supp(iface->phy->name, &band) < 0)
		return -1;
	if (hal_qcsapi_bandwidth_supp(iface, &bw) < 0)
		return -1;
	*protocol = PROTO_11N;
	if (band & BAND_11B)
		*protocol |= PROTO_11B | PROTO_11G;
	if (band & BAND_11A)
		*protocol |= PROTO_11A;
	if (bw >= 80)
		*protocol |= PROTO_11AC;
	return 0;
}

int hal_qcsapi_ssid(const struct iface *iface, string32 ssid)
{
	int qret;
#if !HAVE_POWER_EXT_API
	/* On very old firmwares like BBIC3 the following call fails on down interfaces.
	 * Try to guess such firmwares using HAVE_POWER_EXT_API. */
	if (iface->up == 0)
		return -1;
#endif
	CALL_QCSAPI_IGNORE(wifi_get_SSID, qret, -EOPNOTSUPP,, iface->name, ssid);
	return (qret) ? -1 : 0;
}

int hal_qcsapi_bssid(const struct iface *iface, macaddr_t bssid)
{
	int qret;
	CALL_QCSAPI(interface_get_mac_addr, qret,, iface->name, bssid);
	return (qret) ? -1 : 0;
}

int hal_qcsapi_phy_stats(const struct iface *iface, struct phy_stats *halps)
{
	int qret;
	qcsapi_phy_stats qtnps = { 0 };

#define DBM2INT(x) (lroundf(x))
#define DBMFLDSET(field, value) ({ long int _v = value; if (_v != 0) FLDSET(field, _v); })

	CALL_QCSAPI(get_phy_stats, qret, return -1, iface->phy->name, &qtnps);
	FLDSET(halps->assoc, qtnps.assoc);
	FLDSET(halps->channel, qtnps.channel);
	FLDSET(halps->atten, qtnps.atten);
	FLDSET(halps->rx_packets, qtnps.rx_pkts);
	FLDSET(halps->tx_packets, qtnps.tx_pkts);
	FLDSET(halps->tx_deferred, qtnps.tx_defers);
	FLDSET(halps->tx_retries, qtnps.tx_retries);
	FLDSET(halps->rx_noise, DBM2INT(qtnps.rx_noise));
	FLDSET(halps->rx_gain, qtnps.rx_gain);
	FLDSET(halps->fcs_err, qtnps.rx_cnt_crc);
	FLDSET(halps->sp_fail, qtnps.cnt_sp_fail);
	FLDSET(halps->lp_fail, qtnps.cnt_lp_fail);
	FLDSET(halps->rx_mcs, qtnps.last_rx_mcs);
	FLDSET(halps->tx_mcs, qtnps.last_tx_mcs);
	DBMFLDSET(halps->rcpi, DBM2INT(qtnps.last_rcpi));
	DBMFLDSET(halps->rssi, DBM2INT(qtnps.last_rssi));
	DBMFLDSET(halps->evm, DBM2INT(qtnps.last_evm));
	DBMFLDSET(halps->rssi0, DBM2INT(qtnps.last_rssi_array[0]));
	DBMFLDSET(halps->rssi1, DBM2INT(qtnps.last_rssi_array[1]));
	DBMFLDSET(halps->rssi2, DBM2INT(qtnps.last_rssi_array[2]));
	DBMFLDSET(halps->rssi3, DBM2INT(qtnps.last_rssi_array[3]));
	DBMFLDSET(halps->evm0, DBM2INT(qtnps.last_evm_array[0]));
	DBMFLDSET(halps->evm1, DBM2INT(qtnps.last_evm_array[1]));
	DBMFLDSET(halps->evm2, DBM2INT(qtnps.last_evm_array[2]));
	DBMFLDSET(halps->evm3, DBM2INT(qtnps.last_evm_array[3]));
#if RF_STREAMS == 8
	DBMFLDSET(halps->rssi4, DBM2INT(qtnps.last_rssi_array[4]));
	DBMFLDSET(halps->rssi5, DBM2INT(qtnps.last_rssi_array[5]));
	DBMFLDSET(halps->rssi6, DBM2INT(qtnps.last_rssi_array[6]));
	DBMFLDSET(halps->rssi7, DBM2INT(qtnps.last_rssi_array[7]));
	DBMFLDSET(halps->evm4, DBM2INT(qtnps.last_evm_array[4]));
	DBMFLDSET(halps->evm5, DBM2INT(qtnps.last_evm_array[5]));
	DBMFLDSET(halps->evm6, DBM2INT(qtnps.last_evm_array[6]));
	DBMFLDSET(halps->evm7, DBM2INT(qtnps.last_evm_array[7]));
#endif

#if QCSAPI_GET_TEMPERATURE_INFO_REMOTE == 3892
	{
		int discard = 0, rftemp = 0, bbtemp = 0;
		CALL_QCSAPI(get_temperature_info, qret,, &discard, &rftemp, &bbtemp);
		if (rftemp > 0)
			FLDSET(halps->rf_temp, (rftemp % 1000000 >= 500000) ?
				rftemp / 1000000 + 1 : rftemp / 1000000);
		if (bbtemp > 0)
			FLDSET(halps->bb_temp, (bbtemp % 1000000 >= 500000) ?
				bbtemp / 1000000 + 1 : bbtemp / 1000000);
	}
#endif
	return 0;
}

int hal_qcsapi_cca_stats(const struct iface *iface, struct cca_stats *halcca)
{
	int qret;
	qcsapi_phy_stats qtnps = { 0 };
	halcca->cumulative = 0;

	CALL_QCSAPI(get_phy_stats, qret, return -1, iface->phy->name, &qtnps);
	if (qtnps.cca_total != 0) {
		/* On BBIC3 all CCA stats are 0 if SCS is disabled */
		FLDSET(halcca->total, qtnps.cca_total);
		FLDSET(halcca->rx, qtnps.cca_rx);
		FLDSET(halcca->tx, qtnps.cca_tx);
		FLDSET(halcca->cs_ed, qtnps.cca_int);
		FLDSET(halcca->idle, qtnps.cca_idle);
	}
	return 0;
}

int hal_qcsapi_channel_list(const struct iface *iface, char *buf, int *len)
{
	struct channel_desc *chd = (struct channel_desc *)buf;
	string16 region = { 0 };
	char channels[1024] = { 0 };
	power_t txpower = { 0 };
	char *ch;
	int qret;

	if (get_qcsapi_region(iface->phy->name, region))
		return -1;

	if (strcmp(region, "none") == 0) {
		CALL_QCSAPI(wifi_get_list_channels, qret, return -1,
			iface->phy->name, channels);
	} else {
		CALL_QCSAPI(regulatory_get_list_regulatory_channels, qret, return -1,
			region, 20, channels);
	}

	for (ch = strtok(channels, ","), *len = 0; ch; ch = strtok(NULL, ",")) {
		if (hal_buf_check_clear(buf, *len, sizeof(*chd)))
			break;
		if (get_qcsapi_configured_txpower(iface->phy->name, atoi(ch), txpower, CFGPOWER_BEACON))
			continue;
		/* If regulatory detabase contains information for both bands,
		 * but interface supports only one, API returns txpower == 0
		 * for unsupported channels */
		if (txpower[0] <= 0)
			continue;
		FLDSET(chd->channel, atoi(ch));
		FLDSET(chd->txpower, txpower[0]);
		chd++;
		(*len)++;
	}
	return 0;
}

int hal_qcsapi_assoc_list(const struct iface *iface, char *buf, int *len)
{
	struct assoc_stats *assoc = (struct assoc_stats *)buf;
	int qret;
	uint32_t mode;
	int i;
	macaddr_t macaddr;
	qcsapi_unsigned_int l;
	qcsapi_unsigned_int uval;
	int val;

	if (hal_qcsapi_mode(iface, &mode) < 0)
		return -1;

	CALL_QCSAPI(wifi_get_count_associations, qret, return -1, iface->name, &l);
	for (i = 0; i < l; i++, assoc++) {
		if (hal_buf_check_clear(buf, i, sizeof(*assoc)))
			break;

		/* For WDS both API return peer's MAC address */
		if (mode == WIFI_MODE_STA)
			CALL_QCSAPI(wifi_get_BSSID, qret, return -1, iface->name, macaddr);
		else
			CALL_QCSAPI(wifi_get_associated_device_mac_addr, qret, return -1,
				iface->name, i, macaddr);
		memcpy(assoc->macaddr, macaddr, sizeof(macaddr_t));
		assoc->macaddr_set = 1;

		CALL_QCSAPI(wifi_get_rx_phy_rate_per_association, qret, return -1,
			iface->name, i, &uval);
		FLDSET(assoc->rx_rate, uval * 1024);

		CALL_QCSAPI(wifi_get_tx_phy_rate_per_association, qret, return -1,
			iface->name, i, &uval);
		FLDSET(assoc->tx_rate, uval * 1024);

		CALL_QCSAPI(wifi_get_achievable_rx_phy_rate_per_association, qret, return -1,
			iface->name, i, &uval);
		FLDSET(assoc->rx_max_rate, uval / 1000 * 1024);

		CALL_QCSAPI(wifi_get_achievable_tx_phy_rate_per_association, qret, return -1,
			iface->name, i, &uval);
		FLDSET(assoc->tx_max_rate, uval / 1000 * 1024);

		CALL_QCSAPI(wifi_get_link_quality, qret, return -1,
			iface->name, i, &uval);
		FLDSET(assoc->quality, uval);

		CALL_QCSAPI(wifi_get_rssi_in_dbm_per_association, qret, return -1,
			iface->name, i, &val);
		FLDSET(assoc->rssi, val);

		CALL_QCSAPI(wifi_get_snr_per_association, qret, return -1,
			iface->name, i, &val);
		FLDSET(assoc->snr, val);

		CALL_QCSAPI(wifi_get_bw_per_association, qret, return -1,
			iface->name, i, &uval);
		/*uval = bw_num_to_bitmask(uval);
		if (uval < 0)
			return -1;*/
		FLDSET(assoc->bandwidth, uval);

		CALL_QCSAPI(wifi_get_time_associated_per_association, qret, return -1,
			iface->name, i, &uval);
		FLDSET(assoc->time, uval);

#if HAVE_EXT_ASSOC_API
		CALL_QCSAPI(wifi_get_rx_mcs_per_association, qret, return -1,
			iface->name, i, &uval);
		FLDSET(assoc->rx_mcs, uval);

		CALL_QCSAPI(wifi_get_tx_mcs_per_association, qret, return -1,
			iface->name, i, &uval);
		FLDSET(assoc->tx_mcs, uval);
#endif

		/* The following calls don't work for STA or WDS */
		if (mode != WIFI_MODE_AP)
			continue;

		CALL_QCSAPI(wifi_get_max_queued, qret, return -1,
			iface->name, i, QCSAPI_LOCAL_NODE, 0, &uval);
		FLDSET(assoc->max_queued, uval);
#if HAVE_EXT_ASSOC_API
		CALL_QCSAPI(wifi_get_connection_mode, qret, return -1,
			iface->name, i, &uval);
		switch (uval) {
		case IEEE80211_WIFI_MODE_A:
			uval = PROTO_11A; break;
		case IEEE80211_WIFI_MODE_B:
			uval = PROTO_11B; break;
		case IEEE80211_WIFI_MODE_G:
			uval = PROTO_11G; break;
		case IEEE80211_WIFI_MODE_NA:
		case IEEE80211_WIFI_MODE_NG:
			uval = PROTO_11N; break;
		case IEEE80211_WIFI_MODE_AC:
			uval = PROTO_11AC; break;
		case IEEE80211_WIFI_MODE_AX:
			uval = PROTO_11AX; break;
		default:
			uval = 0; break;
		}
		FLDSET(assoc->protocol, uval);

		{
			string_16 buf = { 0 };
			int rx_streams, tx_streams;
			CALL_QCSAPI(wifi_get_max_mimo, qret, return -1,
				iface->name, i, buf);
			parse_max_mimo(buf, &rx_streams, &tx_streams);
			FLDSET(assoc->rx_streams, rx_streams);
			FLDSET(assoc->tx_streams, tx_streams);
		}

		CALL_QCSAPI(wifi_get_vendor_per_association, qret, return -1,
			iface->name, i, &uval);
		switch (uval) {
		case PEER_VENDOR_QTN:
			uval = VENDOR_QUANTENNA; break;
		case PEER_VENDOR_BRCM:
			uval = VENDOR_BROADCOM; break;
		case PEER_VENDOR_ATH:
			uval = VENDOR_ATHEROS; break;
		case PEER_VENDOR_RLNK:
			uval = VENDOR_RALINK; break;
		case PEER_VENDOR_RTK:
			uval = VENDOR_REALTEK; break;
		case PEER_VENDOR_INTEL:
			uval = VENDOR_INTEL; break;
		default:
			uval = VENDOR_UNKNOWN; break;
		}
		FLDSET(assoc->vendor, uval);
#endif
#if HAVE_TPUT_CAPS_API
		{
			struct ieee8011req_sta_tput_caps tput_caps;
			CALL_QCSAPI(wifi_get_tput_caps, qret, return -1,
				iface->name, i, &tput_caps);

			switch (tput_caps.mode) {
			case IEEE80211_WIFI_MODE_AX:
				/* So far tput_caps doesn't contain 802.11ax capabilities */
			case IEEE80211_WIFI_MODE_AC:
				memcpy(assoc->vhtcaps, (char*)tput_caps.vhtcap_ie + 2,
					HAL_VHTCAP_LEN);
				assoc->vhtcaps_set = 1;
				/* fall through */
			case IEEE80211_WIFI_MODE_NA:
			case IEEE80211_WIFI_MODE_NG:
				memcpy(assoc->htcaps, (char*)tput_caps.htcap_ie + 2,
					HAL_HTCAP_LEN);
				assoc->htcaps_set = 1;
				break;
			}
		}
#endif
	}
	*len = i;
	return 0;
}

int hal_qcsapi_traffic_list(const struct iface *iface, char *buf, int *len)
{
	struct traffic_stats *ts = (struct traffic_stats *)buf;
	struct qcsapi_node_stats ns;
	qcsapi_unsigned_int l;
	int qret;
	uint32_t mode;
	int i;
	macaddr_t macaddr;

	if (hal_qcsapi_mode(iface, &mode) < 0)
		return -1;

	/* wifi_get_node_stats() works only for AP and WDS */
	if (mode == WIFI_MODE_STA)
		return -ENOTSUP;

	CALL_QCSAPI(wifi_get_count_associations, qret, return -1, iface->name, &l);
	for (i = 0; i < l; i++, ts++) {
		if (hal_buf_check_clear(buf, i, sizeof(*ts)))
			break;

		CALL_QCSAPI(wifi_get_associated_device_mac_addr, qret, return -1,
			iface->name, i, macaddr);
		memcpy(ts->macaddr, macaddr, sizeof(macaddr_t));
		ts->macaddr_set = 1;

		CALL_QCSAPI(wifi_get_node_stats, qret, return -1,
			iface->name, i, QCSAPI_LOCAL_NODE, &ns);

		FLDSET(ts->rx_bytes, ns.rx_bytes);
		FLDSET(ts->tx_bytes, ns.tx_bytes);
		FLDSET(ts->rx_packets, ns.rx_pkts);
		FLDSET(ts->tx_packets, ns.tx_pkts);
		FLDSET(ts->rx_discard, ns.rx_discard);
		FLDSET(ts->tx_discard, ns.tx_discard);
		FLDSET(ts->rx_error, ns.rx_err);
		FLDSET(ts->tx_error, ns.tx_err);
		FLDSET(ts->rx_unicast, ns.rx_unicast);
		FLDSET(ts->tx_unicast, ns.tx_unicast);
		FLDSET(ts->rx_multicast, ns.rx_multicast);
		FLDSET(ts->tx_multicast, ns.tx_multicast);
		FLDSET(ts->rx_broadcast, ns.rx_broadcast);
		FLDSET(ts->tx_broadcast, ns.tx_broadcast);
	}
	*len = i;
	return 0;
}


#ifndef IEEE80211_PICK_SCAN_FLUSH
#define IEEE80211_PICK_SCAN_FLUSH 0
#endif

#ifdef IEEE80211_PICK_BG_PASSIVE_SLOW
#define SCAN_DURATION 28
#define SCAN_FLAGS (IEEE80211_PICK_NOPICK_BG | IEEE80211_PICK_BG_PASSIVE_SLOW | IEEE80211_PICK_SCAN_FLUSH)
#else
#define SCAN_DURATION 10
#define SCAN_FLAGS (IEEE80211_PICK_NOPICK_BG | IEEE80211_PICK_SCAN_FLUSH)
#endif
int hal_qcsapi_scan_start(const struct iface *iface, const int force)
{
	struct cca_stats cca = { 0 };
	uint32_t mode = 0;
	int role_rbs = 0;
	int qret;
	int threshold = config.debug_config.scan_threshold;

	if (iface->priv & FLAG_NO_SCAN)
		return -ENOTSUP;
	if (hal_qcsapi_mode(iface, &mode) < 0)
		return -1;
	if (hal_qcsapi_cca_stats(iface, &cca) < 0)
		return -1;
#if QCSAPI_WIFI_GET_EXTENDER_PARAMS_REMOTE && defined QTN_RBS_NO_SCAN
	CALL_QCSAPI(wifi_get_extender_params, qret,, iface->phy->name,
		qcsapi_extender_role, &role_rbs);
	role_rbs = (role_rbs == IEEE80211_EXTENDER_ROLE_RBS) ? 1 : 0;
#endif
	if (force ||
	/* According to tests, BBIC4 is capable to smoothly send
	 * up to 350 Mbit/s of traffic during bgscan. For 4 streams,
	 * 80 MHz bandwidth and MCS9 such traffic occupies 1/4 (250 units)
	 * of FAT. So we could use cca_idle >= 750 to guarantee that
	 * neither our traffic nor traffic on neighboring QTN APs sitting
	 * on the same channel will be affected by bgscan. Let's also
	 * increase this threshold by a small margin of safety.
	 * NOTE: on BBIC3 cca_idle and other CCA stats are always zero
	 * if SCS is disabled. */
	    (cca.idle >= ((threshold >= 0) ? threshold : 800)
	/* MBS tears down QHop link if sees probe requests from RBS, as it
	   thinks that RBS became STA. Do not do a scan while in RBS role. */
	    && !role_rbs
	/* We don't want the new bgscan with fixed TXBF bug to run on STAs
	 * either, because it is quite intrusive and NAV is not accounted
	 * in QTN CCA stats => we are unable to prevent AP and STA to run
	 * scan at the same time just by looking at CCA stats. But unlike
	 * the old scan, it is safe to force the new scan on STAs.
	 * NOTE: WDS interface is a secondary one, so we don't call a scan
	 * on it directly. And anyway for firmwares where qharvestd supports
	 * WDS, TXBF bug is already fixed. */
	    && mode != WIFI_MODE_STA)) {
		CALL_QCSAPI(wifi_start_scan_ext, qret, return -1,
			iface->phy->name, SCAN_FLAGS);
		return 0;
	}
	DBG_INFO("scan skipped: cca_idle=%d, role_rbs=%d, sta=%d",
		(int)cca.idle, role_rbs, (mode == WIFI_MODE_STA) ? 1 : 0);
	return -EBUSY;
}

int hal_qcsapi_scan_duration(const struct iface *iface, uint32_t *duration)
{
	*duration = (iface->priv & FLAG_NO_SCAN) ? 0 : SCAN_DURATION;
	return 0;
}

int hal_qcsapi_scan_status(const struct iface *iface, uint32_t *status)
{
	int st = 0;
	int qret;

	CALL_QCSAPI(wifi_get_scan_status, qret, return -1, iface->name, &st);
	*status = (st) ? SCAN_IN_PROGRESS : 0;
	return 0;
}

int hal_qcsapi_scan_list(const struct iface *iface, char *buf, int *len)
{
	struct scan_stats *ss = (struct scan_stats *)buf;
	struct qcsapi_ap_properties ap_details;
	int num_APs = 0;
	int qret;
	int i;

	CALL_QCSAPI_IGNORE(wifi_get_results_AP_scan, qret, -EPERM, return -1,
		iface->phy->name, (qcsapi_unsigned_int *)&num_APs);
	for (i = 0; i < num_APs; i++, ss++) {
		if (hal_buf_check_clear(buf, i, sizeof(*ss)))
			break;
		CALL_QCSAPI(wifi_get_properties_AP, qret, break,
			iface->phy->name, i, &ap_details);
		memcpy(ss->ssid, ap_details.ap_name_SSID, sizeof(string32) - 1);
		ss->ssid_set = 1;
		memcpy(ss->bssid, ap_details.ap_mac_addr, sizeof(macaddr_t));
		ss->bssid_set = 1;
		FLDSET(ss->channel, ap_details.ap_channel);
		FLDSET(ss->rssi, ap_details.ap_RSSI - 90);
		FLDSET(ss->encrypt_proto, ap_details.ap_protocol);
		FLDSET(ss->encrypt_mode, ap_details.ap_encryption_modes);
		FLDSET(ss->auth_mode, ap_details.ap_authentication_mode);
		FLDSET(ss->max_rate, ap_details.ap_best_data_rate / 1000000 * 1024);
		FLDSET(ss->wps_support, ap_details.ap_wps);
		FLDSET(ss->protocol, ap_details.ap_80211_proto);
#if HAVE_SCAN_BW
		FLDSET(ss->bandwidth, ap_details.ap_bw);
#endif
	}
	*len = i;
	return 0;
}


int hal_qcsapi_set_channel(const struct iface *iface, uint32_t channel)
{
	int qret;
	CALL_QCSAPI(wifi_set_channel, qret, return -1,
		iface->phy->name, (qcsapi_unsigned_int)channel);
	return 0;
}

int hal_qcsapi_set_txpower(const struct iface *iface, int32_t txpower)
{
	uint32_t ch;

	if (hal_qcsapi_channel(iface, &ch) < 0)
		return -1;

	return set_qcsapi_txpower(iface->phy->name, ch, txpower);
}

int hal_qcsapi_set_ssid(const struct iface *iface, char *ssid)
{
	int qret;
	string32 ssid32 = { 0 };

	strncpy(ssid32, ssid, 32);
	CALL_QCSAPI(wifi_set_SSID, qret, return -1,
		iface->name, ssid32);
	return 0;
}

int hal_qcsapi_set_bandwidth(const struct iface *iface, uint32_t bandwidth)
{
	int qret;
#ifdef QCSAPI_WIFI_SET_VHT_REMOTE
	if (bandwidth >= 80)
		CALL_QCSAPI(wifi_set_vht, qret, return -1,
			iface->phy->name, 1);
#endif
	CALL_QCSAPI(wifi_set_bw, qret, return -1,
		iface->phy->name, bandwidth);
	return 0;
}


struct hal_ops hal_qcsapi_ops = {
	.name = "qcsapi",

	.init = hal_qcsapi_init,
	.reinit = hal_qcsapi_reinit,
	.probe = NULL,

	.mode = hal_qcsapi_mode,
	.channel = hal_qcsapi_channel,
	.txpower = hal_qcsapi_txpower,
	.region = hal_qcsapi_region,
	.bandwidth = hal_qcsapi_bandwidth,
	.bandwidth_supp = hal_qcsapi_bandwidth_supp,
	.protocol = hal_qcsapi_protocol,
	.protocol_supp = hal_qcsapi_protocol_supp,
	.ssid = hal_qcsapi_ssid,
	.bssid = hal_qcsapi_bssid,
	.phy_stats = hal_qcsapi_phy_stats,
	.cca_stats = hal_qcsapi_cca_stats,
	.channel_list = hal_qcsapi_channel_list,
	.assoc_list = hal_qcsapi_assoc_list,
	.traffic_list = hal_qcsapi_traffic_list,
	.scan_start = hal_qcsapi_scan_start,
	.scan_duration = hal_qcsapi_scan_duration,
	.scan_status = hal_qcsapi_scan_status,
	.scan_list = hal_qcsapi_scan_list,

	.set_channel = hal_qcsapi_set_channel,
	.set_txpower = hal_qcsapi_set_txpower,
	.set_ssid = hal_qcsapi_set_ssid,
	.set_bandwidth = hal_qcsapi_set_bandwidth,
};
