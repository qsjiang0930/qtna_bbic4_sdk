/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#define _GNU_SOURCE
#include <errno.h>
#include <poll.h>
#include <stdlib.h>
#include <string.h>
#include "pktlogger.h"
#include "qh_curl_ws.h"
#include "qh_event.h"
#include "qh_json_action.h"
#include "qh_json_basic_type.h"
#include "qharvestd.h"

#if HAVE_PKTLOGGER

static void *pkl = NULL;
static uint8_t *recvbuf = NULL;

static int ifname_to_ifindex(char *ifname)
{
	char *endptr;
	int index;

	if (!ifname)
		return -1;
	if (strncmp(ifname, "wifi", 4))
		return -1;
	index = strtol(ifname + 4, &endptr, 10);
	if (endptr == ifname + 4)
		return -1;
	if (index < 0 || index >= PKTLOGGER_MAX_RADIOS)
		return -1;
	return index;
}

void pktlogger_close(void)
{
	if (pkl) {
		pkl_close(pkl);
		pkl = NULL;
	}
	if (recvbuf) {
		free(recvbuf);
		recvbuf = NULL;
	}
	qh_event_cleanup(EVENT_PKL);
}

int pktlogger_init(int send_lzma)
{
	uint32_t lzma_len = PKL_RECV_BUF_MAX_SIZE;

	/* First byte (+1) is reserved for message type of qharvestd <-> cloud protocol. */
	recvbuf = malloc(PKL_RECV_BUF_MAX_SIZE + 1);
	if (recvbuf == NULL)
		return -1;

	if (pkl_open(&pkl, PKTLOGGER_D_NET_PORT, recvbuf + 1, &lzma_len) || pkl == NULL)
		goto bail;

#ifdef PKL_DBG_MESSAGE
	if (config.debug >= 4)
		pkl_debug_pk_verbose_set(pkl, PKL_DBG_MESSAGE);
#endif

	if (send_lzma) {
		struct pollfd *pfd = qh_event_get_pollfd(EVENT_WS);

		if (pfd->fd < 0)
			goto bail;

		recvbuf[0] = WS_BIN_PKTLOGGER_SCHEMA;
		if (send_ws_msg(pfd->fd, WS_BINARY, (char*)recvbuf, lzma_len + 1))
			goto bail;
	}
	return 0;
bail:
	pktlogger_close();
	return -1;
}

int pktlogger_discover(void)
{
	/* If pktlogger is not running, pkl_open() could block for a long time.
	 * Therefore it is better to check whether pktlogger is present at start
	 * of qharvestd and if it is not, then do not try to discover it again. */
	if (pktlogger_init(0)) {
		DBG_WARNING("Failed to detect pktlogger support");
		return -1;
	}
	DBG_NOTICE("Pktlogger support detected");
	pktlogger_close();
	return 0;
}

static int pktlogger_receive_cb(struct pollfd *pfd, void *arg)
{
	int stat = 0;
	uint32_t len = PKL_RECV_BUF_MAX_SIZE;
	struct pollfd *ws_pfd = qh_event_get_pollfd(EVENT_WS);

	if (pfd->revents & (POLLERR | POLLHUP | POLLNVAL)) {
		pktlogger_close();
		return -1;
	}
	if (pfd->revents != POLLIN) /* we listen only for POLLIN event */
		return -ENODATA;

	/* +1 is used to be able to add 1-byte type field in front of pktlogger payload */
	if (pkl_debug_pk_recv_data(pkl, recvbuf + 1, &len, &stat))
		return -ENODATA;

	/* We received message we were subscribed to => send it to the cloud. */
	recvbuf[0] = WS_BIN_PKTLOGGER_DATA;
	send_ws_msg(ws_pfd->fd, WS_BINARY, (char*)recvbuf, len + 1);
	return 0;
}

static int pktlogger_start_listen(void)
{
	int sockfd = -1;

	pkl_debug_pk_get_stream_socket(pkl, &sockfd);
	if (sockfd == -1)
		return -1;

	qh_event_set(EVENT_PKL, sockfd, POLLIN);
	qh_event_set_cb(EVENT_PKL, pktlogger_receive_cb, NULL);
	return 0;
}

JSON *get_json_config_pktlogger_message(struct message_control *mctl, int *ret)
{
	JSON *obj;
	JSON *aobj;
	struct pktlogger_config_t cfg;
	int phy;
	int i;

	if (pkl == NULL)
		goto bail;

	if (pkl_debug_pk_config_get(pkl, &cfg))
		goto bail;

	obj = add_json_message_header(NULL);
	aobj = JSON_NEW_ARRAY();

	for (phy = 0; phy < PKTLOGGER_MAX_RADIOS; phy++) {
		struct pktlogger_radio_config_t *phycfg = &cfg.per_radio[phy];

		if (!(cfg.radio_mask & (1 << phy)))
			continue;

		for (i = 0; i < PKTLOGGER_TYPE_MAX; i++) {
			struct pktlogger_pktlog_config_t *statcfg = &phycfg->pktlog_configs[i];
			JSON *item;

			if (statcfg->type == 0)
				continue;

			item = JSON_NEW_OBJ();
			JSON_ADD_STRING_FIELD(item, KEY_PKL_RADIO, (char*)phycfg->radioname);
			JSON_ADD_INT_FIELD(item, KEY_PKL_STAT, statcfg->type);
			JSON_ADD_INT_FIELD(item, KEY_PKL_STAT_ENABLE,
				(statcfg->flags & PKTLOGGER_CONFIG_FLAGS_ENABLED));
			JSON_ADD_INT_FIELD(item, KEY_PKL_STAT_INTERVAL, statcfg->rate);
			JSON_ADD_INT_FIELD(item, KEY_PKL_STAT_HISTORY, statcfg->history);
			JSON_ADD_ITEM(aobj, item);
		}
	}
	JSON_ADD_FIELD(obj, KEY_PKL_CONFIG, aobj);
	return obj;
bail:
	mctl->enable = 0;
	return NULL;
}

struct pkl_config_tuple {
	char *radio;
	int stat;
	int enable;
	int report;
	int interval;
	int history;
};

static struct data_description pkl_config_tuple_desc[] = {
	{KEY_PKL_RADIO, TYPE_STRING, FLAG_MANDATORY, OFFSET(pkl_config_tuple, radio)},
	{KEY_PKL_STAT, TYPE_S32, FLAG_MANDATORY, OFFSET(pkl_config_tuple, stat)},
	{KEY_PKL_STAT_ENABLE, TYPE_S32, FLAG_MANDATORY, OFFSET(pkl_config_tuple, enable)},
	{KEY_PKL_STAT_REPORT, TYPE_S32, FLAG_MANDATORY, OFFSET(pkl_config_tuple, report)},
	{KEY_PKL_STAT_INTERVAL, TYPE_S32, FLAG_MANDATORY, OFFSET(pkl_config_tuple, interval)},
	{KEY_PKL_STAT_HISTORY, TYPE_S32, FLAG_MANDATORY, OFFSET(pkl_config_tuple, history)},
	{NULL, TYPE_VOID, 0, 0}
};

int do_pktlogger_config(struct message_control *mctl, JSON *obj, JSON *robj)
{
	int phy;
	int stat;
	int i = 0;
	int listen = 0;
	struct pktlogger_config_t cfg;
	struct pkl_config_tuple cfg_tuple;
	JSON *item;
	uint8_t report[PKTLOGGER_MAX_RADIOS * PKTLOGGER_TYPE_MAX] = { 0 };

	if (pkl == NULL)
		return -1;

	if (!robj || JSON_GET_TYPE(robj) != JSON_ARRAY || pkl_debug_pk_config_get(pkl, &cfg))
		return -EAGAIN;

	while ((item = JSON_GET_ITEM(robj, i++))) {
		struct pktlogger_pktlog_config_t *statcfg;

		memset(&cfg_tuple, 0, sizeof(cfg_tuple));
		if (parse_response(item, &cfg_tuple, pkl_config_tuple_desc))
			continue;

		phy = ifname_to_ifindex(cfg_tuple.radio);
		if (phy < 0 || phy >= PKTLOGGER_MAX_RADIOS || !(cfg.radio_mask & (1 << phy)))
			continue;
		if (cfg_tuple.stat < 0 || cfg_tuple.stat >= PKTLOGGER_TYPE_MAX)
			continue;

		statcfg = &cfg.per_radio[phy].pktlog_configs[cfg_tuple.stat];
		if (statcfg->type == 0) /* type not supported by pktlogger */
			continue;

		/* NOTE: we can't ask for reporting here as this stat could be not set yet. */
		report[phy * PKTLOGGER_TYPE_MAX + cfg_tuple.stat] = (cfg_tuple.report) ? 1 : 0;
		if (cfg_tuple.enable)
			statcfg->flags |= PKTLOGGER_CONFIG_FLAGS_ENABLED;
		else
			statcfg->flags &= ~PKTLOGGER_CONFIG_FLAGS_ENABLED;
		statcfg->rate = cfg_tuple.interval;
		statcfg->history = cfg_tuple.history;
	}

	if (pkl_debug_pk_config_set(pkl, &cfg))
		return -EAGAIN;

	for (phy = 0; phy < PKTLOGGER_MAX_RADIOS; phy++) {
		if (!(cfg.radio_mask & (1 << phy)))
			continue;
		for (stat = 0; stat < PKTLOGGER_TYPE_MAX; stat++) {
			if (cfg.per_radio[phy].pktlog_configs[stat].type == 0)
				continue;
			if (report[phy * PKTLOGGER_TYPE_MAX + stat]) {
				pkl_debug_pk_send_stream_request(pkl, phy, stat,
					PKTLOGGER_REQ_COUNT_WHOLE_HISTORY_AND_REAL_TIME_DATA, 0);
				listen = 1;
			} else {
				pkl_debug_pk_stop_stream(pkl, phy, stat);
			}
		}
	}

	if (listen)
		pktlogger_start_listen();
	else
		qh_event_cleanup(EVENT_PKL);

	mctl->enable = 0;
	return 0;
}

#endif
