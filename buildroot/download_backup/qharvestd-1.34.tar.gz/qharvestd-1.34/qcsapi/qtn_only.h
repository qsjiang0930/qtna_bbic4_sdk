/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QTN_ONLY_H
#define __QTN_ONLY_H

#include "qh_json.h"
#include "qh_hal.h"

struct qh_file_list *get_filelist_config(void);
struct qh_file_list *get_filelist_gather_info(void);

JSON *get_json_log_scs_report_all_message(struct message_control *mctl, int *ret);
JSON *get_json_log_gather_info_message(struct message_control *mctl, int *ret);

int qtn_bidicmd(struct iface *iface, int cmd_id, char *arg_buffer);

#endif
