/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include "qharvestd.h"
#include "qcsapi_utils.h"
#include "qh_hal.h"

char error_msg[256];

#ifdef REMOTE_QCSAPI
#if HAVE_RPC_API
#include <qcsapi_rpc_api.h>
#endif
static CLIENT *g_client = NULL;

void free_qcsapi_client(void)
{
	if (g_client != NULL) {
		clnt_destroy(g_client);
		g_client = NULL;
	}
	DBG_ERROR("lost connection to QTN board, terminating");
	exit(1);
}

static CLIENT *try_connect(char *proto, char *remote, char *ifname)
{
	if ((!strcmp(proto, "tcp") || !strcmp(proto, "udp")) && remote) {
		return clnt_create(remote, QCSAPI_PROG, QCSAPI_VERS, proto);
	}
#if HAVE_RPC_API
	else if (!strcmp(proto, "raw") && remote && ifname) {
		macaddr_t mac = { 0 };
		if (str2mac(remote, mac) == 0)
			return qrpc_clnt_raw_create(QCSAPI_PROG, QCSAPI_VERS, ifname,
				mac, QRPC_QCSAPI_RPCD_SID);
	} else if (!strcmp(proto, "pci")) {
		return clnt_pci_create("localhost", QCSAPI_PROG, QCSAPI_VERS, NULL);
	}
#endif
	return NULL;
}

int connect_qcsapi_client(int attempts)
{
	char *proto_set_default[] = { "tcp", "udp", "raw", "pci", NULL };
	char *proto_set_explicit[] = { config.remote_proto, NULL };
	char **proto_set = (config.remote_proto) ? proto_set_explicit : proto_set_default;
	char **proto;

	if (g_client)
		return 0;

	while (attempts-- > 0) {
		for (proto = proto_set; *proto; proto++) {
			g_client = try_connect(*proto, config.remote, config.remote_iface);
			if (g_client) {
				DBG_INFO("connected to QTN board using '%s' protocol", *proto);
				client_qcsapi_set_rpcclient(g_client);
				if (!config.remote_proto)
					config.remote_proto = strdup(*proto);
				return 0;
			}
		}
		DBG_ERROR("cannot connect to QTN board using '%s' protocol (addr=%s iface=%s)",
			(config.remote_proto) ? config.remote_proto : "autodetect",
			(config.remote) ? config.remote : "",
			(config.remote_iface) ? config.remote_iface : "");
		if (attempts > 0)
			sleep(2);
	}
	return -1;
}

#endif

int hal_qcsapi_iface_mode(const char *ifname, uint32_t *mode, int ignore)
{
	int qret = -1;
	qcsapi_wifi_mode qmode = qcsapi_nosuch_mode;

	if (ifname)
		CALL_QCSAPI_IGNORE(wifi_get_mode, qret, ignore,, ifname, &qmode);
	switch (qmode) {
	case qcsapi_access_point:
		*mode = WIFI_MODE_AP;
		break;
	case qcsapi_station:
		*mode = WIFI_MODE_STA;
		break;
	case qcsapi_wds:
		*mode = WIFI_MODE_WDS;
		break;
	default:
		*mode = WIFI_MODE_UNKNOWN;
		break;
	}
	return (qret && qret != ignore) ? -1 : 0;
}

int hal_qcsapi_iface_status(const char *ifname)
{
	char status[16] = { 0 };
	int qret;

	CALL_QCSAPI_IGNORE_ALL(interface_get_status, qret, ifname, status);
	/* NOTE: this QCSAPI returns status "Error" for STA if it is not associated. */
	if (status[0] == 'U' || status[0] == 'R' || status[0] == 'E')
		return 1;
	return 0;
}

int hal_qcsapi_iface_macaddr(const char *ifname, macaddr_t macaddr)
{
	int qret = -1;
	if (ifname)
		CALL_QCSAPI(interface_get_mac_addr, qret, return -1, ifname, macaddr);
        return qret;
}


int get_qcsapi_band_supp(const char *ifname, uint8_t *band)
{
#ifdef QCSAPI_WIFI_GET_SUPPORTED_FREQ_BANDS_REMOTE
	int qret;
	uint8_t b = 0;
	string32 bands = { 0 };

	CALL_QCSAPI(wifi_get_supported_freq_bands, qret, return -1, ifname, bands);
	if (strstr(bands, "2.4G"))
		b |= BAND_11B;
	if (strstr(bands, "5G"))
		b |= BAND_11A;
	if (b == 0)
		return -1;
	*band = b;
#else
	*band = BAND_11A;
#endif
	return 0;
}

int get_qcsapi_region(const char *ifname, string16 region)
{
	int qret;
	CALL_QCSAPI(wifi_get_regulatory_region, qret,, ifname, region);
	return (qret) ? -1 : 0;
}

#if HAVE_CHAN_POWER_API
int get_qcsapi_chan_txpower(const char *ifname, uint32_t channel, power_t power, int mode)
{
	int qret;
	int bwi, ssi, bf, fem;
	struct qcsapi_chan_tx_powers_info info = { 0 };
	const qcsapi_chan_powers *pwr = (const qcsapi_chan_powers *)&info.maxpwr;
	info.channel = channel;

	CALL_QCSAPI_IGNORE_ALL(regulatory_chan_txpower_get, qret, ifname, &info, mode);
	if (qret)
		return -1;
	for (bwi = 0; bwi < BW_NUM; bwi++) {
		for (ssi = 0; ssi < SS_NUM; ssi++) {
			for (bf = 0; bf < BF_NUM; bf++) {
				for (fem = 0; fem < FEM_NUM; fem++) {
					power[PWRIDX(bwi, ssi, bf, fem)] = (*pwr)[fem][bf][ssi][bwi];
				}
			}
		}
	}
	return 0;
}
#endif

int get_qcsapi_beacon_txpower(const char *ifname, uint32_t channel, int32_t *txpower)
{
#if HAVE_CHAN_POWER_API
	power_t power = { 0 };

	if (get_qcsapi_chan_txpower(ifname, channel, power, QCSAPI_PWR_VALUE_TYPE_ACTIVE))
		return -1;
	if (power[0] <= 0)
		return -1;
	*txpower = power[0];
	return 0;
#elif HAVE_POWER_EXT_API
	int qret;
	int pwr20;
	int pwr40;
	int pwr80;

	/* Unlike regulatory/configured tx power APIs, this function retrieves
	 * current tx power directly from driver. It is exactly what we want. */
	CALL_QCSAPI(wifi_get_tx_power_ext, qret, return -1, ifname,
		channel, 0, 1, &pwr20, &pwr40, &pwr80);
	if (pwr20 <= 0)
		return -1;
	*txpower = pwr20;
	return 0;
#else
	return -ENOTSUP;
#endif
}

int get_qcsapi_configured_txpower(const char *ifname, uint32_t channel, power_t power,
	enum cfgpower_mode mode)
{
#if HAVE_CHAN_POWER_API
	return get_qcsapi_chan_txpower(ifname, channel, power, QCSAPI_PWR_VALUE_TYPE_CONFIGURED);
#else
	string16 region;
	int qret;
	int pwr;
	int bw, bwi, ssi, bf;
	int bw_num = (mode == CFGPOWER_BEACON) ? 1 : BW_NUM;
	int ss_num = (mode == CFGPOWER_ALL) ? SS_NUM : 1;
	int bf_num = (mode == CFGPOWER_ALL) ? BF_NUM : 1;

	if (get_qcsapi_region(ifname, region))
		return -1;
	if (strcmp(region, "none") == 0) {
		string32 buf;
		CALL_QCSAPI_IGNORE_ALL(bootcfg_get_parameter, qret, "max_tx_power", buf, sizeof(buf));
		memset(power, (qret) ? DEFAULT_MAX_TXPOWER : atoi(buf), sizeof(power_t));
		return 0;
	}

	for (bwi = 0, bw = 20; bwi < bw_num; bwi++, bw *= 2) {
		for (ssi = 0; ssi < ss_num; ssi++) {
			for (bf = 0; bf < bf_num; bf++) {
#if HAVE_POWER_EXT_API
				CALL_QCSAPI_IGNORE_ALL(regulatory_get_configured_tx_power_ext, qret,
					ifname, channel, region, bw, bf, ssi + 1, &pwr);
#else
				if (ssi > 0 || bf > 0)
					continue;
				CALL_QCSAPI_IGNORE_ALL(regulatory_get_configured_tx_power, qret,
					ifname, channel, region, bw, &pwr);
#endif
				power[PWRIDX(bwi, ssi, bf, 0)] = (qret) ? -1 : pwr;
			}
		}
	}
	return 0;
#endif
}

int set_qcsapi_txpower(const char *ifname, uint32_t channel, int32_t power)
{
	int qret;
	int min_power;
	power_t cfg_power = { 0 };
	string32 buf;

	if (get_qcsapi_configured_txpower(ifname, channel, cfg_power, CFGPOWER_ALL))
		return -1;

	CALL_QCSAPI_IGNORE_ALL(bootcfg_get_parameter, qret, "min_tx_power", buf, sizeof(buf));
	min_power = (qret) ? DEFAULT_MIN_TXPOWER : atoi(buf);

	if (power < min_power)
		return -1;
	if (power > cfg_power[0])
		return -1;
#if HAVE_CHAN_POWER_API
	int bwi, ssi, bf, fem;
	struct qcsapi_chan_tx_powers_info info = { 0 };
	qcsapi_chan_powers *pwr = (qcsapi_chan_powers *)&info.maxpwr;

	info.channel = channel;
	for (bwi = 0; bwi < BW_NUM; bwi++) {
		for (ssi = 0; ssi < SS_NUM; ssi++) {
			for (bf = 0; bf < BF_NUM; bf++) {
				for (fem = 0; fem < FEM_NUM; fem++) {
					int8_t set_power = cfg_power[PWRIDX(bwi, ssi, bf, fem)];
					if (set_power > 0 && power < set_power)
						set_power = power;
					(*pwr)[fem][bf][ssi][bwi] = set_power;
				}
			}
		}
	}
	CALL_QCSAPI(regulatory_chan_txpower_set, qret,, ifname, &info, QCSAPI_PWR_VALUE_TYPE_ACTIVE);
#elif HAVE_POWER_EXT_API
	int ssi, bf, err = 0;
	for (ssi = 0; ssi < SS_NUM; ssi++) {
		for (bf = 0; bf < BF_NUM; bf++) {
			int cfg_20 = cfg_power[PWRIDX(0, ssi, bf, 0)];
			int cfg_40 = cfg_power[PWRIDX(1, ssi, bf, 0)];
			int cfg_80 = (channel > 14) ? cfg_power[PWRIDX(2, ssi, bf, 0)] : 0;

			CALL_QCSAPI(wifi_set_tx_power_ext, qret,,
				ifname, channel, bf, ssi + 1,
				(power < cfg_20) ? power : cfg_20,
				(power < cfg_40) ? power : cfg_40,
				(power < cfg_80) ? power : cfg_80);
			if (qret && !err)
				err = qret;
		}
	}
	qret = err;
#else
	if (get_qcsapi_region(ifname, buf))
		return -1;
	CALL_QCSAPI(wifi_set_regulatory_channel, qret,,
		ifname, channel, buf, cfg_power[0] - power);
#endif
	return qret;
}
