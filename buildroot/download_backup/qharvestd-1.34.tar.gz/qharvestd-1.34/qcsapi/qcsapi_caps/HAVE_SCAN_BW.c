/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include <qcsapi.h>

int main(void)
{
	struct qcsapi_ap_properties ap_details;
	return ap_details.ap_bw = 0;
}
