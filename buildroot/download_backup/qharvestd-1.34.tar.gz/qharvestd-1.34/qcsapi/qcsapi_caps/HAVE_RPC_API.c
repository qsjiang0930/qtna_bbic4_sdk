/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include <qcsapi_rpc_api.h>

int main(void)
{
	CLIENT *c = clnt_pci_create(NULL, 0, 0, NULL);
	if (c == NULL)
		c = qrpc_clnt_raw_create(0, 0, NULL, NULL, QRPC_QCSAPI_RPCD_SID);
	return c == NULL;
}
