/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __PKTLOGGER_H
#define __PKTLOGGER_H

#if HAVE_PKTLOGGER

#include <stdint.h>
#include <pktlogger_common.h>
#include <pkl.h>

#include "qh_json.h"

#define KEY_PKL_CONFIG		"config"
#define KEY_PKL_RADIO		"radio"
#define KEY_PKL_STAT		"stat"
#define KEY_PKL_STAT_ENABLE	"enable"
#define KEY_PKL_STAT_REPORT	"enable_reporting"
#define KEY_PKL_STAT_HISTORY	"history"
#define KEY_PKL_STAT_INTERVAL	"interval"

#define PKL_SEND_LZMA		1

void pktlogger_close(void);
int pktlogger_init(int send_lzma);
int pktlogger_discover(void);
JSON *get_json_config_pktlogger_message(struct message_control *mctl, int *ret);
int do_pktlogger_config(struct message_control *mctl, JSON *obj, JSON *robj);

#endif
#endif
