/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QCSAPI_UTILS_H
#define __QCSAPI_UTILS_H

#include <qcsapi.h>
/* This header has to be included even if REMOTE_QCSAPI is not defined,
 * as we use it to detect availability of certain QCSAPI calls. */
#include <qcsapi_rpc/generated/qcsapi_rpc.h>
#include "qcsapi_caps/qcsapi_caps.h"
#include "qh_hal.h"

enum iface_flags {
	FLAG_NO_SCAN = 1,
};

extern char error_msg[];

#ifdef REMOTE_QCSAPI
#include <qcsapi_rpc/client/qcsapi_rpc_client.h>
#define FREE_QCSAPI_CLIENT(ret) if (ret == -ENOLINK) free_qcsapi_client()
int connect_qcsapi_client(int attempts);
void free_qcsapi_client(void);
#else
#define FREE_QCSAPI_CLIENT(ret)
#endif

#include "qh_utils.h"

#define CALL_QCSAPI_IGNORE2(api, ret, ignore, ignore2, errroutine, ...) \
	({ \
		(ret) = qcsapi_##api(__VA_ARGS__); \
		if (ret < 0 && ret != (ignore) && ret != (ignore2) && (ignore) != INT_MAX) { \
			qcsapi_errno_get_message(ret, error_msg, 256); \
			DBG_ERROR("qcsapi[%s] failed, err code = %d (%s)\n", #api, (ret), error_msg); \
			FREE_QCSAPI_CLIENT(ret); \
			errroutine; \
		} \
	})

#define CALL_QCSAPI_IGNORE(api, ret, ignore, errroutine, ...) \
	CALL_QCSAPI_IGNORE2(api, ret, ignore, ignore, errroutine, __VA_ARGS__)
#define CALL_QCSAPI(api, ret, errroutine, ...) CALL_QCSAPI_IGNORE(api, ret, 0, errroutine, __VA_ARGS__)
#define CALL_QCSAPI_IGNORE_ALL(api, ret, ...) CALL_QCSAPI_IGNORE(api, ret, INT_MAX,, __VA_ARGS__)

#define HAVE_EXT_ASSOC_API ( \
	QCSAPI_WIFI_GET_CONNECTION_MODE_REMOTE && \
	QCSAPI_WIFI_GET_MAX_MIMO_REMOTE && \
	QCSAPI_WIFI_GET_VENDOR_PER_ASSOCIATION_REMOTE && \
	QCSAPI_WIFI_GET_RX_MCS_PER_ASSOCIATION_REMOTE && \
	QCSAPI_WIFI_GET_TX_MCS_PER_ASSOCIATION_REMOTE \
	)
#define HAVE_TPUT_CAPS_API QCSAPI_WIFI_GET_TPUT_CAPS_REMOTE

#define HAVE_POWER_EXT_API ( \
	QCSAPI_REGULATORY_GET_CONFIGURED_TX_POWER_EXT_REMOTE && \
	QCSAPI_WIFI_GET_TX_POWER_EXT_REMOTE && \
	QCSAPI_WIFI_SET_TX_POWER_EXT_REMOTE \
)

#define HAVE_CHAN_POWER_API ( \
	QCSAPI_REGULATORY_CHAN_TXPOWER_GET_REMOTE && \
	QCSAPI_REGULATORY_CHAN_TXPOWER_SET_REMOTE \
)

#if PEARL_11AX_ENABLED
#define QTN_11AX 1
#else
#define QTN_11AX 0
#define IEEE80211_WIFI_MODE_AX IEEE80211_WIFI_MODE_MAX
#endif


#ifdef PEARL_PLATFORM
#define INTERFACE_DEFAULT	"wifi0_0"
#else
#define INTERFACE_DEFAULT	"wifi0"
#endif

/* For BBIC5 we need to get MAC still from "wifi0",
 * as it is present even if "wifi0_0" is turned off. */
#define MAC_INTERFACE_DEFAULT	"wifi0"

#if !HAVE_POWER_EXT_API && !HAVE_CHAN_POWER_API
/* Even though there are qcsapi_regulatory_* calls on BBIC3, there is no
 * regulatory database in new format, so these calls return error.
 * qcsapi_wifi_* calls should be used as they use old database format. */
#define qcsapi_regulatory_get_list_regulatory_channels	qcsapi_wifi_get_list_regulatory_channels
#define qcsapi_regulatory_get_configured_tx_power	qcsapi_wifi_get_configured_tx_power
#endif

#ifdef QCSAPI_QDRV_NUM_RF_STREAMS
#define RF_STREAMS QCSAPI_QDRV_NUM_RF_STREAMS
#else
#define RF_STREAMS 4
#endif

#define DEFAULT_MIN_TXPOWER 9 /* true for BBIC3, BBIC4, BBIC5 */
#define DEFAULT_MAX_TXPOWER 19

#if HAVE_CHAN_POWER_API
#define BW_NUM QCSAPI_PWR_BW_NUM
#define SS_NUM QCSAPI_PWR_IDX_SS_NUM
#define BF_NUM QCSAPI_PWR_IDX_BF_NUM
#define FEM_NUM QCSAPI_PWR_IDX_FEM_PRIPOS_NUM
#else
#define BW_NUM 3
#define SS_NUM RF_STREAMS
#define BF_NUM 2
#define FEM_NUM 1
#endif

enum cfgpower_mode {
	CFGPOWER_ALL = 0,
	CFGPOWER_BEACON,
	CFGPOWER_BW,
};

typedef int8_t power_t[BW_NUM * SS_NUM * BF_NUM * FEM_NUM];
#define PWRIDX(bwi, ssi, bf, fem) \
	(SS_NUM * BF_NUM * FEM_NUM * bwi + BF_NUM * FEM_NUM * ssi + FEM_NUM * bf + fem)

static inline void print_power_t(power_t power, enum cfgpower_mode mode)
{
	int bw, bwi, ssi, bf, fem;
	int bw_num = (mode == CFGPOWER_BEACON) ? 1 : BW_NUM;
	int ss_num = (mode == CFGPOWER_ALL) ? SS_NUM : 1;
	int bf_num = (mode == CFGPOWER_ALL) ? BF_NUM : 1;
	int fem_num = (mode == CFGPOWER_ALL) ? FEM_NUM : 1;

	for (bw = 20, bwi = 0; bwi < bw_num; bw *= 2, bwi++) {
		for (ssi = 0; ssi < ss_num; ssi++) {
			for (bf = 0; bf < bf_num; bf++) {
				for (fem = 0; fem < fem_num; fem++) {
					DBG_INFO("[%3d:%1d:%1d:%1d]: %2d dBm", bw, ssi + 1, bf, fem,
						power[PWRIDX(bwi, ssi, bf, fem)]);
				}
			}
		}
	}
}

int hal_qcsapi_iface_mode(const char *ifname, uint32_t *mode, int ignore);
int hal_qcsapi_iface_status(const char *ifname);
int hal_qcsapi_iface_macaddr(const char *ifname, macaddr_t macaddr);
int get_qcsapi_region(const char *ifname, string16 region);
int get_qcsapi_beacon_txpower(const char *ifname, uint32_t channel, int32_t *txpower);
int get_qcsapi_configured_txpower(const char *ifname, uint32_t channel, power_t power,
	enum cfgpower_mode mode);
int set_qcsapi_txpower(const char *ifname, uint32_t channel, int32_t power);
int get_qcsapi_band_supp(const char *ifname, uint8_t *band);
#endif
