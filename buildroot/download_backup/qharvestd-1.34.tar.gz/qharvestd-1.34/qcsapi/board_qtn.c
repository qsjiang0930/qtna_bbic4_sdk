/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include "qharvestd.h"
#include "qh_hal.h"
#include "qcsapi_utils.h"
#include "qh_utils.h"

int board_qtn_init_iface_list(struct board *board)
{
	struct iface *head = NULL;
	struct iface **next = &head;
	char ifname[IFNAMSIZ] = { 0 };
	int qret;
	int radio;

	board->ifnum = 0;
	board->head = NULL;

#if !QCSAPI_RADIO_GET_INTERFACE_BY_INDEX_ALL_REMOTE
	/* [radio_]get_interface_by_index calls return only AP interfaces */
	uint32_t mode;
	if (hal_qcsapi_iface_mode(config.main_interface_name, &mode, -ENODEV) < 0)
		return -1;

	/* get_interface_by_index call works only in AP mode, but if mode is UNKNOWN,
	 * then it is likely that config.main_interface_name doesn't exist at all,
	 * like in BBIC5 wifi2_0 only case. Let's try to use interface discovery
	 * calls in this case to try to find wifi2_0, as anyway UNKNOWN mode won't
	 * be accepted by the cloud. */
	if (mode != WIFI_MODE_AP && mode != WIFI_MODE_UNKNOWN) {
		head = xcalloc(1, sizeof(*head));
		strncpy(head->name, config.main_interface_name, sizeof(ifname) - 1);
		head->phy = head;
		head->hal = &hal_qcsapi_ops;
		head->board = board;
		head->up = hal_qcsapi_iface_status(head->name);
		board->ifnum = 1;
		board->head = head;
		return 0;
	}
#endif

	for (radio = 0; radio <= 2; radio++) {
		int idx;
		struct iface *phy = NULL;
		for (idx = 0;; idx++, (board->ifnum)++) {
			struct iface *iface;
#if QCSAPI_RADIO_GET_INTERFACE_BY_INDEX_ALL_REMOTE
			CALL_QCSAPI_IGNORE_ALL(radio_get_interface_by_index_all, qret,
				radio, idx, ifname, sizeof(ifname) - 1);
#elif QCSAPI_RADIO_GET_INTERFACE_BY_INDEX_REMOTE
			CALL_QCSAPI_IGNORE_ALL(radio_get_interface_by_index, qret,
				radio, idx, ifname, sizeof(ifname) - 1);
#else
			if (radio > 0)
				break;
			CALL_QCSAPI_IGNORE(get_interface_by_index, qret, -EINVAL, break,
				idx, ifname, sizeof(ifname) - 1);
#endif
			if (qret)
				break;

			*next = iface = xcalloc(1, sizeof(*iface));
			next = &iface->next;
			strcpy(iface->name, ifname);
			if (!phy)
				phy = iface;
			iface->phy = phy;
			iface->hal = &hal_qcsapi_ops;
			iface->board = board;
			iface->up = hal_qcsapi_iface_status(ifname);
		}
	}
	board->head = head;
	return 0;
}

static int board_qtn_get_firmware_version(string32 version)
{
	int qret;

	CALL_QCSAPI(firmware_get_version, qret, return -1, version, sizeof(string32));
	return 0;
}

static int board_qtn_get_platform_id(string32 id)
{
#if defined QCSAPI_GET_PLATFORM_ID_REMOTE
	int qret;
	qcsapi_unsigned_int platform_id;
	CALL_QCSAPI(get_platform_id, qret,, &platform_id);
	if (qret >= 0) {
		snprintf(id, sizeof(string32), "%u", (unsigned int)platform_id);
		return 0;
	}
#elif !defined REMOTE_QCSAPI
	char *platform = execl_get_output(F_MOD_FILE, "/scripts/platform_id");
	if (platform == NULL)
		platform = execl_get_output(F_DEV_NULL,
			PATH_QDRVCMD, "-proc", "get", "0", "platform_id");
	if (platform != NULL) {
		snprintf(id, sizeof(string32), "%s", platform);
		free(platform);
		return 0;
	}
#endif
	return -1;
}

static int board_qtn_get_reboot_cause(uint16_t *cause)
{
	unsigned int val = 0;
#if QCSAPI_SYSTEM_GET_DEBUG_VALUE_REMOTE
	int qret;
	qcsapi_unsigned_int qval;

	CALL_QCSAPI(system_get_debug_value, qret, return -1, QCSAPI_REBOOT_CAUSE, &qval);
	val = (unsigned int)qval;
#elif !defined REMOTE_QCSAPI
	unsigned int regaddr = 0;
	unsigned int regval = 0;

	/* Register address and cause bits are the same for BBIC3, BBIC4, BBIC5. */
	FILE *pf = execl_popen(0, PATH_READMEM, "0xe0000010");
	if (pf) {
		if (fscanf(pf, "%x : %x", &regaddr, &regval) == 2)
			val = regval;
		execl_pclose(pf);
	}
#endif
	/* coverity[const] - used for not to have too many macro */
	switch (val & 0x07) {
	case 1:
		*cause = 1; break;
	case 2:
		*cause = 2; break;
	case 4:
		*cause = 3; break;
	default:
		return -1;
	}
	return 0;
}

static int board_qtn_get_carrier_id(uint16_t *carrier_id)
{
	int qret;
	qcsapi_unsigned_int id;

	CALL_QCSAPI(get_carrier_id, qret, return -1, &id);
	*carrier_id = (uint16_t)id;
	return 0;
}

static inline int board_qtn_get_macaddr(macaddr_t macaddr)
{
	return hal_qcsapi_iface_macaddr(config.mac_interface_name, macaddr);
}

int board_qtn_init(struct board *board)
{
	if (!board_qtn_get_macaddr(board->macaddr))
		board->macaddr_set = 1;
	if (!board_qtn_get_firmware_version(board->firmware))
		board->firmware_set = 1;
	if (!board_qtn_get_platform_id(board->platform))
		board->platform_set = 1;
	if (!board_qtn_get_reboot_cause(&board->reboot_cause))
		board->reboot_cause_set = 1;
	if (!board_qtn_get_carrier_id(&board->carrier_id))
		board->carrier_id_set = 1;
	return 0;
}

int board_qtn_upgrade(struct board *board, char *fw_file)
{
#if HAVE_FW_UPGRADE && !defined REMOTE_QCSAPI
	int qret;
	char buf[100];

	CALL_QCSAPI(bootcfg_get_parameter, qret, return -1, "bootcmd", buf, 100);
	if (strncmp(buf, "bootselect", 10) == 0) {
		CALL_QCSAPI(bootcfg_get_parameter, qret, return -1, "bootselect", buf, 100);

		if ((buf[1] == '\0') && (buf[0] == '0')) {
			CALL_QCSAPI(flash_image_update, qret, return -1, fw_file,
				qcsapi_safety_image);
			CALL_QCSAPI(bootcfg_update_parameter, qret, return -1, "bootselect", "1");
		} else if ((buf[1] == '\0') && (buf[0] == '1')) {
			CALL_QCSAPI(flash_image_update, qret, return -1, fw_file,
				qcsapi_live_image);
			CALL_QCSAPI(bootcfg_update_parameter, qret, return -1, "bootselect", "0");
		}
	} else {
		CALL_QCSAPI(flash_image_update, qret, return -1, fw_file,
			qcsapi_live_image);
	}
	DBG_NOTICE("firmware upgraded, system rebooting...");
	/* coverity[check_return] - coverity fails to properly interpret casting to (void) for a macro */
	(void)execl_run(0, PATH_REBOOT);
	return 0;
#else
	return -ENOTSUP;
#endif
}


struct board board_qtn = {
	.name = "quantenna",
	.init_iface_list = board_qtn_init_iface_list,
	.free_iface = NULL,
	.init = board_qtn_init,
	.upgrade = board_qtn_upgrade,
	.firmware_set = 0,
	.kernel_set = 0,
	.platform_set = 0,
	.reboot_cause_set = 0,
	.carrier_id_set = 0,
};
