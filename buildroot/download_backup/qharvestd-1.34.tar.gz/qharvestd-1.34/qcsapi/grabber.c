#include "grabber.h"
#if HAVE_GRABBER
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include "qharvestd.h"
#include "qh_event.h"
#include "qh_json_basic_type.h"
#include "qh_utils.h"
#include "qcsapi_utils.h"
#if QCSAPI_GRAB_CONFIG_REMOTE
#include <qcsapi_grabber.h>
#endif

enum grabber_state {
	GRABBER_IDLE = 0,
	GRABBER_BUSY,
	GRABBER_DONE,
};

static enum grabber_state state = GRABBER_IDLE;

int grabber_func(void *data)
{
#if QCSAPI_GRAB_CONFIG_REMOTE
	FILE *file = fopen(GRABBER_FILE, "w");
	int ret = qcsapi_grabber_write_config_blob(file, QCSAPI_GRABBER_PARAM_ALL, NULL);
	if (file)
		fclose(file);
	return ret;
#elif !defined(REMOTE_QCSAPI)
	int fd = open(GINFO_FILE, O_CREAT | O_WRONLY | O_TRUNC, S_IRUSR | S_IWUSR);
	int ret = execl_write_fd(0, fd, -1, PATH_GINFO);
	if (fd >= 0)
		close(fd);
	return ret;
#else
	return 0;
#endif
}

int grabber_cb(int status, void *data)
{
	struct message_control *mctl = get_message_control(KEY_MESSAGE_LOG_GATHER_INFO_REQUEST);
	state = GRABBER_DONE;
	mctl->timeout = 1;
	return -EINTR;
}

JSON *get_json_grabber_message(struct message_control *mctl, int *ret)
{
	switch (state) {
	case GRABBER_IDLE:
		if (run_async(EVENT_GRABBER, grabber_func, grabber_cb, NULL) == 0) {
			state = GRABBER_BUSY;
			return NULL;
		}
		return get_json_default_message(mctl, ret);
	case GRABBER_DONE:
		state = GRABBER_IDLE;
		return get_json_default_message(mctl, ret);
	case GRABBER_BUSY:
		break;
	}
	return NULL;
}

#endif
