/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include <fcntl.h>
#include <qcsapi.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "qharvestd.h"
#include "qh_iface.h"
#include "qh_json.h"
#include "qh_json_basic_type.h"
#include "qh_json_action.h"
#include "qh_utils.h"
#include "qcsapi_utils.h"
#include "qtn_only.h"

#define PKTLOGGER_CONFIG_INTERVAL	3600

static void get_scs_status(char *ifname, int *status, int *have_report)
{
	int qret;
	qcsapi_unsigned_int st = 0;

	CALL_QCSAPI(wifi_get_scs_status, qret,, ifname, &st);

	if (status)
		*status = st;
	if (have_report) {
#ifdef QCSAPI_WIFI_SET_SCS_STATS_REMOTE
		/* Now SCS reports availability depends not on whether SCS enabled or not,
		 * but on whether scs_stats are enabled, which we can't check, as there is
		 * no 'get' function, but only 'set' one. On the other hand, scs_stats are
		 * enabled by default and there is no reason to disable them => let's assume
		 * that SCS reports are available if get_scs_status QCSAPI call succeeds.
		 */
		*have_report = !qret;
#else
		*have_report = st;
#endif
	}
}

JSON *get_json_log_scs_report_all_message(struct message_control *mctl, int *ret)
{
	JSON *obj = add_json_message_header(NULL);
	JSON *aobj = JSON_NEW_ARRAY();
	struct iface *iface;
	int qret;

	for (iface = iflist; iface; iface = iface->next) {
		struct JSON *ifobj;
		int status = 0;
		int have_report = 0;

		if (iface != iface->phy || strcmp(iface->hal->name, "qcsapi"))
			continue;

		ifobj = JSON_NEW_OBJ();
		JSON_ADD_STRING_FIELD(ifobj, KEY_IFACE, iface->name);

		get_scs_status(iface->name, &status, &have_report);
		JSON_ADD_INT_FIELD(ifobj, KEY_SCS_ENABLE, status);

		if (have_report) {
			struct qcsapi_scs_ranking_rpt rpt = { 0 };
			JSON *rpt_obj;
			int i;

			CALL_QCSAPI_IGNORE2(wifi_get_scs_stat_report, qret,
				-EPERM, -qcsapi_only_on_AP,, iface->name, &rpt);
			if (qret == 0) {
				rpt_obj = JSON_NEW_ARRAY();
				for (i = 0; i < rpt.num; i++) {
					JSON *p = JSON_NEW_OBJ();
					JSON_ADD_INT_FIELD(p, KEY_CHANNEL, rpt.chan[i]);
					JSON_ADD_INT_FIELD(p, KEY_DFS, rpt.dfs[i]);
					JSON_ADD_INT_FIELD(p, KEY_TXPWR, rpt.txpwr[i]);
					JSON_ADD_INT_FIELD(p, KEY_METRIC, rpt.metric[i]);
					JSON_ADD_INT_FIELD(p, KEY_CCA_INTF, rpt.cca_intf[i]);
					JSON_ADD_INT_FIELD(p, KEY_PMBL_AP, rpt.pmbl_ap[i]);
					JSON_ADD_INT_FIELD(p, KEY_PMBL_STA, rpt.pmbl_sta[i]);
					JSON_ADD_ITEM(rpt_obj, p);
				}
				JSON_ADD_FIELD(ifobj, KEY_CHANNEL_REPORT, rpt_obj);
			}
		}
		JSON_ADD_ITEM(aobj, ifobj);
	}
	JSON_ADD_FIELD(obj, KEY_INTERFACES, aobj);
	return obj;
}

int qtn_bidicmd(struct iface *iface, int cmd_id, char *arg_buffer)
{
	int qret = -1;
	char *param_name;
	char *param_value;

	switch (cmd_id) {
	case BIDICMD_SCS:
		if (arg_buffer[0] == 0 || iface == NULL)
			goto bail;
		CALL_QCSAPI(wifi_scs_enable, qret, goto bidicmd_completion_code,
			iface->name, (uint16_t)atoi(arg_buffer));
		break;

	case BIDICMD_SCS_REPORT:
		if (arg_buffer[0] == 0 || iface == NULL)
			goto bail;
		CALL_QCSAPI(wifi_set_scs_report_only, qret, goto bidicmd_completion_code,
			iface->name, (uint16_t)atoi(arg_buffer));
		break;

	case BIDICMD_OCAC:
		if (arg_buffer[0] == 0 || iface == NULL)
			goto bail;
#ifdef QCSAPI_WIFI_START_OCAC_REMOTE
		{
			uint16_t channel = 0;
			uint16_t fat = 0;
			uint16_t traffic = 0;
			uint16_t cca_intf = 0;

			for (param_name = strtok(arg_buffer, "="), param_value = strtok(NULL, " ");
			     param_name && param_value;
			     param_name = strtok(NULL, "="), param_value = strtok(NULL, " ")) {
				if (MATCH(param_name, "channel")) {
					channel = (uint16_t)atoi(param_value);
				} else if (MATCH(param_name, "fat")) {
					fat = (uint16_t)atoi(param_value);
				} else if (MATCH(param_name, "traffic")) {
					traffic = (uint16_t)atoi(param_value);
				} else if (MATCH(param_name, "cca_intf")) {
					cca_intf = (uint16_t)atoi(param_value);
				}
			}
			if (fat) {
				CALL_QCSAPI(wifi_set_ocac_thrshld, qret,
					goto bidicmd_completion_code,
					iface->name, "fat", fat);
			}
			if (traffic) {
				CALL_QCSAPI(wifi_set_ocac_thrshld, qret,
					goto bidicmd_completion_code,
					iface->name, "traffic", traffic);
			}
			if (cca_intf) {
				CALL_QCSAPI(wifi_set_ocac_thrshld, qret,
					goto bidicmd_completion_code,
					iface->name, "cca_intf", cca_intf);
			}
			CALL_QCSAPI(wifi_start_ocac, qret, goto bidicmd_completion_code,
				iface->name, channel);
		}
#endif /* QCSAPI_WIFI_START_OCAC_REMOTE */
		break;

	case BIDICMD_WIRELESS_CONF:
		if (arg_buffer[0] == 0)
			goto bail;
		param_name = param_value = arg_buffer;
		while (*param_value != '=' && *param_value != 0)
			param_value++;
		if (*param_value == 0)
			goto bail;

		*param_value = 0;
		param_value++;
		CALL_QCSAPI(config_update_parameter, qret, goto bidicmd_completion_code,
			(iface) ? iface->name : "global", param_name, param_value);
		break;

	case BIDICMD_MAC_FILTER:
		if (arg_buffer[0] == 0 || iface == NULL)
			goto bail;

		CALL_QCSAPI(wifi_set_mac_address_filtering, qret, goto bidicmd_completion_code,
			iface->name,
			(qcsapi_mac_address_filtering)(atoi(arg_buffer) ? 2 : 0));
		break;

	case BIDICMD_PKL_CONFIG:
#if HAVE_PKTLOGGER
		if (config.debug_config.pktlogger) {
			struct message_control *msg =
				get_message_control(KEY_MESSAGE_CONFIG_PKTLOGGER_REQUEST);
			msg->enable = 1;
			msg->timeout = 1;
			msg->interval = PKTLOGGER_CONFIG_INTERVAL;
			msg->backoff = 0;
			qret = 0;
		}
#endif
		break;
	}
bidicmd_completion_code:
	return qret;
bail:
	return INT_MAX;
}
