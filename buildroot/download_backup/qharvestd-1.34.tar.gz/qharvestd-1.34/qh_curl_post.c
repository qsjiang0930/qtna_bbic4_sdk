/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#define _GNU_SOURCE
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <limits.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <curl/curl.h>
#include <net/if.h>
#include "qharvestd.h"
#include "qh_event.h"
#include "qh_json.h"
#include "qh_utils.h"
#include "qh_curl_post.h"
#include "qcsapi/grabber.h"

struct qh_memory {
	FILE *fp;
	char *data;
	int size;
};

#if HAVE_CURL_MULTI
static CURLMcode qh_curl_multi_perform(CURLM *curlm, int *still_running)
{
	CURLMcode res = curl_multi_perform(curlm, still_running);
	if (res != CURLM_OK)
		DBG_ERROR("curl_multi_perform(): %s\n", curl_multi_strerror(res));
	return res;
}

#define qh_curl_event_setup(curlm, cb) qh_curl_event(curlm, cb)
#define qh_curl_event_cleanup() ((void)qh_curl_event(NULL, NULL))
static int qh_curl_event(CURLM *curlm, qh_cb cb)
{
	int maxfd = -1;
	int fd;
	int fdnum = 0;
	fd_set fdread;
	fd_set fdwrite;
	fd_set fdexcep;

	if (curlm == NULL || cb == NULL)
		goto cleanup;

	FD_ZERO(&fdread);
	FD_ZERO(&fdwrite);
	FD_ZERO(&fdexcep);

	if (curl_multi_fdset(curlm, &fdread, &fdwrite, &fdexcep, &maxfd) != CURLM_OK)
		return -1;

	for (fd = 0; fd <= maxfd; fd++) {
		int events = 0;
		if (FD_ISSET(fd, &fdread))
			events |= POLLIN;
		if (FD_ISSET(fd, &fdwrite))
			events |= POLLOUT;
		if (FD_ISSET(fd, &fdexcep))
			events |= POLLIN | POLLOUT;
		if (events) {
			if (fdnum < EVENT_CURL_NUM) {
				qh_event_set(EVENT_CURL + fdnum, fd, events);
				qh_event_set_cb(EVENT_CURL + fdnum, cb, curlm);
				if (config.curl_config.verbose > 2)
					DBG_INFO("curl: monitor fd %d (%d in total)", fd, fdnum + 1);
			} else {
				DBG_INFO("curl: unexpected behavior - more than %d fds to monitor",
					EVENT_CURL_NUM);
				return -1;
			}
			fdnum++;
		}
	}
cleanup:
	for (; fdnum < EVENT_CURL_NUM; fdnum++)
		qh_event_cleanup(EVENT_CURL + fdnum);
	return 0;
}

static int curl_cb(struct pollfd *pfd, void *arg)
{
	if (pfd->revents == 0)
		return -ENODATA;
	/* CURL 'multi' has some data to process => return to its main loop. */
	return -ECOMM;
}

#define MULTI_TIMEOUT_NORMAL 500
#define MULTI_TIMEOUT_SHORT  25
#define MULTI_TIMEOUT_MIN    5
static CURLcode qh_curl_multi_wrapper(CURL *curl)
{
	static CURLM *curlm = NULL;
	CURLMcode mcode;
	int res = -1;
	int still_running = 0;

	if (!curl)
		return CURLE_BAD_FUNCTION_ARGUMENT;
	if (!curlm)
		curlm = curl_multi_init();
	if (!curlm)
		return CURLE_OUT_OF_MEMORY;

	mcode = curl_multi_add_handle(curlm, curl);
	if (mcode) {
		curl_multi_cleanup(curlm);
		if(mcode == CURLM_OUT_OF_MEMORY)
			return CURLE_OUT_OF_MEMORY;
		else
			return CURLE_FAILED_INIT;
	}

	qh_curl_multi_perform(curlm, &still_running);
	while (still_running > 0) {
		struct timespec time = { 0, 0 };
		long multi_timeout = MULTI_TIMEOUT_NORMAL;
		long timeout;

		if (qh_curl_event_setup(curlm, curl_cb))
			multi_timeout = MULTI_TIMEOUT_SHORT;

		timeout = multi_timeout;
		curl_multi_timeout(curlm, &timeout);
		timeout = (timeout < multi_timeout) ? timeout + 1 : multi_timeout;
		if (timeout < MULTI_TIMEOUT_MIN)
			timeout = MULTI_TIMEOUT_MIN;
		if (config.curl_config.verbose > 2)
			DBG_INFO("curl: timeout = %ld ms", timeout);

		time.tv_nsec = timeout * 1000000;
		if (qh_event_listen(&time) != -ECOMM && time.tv_nsec > 0)
			nanosleep(&time, NULL);

		if (qh_curl_multi_perform(curlm, &still_running) != CURLM_OK)
			still_running = 0;
	}
	qh_curl_event_cleanup();

	while (1) {
		int msgq = 0;
		struct CURLMsg *m = curl_multi_info_read(curlm, &msgq);

		if (!m)
			break;
		if(m->msg == CURLMSG_DONE)
			res = m->data.result;
	}

	curl_multi_remove_handle(curlm, curl);
	if (res != CURLE_OK) {
		curl_multi_cleanup(curlm);
		curlm = NULL;
	}
	return (res >= 0) ? res : CURLE_OK;
}
#endif

#define CURL_TIME(curl, param) ({ \
	double var; \
	if (CURLE_OK == curl_easy_getinfo(curl, CURLINFO_##param##_TIME, &var)) { \
		DBG_INFO("%s: %.3f", #param, var); \
	} \
})

CURLcode qh_curl_easy_perform_ext(CURL *curl, long *code, int force_easy)
{
	CURLcode res;
	long http_code = 0;
	char curl_error_desc[CURL_ERROR_SIZE];

	curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_error_desc);
#if HAVE_CURL_MULTI
	if (!config.curl_config.easy && !force_easy)
		res = qh_curl_multi_wrapper(curl);
	else
#endif
		res = curl_easy_perform(curl);

	if (config.curl_config.verbose) {
		CURL_TIME(curl, NAMELOOKUP);
		CURL_TIME(curl, CONNECT);
		CURL_TIME(curl, APPCONNECT);
		CURL_TIME(curl, PRETRANSFER);
		CURL_TIME(curl, STARTTRANSFER);
		CURL_TIME(curl, TOTAL);
		CURL_TIME(curl, REDIRECT);
	}

	if (curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code) == CURLE_OK
	    && http_code >= 400) {
		/* emulate CURLOPT_FAILONERROR option */
		res = CURLE_HTTP_RETURNED_ERROR;
		snprintf(curl_error_desc, CURL_ERROR_SIZE,
			 "The requested URL returned error: %ld", http_code);
	}
	if (res != CURLE_OK)
		DBG_ERROR("curl_easy_perform(): %s\n", curl_error_desc);
	if (code)
		*code = http_code;
	return res;
}

static size_t curl_writememory(void *ptr, size_t size, size_t nmem, void *priv)
{
	size_t len = size * nmem;
	struct qh_memory *mem = (struct qh_memory *) priv;
	int written;

	if (len) {
		if (mem->fp) {
			written = fwrite(ptr, size, nmem, mem->fp);
			if (written <= 0) {
				DBG_WARNING("fwrite failed, written = %d", written);
			}
		}
		if (len > CURL_MAX_HTTP_HEADER)
			len = CURL_MAX_HTTP_HEADER;

		mem->data = (char *)realloc(mem->data, mem->size + len + 1);
		if (mem->data) {
			memcpy(&(mem->data[mem->size]), ptr, len);
			mem->size += len;
			mem->data[mem->size] = 0;
		} else {
			len = 0;
			DBG_WARNING("realloc additional %zu bytes failed", len + 1);
		}
	}
	return len;
}

static void fill_form_with_json(JSON *obj, struct curl_httppost **head,
	struct curl_httppost **tail)
{
	JSON_FOREACH(obj, key, value) {
		int jtype = JSON_GET_TYPE(value);
		switch (jtype) {
		case JSON_STRING:
			curl_formadd(head, tail, CURLFORM_COPYNAME, key,
				CURLFORM_COPYCONTENTS, JSON_GET_STRING(value), CURLFORM_END);
			break;
		default:
			continue;
			break;
		}
	}
}

static void replace_pattern(char *pattern, char *buf, int bufsz)
{
	if (strncmp(pattern, PROC_PID, sizeof(PROC_PID) - 1) == 0)
		snprintf(buf, bufsz, "/proc/%ld/%s", (long)getpid(), pattern + sizeof(PROC_PID) - 1);
	else if (strncmp(pattern, QH_CONFIG, sizeof(QH_CONFIG)) == 0)
		snprintf(buf, bufsz, "%s", config.conf_file);
	else
		snprintf(buf, bufsz, "%s", pattern);
}

static void fill_form_with_filelist(struct qh_file_list *filelist, struct curl_httppost **head,
	struct curl_httppost **tail)
{
#define QH_BUFSIZE 8192
#define MIME_GENERIC "application/octet-stream"
#define MIME_GRABBER "application/grabber"
	char file[NAME_MAX];
	char *buf_ptr = (char *)xmalloc(QH_BUFSIZE);
	struct stat st;

	for (;filelist->file; filelist++) {
		replace_pattern(filelist->file, file, sizeof(file));
		if (stat(file, &st) == -1)
			continue;
		if (filelist->tmp_file && strcmp(file, filelist->tmp_file)) {
			int read_fd;
			int write_fd;
			int count;

			/* coverity[toctou] - there is no race condition between stat and open */
			if ((read_fd = open(file, O_RDONLY)) == -1)
				continue;
			if ((write_fd = open(filelist->tmp_file, O_WRONLY | O_CREAT,
			                     st.st_mode)) == -1) {
				close(read_fd);
				continue;
			}
			do {
				count = read(read_fd, buf_ptr, QH_BUFSIZE);
				if (count <= 0)
					break;
			} while (write(write_fd, buf_ptr, count) != -1);

			close(read_fd);
			close(write_fd);
			if (count > 0)
				continue;
		}
		curl_formadd(head, tail,
			CURLFORM_COPYNAME, filelist->file,
			CURLFORM_FILENAME, filelist->file,
			CURLFORM_FILE, (filelist->tmp_file ?
					filelist->tmp_file : file),
			CURLFORM_CONTENTTYPE, (strcmp(filelist->file, GRABBER_FILE) ?
					MIME_GENERIC : MIME_GRABBER),
			CURLFORM_END);
	}

	free(buf_ptr);
}

static inline void filelist_cleanup_tmp(struct qh_file_list *filelist)
{
	for (;filelist && filelist->file; filelist++) {
		if (filelist->tmp_file)
			(void)unlink(filelist->tmp_file);
	}
}

#define QH_FILE_MAX 8			/* limit to 7 rotated files (2 in real world) */
struct qh_file_rotate {
	char *logfile;
	is_whole_msg_func is_whole_msg;
	size_t offset;		/* offset to start read file from */
	size_t new_offset;	/* we can't update 'offset' before successful curl_easy_perform */
	size_t inode;		/* inode of the file for which offset was stored */
	size_t new_inode;
	size_t bytes_to_read;
	FILE * flist[QH_FILE_MAX]; /* list of handlers of opened files */
};

struct qh_file_rotate rinfo_log = { 0 };

int is_whole_logmsg(struct qh_file_rotate *rinfo)
{
	char ch;
	char *fmap;
	int fd = fileno(rinfo->flist[0]);
	if (fd < 0)
		return 0;

	/* Writing less than PIPE_BUF (4096 on Linux) bytes to log file
	 * is guaranteed to be atomic => we should see '\n' as the last
	 * written character => we are on the message bound. */

	fmap = (char *)mmap(NULL, rinfo->new_offset, PROT_READ, MAP_SHARED, fd, 0);
	if (fmap == NULL || fmap == MAP_FAILED)
		return 0;
	ch = *(fmap + rinfo->new_offset - 1);
	munmap(fmap, rinfo->new_offset);
	if (ch != '\n')
		return 0;
	return 1;
}

void rotate_info_init(struct qh_file_rotate *rinfo, char *file, is_whole_msg_func func)
{
	rinfo->logfile = file;
	rinfo->is_whole_msg = func;
}

static inline void rotate_info_update(struct qh_file_rotate *rinfo)
{
	rinfo->offset = rinfo->new_offset;
	rinfo->inode = rinfo->new_inode;
}

static inline void rotate_info_cleanup(struct qh_file_rotate *rinfo)
{
	int i;
	for (i = 0; i < QH_FILE_MAX && rinfo->flist[i]; i++) {
		fclose(rinfo->flist[i]);
		rinfo->flist[i] = NULL;
	}
}

static int fill_form_with_logfile(struct qh_file_rotate *rinfo,
	struct curl_httppost **head, struct curl_httppost **tail)
{
#ifndef LOG_SEPARATOR
#define LOG_SEPARATOR "."
#endif
	/* NOTE: here we use the fact that inode numbers
	 * are allocated incrementally on tmpfs. */
	int i;
	int j;
	struct stat st[QH_FILE_MAX];
	struct stat st_tmp;
	long total_len;
	int ret = -EAGAIN; /* perform exponential backoff on error */

	if (rinfo->logfile[0] == 0)
		return -ENODATA;

	memset(rinfo->flist, 0, QH_FILE_MAX * sizeof(FILE *));
	for (i = -1, j = 0; j < QH_FILE_MAX; i++) {
		char fname[NAME_MAX];
		if (j == 0)
			snprintf(fname, NAME_MAX, "%s", config.logfile);
		else
			snprintf(fname, NAME_MAX, "%s%s%d", config.logfile, LOG_SEPARATOR, i);
		if (stat(fname, &st[j]) != 0) {
			if (i == -1) /* no file to process */
				goto bail;
			if (i == 0) /* not all syslogs create file.0 */
				continue;
			/* file we stopped at last time was rotated out, some logs were lost */
			rinfo->offset = 0;
			j--;
			break;
		}
		/* coverity[toctou] - there is no race condition between stat and fopen */
		if ((rinfo->flist[j] = fopen(fname, "r")) == NULL)
			goto bail;
		if (rinfo->inode == st[j].st_ino)
			break; /* remaining files have already been processed */
		j++;
	}
	if (j == QH_FILE_MAX) /* too many log files */
		goto bail;

	/* all files already opened, but we need to check that rotation
	 * didn't happen while opening them */
	if (stat(config.logfile, &st_tmp) != 0 || st_tmp.st_ino != st[0].st_ino)
		goto bail;

	/* Check that we are on the message bound. If not => bail. */
	rinfo->new_offset = st[0].st_size;
	rinfo->new_inode = st[0].st_ino;
	if (rinfo->new_offset != 0 && rinfo->is_whole_msg && !rinfo->is_whole_msg(rinfo))
		goto bail;

	/* Set up offset for the oldest file to process, because it has already
	 * been partially processed. */
	if (fseek(rinfo->flist[j], rinfo->offset, SEEK_SET) != 0)
		goto bail;

	/* Now we need to compute total length of new messages in bytes */
	total_len = 0;
	for (i = 0; i <= j; i++)
		total_len += st[i].st_size;
	/* already processed part of the most old file */
	total_len -= rinfo->offset;
	if (total_len > 0) {	/* there is new info */
		rinfo->bytes_to_read = total_len;
		curl_formadd(head, tail,
			CURLFORM_COPYNAME, LOGFILE_DEFAULT,
			CURLFORM_FILENAME, LOGFILE_DEFAULT,
			CURLFORM_STREAM, rinfo,
			CURLFORM_CONTENTSLENGTH, total_len,
			CURLFORM_CONTENTTYPE, "application/octet-stream",
			CURLFORM_END);
		return 0;
	}
	ret = -ENODATA;
bail:
	rotate_info_cleanup(rinfo);
	return ret;
}

size_t read_from_files(void *ptr, size_t size, size_t nmemb, void *userdata)
{
	struct qh_file_rotate *rinfo = (struct qh_file_rotate *)userdata;
	int i;
	size_t total_bytes_read = 0;
	size_t bytes_to_read = (size * nmemb < rinfo->bytes_to_read)
		? size * nmemb : rinfo->bytes_to_read;

	/* we need to read from the oldest file first */
	for (i = QH_FILE_MAX - 1; i >= 0; --i) {
		if (rinfo->flist[i] == NULL)
			continue;
		if (total_bytes_read >= bytes_to_read)
			break;
		total_bytes_read +=
			fread(ptr + total_bytes_read, 1, bytes_to_read - total_bytes_read,
				rinfo->flist[i]);
	}
	rinfo->bytes_to_read -= total_bytes_read;
	return total_bytes_read;
}

/* This function tries to resemble output of libcurl internal debug function,
 * but also outputs notifications about sent/received data traffic. */
static int qh_curl_debug(CURL *handle, curl_infotype type, char *data, size_t sz, void *userp)
{
	char *ptr;
	unsigned int size = (unsigned int)sz;

	switch (type) {
	case CURLINFO_TEXT:
		fprintf(stderr, "* %s", data);
		break;
	case CURLINFO_HEADER_IN:
		/* Print only HTTP headers, but not HTTP data string. */
		fprintf(stderr, "< %s", (data[0] != '\n' && data[0] != '\r') ? data : "\n");
		break;
	case CURLINFO_HEADER_OUT:
		/* Here data could be embedded into the header info string,
		 * therefore it has to be truncated. Unlike CURLINFO_HEADER_IN,
		 * here output is not splitted into multiple strings. */
		ptr = strnstr(data, "\r\n\r\n", sz);
		if (ptr) {
			size = ptr - data;
			{
				char buf[size + 1];
				snprintf(buf, size + 1, "%s", data);
				fprintf(stderr, "> %s\n\n", buf);
			}
		} else
			fprintf(stderr, "> %s", data);
		break;
	case CURLINFO_DATA_IN:
		fprintf(stderr, "<<< Recv data (%d bytes)\n", size);
		break;
	case CURLINFO_DATA_OUT:
		fprintf(stderr, ">>> Send data (%d bytes)\n", size);
		break;
	case CURLINFO_SSL_DATA_IN:
		fprintf(stderr, "<<< Recv SSL data (%d bytes)\n", size);
		break;
	case CURLINFO_SSL_DATA_OUT:
		fprintf(stderr, ">>> Send SSL data (%d bytes)\n", size);
		break;

	default:
		break;
	}
	return 0;
}

void qh_curl_set_connection_options(CURL *curl, int https)
{
	if (config.curl_config.bind_iface) {
		char ifname[IFNAMSIZ + 3];
		snprintf(ifname, IFNAMSIZ + 3, "if!%s", config.curl_config.bind_iface);
		curl_easy_setopt(curl, CURLOPT_INTERFACE, ifname);
	}
	if (config.curl_config.dns_iface) {
		CURLcode ret = CURLE_UNKNOWN_OPTION;
#if LIBCURL_VERSION_NUM >= 0x072100 /* since 7.33.0 */
		ret = curl_easy_setopt(curl, CURLOPT_DNS_INTERFACE, config.curl_config.dns_iface);
#endif
		if (ret != CURLE_OK) {
			DBG_ERROR("CURLOPT_DNS_INTERFACE[%s]: %s",
				config.curl_config.dns_iface, curl_easy_strerror(ret));
		}
	}
	if (config.curl_config.dns_list) {
		CURLcode ret =
			curl_easy_setopt(curl, CURLOPT_DNS_SERVERS, config.curl_config.dns_list);
		if (ret != CURLE_OK) {
			DBG_ERROR("CURLOPT_DNS_SERVERS[%s]: %s",
				config.curl_config.dns_list, curl_easy_strerror(ret));
		}
	}
	if (config.curl_config.verbose)
		curl_easy_setopt(curl, CURLOPT_VERBOSE, 1);
	if (config.curl_config.verbose > 1)
		curl_easy_setopt(curl, CURLOPT_DEBUGFUNCTION, qh_curl_debug);
	curl_easy_setopt(curl, CURLOPT_TIMEOUT, config.request_timeout);

	if (https) {
		if (config.curl_config.ca_file)
			curl_easy_setopt(curl, CURLOPT_CAINFO, config.curl_config.ca_file);
		if (config.curl_config.verify_peer == 0)
			curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
		if (config.curl_config.verify_host == 0)
			curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
		curl_easy_setopt(curl, CURLOPT_SSLVERSION,
			(long)(config.curl_config.ssl_version));
		if (!config.curl_config.encrypt)
			curl_easy_setopt(curl, CURLOPT_SSL_CIPHER_LIST, "NULL");
	}
}

int qh_curl_post_json(struct message_control *mctl, JSON *inobj, JSON **outobj)
{
#define JSON_DATA_FIELD "jsonData"
#define MIME_JSON "application/json"
#define MIME_MULTIPART "multipart/form-data"
	int ret = -1;
	static CURL *curl = NULL;
	CURLcode res = CURLE_OK;
	long http_code = 0;
	struct qh_memory mem = { NULL, NULL, 0 };
	struct qh_memory hmem = { NULL, NULL, 0 };
	struct curl_slist *headers = NULL;
	struct curl_httppost *formpost = NULL;
	struct curl_httppost *lastptr = NULL;
	*outobj = NULL;
	const char *str = NULL;
	const char *str1 = NULL;
	struct qh_file_rotate *rinfo = mctl->jobj;

	curl_global_init(CURL_GLOBAL_ALL);

	if (!curl)
		curl = curl_easy_init();
	if (!curl)
		goto bail;

	qh_curl_set_connection_options(curl, IS_HTTPS(mctl->url));

	if (config.debug_config.curl_debug_file) {
		mem.fp = fopen(config.debug_config.curl_debug_file, "w+");
		hmem.fp = mem.fp;
	}

	str = JSON_TO_STRING(inobj);
	if (mctl->get_filelist || mctl->flag & FLAG_ROTATION) {
		fill_form_with_json(inobj, &formpost, &lastptr);
		if (mctl->flag & FLAG_ROTATION) {
			curl_easy_setopt(curl, CURLOPT_READFUNCTION, read_from_files);
			ret = fill_form_with_logfile(rinfo, &formpost, &lastptr);
			if (ret) {
				if (ret == -ENODATA)
					DBG_INFO("no new content, ignore curl post");
				goto bail;
			}
		} else {
			fill_form_with_filelist(mctl->get_filelist(), &formpost, &lastptr);
		}
		curl_easy_setopt(curl, CURLOPT_HTTPPOST, formpost);
	} else {
		headers = curl_slist_append(headers, "Content-Type: " MIME_JSON);
		curl_easy_setopt(curl, CURLOPT_POSTFIELDS, str);
	}
	if (config.oauth.enabled && config.oauth.token) {
		char tmp[strlen(OAUTH_HEADER) + strlen(config.oauth.token) + 1];
		strcpy(tmp, OAUTH_HEADER);
		strcat(tmp, config.oauth.token);
		headers = curl_slist_append(headers, tmp);
	}

	headers = curl_slist_append(headers, "Expect:");
	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

	curl_easy_setopt(curl, CURLOPT_URL, mctl->url);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_writememory);
	/* coverity[bad_sizeof] */
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&mem);
	/* coverity[bad_sizeof] */
	curl_easy_setopt(curl, CURLOPT_HEADERDATA, (void *)&hmem);

	DBG_INFO("target: %s", mctl->url);
	DBG_INFO("request: %s", str);
	res = qh_curl_easy_perform(curl, &http_code);
	if (hmem.data && strcasestr(hmem.data, "Content-Type: " MIME_JSON)) {
		if (mem.data) {
			*outobj = JSON_PARSE(mem.data);
			str1 = JSON_TO_STRING(*outobj);
		} else {
			*outobj = NULL;
		}
		DBG((res == CURLE_OK) ? LOG_INFO : LOG_ERR, "response: %s", str1);
	}
	if (res != CURLE_OK) {
		ret = -EAGAIN;
		if (http_code == 429 && hmem.data) {
			char *str = strcasestr(hmem.data, "Retry-After: ");
			if (str) {
				int throttle;
				str += sizeof("Retry-After: ") - 1;
				throttle = strtol(str, NULL, 10);
				if (throttle > 0) {
					mctl->timeout = throttle;
					ret = -ETIME;
				}
			}
		} else if (http_code == 400 && mctl->flag & FLAG_OAUTH) {
			ret = -EACCES;
		} else if (config.oauth.enabled && http_code == 401) {
			free(config.oauth.token);
			config.oauth.token = NULL;
		} else if (res == CURLE_COULDNT_RESOLVE_HOST) {
			qh_res_init();
		}
		goto bail;
	}
	ret = 0;

bail:
	if (str)
		JSON_FREE_STRING(str);
	if (str1)
		JSON_FREE_STRING(str1);
	if (headers)
		curl_slist_free_all(headers);
	if (formpost)
		curl_formfree(formpost);
	if (mem.fp)
		fclose(mem.fp);
	if (mem.data)
		free(mem.data);
	if (hmem.data)
		free(hmem.data);
	if (curl) {
		if (res == CURLE_OK && http_code != 308 /* redirect */) {
			curl_easy_reset(curl);
		} else { /* paranoia - it is better not to reuse curl handler on error */
			curl_easy_cleanup(curl);
			curl = NULL;
		}
	}
	if (mctl->get_filelist)
		filelist_cleanup_tmp(mctl->get_filelist());
	if (mctl->flag & FLAG_ROTATION) {
		if (res == CURLE_OK && ret == 0)
			rotate_info_update(rinfo);
		rotate_info_cleanup(rinfo);
	}
	return ret;
}
