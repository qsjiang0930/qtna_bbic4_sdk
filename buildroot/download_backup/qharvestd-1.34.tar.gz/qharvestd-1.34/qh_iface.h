/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QH_IFACE_H
#define __QH_IFACE_H

#include <errno.h>
#include <net/if.h>
#include <stdio.h>
#include "qh_hal.h"

extern struct iface *iflist;
extern int ifnum;
extern macaddr_t g_macaddr;

struct iface* get_iface_list(int *ifnum);
void free_iface_list(struct iface *head, int *ifnum);
int get_wifi_mode(int default_mode);
int init_global_mac_addr(struct board *board);

#endif
