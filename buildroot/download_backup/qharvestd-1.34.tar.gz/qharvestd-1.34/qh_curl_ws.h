/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QH_CURL_WS_H
#define __QH_CURL_WS_H

#include <poll.h>
#include <time.h>
#include "qh_json.h"

#define WS_VERSION 13
#define WS_UUID "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
#define WS_DEFLATE "permessage-deflate"
#define WS_SRV_NOCTX "server_no_context_takeover"
#define WS_CLI_NOCTX "client_no_context_takeover"

enum ws_type {
	WS_TEXT = 1,
	WS_BINARY = 2,
	WS_CLOSE = 8,
	WS_PING = 9,
	WS_PONG = 10,
};

enum ws_bin_type {
	WS_BIN_PKTLOGGER_DATA = 1,
	WS_BIN_PKTLOGGER_SCHEMA,
	WS_BIN_PTY,
};

enum ws_close_code {
	WS_CLOSE_OK      = 1000,
	WS_CLOSE_PROTO   = 1002,
	WS_CLOSE_TYPE    = 1003,
	WS_CLOSE_GENERIC = 1008,
	WS_CLOSE_2BIG    = 1009,
};

struct http_hdr {
	int paylen;
	char *payload;
};

struct ws_msg {
	int type;
	int deflated;
	int paylen;
	char *payload;
};

typedef int (*msg_parser_t)(char *buf, int len, void *data);

int get_message(struct pollfd *pfd, msg_parser_t parser, void *data);
int parse_ws_msg(char *buf, int len, void *data);
int send_ws_msg(int sockfd, int type, const char *payload, int len);
int curl_ws_connect(void);
void curl_ws_cleanup(void);
void qh_disconnect_ws(char *url);
void qh_disable_ws(void);
#define ws_schedule_reconnect() ws_schedule_reconnect_timeout(0)
int ws_schedule_reconnect_timeout(int timeout);
int do_ping_ws(struct message_control *mctl, JSON *obj, JSON *robj);

#endif
