/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include <ctype.h>
#include "qharvestd.h"
#include "qh_hal.h"
#include "qh_utils.h"

int board_generic_init_iface_list(struct board *board)
{
	struct iface *head = NULL;
	struct iface **next = &head;
	struct iface *phy = NULL;
	struct iface *iface;
	int phyidx;
	int lastphyidx = -1;
	char ifname[IFNAMSIZ];
	char buf[256];
	char *tok;
	FILE *p;
	int i;

	board->ifnum = 0;
	board->head = NULL;

	p = execl_popen(0, PATH_IFCONFIG, "-a");
	if (!p)
		return -1;

	while (fgets(buf, 256, p)) {
		if (isspace((unsigned char)buf[0]))
			continue;
		if ((tok = strtok(buf, SPACE)) == NULL)
			continue;
		snprintf(ifname, sizeof(ifname), "%s", tok);
		sanitize_ifname(ifname);

		for (i = 0; i < hals_num; i++) {
			if (hals[i]->probe && hals[i]->probe(ifname, &phyidx) == 0)
				break;
		}
		if (i >= hals_num)
			continue;

		*next = iface = xcalloc(1, sizeof(*iface));
		next = &iface->next;
		strcpy(iface->name, ifname);
		if (lastphyidx != phyidx) {
			phy = iface;
			lastphyidx = phyidx;
		}
		iface->phy = phy;
		iface->hal = hals[i];
		iface->board = board;
		iface->up = get_ifup(ifname);
		(board->ifnum)++;
	}
	execl_pclose(p);

	board->head = head;
	return 0;
}

static int board_generic_get_firmware_version(string32 version)
{
	string32 str1;
	string32 str2;

	if (execl_buf_output(str1, sizeof(str1), 0, PATH_UNAME, "-r") == NULL)
		return -1;
	if (execl_buf_output(str2, sizeof(str2), 0, PATH_UNAME, "-m") == NULL)
		return -1;
	snprintf(version, sizeof(string32), "%s-%s", str1, str2);
	return 0;
}

static inline int board_generic_get_macaddr(macaddr_t macaddr)
{
	char ifname[IFNAMSIZ];
	macaddr_t mac;
	char buf[256];
	char *tok;
	FILE *p;
	int i;
	int ret = -1;

	p = execl_popen(0, PATH_IFCONFIG, "-a");
	if (!p)
		return -1;

	while (fgets(buf, 255, p)) {
		if (isspace((unsigned char)buf[0]))
			continue;
		if (strlen(buf) < IFNAMSIZ + 2)
			continue;
		if ((tok = strtok(buf, SPACE)) == NULL)
			continue;
		snprintf(ifname, sizeof(ifname), "%s", tok);
		sanitize_ifname(ifname);

		if (get_macaddr(ifname, mac))
			continue;

		for (i = 0; i < hals_num; i++) {
			if (hals[i]->probe && hals[i]->probe(ifname, NULL) == 0)
				break;
		}
		if (i >= hals_num)
			continue;

		memcpy(macaddr, mac, sizeof(macaddr_t));
		ret = 0;
		break;
	}
	execl_pclose(p);

	return ret;
}

int board_generic_init(struct board *board)
{
	if (!board_generic_get_macaddr(board->macaddr))
		board->macaddr_set = 1;
	if (!board_generic_get_firmware_version(board->firmware))
		board->firmware_set = 1;
	return 0;
}

int board_generic_upgrade(struct board *board, char *fw_file)
{
	return -ENOTSUP;
}

struct board board_generic = {
	.name = "generic",
	.init_iface_list = board_generic_init_iface_list,
	.free_iface = NULL,
	.init = board_generic_init,
	.upgrade = board_generic_upgrade,
	.firmware_set = 0,
	.kernel_set = 0,
	.platform_set = 0,
	.reboot_cause_set = 0,
	.carrier_id_set = 0,
};
