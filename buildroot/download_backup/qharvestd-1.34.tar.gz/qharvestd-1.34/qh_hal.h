/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QH_HAL_H
#define __QH_HAL_H

#include <ctype.h>
#include <stdint.h>
#include <string.h>
#include <net/if.h>
#include "qh_utils.h"

/* return value from customization script */
#define ENOTIMPL 252

/* file to store downloaded firmware before upgrade */
#define TMP_FIRMWARE_FILENAME "/tmp/firmware_tmp"

#define FLDSET(name, value) (name ## _set = 1, name = value)

#define HAL_HTCAP_LEN  26
#define HAL_VHTCAP_LEN 12

typedef char string64[65];
typedef char string32[33];
typedef char string16[17];
typedef char string2[3];

static inline int str2mac(char *str, macaddr_t mac)
{
	return (6 == sscanf(str, "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx",
		mac, mac + 1, mac + 2, mac + 3, mac + 4, mac + 5)) ? 0 : -EINVAL;
}
static inline char *mac2str(macaddr_t mac, char *str)
{
	sprintf(str, "%02x:%02x:%02x:%02x:%02x:%02x",
		mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
	return str;
}

static inline int maczero(macaddr_t mac)
{
	int i;
	for (i = 0; i < sizeof(macaddr_t) && mac[i] == 0; i++) {}
	return (i == sizeof(macaddr_t)) ? 1 : 0;
}

static inline uint32_t chan2freq(const uint32_t channel)
{
	if (channel == 0)
		return 0;
	else if (channel < 14)
		return 2407 + 5 * channel;
	else if (channel == 14)
		return 2484;
	else
		return 5000 + 5 * channel;
}

static inline uint32_t freq2chan(const uint32_t freq)
{
	if (freq == 0)
		return 0;
	else if (freq < 2484)
		return (freq - 2407) / 5;
	else if (freq == 2484)
		return 14;
	else
		return (freq - 5000) / 5;
}

static inline int validate_region(const char *const reg)
{
	/* "--" is used for QTN region "none", "00" is a "World regulatory domain",
	 * and everything else has to conform to ISO 3166-1 alpha-2 */
	if (strcmp(reg, "--") && strcmp(reg, "00") && (strlen(reg) != 2 ||
	    !(isascii((unsigned char)reg[0])) || !isalpha((unsigned char)reg[0]) ||
	    !(isascii((unsigned char)reg[1])) || !isalpha((unsigned char)reg[1])))
		return -1;
	return 0;
}

struct hal_ops;
struct board;

struct iface {
	char name[IFNAMSIZ];
	struct iface *phy;
	struct iface *next;
	struct hal_ops *hal;
	struct board *board;
	int up;
	uintptr_t priv;
};

struct board {
	const char *name;
	struct iface *head;
	int ifnum;
	uintptr_t priv;
	int (*init_iface_list)(struct board *);
	void (*free_iface)(struct iface*);
	int (*init)(struct board *);
	int (*upgrade)(struct board *, char *fw_file);

	macaddr_t macaddr;
	string32 firmware;
	string16 kernel;
	string32 platform;
	uint16_t reboot_cause;
	uint16_t carrier_id;

	uint8_t macaddr_set : 1;
	uint8_t firmware_set : 1;
	uint8_t kernel_set : 1;
	uint8_t platform_set : 1;
	uint8_t reboot_cause_set : 1;
	uint8_t carrier_id_set : 1;
};

struct cca_stats {
	int64_t total;
	int64_t rx;
	int64_t tx;
	int64_t rx_tx;
	int64_t rx_cs;
	int64_t cs;
	int64_t ed;
	int64_t cs_ed;
	int64_t idle;

	uint8_t total_set : 1;
	uint8_t rx_set : 1;
	uint8_t tx_set : 1;
	uint8_t rx_tx_set : 1;
	uint8_t rx_cs_set : 1;
	uint8_t cs_set : 1;
	uint8_t ed_set : 1;
	uint8_t cs_ed_set : 1;
	uint8_t idle_set : 1;

	uint8_t cumulative : 1;
};

struct phy_stats {
	uint32_t assoc;
	uint32_t channel;
	uint16_t atten;
	uint32_t rx_packets;
	uint32_t tx_packets;
	uint32_t tx_deferred;
	uint32_t tx_retries;
	int16_t rx_noise;
	uint16_t rx_gain;
	uint32_t fcs_err;
	uint32_t sp_fail;
	uint32_t lp_fail;
	uint32_t rx_mcs;
	uint32_t tx_mcs;
	int16_t rcpi;
	int16_t rssi;
	int16_t rssi0;
	int16_t rssi1;
	int16_t rssi2;
	int16_t rssi3;
	int16_t rssi4;
	int16_t rssi5;
	int16_t rssi6;
	int16_t rssi7;
	int16_t evm;
	int16_t evm0;
	int16_t evm1;
	int16_t evm2;
	int16_t evm3;
	int16_t evm4;
	int16_t evm5;
	int16_t evm6;
	int16_t evm7;
	int16_t rf_temp;
	int16_t bb_temp;

	uint8_t assoc_set : 1;
	uint8_t channel_set : 1;
	uint8_t atten_set : 1;
	uint8_t rx_packets_set : 1;
	uint8_t tx_packets_set : 1;
	uint8_t tx_deferred_set : 1;
	uint8_t tx_retries_set : 1;
	uint8_t rx_noise_set : 1;
	uint8_t rx_gain_set : 1;
	uint8_t fcs_err_set : 1;
	uint8_t sp_fail_set : 1;
	uint8_t lp_fail_set : 1;
	uint8_t rx_mcs_set : 1;
	uint8_t tx_mcs_set : 1;
	uint8_t rcpi_set : 1;
	uint8_t rssi_set : 1;
	uint8_t rssi0_set : 1;
	uint8_t rssi1_set : 1;
	uint8_t rssi2_set : 1;
	uint8_t rssi3_set : 1;
	uint8_t rssi4_set : 1;
	uint8_t rssi5_set : 1;
	uint8_t rssi6_set : 1;
	uint8_t rssi7_set : 1;
	uint8_t evm_set : 1;
	uint8_t evm0_set : 1;
	uint8_t evm1_set : 1;
	uint8_t evm2_set : 1;
	uint8_t evm3_set : 1;
	uint8_t evm4_set : 1;
	uint8_t evm5_set : 1;
	uint8_t evm6_set : 1;
	uint8_t evm7_set : 1;
	uint8_t rf_temp_set : 1;
	uint8_t bb_temp_set : 1;
};

struct assoc_stats {
	macaddr_t macaddr;
	uint32_t rx_rate;
	uint32_t tx_rate;
	uint32_t rx_max_rate;
	uint32_t tx_max_rate;
	uint32_t quality;
	int16_t rssi;
	int16_t snr;
	uint32_t bandwidth;
	uint32_t protocol;
	uint32_t rx_mcs;
	uint32_t tx_mcs;
	uint32_t rx_streams;
	uint32_t tx_streams;
	uint32_t time;
	uint32_t max_queued;
	uint16_t vendor;
	string32 htcaps;
	string16 vhtcaps;

	uint8_t macaddr_set : 1;
	uint8_t rx_rate_set : 1;
	uint8_t tx_rate_set : 1;
	uint8_t rx_max_rate_set : 1;
	uint8_t tx_max_rate_set : 1;
	uint8_t quality_set : 1;
	uint8_t rssi_set : 1;
	uint8_t snr_set : 1;
	uint8_t bandwidth_set : 1;
	uint8_t protocol_set : 1;
	uint8_t rx_mcs_set : 1;
	uint8_t tx_mcs_set : 1;
	uint8_t rx_streams_set : 1;
	uint8_t tx_streams_set : 1;
	uint8_t time_set : 1;
	uint8_t max_queued_set : 1;
	uint8_t vendor_set : 1;
	uint8_t htcaps_set : 1;
	uint8_t vhtcaps_set : 1;
};

struct traffic_stats {
	macaddr_t macaddr;
	uint64_t rx_bytes;
	uint64_t tx_bytes;
	uint32_t rx_packets;
	uint32_t tx_packets;
	uint32_t rx_discard;
	uint32_t tx_discard;
	uint32_t rx_error;
	uint32_t tx_error;
	uint32_t rx_unicast;
	uint32_t tx_unicast;
	uint32_t rx_multicast;
	uint32_t tx_multicast;
	uint32_t rx_broadcast;
	uint32_t tx_broadcast;
	uint32_t tx_retries;

	uint8_t macaddr_set : 1;
	uint8_t rx_bytes_set : 1;
	uint8_t tx_bytes_set : 1;
	uint8_t rx_packets_set : 1;
	uint8_t tx_packets_set : 1;
	uint8_t rx_discard_set : 1;
	uint8_t tx_discard_set : 1;
	uint8_t rx_error_set : 1;
	uint8_t tx_error_set : 1;
	uint8_t rx_unicast_set : 1;
	uint8_t tx_unicast_set : 1;
	uint8_t rx_multicast_set : 1;
	uint8_t tx_multicast_set : 1;
	uint8_t rx_broadcast_set : 1;
	uint8_t tx_broadcast_set : 1;
	uint8_t tx_retries_set : 1;
};

struct scan_stats {
	string32 ssid;
	macaddr_t bssid;
	uint32_t channel;
	int32_t rssi;
	uint32_t encrypt_proto;
	uint32_t encrypt_mode;
	uint32_t auth_mode;
	uint32_t max_rate;
	uint32_t wps_support;
	uint32_t protocol;
	uint32_t bandwidth;

	uint8_t ssid_set : 1;
	uint8_t bssid_set : 1;
	uint8_t channel_set : 1;
	uint8_t rssi_set : 1;
	uint8_t encrypt_proto_set : 1;
	uint8_t encrypt_mode_set : 1;
	uint8_t auth_mode_set : 1;
	uint8_t max_rate_set : 1;
	uint8_t wps_support_set : 1;
	uint8_t protocol_set : 1;
	uint8_t bandwidth_set : 1;
};

struct channel_desc {
	uint32_t channel;
	uint32_t txpower;

	uint8_t channel_set : 1;
	uint8_t txpower_set : 1;
};

enum wifi_mode {
	WIFI_MODE_UNKNOWN = 0,
	WIFI_MODE_AP,
	WIFI_MODE_STA,
	WIFI_MODE_WDS,
};

enum wifi_proto {
	PROTO_11A = 0x04,
	PROTO_11B = 0x01,
	PROTO_11G = 0x02,
	PROTO_11N = 0x08,
	PROTO_11AC = 0x10,
	PROTO_11AX = 0x20,
};

enum wifi_band {
	BAND_11A = 0x01,
	BAND_11B = 0x02,
};

enum proto_bitmask {
	PROTO_SINGLE = 0,
	PROTO_SET = 1,
};

static inline uint8_t proto_str2bitmask(const char *proto, int set)
{
	/* this function can parse strings like bgn, nac (set of protocols)
	 * or like a, b, g, na, ng, ac, ax (single protocol) */
	uint8_t mode = 0;
	if (strstr(proto, "ax")) {
		mode |= PROTO_11AX;
		if (!set)
			return mode;
	}
	if (strstr(proto, "ac")) {
		mode |= PROTO_11AC;
		if (!set)
			return mode;
	}
	if (strstr(proto, "g"))
		mode |= PROTO_11G;
	if (strstr(proto, "b"))
		mode |= PROTO_11B;
	if (strstr(proto, "a"))
		mode |= PROTO_11A;
	if (strstr(proto, "n"))
		mode |= PROTO_11N;
	return mode;
}

enum wifi_vendor {
	VENDOR_UNKNOWN = 0,
	VENDOR_QUANTENNA,
	VENDOR_BROADCOM,
	VENDOR_ATHEROS,
	VENDOR_RALINK,
	VENDOR_REALTEK,
	VENDOR_INTEL,
};

enum scan_flags {
	SCAN_IN_PROGRESS = 1,
};

#define HAL_BUF_LEN 16384 /* it should be enough for more than 100 entries */
extern char hal_buf[HAL_BUF_LEN];
static inline int hal_buf_check_clear(char *buf, int idx, size_t size)
{
	/* Ensure minimum limits at compile time */
	BUILD_BUG_ON(sizeof(struct assoc_stats) * 128 > HAL_BUF_LEN);
	BUILD_BUG_ON(sizeof(struct traffic_stats) * 128 > HAL_BUF_LEN);
	BUILD_BUG_ON(sizeof(struct scan_stats) * 192 > HAL_BUF_LEN);

	if ((idx + 1) * size > HAL_BUF_LEN)
		return -1;
	memset(buf + size * idx, 0, size);
	return 0;
}

struct hal_ops {
	const char *name;

	int (*init)(void);
	int (*reinit)(void);
	int (*probe)(const char *ifname, int *phyidx);

	int (*mode)(const struct iface *, uint32_t *);
	int (*channel)(const struct iface *, uint32_t *);
	int (*txpower)(const struct iface *, int32_t *);
	int (*region)(const struct iface *, string2);
	int (*bandwidth)(const struct iface *, uint32_t *);
	int (*bandwidth_supp)(const struct iface *, uint32_t *);
	int (*protocol)(const struct iface *, uint32_t *);
	int (*protocol_supp)(const struct iface *, uint32_t *);
	int (*ssid)(const struct iface *, string32);
	int (*bssid)(const struct iface *, macaddr_t);
	int (*phy_stats)(const struct iface *, struct phy_stats *);
	int (*cca_stats)(const struct iface *, struct cca_stats *);
	int (*channel_list)(const struct iface *, char *, int *);
	int (*assoc_list)(const struct iface *, char *, int *);
	int (*traffic_list)(const struct iface *, char *, int *);
	int (*scan_start)(const struct iface *, const int force);
	int (*scan_duration)(const struct iface *, uint32_t *duration);
	int (*scan_status)(const struct iface *, uint32_t *);
	int (*scan_list)(const struct iface *, char *, int *);

	int (*set_channel)(const struct iface *, uint32_t);
	int (*set_txpower)(const struct iface *, int32_t);
	int (*set_ssid)(const struct iface *, char *);
	int (*set_bandwidth)(const struct iface *, uint32_t);
};

extern struct board board_qtn;
extern struct board board_generic;
extern struct board board_brcm;
extern struct board board_qwe;
extern struct board board_mtk;
extern struct hal_ops hal_qcsapi_ops;
extern struct hal_ops hal_nl80211_ops;
extern struct hal_ops hal_wl_ops;
extern struct hal_ops hal_qwe_ops;
extern struct hal_ops hal_mtk_ops;

extern struct board *boards[];
extern struct hal_ops *hals[];
extern const int boards_num;
extern const int hals_num;

#endif
