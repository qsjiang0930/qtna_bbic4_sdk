/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <curl/curl.h>
#include "qharvestd.h"
#include "qh_event.h"
#include "qh_iface.h"
#include "qh_utils.h"
#include "qh_json.h"
#include "qh_json_basic_type.h"
#include "qh_json_message.h"
#include "qh_json_action.h"
#include "qh_json_basic_type.h"
#include "qh_curl_post.h"
#include "qh_curl_ws.h"
#include "qh_hal.h"
#ifdef HAL_QCSAPI
#include "qcsapi/qtn_only.h"
#endif

int parse_response(JSON *obj, void *data, struct data_description *data_desc)
{
	int ret = -1;
	char *pdata = (char *)data;
	JSON *o;

	if ((obj == NULL) || (data == NULL) || (data_desc == NULL))
		goto bail;
	while (data_desc->key != NULL) {
		if (JSON_GET_OBJ(obj, data_desc->key, &o) && o) {
			switch (data_desc->type) {
			case TYPE_STRING:	/* do not copy */
				if ((data_desc->flag & FLAG_MANDATORY) &&
				     JSON_GET_STRING(o) == NULL) {
					/* cJSON returns object even for NULL value */
					goto bail;
				}
				*((const char **)(pdata + data_desc->offset)) =
					JSON_GET_STRING(o);
				break;
			case TYPE_S64:
			case TYPE_U64:
				*((uint64_t *)(pdata + data_desc->offset)) =
					(uint64_t)(JSON_GET_DOUBLE(o));
				break;
			case TYPE_S32:
			case TYPE_U32:
				*((int *)(pdata + data_desc->offset)) = JSON_GET_INT(o);
				break;
			case TYPE_S16:
			case TYPE_U16:
				*((int16_t *)(pdata + data_desc->offset)) = JSON_GET_INT(o);
				break;
			case TYPE_DOUBLE:
				*((double *)(pdata + data_desc->offset)) =
					JSON_GET_DOUBLE(o);
				break;
			case TYPE_OBJECT:
				if (data_desc->flag & FLAG_RECURSIVE) {
					ret = parse_response(o, data,
						(struct data_description *)(data_desc->offset));
					if (ret)
						goto bail;
				} else {
					*((JSON **)(pdata + data_desc->offset)) = o;
				}
				break;
			case TYPE_VOID:
				break;
			default:
				goto bail;
				break;
			};
		} else if (data_desc->flag & FLAG_MANDATORY) {
			goto bail;
		}

		data_desc++;
	}

	ret = 0;
 bail:
	return ret;

}

#if HAVE_FW_UPGRADE
static int _download_file(char *url, const char *file_name)
{
	CURL *curl = curl_easy_init();
	CURLcode res = CURL_LAST;
	FILE *f = fopen(file_name, "wb");
	long offset;
	int step;
	double length;

	if (!curl || !f)
		goto bail;

	qh_curl_set_connection_options(curl, IS_HTTPS(url));
	curl_easy_setopt(curl, CURLOPT_URL, url);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, f);
	res = qh_curl_easy_perform(curl, NULL);
	if (res != CURLE_OPERATION_TIMEDOUT)
		goto bail;

	/* standard download timed out, try ranged one */
	if (CURLE_OK != curl_easy_getinfo(curl, CURLINFO_CONTENT_LENGTH_DOWNLOAD, &length))
		goto bail;

	for (offset = ftell(f), step = 1024 * 1024;
	     (res == CURLE_OK || res == CURLE_OPERATION_TIMEDOUT) && offset > 0;) {
		char range[32];
		long foffset;

		snprintf(range, 32, "%ld-%ld", offset, offset + step - 1);
		curl_easy_setopt(curl, CURLOPT_RANGE, range);
		DBG_INFO("downloading range %s (%d bytes)", range, step);
		res = qh_curl_easy_perform(curl, NULL);

		foffset = ftell(f);
		if (res == CURLE_OPERATION_TIMEDOUT) {
			step /= 4;
			if (step < 65536)
				break;
			offset = foffset;
		} else {
			offset += step;
			step *= 2;
		}

		if (foffset >= (int)length) /* the file has been received */
			break;
	}

bail:
	if (curl)
		curl_easy_cleanup(curl);
	if (f)
		fclose(f);
	return (res == CURLE_OK) ? 0 : -1;
}

char *g_firmware_download_protocols[] = {
	"http",
	NULL
};

static int _is_valid_protocol(char *url, char **protocol_list)
{
	while (*protocol_list) {
		if (strncmp(*protocol_list, url, strlen(*protocol_list)) == 0) {
			return 1;
		}
		protocol_list++;
	}
	return 0;
}

struct upgrade_response {
	char *result;
	char *url;
	char *md5;
};

static struct data_description upgrade_response_desc[] = {
	{KEY_URL, TYPE_STRING, FLAG_MANDATORY, OFFSET(upgrade_response, url)},
	{KEY_MD5SUM, TYPE_STRING, FLAG_MANDATORY, OFFSET(upgrade_response, md5)},
	{NULL, TYPE_VOID, 0, 0}
};

int do_firmware_upgrade(struct message_control *mctl, JSON *obj, JSON *robj)
{
	int ret = -1;
	char *md5 = NULL;

	struct upgrade_response response = { 0 };

	if (parse_response(robj, &response, upgrade_response_desc)) {
		goto bail;
	}

	if ((response.url == NULL) || (response.md5 == NULL)) {
		goto bail;
	}

	if (!(_is_valid_protocol(response.url, g_firmware_download_protocols))) {
		DBG_ERROR("url=%s, no valid url for firmware found", response.url);
		goto bail;
	}

	DBG_INFO("download at %s", response.url);
	if (_download_file(response.url, TMP_FIRMWARE_FILENAME) < 0) {
		goto bail;
	}
	md5 = execl_get_output(0, PATH_MD5SUM, TMP_FIRMWARE_FILENAME);
	if (md5 == NULL) {
		DBG_ERROR("failed to compute firmware md5");
		goto bail;
	}
	if (strncmp(response.md5, md5, 32) != 0) {
		DBG_ERROR("firmware md5 doesn't match");
		goto bail;
	} else {
		DBG_INFO("firmware match, burn to flash...");
	}
	/* Upgrade is supported only for the first (NPU) board */
	if (config.script)
		ret = execl_run_limit(0, 60, config.script, "upgrade", TMP_FIRMWARE_FILENAME);
	if (!config.script || ret == ENOTIMPL)
		ret = boards[0]->upgrade(boards[0], TMP_FIRMWARE_FILENAME);
	if (ret)
		DBG_ERROR("firmware upgrade failed, status=%d", ret);
 bail:
	if (md5)
		free(md5);
	return ret;
}
#endif

struct msg_timing {
	int enable;
	int interval;
	int delay;
};

struct poll_response {
	char *result;
	char *redirect_url;
	char *bidicmd_url;
	struct msg_timing poll;
	struct msg_timing config;
	struct msg_timing log_messages;
	struct msg_timing log_scs_report_all;
	struct msg_timing log_scan;
	struct msg_timing log_gather_info;
	struct msg_timing bidicmd;
	struct msg_timing upgrade;
	struct msg_timing log_capabilities;
	struct msg_timing log_bundled_stats;
	struct msg_timing check_health;
	struct health_stats health_thresholds;
	double smooth_weight;
};

static struct data_description health_thresholds_desc[] = {
	{KEY_CCA_INT, TYPE_U16, 0, OFFSET(poll_response, health_thresholds.cca_cs_ed)},
	{KEY_CCA_IDLE, TYPE_U16, 0, OFFSET(poll_response, health_thresholds.cca_idle)},
	{KEY_CNT_SP_FAIL, TYPE_S32, 0, OFFSET(poll_response, health_thresholds.sp_fail)},
	{KEY_CNT_LP_FAIL, TYPE_S32, 0, OFFSET(poll_response, health_thresholds.lp_fail)},
	{KEY_RSSI, TYPE_S16, 0, OFFSET(poll_response, health_thresholds.rssi)},
	{KEY_TX_PHY_RATE, TYPE_S32, 0, OFFSET(poll_response, health_thresholds.tx_rate)},
	{NULL, TYPE_VOID, 0, 0}
};

static struct data_description poll_response_desc[] = {
	{KEY_REDIRECT_URL, TYPE_STRING, 0, OFFSET(poll_response, redirect_url)},
	{KEY_BIDICMD_URL, TYPE_STRING, 0, OFFSET(poll_response, bidicmd_url)},
	{KEY_POLL_ENABLE, TYPE_S32, 0, OFFSET(poll_response, poll.enable)},
	{KEY_POLL_INTERVAL, TYPE_S32, 0, OFFSET(poll_response, poll.interval)},
	{KEY_POLL_DELAY, TYPE_S32, 0, OFFSET(poll_response, poll.delay)},
	{KEY_CONFIG_ENABLE, TYPE_S32, 0, OFFSET(poll_response, config.enable)},
	{KEY_CONFIG_INTERVAL, TYPE_S32, 0, OFFSET(poll_response, config.interval)},
	{KEY_CONFIG_DELAY, TYPE_S32, 0, OFFSET(poll_response, config.delay)},
	{KEY_LOG_MESSAGES_ENABLE, TYPE_S32, 0, OFFSET(poll_response, log_messages.enable)},
	{KEY_LOG_MESSAGES_INTERVAL, TYPE_S32, 0, OFFSET(poll_response, log_messages.interval)},
	{KEY_LOG_MESSAGES_DELAY, TYPE_S32, 0, OFFSET(poll_response, log_messages.delay)},
	{KEY_LOG_SCS_REPORT_ALL_ENABLE, TYPE_S32, 0, OFFSET(poll_response,
				log_scs_report_all.enable)},
	{KEY_LOG_SCS_REPORT_ALL_INTERVAL, TYPE_S32, 0, OFFSET(poll_response,
				log_scs_report_all.interval)},
	{KEY_LOG_SCS_REPORT_ALL_DELAY, TYPE_S32, 0, OFFSET(poll_response,
				log_scs_report_all.delay)},
	{KEY_LOG_SCAN_ENABLE, TYPE_S32, 0, OFFSET(poll_response, log_scan.enable)},
	{KEY_LOG_SCAN_INTERVAL, TYPE_S32, 0, OFFSET(poll_response, log_scan.interval)},
	{KEY_LOG_SCAN_DELAY, TYPE_S32, 0, OFFSET(poll_response, log_scan.delay)},
	{KEY_LOG_GATHER_INFO_ENABLE, TYPE_S32, 0, OFFSET(poll_response, log_gather_info.enable)},
	{KEY_LOG_GATHER_INFO_INTERVAL, TYPE_S32, 0, OFFSET(poll_response,
				log_gather_info.interval)},
	{KEY_LOG_GATHER_INFO_DELAY, TYPE_S32, 0, OFFSET(poll_response, log_gather_info.delay)},
	{KEY_BIDICMD_ENABLE, TYPE_S32, 0, OFFSET(poll_response, bidicmd.enable)},
	{KEY_UPGRADE_ENABLE, TYPE_S32, 0, OFFSET(poll_response, upgrade.enable)},
	{KEY_UPGRADE_INTERVAL, TYPE_S32, 0, OFFSET(poll_response, upgrade.interval)},
	{KEY_UPGRADE_DELAY, TYPE_S32, 0, OFFSET(poll_response, upgrade.delay)},
	{KEY_LOG_CAPABILITIES_ENABLE, TYPE_S32, 0, OFFSET(poll_response, log_capabilities.enable)},
	{KEY_LOG_CAPABILITIES_INTERVAL, TYPE_S32, 0, OFFSET(poll_response, log_capabilities.interval)},
	{KEY_LOG_CAPABILITIES_DELAY, TYPE_S32, 0, OFFSET(poll_response, log_capabilities.delay)},
	{KEY_LOG_BUNDLED_STATS_ENABLE, TYPE_S32, 0, OFFSET(poll_response, log_bundled_stats.enable)},
	{KEY_LOG_BUNDLED_STATS_INTERVAL, TYPE_S32, 0, OFFSET(poll_response, log_bundled_stats.interval)},
	{KEY_LOG_BUNDLED_STATS_DELAY, TYPE_S32, 0, OFFSET(poll_response, log_bundled_stats.delay)},
	{KEY_CHECK_HEALTH_ENABLE, TYPE_S32, 0, OFFSET(poll_response, check_health.enable)},
	{KEY_CHECK_HEALTH_INTERVAL, TYPE_S32, 0, OFFSET(poll_response, check_health.interval)},
	{KEY_CHECK_HEALTH_DELAY, TYPE_S32, 0, OFFSET(poll_response, check_health.delay)},
	{KEY_HEALTH_THRESHOLDS, TYPE_OBJECT, FLAG_RECURSIVE, (intptr_t)health_thresholds_desc},
	{KEY_SMOOTH_WEIGHT, TYPE_DOUBLE, 0, OFFSET(poll_response, smooth_weight)},
	{NULL, TYPE_VOID, 0, 0}
};

struct bidicmd_response {
	char *command;
	JSON *arguments;
	int request_id;
};

static struct data_description bidicmd_response_desc[] = {
	{KEY_BIDICMD_COMMAND, TYPE_STRING, FLAG_MANDATORY, OFFSET(bidicmd_response, command)},
	{KEY_BIDICMD_ARGUMENTS, TYPE_OBJECT, 0, OFFSET(bidicmd_response, arguments)},
	{KEY_BIDICMD_REQUEST_ID, TYPE_S32, 0, OFFSET(bidicmd_response, request_id)},
	{NULL, TYPE_VOID, 0, 0}
};

struct bidicmd_entry {
	int id;
	char *name;
};

static struct bidicmd_entry bidicmd_table[] = {
	{BIDICMD_REBOOT,	"reboot"	},
	{BIDICMD_SSID,		"ssid"		},
	{BIDICMD_SCS,		"scs"		},
	{BIDICMD_SCS_REPORT,	"scs_report"	},
	{BIDICMD_CHANNEL,	"channel"	},
	{BIDICMD_OCAC,		"ocac"		},
	{BIDICMD_BW,		"bw"		},
	{BIDICMD_TXPOWER,	"txpower"	},
	{BIDICMD_WIRELESS_CONF,	"wireless_conf"	},
	{BIDICMD_MAC_FILTER,	"mac_filter"	},
	{BIDICMD_FORCE_SCAN,	"force_scan"	},
	{BIDICMD_FORCE_POLL,	"force_poll"	},
	{BIDICMD_PKL_CONFIG,	"pklogger_sync"	},
	{0,			NULL		}
};

int is_bidicmd_supported(struct bidicmd_response *bidicmd_resp)
{
	struct bidicmd_entry *entry = bidicmd_table;
	while (entry->name != NULL) {
		if (strcmp(entry->name, bidicmd_resp->command) == 0)
			return entry->id;
		entry++;
	}
	return 0;
}

int do_bidicmd(struct message_control *mctl, JSON *obj /* NULL */, JSON *robj /* NULL */)
{
	struct message_control *msg;
	struct bidicmd_response bidicmd_resp = { 0 };
	int qret = -1;
	int cmd_id;
	char arg_buffer[80] = { 0 };
	JSON *arg_obj;
	JSON *res_obj = NULL;
	struct iface *iface = NULL;
	struct pollfd *pfd = qh_event_get_pollfd(EVENT_WS);
	JSON *jobj;

	if (pfd->fd < 0) {
		curl_ws_connect();
		if (config.bidicmd_url == NULL) /* just a safeguard, it shouldn't be true */
			mctl->enable = 0;
		/* Unconditionally perform exponential backoff. If connect attempt is
		 * successful, bidicmd will be disabled in corresponding handler. */
		return -EAGAIN;
	}

	jobj = obj_dequeue(&mctl->jobj);
	if (jobj == NULL)
		goto bail;

	if (parse_response(jobj, &bidicmd_resp, bidicmd_response_desc))
		goto bail;

	if (bidicmd_resp.arguments != NULL) {
		arg_obj =  JSON_GET_ITEM(bidicmd_resp.arguments, 1);
		if (arg_obj != NULL) {
			strncpy(arg_buffer, JSON_GET_STRING(arg_obj),
				sizeof(arg_buffer) - 1);
			for (iface = iflist; iface; iface = iface->next) {
				if (strcmp(iface->name, arg_buffer) == 0)
					break;
			}
			arg_buffer[0] = 0;
			if (iface == NULL)
				goto bail;
		}
		arg_obj =  JSON_GET_ITEM(bidicmd_resp.arguments, 0);
		if (arg_obj != NULL)
			strncpy(arg_buffer, JSON_GET_STRING(arg_obj), sizeof(arg_buffer) - 1);
	}

	DBG_INFO("bidicmd_resp: command %s, arguments %s, request_id %d",
		bidicmd_resp.command, arg_buffer, bidicmd_resp.request_id);

	if ((cmd_id = is_bidicmd_supported(&bidicmd_resp)) == 0) {
		goto bail;
	}

	DBG_INFO("cmd_id %d", cmd_id);

	switch (cmd_id) {
	case BIDICMD_REBOOT:
#if HAVE_BIDICMD_REBOOT
		qret = 0;
#endif
		break;

	case BIDICMD_SSID:
		if (arg_buffer[0] == 0 || iface == NULL)
			goto bail;
		if (config.script)
			qret = execl_run(0, config.script, "set", "ssid", arg_buffer, iface->name);
		if (!config.script || qret == ENOTIMPL)
			qret = iface->hal->set_ssid(iface, arg_buffer);
		break;

	case BIDICMD_CHANNEL:
		if (arg_buffer[0] == 0 || iface == NULL)
			goto bail;
		if (config.script)
			qret = execl_run(0, config.script, "set", "channel", arg_buffer, iface->name);
		if (!config.script || qret == ENOTIMPL)
			qret = iface->hal->set_channel(iface, (uint32_t)atoi(arg_buffer));
		break;

	case BIDICMD_BW:
		if (arg_buffer[0] == 0 || iface == NULL)
			goto bail;
		if (config.script)
			qret = execl_run(0, config.script, "set", "bandwidth", arg_buffer, iface->name);
		if (!config.script || qret == ENOTIMPL)
			qret = iface->hal->set_bandwidth(iface, (uint32_t)atoi(arg_buffer));
		break;

	case BIDICMD_TXPOWER:
		if (arg_buffer[0] == 0 || iface == NULL)
			goto bail;
		if (config.script)
			qret = execl_run(0, config.script, "set", "txpower", arg_buffer, iface->name);
		if (!config.script || qret == ENOTIMPL)
			qret = iface->hal->set_txpower(iface, (uint32_t)atoi(arg_buffer));
		break;

	case BIDICMD_FORCE_SCAN:
		msg = get_message_control(KEY_MESSAGE_LOG_SCAN_REQUEST);
		msg->flag |= FLAG_FORCE_SCAN;
		qret = qh_process_message(msg);
		break;

	case BIDICMD_FORCE_POLL:
		msg = get_message_control(KEY_MESSAGE_POLL_REQUEST);
		msg->timeout = 1;
		qret = 0;
		break;

#ifdef HAL_QCSAPI
	default:
		qret = qtn_bidicmd(iface, cmd_id, arg_buffer);
		if (qret == INT_MAX)
			goto bail;
#endif
	}

	obj = add_json_message_header(obj);
	JSON_ADD_INT_FIELD(obj, KEY_BIDICMD_REQUEST_ID, bidicmd_resp.request_id);
	JSON_ADD_INT_FIELD(obj, KEY_BIDICMD_STATUS_CODE, qret);
	if (res_obj)
		JSON_ADD_FIELD(obj, KEY_BIDICMD_RESPONSE, res_obj);

	/* We do not retry to send status code because we do not listen websockets for
	 * new incoming messages until current bidicmd gets processed. */
	qh_curl_post_json(mctl, obj, &robj);
#if HAVE_BIDICMD_REBOOT
	if (cmd_id == BIDICMD_REBOOT) {
		curl_ws_cleanup();
		DBG_NOTICE("do_bidicmd: system rebooting...");
		if (execl_run(0, PATH_REBOOT))
			goto bail;
		config.running = 0;
	}
#endif

bail:
	if (jobj)
		JSON_PUT_REF(jobj);
	if (obj)
		JSON_PUT_REF(obj);
	if (robj)
		JSON_PUT_REF(robj);
	if (mctl->jobj)
		mctl->timeout = 1;
	else
		mctl->enable = 0;
	return 0;
}


#define DEFAULT_SMOOTH_WEIGHT 0.2
#define DEFAULT_SMOOTH_ITERATIONS 5
struct health_stats g_default_health_thresholds = {
	.cca_cs_ed = UINT16_MAX,
	.cca_idle = 0,
	.sp_fail = UINT32_MAX,
	.lp_fail = UINT32_MAX,
	.rssi = INT16_MIN,
	.tx_rate = 0,
};
struct health_stats g_health_thresholds;
struct health_stats g_smoothed_health_stats = { 0 };
int g_health_flags = 0;
double g_smooth_weight = DEFAULT_SMOOTH_WEIGHT;
unsigned int g_check_health_iterations = 0;
int do_check_health(struct message_control *mctl, JSON *obj, JSON *robj)
{
	struct health_stats health_stats = { 0 };
	struct cca_stats cca1[ifnum];
	struct cca_stats cca2[ifnum];
	struct timespec sleep_time = { 0, 250000000 };
	int health_flags = 0;
	struct iface *iface;
	int ifidx;

	health_stats.cca_idle = 1000;
	health_stats.rssi = INT16_MAX;
	health_stats.tx_rate = UINT32_MAX;
	memset(cca1, 0, sizeof(cca1));
	memset(cca2, 0, sizeof(cca2));

	for (iface = iflist, ifidx = 0; iface; iface = iface->next, ifidx++) {
		if (get_cca_stats(iface, &cca1[ifidx], NULL))
			continue;
	}

	/* 250ms is enough for cumulative CCA counters to be updated */
	qh_event_listen_sleep(&sleep_time);

	for (iface = iflist, ifidx = 0; iface; iface = iface->next, ifidx++) {
		if (get_cca_stats(iface, &cca2[ifidx], &cca1[ifidx]))
			continue;
	}

	for (iface = iflist, ifidx = 0; iface; iface = iface->next, ifidx++) {
		struct phy_stats ps = { 0 };
		struct cca_stats *cca = &cca2[ifidx];
		int len;
		int i;

		if (iface->hal->assoc_list(iface, hal_buf, &len) < 0)
			continue;
		for (i = 0; i < len; i++) {
			struct assoc_stats *as = (struct assoc_stats *)hal_buf + i;

			if (as->rssi_set && as->rssi < health_stats.rssi)
				health_stats.rssi = as->rssi;
			if (as->tx_rate_set && as->tx_rate < health_stats.tx_rate)
				health_stats.tx_rate = as->tx_rate;
		}

		if (iface->phy != iface || iface->hal->phy_stats(iface, &ps) < 0)
			continue;
		if (ps.sp_fail_set && ps.sp_fail > health_stats.sp_fail)
			health_stats.sp_fail = ps.sp_fail;
		if (ps.lp_fail_set && ps.lp_fail > health_stats.lp_fail)
			health_stats.lp_fail = ps.lp_fail;
		if (cca->cs_ed_set && cca->cs_ed > health_stats.cca_cs_ed)
			health_stats.cca_cs_ed = cca->cs_ed;
		if (cca->idle_set && cca->idle < health_stats.cca_idle)
			health_stats.cca_idle = cca->idle;
	}

#define SMOOTH(field) do { g_smoothed_##field = \
	g_smoothed_##field * (1 - g_smooth_weight) + field * g_smooth_weight; } while(0)
#define CHECK_HEALTH_STAT(flag, field, op, value) do { \
	DBG_INFO("%s value=%d, threshold=%d", #field, g_smoothed_##field, value); \
	if (g_smoothed_##field op value) { \
		health_flags |= 1 << HEALTH_FLAG_##flag; \
	} } while(0)

	if (g_check_health_iterations) {
		SMOOTH(health_stats.cca_cs_ed);
		SMOOTH(health_stats.cca_idle);
		SMOOTH(health_stats.sp_fail);
		SMOOTH(health_stats.lp_fail);
		if (health_stats.rssi != INT16_MAX)
			SMOOTH(health_stats.rssi);
		if (health_stats.tx_rate != UINT32_MAX)
			SMOOTH(health_stats.tx_rate);
	} else {
		g_smoothed_health_stats = health_stats;
	}
	CHECK_HEALTH_STAT(CCA_INT,
		health_stats.cca_cs_ed, >, g_health_thresholds.cca_cs_ed);
	CHECK_HEALTH_STAT(CCA_IDLE,
		health_stats.cca_idle, <, g_health_thresholds.cca_idle);
	CHECK_HEALTH_STAT(CNT_SP_FAIL,
		health_stats.sp_fail, >, g_health_thresholds.sp_fail);
	CHECK_HEALTH_STAT(CNT_LP_FAIL,
		health_stats.lp_fail, >, g_health_thresholds.lp_fail);
	if (health_stats.rssi != INT16_MAX)
		CHECK_HEALTH_STAT(RSSI,
			health_stats.rssi, <, g_health_thresholds.rssi);
	if (health_stats.tx_rate != UINT32_MAX)
		CHECK_HEALTH_STAT(TX_PHY_RATE,
			health_stats.tx_rate, <, g_health_thresholds.tx_rate);

	/* Local copy of health flags is needed for not to update g_health_flags
	 * if there are insufficient number of performed smooth iterations, so
	 * if regular poll will be sent it will not contain unsmoothed metrics.
	 */
	if (++g_check_health_iterations > DEFAULT_SMOOTH_ITERATIONS) {
		if (health_flags && !g_health_flags) {
			struct message_control *m =
				get_message_control(KEY_MESSAGE_POLL_REQUEST);
			m->timeout = 1; //force poll
			DBG_INFO("Device metrics are bad, poll request forced");
		}
		g_health_flags = health_flags;
	} else {
		g_health_flags = 0;
	}
	return 0;
}


struct oauth_response {
	char *token;
	char *type;
	char *scope;
	int32_t expire;
};

static struct data_description oauth_response_desc[] = {
	{KEY_TOKEN, TYPE_STRING, FLAG_MANDATORY, OFFSET(oauth_response, token)},
	{KEY_TOKEN_TYPE, TYPE_STRING, 0, OFFSET(oauth_response, type)},
	{KEY_SCOPE, TYPE_STRING, 0, OFFSET(oauth_response, scope)},
	{KEY_EXPIRE, TYPE_S32, 0, OFFSET(oauth_response, expire)},
	{NULL, TYPE_VOID, 0, 0}
};

int do_oauth(struct message_control *mctl, JSON *obj, JSON *robj)
{
	struct oauth_response oauth_resp = { 0 };
	if (parse_response(robj, &oauth_resp, oauth_response_desc))
		return -EACCES;
	config.oauth.token = xstrdup(oauth_resp.token);
	config.oauth.expire = oauth_resp.expire * 8 / 10; /* renew access token in advance */
	return -ERESTART;
}

void set_message_timing(struct message_control *msg, struct msg_timing timing)
{
	int was_enabled;
	if (!msg || timing.enable < 0)
		return;
	was_enabled = msg->enable;
	msg->enable = (timing.interval > 0) ? timing.enable : 0;
	msg->interval = timing.interval;
	if (msg->enable) {
		if (was_enabled > 0) { //not disabled && not enabled initially
			if (timing.interval < msg->timeout)
				msg->timeout = timing.interval;
		} else {
			msg->timeout = timing.delay ? timing.delay : 1;
		}
	}
	DBG_INFO("%s: [was]enabled=[%d]%d, delay=%d, interval=%d, timeout=%d",
		msg->name, was_enabled, msg->enable, timing.delay,
		msg->interval, msg->timeout);
}

int do_poll(struct message_control *mctl, JSON *obj, JSON *robj)
{
	int ret = -1;

	struct message_control *msg;
	struct poll_response response = { 0 };

	response.poll.enable = response.config.enable = -1;
	response.log_messages.enable = response.upgrade.enable = -1;
	response.check_health.enable = -1;
	response.health_thresholds = g_default_health_thresholds;
	response.smooth_weight = DEFAULT_SMOOTH_WEIGHT;
	g_health_thresholds = g_default_health_thresholds;

	if (parse_response(robj, &response, poll_response_desc)) {
		goto bail;
	}

	if (response.redirect_url) {
		if (config.base_url && strcmp(config.base_url, response.redirect_url) == 0)
			goto process_response;
		DBG_NOTICE("redirected to '%s'", response.redirect_url);
		if (config.base_url)
			free(config.base_url);
		config.base_url = xstrdup(response.redirect_url);
		init_message_controls();
		/* set timeout to 0, return -ERESTART => immediately try one more time =>
		 * faster redirect, but is slows down if we have loop in redirects */
		mctl->timeout = 0;
		return -ERESTART;
	} else {
 process_response:
		msg = get_message_control(KEY_MESSAGE_POLL_REQUEST);
		if (msg->enable == INITIAL_ENABLE)
			DBG_NOTICE("qharvestd successfully initialized by the cloud");
		set_message_timing(msg, response.poll);
		msg = get_message_control(KEY_MESSAGE_CONFIG_REQUEST);
		set_message_timing(msg, response.config);
		msg = get_message_control(KEY_MESSAGE_LOG_GATHER_INFO_REQUEST);
		set_message_timing(msg, response.log_gather_info);
		msg = get_message_control(KEY_MESSAGE_LOG_MESSAGES_REQUEST);
		set_message_timing(msg, response.log_messages);
		msg = get_message_control(KEY_MESSAGE_LOG_SCS_REPORT_ALL_REQUEST);
		set_message_timing(msg, response.log_scs_report_all);
		msg = get_message_control(KEY_MESSAGE_LOG_SCAN_REQUEST);
		set_message_timing(msg, response.log_scan);
		if (config.upgrade) {
			msg = get_message_control(KEY_MESSAGE_UPGRADE_REQUEST);
			set_message_timing(msg, response.upgrade);
		}
		msg = get_message_control(KEY_MESSAGE_CHECK_HEALTH);
		if ((msg) && (response.check_health.enable > 0)) {
			g_smooth_weight = response.smooth_weight;
			g_health_thresholds = response.health_thresholds;
		} else {
			g_check_health_iterations = 0;
			g_health_flags = 0;
		}
		set_message_timing(msg, response.check_health);
		msg = get_message_control(KEY_MESSAGE_LOG_CAPABILITIES_REQUEST);
		set_message_timing(msg, response.log_capabilities);
		msg = get_message_control(KEY_MESSAGE_LOG_BUNDLED_STATS_REQUEST);
		set_message_timing(msg, response.log_bundled_stats);

		/* Bidirectional commands are received from WebSockets connection.
		 * BIDICMD message is used to connect to websockets server (auto rescheduling)
		 * and to handle received command and send a response (explicit rescheduling). */
		if (config.ws.url)
			response.bidicmd_url = config.ws.url;
		if (response.bidicmd.enable && response.bidicmd_url) {
			if (config.bidicmd_url &&
			    strcmp(config.bidicmd_url, response.bidicmd_url)) {
				qh_disable_ws();
			}
			if (!config.bidicmd_url) {
				config.bidicmd_url = xstrdup(response.bidicmd_url);
				DBG_INFO("got new bidicmd_url: %s", config.bidicmd_url);
				ws_schedule_reconnect();
			}
		} else if (config.bidicmd_url) {
			qh_disable_ws();
		}

		//Now we reset timeout for poll message as for any other message.
		//We also do not need to restart processing of the messages,
		//because poll message is processed first and all changes the poll
		//introduced will be applied to subsequent messages.
		ret = 0;
	}

bail:
	return ret;
}
