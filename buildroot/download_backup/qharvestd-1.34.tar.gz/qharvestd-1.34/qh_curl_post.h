/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QH_CURL_POST_H
#define __QH_CURL_POST_H

#include <curl/curl.h>
#include "qh_json.h"

#ifndef HAVE_CURL_MULTI
#define HAVE_CURL_MULTI 1
#endif

#define IS_HTTPS(url) (strncmp((url), "https:", 6) == 0)

#define PROC_PID "/proc/$$/"
#define QH_CONFIG "qharvestd.conf"

struct qh_file_rotate;
extern struct qh_file_rotate rinfo_log;

typedef int (*is_whole_msg_func)(struct qh_file_rotate *rinfo);
int is_whole_logmsg(struct qh_file_rotate *rinfo);
void rotate_info_init(struct qh_file_rotate *rinfo, char *file, is_whole_msg_func func);

#define OAUTH_HEADER "Authorization: Bearer "
int qh_curl_post_json(struct message_control *mctl, JSON *inobj, JSON **outobj);
void qh_curl_set_connection_options(CURL *curl, int https);
#define CURL_FORCE_EASY 1
#define qh_curl_easy_perform(curl, code) qh_curl_easy_perform_ext(curl, code, 0)
CURLcode qh_curl_easy_perform_ext(CURL *curl, long *http_code, int force_easy);

#endif
