/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __HAL_MTK_H
#define __HAL_MTK_H

#define IWPRIV_CFG(iface) PATH_IWPRIV, (iface), "maui", "curconfig"
#define IWPRIV_CAP(iface) PATH_IWPRIV, (iface), "maui", "capability"
#define IWPRIV_PHY(iface) PATH_IWPRIV, (iface), "maui", "phystats"

#endif
