/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include "qharvestd.h"
#include "qh_hal.h"
#include "qh_utils.h"
#include "hal_mtk.h"

static uint8_t best_proto(uint8_t mask)
{
	/* better proto has higher bit */
	int i;
	for (i = 0; mask; i++)
		mask >>= 1;
	return (i) ? (1 << (i - 1)) : 0;
}

static int get_rate(int mcs, int bw, int sgi)
{
	int rate;
	int rate_20lgi[32] = {  65,  130,  195,  260,  390,  520,  585,  650,
	                       130,  260,  390,  520,  780, 1040, 1170, 1300,
	                       195,  390,  585,  780, 1170, 1560, 1755, 1950,
	                       260,  520,  780, 1040, 1560, 2080, 2340, 2600 };
	int rate_20sgi[32] = {  72,  144,  217,  289,  433,  578,  650,  722,
	                       144,  289,  433,  578,  867, 1156, 1300, 1444,
	                       217,  433,  650,  867, 1300, 1733, 1950, 2167,
	                       288,  576,  868, 1156, 1732, 2312, 2600, 2888 };

	if (mcs < 0 || mcs > 31)
		return -1;
	rate = (sgi) ? rate_20sgi[mcs] : rate_20lgi[mcs];
	if (bw == 40)
		rate *= 2.077562327;
	return rate * 1024 / 10;
}

static int parse_mcs_str(char *str)
{
	char *tok = strstr(str, "MCS");
	if (tok == NULL)
		return -1;
	return atoi(tok + 3);
}


static int parse_rate_str(char *str, int *rate, int *mcs, int *sgi)
{
	char *rate_str = gettok(str, "Rate", 2, SPACE);
	char *bw_str = strtok(NULL, SPACE);
	char *gi_str = strtok(NULL, SPACE);
	int bw;
	int r;
	int m;
	int gi;

	if (rate_str == NULL || bw_str == NULL || gi_str == NULL)
		return -1;
	if ((bw = atoi(bw_str)) == 0)
		return -1;
	r = atoi(rate_str);
	gi = (gi_str[0] == 'L') ? 0 : 1;

	if (r) {
		*rate = r * 1024;
		*mcs = -1;
		*sgi = gi;
		return 0;
	}

	if ((m = parse_mcs_str(rate_str)) < 0)
		return -1;
	if ((r = get_rate(m, bw, gi)) < 0)
		return -1;
	*rate = r;
	*mcs = m;
	*sgi = gi;
	return 0;
}

int hal_mtk_mode(const struct iface *iface, uint32_t *mode)
{
	string32 buf;
	*mode = execl_output_grep_awk(buf, sizeof(buf), 0, GREP("_STA"), AWK(0, NULL),
		IWPRIV_CFG(iface->name)) ? WIFI_MODE_STA : WIFI_MODE_AP;
	return 0;
}

int hal_mtk_channel(const struct iface *iface, uint32_t *channel)
{
	int chan = execl_get_int(0, GREP("Channel:"), AWK(3, SPACE), IWPRIV_CFG(iface->name));
	if (chan < 0)
		return -1;
	*channel = chan;
	return 0;
}

int hal_mtk_txpower(const struct iface *iface, int32_t *txpower)
{
	int txpwr = execl_get_int(0, GREP("dbm"), AWK(8, SPACE), IWPRIV_PHY(iface->name));
	if (txpwr <= 0)
		return -1;
	*txpower = txpwr;
	return 0;
}

int hal_mtk_region(const struct iface *iface, string2 region)
{
	char *str = execl_output_grep_awk(NULL, 0, 0, GREP("Region:"), AWK(3, SPACE),
		IWPRIV_CFG(iface->name));
	if (!str)
		return -1;
	if (validate_region(str)) {
		free(str);
		return -1;
	}
	snprintf(region, sizeof(string2), "%s", str);
	free(str);
	return 0;
}

int hal_mtk_bandwidth(const struct iface *iface, uint32_t *bandwidth)
{
	int bw = execl_get_int(0, GREP("Bandw"), AWK(2, "_"), IWPRIV_CFG(iface->name));
	if (bw < 0)
		return -1;
	*bandwidth = (bw == 40) ? 40 : 20;
	return 0;
}

int hal_mtk_bandwidth_supp(const struct iface *iface, uint32_t *bandwidth)
{
	*bandwidth = 40; /* according to internal implementation */
	return 0;
}

int hal_mtk_protocol(const struct iface *iface, uint32_t *protocol)
{
	char mask[IFNAMSIZ];

	if (execl_output_grep_awk(mask, sizeof(mask), 0, GREP("Proto"), AWK(3, SPACE),
		IWPRIV_CFG(iface->name)) == NULL)
		return -1;

	if (strchr(mask, 'N'))
		*protocol = PROTO_11N;
	else if (strchr(mask, 'G'))
		*protocol = PROTO_11G;
	else if (strchr(mask, 'B'))
		*protocol = PROTO_11B;
	else
		return -1;
	return 0;
}

int hal_mtk_protocol_supp(const struct iface *iface, uint32_t *protocol)
{
	*protocol = PROTO_11B | PROTO_11G | PROTO_11N; /* according to internal implementation */
	return 0;
}

int hal_mtk_ssid(const struct iface *iface, string32 ssid)
{
	char buf[256];
	char *str;
	char *ch;
	int dash = 5;

	if (execl_output_grep_awk(buf, sizeof(buf), F_AT_START, GREP("SSID"), AWK(0, NULL),
		IWPRIV_CFG(iface->name)) == NULL)
		return -1;
	str = buf + 6;
	for (ch = str + strlen(str); *ch != ' ' && ch > str; ch--);
	for (; dash && ch > str; ch--) {
		if (*ch == '-')
			dash--;
	}
	if (dash > 0 || ch <= str)
		return -1;
	*ch = '\0';
	snprintf(ssid, sizeof(string32), "%s", str);
	return 0;
}

int hal_mtk_bssid(const struct iface *iface, macaddr_t bssid)
{
	char *str = execl_output_grep_awk(NULL, 0, 0, GREP("MAC:"), AWK(3, SPACE),
		IWPRIV_CFG(iface->name));
	if (!str)
		return -1;
	str2mac(str, bssid);
	free(str);
	return 0;
}

int hal_mtk_assoc_list(const struct iface *iface, char *halbuf, int *len)
{
	struct assoc_stats *asbuf = (struct assoc_stats *)halbuf;
	struct assoc_stats *as = asbuf - 1;
	char buf[256];
	char *tok;
	FILE *p;
	int sgi = -1;
	int bw = -1;

	*len = 0;

	p = execl_popen(0, PATH_IWPRIV, iface->name, "maui", "associnfo");
	if (!p)
		return -1;

	while (fgets(buf, sizeof(buf), p)) {
		if (halbuf == NULL) {
			/* only count associations */
			if (tok = gettok(buf, "MAC:", 1, SPACE))
				(*len)++;
			continue;
		}

		if (tok = gettok(buf, "MAC:", 1, SPACE)) {
			if (hal_buf_check_clear(halbuf, *len, sizeof(*as)))
				break;
			as++;
			(*len)++;
			str2mac(tok, as->macaddr);
			as->macaddr_set = 1;
			sgi = -1;
			bw = -1;
		} else if (tok = gettok(buf, "Protocal:", 1, SPACE)) {
			uint8_t proto = proto_str2bitmask(tok, PROTO_SET);
			FLDSET(as->protocol, best_proto(proto));
		} else if (tok = gettok(buf, "BW:", 1, SPACE)) {
			bw = atoi(tok);
			FLDSET(as->bandwidth, bw);
		} else if (tok = gettok(buf, "RSSI:", 1, SPACE)) {
			FLDSET(as->rssi, atoi(tok));
		} else if (tok = strstr(buf, "RX Rate")) {
			int rate = -1;
			int mcs = -1;
			if (parse_rate_str(tok, &rate, &mcs, &sgi))
				continue;
			if (rate >= 0)
				FLDSET(as->rx_rate, rate);
			if (mcs >= 0)
				FLDSET(as->rx_mcs, mcs);
		} else if (tok = strstr(buf, "TX Rate")) {
			int rate = -1;
			int mcs = -1;
			if (parse_rate_str(tok, &rate, &mcs, &sgi))
				continue;
			if (rate >= 0)
				FLDSET(as->tx_rate, rate);
			if (mcs >= 0)
				FLDSET(as->tx_mcs, mcs);
		} else if (tok = gettok(buf, "MaxRxRate:", 1, "-")) {
			int rate = atoi(tok) * 1024;
			if (rate == 0) {
				int mcs = parse_mcs_str(tok);
				if (mcs < 0 || bw < 0 || sgi < 0)
					continue;
				rate = get_rate(mcs, bw, sgi);
			}
			FLDSET(as->rx_max_rate, rate);
		} else if (tok = gettok(buf, "MaxTxRate:", 1, "-")) {
			int rate = atoi(tok) * 1024;
			if (rate == 0) {
				int mcs = parse_mcs_str(tok);
				if (mcs < 0 || bw < 0 || sgi < 0)
					continue;
				rate = get_rate(mcs, bw, sgi);
			}
			FLDSET(as->tx_max_rate, rate);
		}
	}
	execl_pclose(p);
	return 0;
}

int hal_mtk_traffic_list(const struct iface *iface, char *halbuf, int *len)
{
	struct traffic_stats *tsbuf = (struct traffic_stats *)halbuf;
	struct traffic_stats *ts = tsbuf - 1;
	char buf[256];
	char *tok;
	FILE *p;

	*len = 0;

	p = execl_popen(0, PATH_IWPRIV, iface->name, "maui", "associnfo");
	if (!p)
		return -1;

	while (fgets(buf, sizeof(buf), p)) {
		if (tok = gettok(buf, "MAC:", 1, SPACE)) {
			if (hal_buf_check_clear(halbuf, *len, sizeof(*ts)))
				break;
			ts++;
			(*len)++;
			str2mac(tok, ts->macaddr);
			ts->macaddr_set = 1;
		} else if (tok = gettok(buf, "RxBytes:", 1, SPACE)) {
			FLDSET(ts->rx_bytes, atoll(tok));
		} else if (tok = gettok(buf, "RxPackets:", 1, SPACE)) {
			FLDSET(ts->rx_packets, atoi(tok));
		} else if (tok = gettok(buf, "TxBytes:", 1, SPACE)) {
			FLDSET(ts->tx_bytes, atoll(tok));
		} else if (tok = gettok(buf, "TxPackets:", 1, SPACE)) {
			FLDSET(ts->tx_packets, atoi(tok));
		}
	}
	execl_pclose(p);
	return 0;
}

int hal_mtk_phy_stats(const struct iface *iface, struct phy_stats *halps)
{
	uint32_t channel;
	int len;

	if (hal_mtk_channel(iface, &channel) == 0)
		FLDSET(halps->channel, channel);
	if (hal_mtk_assoc_list(iface, NULL, &len) == 0)
		FLDSET(halps->assoc, len);
	return 0;
}

int hal_mtk_cca_stats(const struct iface *iface, struct cca_stats *cca)
{
	return -ENOTSUP;
}

int hal_mtk_channel_list(const struct iface *iface, char *halbuf, int *len)
{
	struct channel_desc *chd = (struct channel_desc *)halbuf;
	char buf[256];
	char *tok;
	int channel;
	int first_ch;
	int last_ch;
	int txpower = 0;

	tok = execl_output_grep_awk(buf, sizeof(buf), 0, GREP("Channel:"), AWK(3, SPACE),
		IWPRIV_CAP(iface->name));
	if (!tok)
		return -1;
	tok = strtok(tok, SPACE"~");
	if (!tok)
		return -1;
	first_ch = atoi(tok);
	tok = strtok(NULL, SPACE);
	if (!tok)
		return -1;
	last_ch = atoi(tok);
	if (first_ch == 0 || last_ch == 0)
		return -1;

	for (channel = first_ch, *len = 0; channel <= last_ch; channel++, chd++, (*len)++) {
		if (hal_buf_check_clear(halbuf, *len, sizeof(*chd)))
			break;
		FLDSET(chd->channel, channel);
		if (txpower)
			FLDSET(chd->txpower, txpower);
	}
	return 0;
}

#define SCAN_DURATION 10
int hal_mtk_scan_start(const struct iface *iface, const int force)
{
	int len = -1;
	if (!force && (hal_mtk_assoc_list(iface, NULL, &len) || len != 0))
		return -1;
	/* do an active scan once */
	return (execl_run(F_DEV_NULL, PATH_IWPRIV, iface->name, "set", "SiteSurvey=1")) ? -1 : 0;
}

int hal_mtk_scan_duration(const struct iface *iface, uint32_t *duration)
{
	*duration = SCAN_DURATION;
	return 0;
}

int hal_mtk_scan_status(const struct iface *iface, uint32_t *status)
{
	return -ENOTSUP;
}

int hal_mtk_scan_list(const struct iface *iface, char *halbuf, int *len)
{
	struct scan_stats *ss = (struct scan_stats *)halbuf;
	char buf[256];
	FILE *p;
	int i;

	if (iface != iface->phy)
		return -1;

	p = execl_popen(0, PATH_IWPRIV, iface->name, "maui", "scaninfo");
	if (!p)
		return -1;

	ss = (struct scan_stats *)halbuf - 1;
	*len = 0;
	while (fgets(buf, 256, p)) {
		char *mac = buf;
		char *ssid = buf + 20;
		char *chan = buf + 53;
		char *bw = buf + 63;
		char *proto = buf + 69;
		char *rssi = buf + 79;

		if (buf[0] == '\0' || buf[1] == '\0' || buf[2] != ':')
			continue;
		if (strlen(buf) < 82 || buf[17] != ' ' || buf[52] != ' ')
			continue;
		if (hal_buf_check_clear(halbuf, *len, sizeof(*ss)))
			break;

		buf[17] = 0;
		for (i = 52; buf[i] == ' '; i--)
			buf[i] = 0;
		buf[55] = 0;
		buf[66] = 0;
		buf[77] = 0;

		if (str2mac(mac, (ss + 1)->bssid))
			continue;
		ss++;
		(*len)++;
		ss->bssid_set = 1;
		strncpy(ss->ssid, ssid, sizeof(string32) - 1);
		ss->ssid_set = 1;
		FLDSET(ss->channel, atoi(chan));
		FLDSET(ss->bandwidth, atoi(bw));
		if (proto[0] == '1')
			FLDSET(ss->protocol, proto_str2bitmask(proto, PROTO_SET));
		FLDSET(ss->rssi, atoi(rssi));
	}
	execl_pclose(p);
	return 0;
}

int hal_mtk_set_channel(const struct iface *iface, uint32_t channel)
{
	return execl_run(F_DEV_NULL, PATH_IWPRIV, iface->name, "set",
		str16("Channel=%d", channel)) ? -1 : 0;
}

int hal_mtk_set_txpower(const struct iface *iface, int32_t txpower)
{
	return -ENOTSUP;
}

int hal_mtk_set_ssid(const struct iface *iface, char *ssid)
{
	return -ENOTSUP;
}

int hal_mtk_set_bandwidth(const struct iface *iface, uint32_t bandwidth)
{
	return execl_run(F_DEV_NULL, PATH_IWPRIV, iface->name, "set",
		str16("HtBw=%d", (bandwidth == 40) ? 1 : 0)) ? -1 : 0;
}

struct hal_ops hal_mtk_ops = {
	.name = "mtk",

	.init = NULL,
	.reinit = NULL,
	.probe = NULL,

	.mode = hal_mtk_mode,
	.channel = hal_mtk_channel,
	.txpower = hal_mtk_txpower,
	.region = hal_mtk_region,
	.bandwidth = hal_mtk_bandwidth,
	.bandwidth_supp = hal_mtk_bandwidth_supp,
	.protocol = hal_mtk_protocol,
	.protocol_supp = hal_mtk_protocol_supp,
	.ssid = hal_mtk_ssid,
	.bssid = hal_mtk_bssid,
	.phy_stats = hal_mtk_phy_stats,
	.cca_stats = hal_mtk_cca_stats,
	.channel_list = hal_mtk_channel_list,
	.assoc_list = hal_mtk_assoc_list,
	.traffic_list = hal_mtk_traffic_list,
	.scan_start = hal_mtk_scan_start,
	.scan_duration = hal_mtk_scan_duration,
	.scan_status = hal_mtk_scan_status,
	.scan_list = hal_mtk_scan_list,

	.set_channel = hal_mtk_set_channel,
	.set_txpower = hal_mtk_set_txpower,
	.set_ssid = hal_mtk_set_ssid,
	.set_bandwidth = hal_mtk_set_bandwidth,
};
