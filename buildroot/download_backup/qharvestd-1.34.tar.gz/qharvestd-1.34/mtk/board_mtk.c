/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include "qharvestd.h"
#include "qh_hal.h"
#include "qh_utils.h"
#include "hal_mtk.h"

int board_mtk_init_iface_list(struct board *board)
{
	struct iface *head = NULL;
	struct iface **next = &head;
	struct iface *phy = NULL;
	struct iface *iface;
	char buf[256];
	char *tok;
	FILE *p;

	board->ifnum = 0;
	board->head = NULL;

	p = execl_popen(0, PATH_IFCONFIG, "-a");
	if (!p)
		return -1;

	while (fgets(buf, 256, p)) {
		if (strstr(buf, "ra") != buf)
			continue;
		if ((tok = strtok(buf, SPACE)) == NULL)
			continue;
		sanitize_ifname(tok);
		if (execl_run(F_DEV_NULL, IWPRIV_CFG(tok)))
			continue;

		*next = iface = xcalloc(1, sizeof(*iface));
		next = &iface->next;
		snprintf(iface->name, sizeof(iface->name), "%s", tok);
		if (phy == NULL)
			phy = iface;
		iface->phy = phy;
		iface->hal = &hal_mtk_ops;
		iface->board = board;
		iface->up = get_ifup(iface->name);
		(board->ifnum)++;
	}
	execl_pclose(p);

	board->head = head;
	return 0;
}

static int board_mtk_get_firmware_version(string32 version)
{
	return -ENOTSUP;
}

static inline int board_mtk_get_macaddr(macaddr_t macaddr)
{
	/* use ifconfig, as iwpriv doesn't work if interface is down */
	return get_macaddr("ra0", macaddr);
}

int board_mtk_init(struct board *board)
{
	if (!board_mtk_get_macaddr(board->macaddr))
		board->macaddr_set = 1;
	if (!board_mtk_get_firmware_version(board->firmware))
		board->firmware_set = 1;
	return 0;
}

int board_mtk_upgrade(struct board *board, char *fw_file)
{
	return -ENOTSUP;
}

struct board board_mtk = {
	.name = "mtk",
	.init_iface_list = board_mtk_init_iface_list,
	.free_iface = NULL,
	.init = board_mtk_init,
	.upgrade = board_mtk_upgrade,
	.firmware_set = 0,
	.kernel_set = 0,
	.platform_set = 0,
	.reboot_cause_set = 0,
	.carrier_id_set = 0,
};
