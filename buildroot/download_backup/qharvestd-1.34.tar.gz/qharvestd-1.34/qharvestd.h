/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QH_LOGD_H_
#define __QH_LOGD_H_

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <errno.h>
#include "qh_hal.h"

#ifndef COMMIT_HASH
#define COMMIT_HASH ""
#endif

#define _STR(s)     #s
#define STR(s)      _STR(s)
#ifndef VERSION
#error No version defined
#else
#define __VERSION STR(VERSION)
#endif

#ifndef PATH_QDRVCMD
#define PATH_QDRVCMD "qdrvcmd"
#endif
#ifndef PATH_READMEM
#define PATH_READMEM "readmem"
#endif
#ifndef PATH_QCOMM_CLI
#define PATH_QCOMM_CLI "qcomm_cli"
#endif
#ifndef PATH_REBOOT
#define PATH_REBOOT "reboot"
#endif
#ifndef PATH_MD5SUM
#define PATH_MD5SUM "md5sum"
#endif
#ifndef PATH_ROUTE
#define PATH_ROUTE "route"
#endif
#ifndef PATH_ARP
#define PATH_ARP "arp"
#endif
#ifndef PATH_IFCONFIG
#define PATH_IFCONFIG "ifconfig"
#endif
#ifndef PATH_UNAME
#define PATH_UNAME "uname"
#endif
#ifndef PATH_IW
#define PATH_IW "iw"
#endif
#ifndef PATH_WL
#define PATH_WL "wl"
#endif
#ifndef PATH_QWECFG
#define PATH_QWECFG "qweconfig"
#endif
#ifndef PATH_QWEACT
#define PATH_QWEACT "qweaction"
#endif
#ifndef PATH_QCSAPI
#define PATH_QCSAPI "call_qcsapi"
#endif
#ifndef PATH_IWPRIV
#define PATH_IWPRIV "iwpriv"
#endif
#ifndef PATH_BRCTL
#define PATH_BRCTL "brctl"
#endif
#ifndef PATH_LOGIN
#define PATH_LOGIN "login"
#endif
#ifndef PATH_GINFO
#define PATH_GINFO "gather_info"
#endif

#define BASE_URL_MESSAGE_POLLING			"poll"
#define BASE_URL_MESSAGE_CONFIG				"files"
#define BASE_URL_MESSAGE_CONFIG_PKTLOGGER		"pktlogger/configsync"
#define BASE_URL_MESSAGE_LOG_MESSAGES			"log/messages"
#define BASE_URL_MESSAGE_LOG_SCS_REPORT_ALL		"log/scs_report_all"
#define BASE_URL_MESSAGE_LOG_GATHER_INFO		"files"
#define BASE_URL_MESSAGE_LOG_SCAN_RESULTS		"log/scan_results"
#define BASE_URL_MESSAGE_LOG_BIDICMD			"log/bidicmd"
#define BASE_URL_MESSAGE_LOG_CAPABILITIES		"log/capabilities"
#define BASE_URL_MESSAGE_LOG_BUNDLED_STATS		"log/bundled_stats"
#define BASE_URL_MESSAGE_UPGRADE			"upgrade"
#define BASE_URL_MESSAGE_OAUTH				"auth/token"

#define MY_NAME			"qharvestd"
#define BASE_URL_DEFAULT	"https://qharvest-prod.quantenna.com/api/"
#ifndef CONF_FILE_DEFAULT
#define CONF_FILE_DEFAULT	"/etc/qharvestd.conf"
#endif
#define REMOTE_PROTO_DEFAULT	"tcp"

#define LOGFILE_DEFAULT "/var/log/messages"
#ifndef LOGFILE
#define LOGFILE LOGFILE_DEFAULT
#endif

#ifndef HAVE_PKTLOGGER
#define HAVE_PKTLOGGER 0
#endif

#ifndef HAVE_FW_UPGRADE
#define HAVE_FW_UPGRADE 0
#endif

#ifndef HAVE_SONIQ
#define HAVE_SONIQ 0
#endif

#ifndef HAVE_ZLIB
#define HAVE_ZLIB 0
#endif

#define MAY_ALIAS __attribute__((__may_alias__))

#define MESSAGE_TIMEOUT_DEFAULT		120

struct qh_debug_config {
	int console_print;
	int http;
	int pktlogger;
	int scan_threshold;
	char *curl_debug_file;
	char *mac;
	char *mode;
};

struct qh_curl_config {
	int verbose;
	int ssl_version;
	int verify_peer;
	int verify_host;
	int encrypt;
	int easy;
	char *ca_file;
	char *bind_iface;
	char *dns_iface;
	char *dns_list;
};

struct qh_ws_config {
	char *url;
	int ping;
	int compress;
	int verbose;
};

struct qh_oauth_config {
	int enabled;
	char *client_id;
	char *device_id;
	char *secret;
	char *token;
	int32_t expire;
};

struct qh_config {
	int running;
	unsigned int sequence;
	unsigned int session;
	char *base_url;
	int syslog;
	int debug;
	char *logfile;
	char *bidicmd_url;
#ifdef REMOTE_QCSAPI
	char *remote;
	char *remote_proto;
	char *remote_iface;
#endif
	char *conf_file;
	char *script;
	int primary_board;
	int upgrade;
	int pty;
	struct qh_debug_config debug_config;

	long request_timeout;

	char *main_interface_name;
	char *mac_interface_name;
	struct qh_curl_config curl_config;
	struct qh_ws_config ws;
	struct qh_oauth_config oauth;

};

extern struct qh_config config;
extern int qh_fast_start;
extern int g_start_uptime;
extern string32 g_firmware;
extern string32 g_platform;

#endif
