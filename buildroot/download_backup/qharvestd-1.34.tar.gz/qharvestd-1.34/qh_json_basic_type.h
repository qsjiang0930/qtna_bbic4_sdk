/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QH_JSON_BASIC_TYPE_H
#define __QH_JSON_BASIC_TYPE_H

#include "qh_json.h"
#include "qh_hal.h"

struct qh_file_list *get_filelist_config(void);

struct qh_file_list *get_filelist_grabber(void);

JSON *get_json_from_mac(macaddr_t macaddr);

JSON *get_json_timestamp(void);

JSON *add_json_message_header(JSON *obj);

JSON *get_json_polling_message(struct message_control *mctl, int *ret);

JSON *get_json_default_message(struct message_control *mctl, int *ret);

JSON *get_json_log_scan_results_message(struct message_control *mctl, int *ret);

JSON *get_json_log_capabilities_message(struct message_control *mctl, int *ret);

JSON *get_json_log_bundled_stats_message(struct message_control *mctl, int *ret);

JSON *get_json_upgrade_message(struct message_control *mctl, int *ret);

JSON *get_json_oauth_message(struct message_control *mctl, int *ret);

void do_initial_scan(void);

int get_cca_stats(struct iface *iface, struct cca_stats *cur, struct cca_stats *old);

#endif
