/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#define _GNU_SOURCE
#include <fcntl.h>
#include <limits.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <poll.h>
#include <resolv.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/sysinfo.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include "qh_utils.h"

char *str16(const char *fmt, ...)
{
	static char buf[16];
	va_list ap;

	va_start(ap, fmt);
	(void)vsnprintf(buf, 16, fmt, ap);
	va_end(ap);
	return buf;
}

char *str32(const char *fmt, ...)
{
	static char buf[32];
	va_list ap;

	va_start(ap, fmt);
	(void)vsnprintf(buf, 32, fmt, ap);
	va_end(ap);
	return buf;
}

char *str64(const char *fmt, ...)
{
	static char buf[64];
	va_list ap;

	va_start(ap, fmt);
	(void)vsnprintf(buf, 64, fmt, ap);
	va_end(ap);
	return buf;
}

#define WAIT_FOREVER -1
static int wait_status(pid_t pid, int usec)
{
	int ret = 0;
	int status = 0;
	if (usec >= 0) {
		/* Monitoring with less than 10ms precision has a big overhead. */
		for (; (ret = waitpid(pid, &status, WNOHANG)) == 0 && usec > 0; usec -= MS_U(10))
			usleep(MS_U(10));
		if (ret < 0)
			return -1;
		if (ret == 0)
			return -ETIMEDOUT;
	} else {
		do {
			ret = waitpid(pid, &status, 0);
			if (ret < 0 && errno != EINTR)
				return -1;
			if (ret >= 0)
				break;
		} while (1);
	}
	return (WIFEXITED(status)) ? WEXITSTATUS(status) : -1;
}

pid_t execv_base(int *fdout, int *fderr, int flags, int pipeflags, const char *const argv[])
{
	/* if (flags & F_DEV_NULL) is 0, then NULL in fdout/fderr means that
	 * a child will use the same stdout/stderr as a parent. Otherwise NULL
	 * means that corresponding fd has to be redirected to /dev/null. */

	enum {
		PARENT_STDOUT = 0,
		CHILD_STDOUT,
		PARENT_STDERR,
		CHILD_STDERR,
		PIPE_MAX,
	};

	int pipefd[PIPE_MAX] = { -1, -1, -1, -1 };
	int *out[3] = { NULL, fdout, fderr };
	pid_t pid;
	int curflags;
	int i, j;

	for (i = 0; i < PIPE_MAX; i += 2) {
		if (pipe(pipefd + i))
			goto cleanup;
		if (!pipeflags)
			continue;
		curflags = fcntl(pipefd[i], F_GETFL, 0);
		if (curflags < 0)
			goto cleanup;
		if (fcntl(pipefd[i], F_SETFL, curflags | pipeflags) < 0)
			goto cleanup;
	}

	pid = fork();
	if (pid == 0) {
		int fdnull = (flags & F_DEV_NULL) ? open("/dev/null", O_WRONLY) : -1;

		if (flags & F_DBL_FORK) {
			pid_t cpid = fork();
			if (cpid > 0) {
				_exit(0); /* exit from child => make grandchild orphan */
			} else if (cpid < 0) {
				_exit(1); /* report to parent that fork failed */
			}
		}

		/* close parent endpoints */
		for (i = 0; i < PIPE_MAX; i += 2)
			close(pipefd[i]);
		/* set own endpoints [i] to stdout and stderr [j] */
		for (i = 1, j = 1; i < PIPE_MAX; i += 2, j++) {
			if (out[j]) {
				if (flags & F_FD_WRITE)
					dup2(*(out[j]), j); /* redirect to provided fd */
				else
					dup2(pipefd[i], j); /* redirect to pipe to parent */
			} else if (fdnull >= 0) {
				dup2(fdnull, j); /* redirect to /dev/null */
			}
			close(pipefd[i]);
		}
		if (fdnull >= 0)
			close(fdnull);
		/* If a child spawns some processes, then they also need to be killed
		 * if we want to kill the child => make it a process group leader. */
		setsid();
		if (execvp(*argv, (char *const *)argv) < 0)
			_exit(1);
	} else if (pid > 0) {
		if (flags & F_DBL_FORK) {
			if (wait_status(pid, WAIT_FOREVER))
				goto cleanup;
		}
		/* close child endpoints */
		for (i = 1; i < PIPE_MAX; i += 2)
			close(pipefd[i]);
		/* close unused parent endpoints */
		for (i = 0, j = 1; i < PIPE_MAX; i += 2, j++) {
			if (out[j] && !(flags & F_FD_WRITE))
				*(out[j]) = pipefd[i];
			else
				close(pipefd[i]);
		}
		return pid;
	}
cleanup:
	for (i = 0; i < PIPE_MAX; i++) {
		if (pipefd[i] >= 0)
			close(pipefd[i]);
	}
	return -1;
}

int execv_run_limit_ts(int devnull, struct timespec *time, const char *const argv[])
{
	return execv_run_ext_limit_ts((devnull) ? F_DEV_NULL : 0,
		NULL, NULL, NULL, NULL, time, argv);
}

int execv_run_limit(int devnull, int seconds, const char *const argv[])
{
	struct timespec time = { seconds, 0 };
	return execv_run_limit_ts(devnull, &time, argv);
}

int execv_run_ext_limit_ts(int flags, char **out, int *outlen, char **err, int *errlen,
	struct timespec *time, const char *const argv[])
{
	const int bufsz = 4096;
	char tmpbuf[bufsz];
	int i;
	int status = 0;
	pid_t pid = 0;
	int fdflags = O_RDONLY | O_NONBLOCK;
	int fd[2] = { -1, -1 };
	struct pollfd _poll[2] = {{ 0 }}; /* { 0 } raises warning due to GCC bug #53119 */
	char *output[2] = { 0 };
	int maxlen[2] = { (outlen && *outlen > 0) ? *outlen : bufsz - 2,
		(errlen && *errlen > 0) ? *errlen : bufsz - 2 };
	int total_read[2] = { 0 };
	struct timespec remain;

	if (time == NULL)
		return -1;
	timespec_set(&remain, time);

	if (flags & F_MOD_FILE) {
		fd[0] = open(argv[0], fdflags);
		if (fd[0] < 0)
			return -1;
	} else {
		pid = execv_base((out) ? &fd[0] : NULL, (err) ? &fd[1] : NULL, flags, fdflags, argv);
		if (pid < 0)
			return -1;
	}

	_poll[0].fd = fd[0];
	_poll[1].fd = fd[1];
	while (timespec_cmp(&remain, NULL) > 0 && (_poll[0].fd >= 0 || _poll[1].fd >= 0)) {
		int ret;
		struct timespec start;
		struct timespec end;
		struct timespec diff;
		int ch_read;
		char *tmp;

		clock_gettime(CLOCK_MONOTONIC, &start);

		for (i = 0; i < 2; i++) {
			_poll[i].events = POLLIN;
			_poll[i].revents = 0;
		}

		ret = ppoll(_poll, 2, &remain, NULL);
		if (ret < 0)
			break;

		for (i = 0; i < 2; i++) {
			if (_poll[i].revents == 0)
				continue;

			/* Note: POLLHUP event is valid here, as by that time command,
			 * which output we want to read, could already be completed =>
			 * writing end of pipe could be closed and POLLHUP indicates it */
			if (_poll[i].revents & (POLLERR | POLLNVAL)) {
				_poll[i].fd = -1;
				continue;
			}

			ch_read = read(_poll[i].fd, tmpbuf, bufsz);
			if (ch_read <= 0) { /* EOF or error */
				_poll[i].fd = -1;
				continue;
			}

			if (total_read[i] + ch_read > maxlen[i])
				ch_read = maxlen[i] - total_read[i];
			tmp = (char *)realloc(output[i], total_read[i] + ch_read + 1);
			if (tmp == NULL) {
				_poll[i].fd = -1;
				continue;
			}

			output[i] = tmp;
			memcpy(output[i] + total_read[i], tmpbuf, ch_read);
			total_read[i] += ch_read;
		}

		clock_gettime(CLOCK_MONOTONIC, &end);
		timespec_sub(&diff, &end, &start);
		timespec_sub(&remain, &remain, &diff);
	}


	for (i = 0; i < 2; i++) {
		if (output[i]) {
			output[i][total_read[i]] = '\0';
			/* also remove the linefeed if it is present */
			if (total_read[i] > 0 && output[i][total_read[i] - 1] == '\n')
				output[i][--total_read[i]] = '\0';
		}
		if (fd[i] >= 0)
			close(fd[i]);
	}

	if (out)
		*out = output[0];
	else if (output[0])
		free(output[0]);

	if (err)
		*err = output[1];
	else if (output[1])
		free(output[1]);

	if (outlen)
		*outlen = total_read[0];
	if (errlen)
		*errlen = total_read[1];
	if (pid) {
		int usec = SEC_U(remain.tv_sec) + remain.tv_nsec / 1000;
		status = wait_status(pid, (usec >= 0) ? usec : 0);
		if (status == -ETIMEDOUT)
			kill_and_wait(-pid, SIGKILL, SEC_U(1));
	}
	return status;
}

int execv_run_ext_limit(int flags, char **out, int *outlen, char **err, int *errlen,
	int seconds, const char *const argv[])
{
	struct timespec time = { seconds, 0 };
	return execv_run_ext_limit_ts(flags, out, outlen, err, errlen, &time, argv);
}

struct execv_popen_le {
	struct execv_popen_le *next;
	FILE *f;
	pid_t pid;
};

static struct execv_popen_le *execv_popen_lh = NULL;

FILE *execv_popen(int devnull, const char *const argv[])
{
	int fd = -1;
	int flags = (devnull) ? F_DEV_NULL : 0;
	pid_t pid;
	FILE *f;
	struct execv_popen_le *le = xmalloc(sizeof(*le));

	pid = execv_base(&fd, NULL, flags, O_RDONLY, argv);
	if (pid <= 0)
		goto bail;
	f = fdopen(fd, "r");
	if (f == NULL) {
		close(fd);
		kill_and_wait(-pid, SIGKILL, SEC_U(1));
		goto bail;
	}

	le->next = execv_popen_lh;
	le->f = f;
	le->pid = pid;
	execv_popen_lh = le;
	return f;
bail:
	if (le)
		free(le);
	return NULL;
}

int execv_pclose(FILE *f)
{
	struct execv_popen_le *found = NULL;
	pid_t pid;

	if (execv_popen_lh == NULL)
		return -1;
	if (execv_popen_lh->f == f) {
		found = execv_popen_lh;
		execv_popen_lh = execv_popen_lh->next;
	} else {
		struct execv_popen_le *prev = execv_popen_lh;
		struct execv_popen_le *curr = execv_popen_lh->next;
		while (curr != NULL) {
			if (curr->f == f) {
				prev->next = curr->next;
				found = curr;
				break;
			}
			prev = curr;
			curr = curr->next;
		}
	}
	if (found == NULL)
		return -1;
	fclose(f);
	pid = found->pid;
	free(found);
	return wait_status(pid, WAIT_FOREVER);
}

char *execv_get_output_limit_ts(int flags, int *len, struct timespec *time, const char *const argv[])
{
	char *output = NULL;
	if (execv_run_ext_limit_ts(flags, &output, len, NULL, NULL, time, argv) < 0) {
		if (output != NULL)
			free(output);
		return NULL;
	}
	return output;
}

char *execv_get_output_limit(int flags, int *len, int seconds, const char *const argv[])
{
	struct timespec time = { seconds, 0 };
	return execv_get_output_limit_ts(flags, len, &time, argv);
}

char *execv_buf_output_limit_ts(char *buf, int bufsz,
	int flags, struct timespec *time, const char *const argv[])
{
	int len = bufsz;
	char *output;

	if (buf == NULL)
		return NULL;
	output = execv_get_output_limit_ts(flags, &len, time, argv);
	if (output == NULL)
		return NULL;
	snprintf(buf, bufsz, "%s", output);
	free(output);
	return buf;
}

char *execv_buf_output_limit(char *buf, int bufsz,
	int flags, int seconds, const char *const argv[])
{
	struct timespec time = { seconds, 0 };
	return execv_buf_output_limit_ts(buf, bufsz, flags, &time, argv);
}

/* This function behaves similar to <argv> | grep -m1 <grep> | awk -F<fsep> '{print $<field>}'.
 * For example the following 2 commands return the same string:
 * 1  (C): execv_output_grep_awk(..., "HWaddr", 5, SPACE, ["ifconfig", NULL]);
 * 2 (sh): ifconfig | grep -m1 HWaddr | awk '{print $5}'
 *
 * F_AT_START - check that grepped string is at the very beginning of a line (BOL).
 * F_POS_GREP - start "awk" logic from grepped string position, not from BOL.
 * F_IGN_CASE - ignore case while grepping (like grep -i).
 * F_GREP_INV - do inversed grep (like grep -v).
 * F_GREP_ALL - do not stop at the first match.
 */
char *execv_output_grep_awk(char *outbuf, int outsz, int flags,
	char *grep, unsigned int field, char *fsep, const char *const argv[])
{
	/* As we need to use fgets (streams) in this function,
	 * we can't use low-level polling functions here =>
	 * execution time of this function is unlimited. */
	const int bufsz = 512;
	char buf[bufsz];
	char *tok = NULL;
	char *result = outbuf;
	int match = 0;
	FILE *p = execv_popen((flags & F_DEV_NULL), argv);
	if (!p)
		return NULL;

	/* use bufsz - 1 to leave space for extra newline character if token is at EOL */
	while (fgets(buf, bufsz - 1, p) != NULL) {
		char *start = buf;
		char *s;
		int toksz;

		if (grep) {
			int match = 1;
			s = (flags & F_IGN_CASE) ? strcasestr(buf, grep) : strstr(buf, grep);

			if (s == NULL)
				match = 0;
			if ((flags & F_AT_START) && s != start)
				match = 0;
			if ((flags & F_GREP_INV) && match == 1)
				continue;
			if (!(flags & F_GREP_INV) && match == 0)
				continue;
			if ((flags & F_POS_GREP) && s != NULL)
					start = s;
		}

		/* match, remove training newline */
		s = strchr(start, '\n');
		if (s)
			*s = '\0';

		tok = (field) ? gettok(start, NULL, field - 1, (fsep) ? fsep : SPACE) : start;
		if (tok == NULL)
			continue;
		match++;

		/* add newline, concatenate matched token */
		strcat(tok, "\n");
		toksz = strlen(tok);
		if (outbuf) {
			int sz = (outsz - toksz > 0) ? toksz : outsz - 1;
			snprintf(outbuf, sz + 1, "%s", tok);
			outbuf += sz;
			outsz -= sz;
			if (outsz <= 0)
				break;
		} else {
			int oldlen = (result) ? strlen(result) : 0;
			char *tmp = (char *)realloc(result, oldlen + toksz + 1);
			if (tmp == NULL)
				break;
			result = tmp;
			tmp = result + oldlen;
			snprintf(tmp, toksz + 1, "%s", tok);
		}
		if (!(flags & F_GREP_ALL))
			break;
	}
	(void)execv_pclose(p);

	if (match == 0 || result == NULL)
		return NULL;

	/* remove trailing newline of the latest token */
	tok = strrchr(result, '\n');
	if (tok)
		*tok = '\0';
	return result;
}

int execv_get_int_base(int base, int flags,
	char *grep, unsigned int field, char *fsep, const char *const argv[])
{
	const int bufsz = 64;
	char buf[bufsz];

	if (NULL == execv_output_grep_awk(buf, bufsz, flags, grep, field, fsep, argv))
		return INT_MIN;
	return strtol(buf, NULL, base);
}

int execv_write_fd(int flags, int fdout, int fderr, const char *const argv[])
{
	pid_t pid;

	if (fdout < 0 && fderr < 0)
		return -1;
	pid = execv_base((fdout >= 0) ? &fdout : NULL, (fderr >= 0) ? &fderr : NULL,
		flags | F_FD_WRITE, 0, argv);
	if (pid <= 0)
		return -1;
	return wait_status(pid, WAIT_FOREVER);
}

int kill_and_wait(pid_t pid, int signal, int usec)
{
	if (kill(pid, signal))
		return -1;
	/* Wait for process with 1ms step. Usually it takes up to 1ms. */
	for (; waitpid((pid > 0) ? pid : -pid, NULL, WNOHANG) == 0 && usec > 0; usec -= MS_U(1))
		usleep(MS_U(1));
	return 0;
}

/*
   Printable Encoding Characters from RFC1113:

   Value Encoding  Value Encoding  Value Encoding  Value Encoding
       0 A            17 R            34 i            51 z
       1 B            18 S            35 j            52 0
       2 C            19 T            36 k            53 1
       3 D            20 U            37 l            54 2
       4 E            21 V            38 m            55 3
       5 F            22 W            39 n            56 4
       6 G            23 X            40 o            57 5
       7 H            24 Y            41 p            58 6
       8 I            25 Z            42 q            59 7
       9 J            26 a            43 r            60 8
      10 K            27 b            44 s            61 9
      11 L            28 c            45 t            62 +
      12 M            29 d            46 u            63 /
      13 N            30 e            47 v
      14 O            31 f            48 w         (pad) =
      15 P            32 g            49 x
      16 Q            33 h            50 y           (1) *

   (1) The character "*" is used to enclose portions of an
   encoded message to which encryption processing has not
   been applied.
*/
static const char printable64[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

/* 	Return null string "" if failed to encode;
	otherwise, pointer to buf which holds the encoded string */
char *encode64(char *buf, size_t size, char *data, size_t len)
{
	int ix;
	int iy;

	if (buf == NULL || size < 1) {
		return NULL;
	}

	if (data == NULL || len <= 0 || (len + 2) / 3 * 4 + 1 > size) {
		buf[0] = 0;
		return buf;
	}

	memset(buf, 0, size);
	for (ix = 0, iy = 0; iy < len; ix += 4, iy += 3) {
		uint8_t data0 = (uint8_t)(data[iy]);
		uint8_t data1 = (uint8_t)((iy + 1 >= len) ? 0 : data[iy + 1]);
		uint8_t data2 = (uint8_t)((iy + 2 >= len) ? 0 : data[iy + 2]);
		buf[ix] = printable64[data0 >> 2];
		buf[ix + 1] =
			printable64[((data0 & 0x3) << 4) | ((data1 & 0xf0) >> 4)];
		buf[ix + 2] = (iy + 2 > len) ? '=' :
			printable64[((data1 & 0xf) << 2) | ((data2 & 0xc0) >> 6)];
		buf[ix + 3] = (iy + 3 > len) ? '=' :
			printable64[data2 & 0x3f];
	}
	return buf;
}

void *xmalloc(size_t size)
{
	void *p = malloc(size);
	if (!p)
		exit(1);
	return p;
}

void *xcalloc(size_t nmemb, size_t size)
{
	void *p = calloc(nmemb, size);
	if (!p)
		exit(1);
	return p;
}

char *xstrdup(const char *str)
{
	char *s = strdup(str);
	if (!s)
		exit(1);
	return s;
}

char *check_string(char *str, int (*func)(int))
{
	if (!str)
		return NULL;
	while (*str) {
		if (!func(*str))
			return str;
		str++;
	}
	return NULL;
}

typedef int (*strncmp_t)(const char *s1, const char *s2, size_t n);

static char *strstr_cmp(const char *haystack, const char *needle, size_t len, strncmp_t cmp)
{
	int i;
	size_t needle_len;

	if (0 == (needle_len = strlen(needle)))
		return (char *)haystack;

	for (i = 0; i <= (int)(len - needle_len) && *haystack; i++)
	{
		if (0 == cmp(haystack, needle, needle_len))
			return (char *)haystack;
		haystack++;
	}
	return NULL;
}

char *strnstr(const char *haystack, const char *needle, size_t len)
{
	return strstr_cmp(haystack, needle, len, strncmp);
}

char *strncasestr(const char *haystack, const char *needle, size_t len)
{
	return strstr_cmp(haystack, needle, len, strncasecmp);
}

static void timespec_fix(struct timespec *ts)
{
	if (ts->tv_nsec >= SEC_N(1)) {
		ts->tv_sec += 1;
		ts->tv_nsec -= SEC_N(1);
	}
	if (ts->tv_nsec <= -SEC_N(1)) {
		ts->tv_sec -= 1;
		ts->tv_nsec += SEC_N(1);
	}
	if (ts->tv_sec > 0 && ts->tv_nsec < 0) {
		ts->tv_sec -= 1;
		ts->tv_nsec += SEC_N(1);
	}
	if (ts->tv_sec < 0 && ts->tv_nsec > 0) {
		ts->tv_sec += 1;
		ts->tv_nsec -= SEC_N(1);
	}
}

void timespec_add(struct timespec *res, struct timespec *arg1, struct timespec *arg2)
{
	if (!res || !arg1 || !arg2)
		return;
	res->tv_sec = arg1->tv_sec + arg2->tv_sec;
	res->tv_nsec = arg1->tv_nsec + arg2->tv_nsec;
	timespec_fix(res);
}

void timespec_sub(struct timespec *res, struct timespec *arg1, struct timespec *arg2)
{
	if (!res || !arg1 || !arg2)
		return;
	res->tv_sec = arg1->tv_sec - arg2->tv_sec;
	res->tv_nsec = arg1->tv_nsec - arg2->tv_nsec;
	timespec_fix(res);
}

int timespec_cmp(struct timespec *arg1, struct timespec *arg2)
{
	struct timespec zero = { 0, 0 };
	if (!arg1)
		arg1 = &zero;
	if (!arg2)
		arg2 = &zero;

	if (arg1->tv_sec < arg2->tv_sec)
		return -1;
	if (arg1->tv_sec > arg2->tv_sec)
		return 1;
	if (arg1->tv_nsec < arg2->tv_nsec)
		return -1;
	if (arg1->tv_nsec > arg2->tv_nsec)
		return 1;
	return 0;
}

void obj_enqueue(void *h, void *obj)
{
	struct obj_list **head = (struct obj_list **)h;
	struct obj_list *item = xcalloc(1, sizeof(*item));

	item->obj = obj;
	while (*head)
		head = &((*head)->next);
	*head = item;
}

void *obj_dequeue(void *h)
{
	struct obj_list **head = (struct obj_list **)h;
	struct obj_list *item = *head;
	void *obj;

	if (!item)
		return NULL;
	*head = item->next;
	obj = item->obj;
	free(item);
	return obj;
}

char *gettok(char *str, char *substr, unsigned int n, char *delim)
{
	char *tok = NULL;
	int i;

	if (str) {
		if (substr)
			str = strstr(str, substr);
		if (!str)
			return NULL;
	}
	tok = strtok(str, delim);
	for (i = 1; i <= n; ++i)
		tok = strtok(NULL, delim);
	return tok;
}

void qh_res_init(void)
{
#if HAVE_RESOLVCONF_REREAD
/* This is a workaround for libc flavors that never reread resolv.conf */
#ifndef _PATH_RESCONF  /* Normally defined in <resolv.h> */
#define _PATH_RESCONF "/etc/resolv.conf"
#endif
	static time_t last_reread = 0;
	time_t t = time(NULL);
	struct stat st;

	if (stat(_PATH_RESCONF, &st))
		return;
	if (t >= last_reread) { /* if last_reread is in the future => reread */
		if (last_reread > st.st_mtime)
			return;
		/* modification time is in the future => reread with reasonable interval */
		if (t < st.st_mtime && t - last_reread < 600)
			return;
	}
	if (res_init())
		return;
	last_reread = t;
#endif
	return;
}

int get_macaddr(char *ifname, macaddr_t mac)
{
	struct ifreq s;
	int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
	if (fd < 0)
		return -1;

	snprintf(s.ifr_name, sizeof(s.ifr_name), "%s", ifname);
	if (ioctl(fd, SIOCGIFHWADDR, &s) == 0 && s.ifr_hwaddr.sa_family == ARPHRD_ETHER) {
		memcpy(mac, s.ifr_addr.sa_data, sizeof(macaddr_t));
		close(fd);
		return 0;
	}
	close(fd);
	return -1;
}

int get_ifup(char *ifname)
{
	struct ifreq s;
	int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
	if (fd < 0)
		return 0;

	snprintf(s.ifr_name, sizeof(s.ifr_name), "%s", ifname);
	if (ioctl(fd, SIOCGIFFLAGS, &s) == 0 && (s.ifr_flags & IFF_UP)) {
		close(fd);
		return 1;
	}
	close(fd);
	return 0;
}

char *sanitize_ifname(char *ifname)
{
	int l = strnlen(ifname, IFNAMSIZ);
	/* Truncate to IFNAMSIZ and eliminate trailing : from new ifconfig output. */
	if ((l > 0 && ifname[l - 1] == ':') || l == IFNAMSIZ)
		ifname[l - 1] = '\0';
	return ifname;
}

int get_uptime(void) {
	struct sysinfo info;
	if (sysinfo(&info) != 0) {
		return -1;
	}
	return (int)info.uptime;
}
