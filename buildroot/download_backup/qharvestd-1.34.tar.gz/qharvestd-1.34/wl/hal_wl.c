/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include <ctype.h>
#include <limits.h>
#include "qharvestd.h"
#include "qh_hal.h"
#include "qh_utils.h"

static int wl_get_band(const char *ifname)
{
	char buf[32];
	return execl_output_grep_awk(buf, sizeof(buf), 0, GREP("a"), AWK(0, NULL),
		PATH_WL, "-a", ifname, "band") ? 5 : 2;
}

static int wl_get_noise(const char *ifname)
{
	/* 'chanim_stats' could be unavailable in old wl versions */
	int noise = execl_get_int(F_DEV_NULL | F_AT_START, GREP("0x"), AWK(13, SPACE),
		PATH_WL, "-a", ifname, "chanim_stats");
	if (noise == INT_MIN || noise >= 0)
		noise = execl_get_int(0, GREP(NULL), AWK(0, NULL),
			PATH_WL, "-a", ifname, "noise");
	return (noise == INT_MIN || noise >= 0) ? 0 : noise;
}

int hal_wl_mode(const struct iface *iface, uint32_t *mode)
{
	int is_ap = execl_get_int(0, GREP(NULL), AWK(0, NULL), PATH_WL, "-a", iface->name, "ap");
	if (is_ap < 0)
		return -1;
	*mode = (is_ap) ? WIFI_MODE_AP : WIFI_MODE_STA;
	return 0;
}

int hal_wl_channel(const struct iface *iface, uint32_t *channel)
{
	int chan = execl_get_int(F_POS_GREP, GREP("Channel:"), AWK(2, SPACE),
		PATH_WL, "-a", iface->name, "status");
	if (chan < 0)
		return -1;
	*channel = chan;
	return 0;
}

int hal_wl_txpower(const struct iface *iface, int32_t *txpower)
{
	int qdbm = execl_get_int(0, GREP(NULL), AWK(3, SPACE),
		PATH_WL, "-a", iface->name, "txpwr1");
	if (qdbm < 0)
		return -1;
	*txpower = ((qdbm % 4) > 1) ? qdbm / 4 + 1 : qdbm;
	return 0;
}

int hal_wl_region(const struct iface *iface, string2 region)
{
	char *str = execl_output_grep_awk(NULL, 0, 0, GREP(NULL), AWK(1, SPACE),
		PATH_WL, "-a", iface->name, "country");
	if (!str)
		return -1;
	if (validate_region(str)) {
		free(str);
		return -1;
	}

	snprintf(region, sizeof(string2), "%s", str);
	free(str);
	return 0;
}

int hal_wl_bandwidth(const struct iface *iface, uint32_t *bandwidth)
{
	int bw = execl_get_int(0, GREP("MHz"), AWK(5, SPACE),
		PATH_WL, "-a", iface->name, "status");
	if (bw < 0)
		return -1;
	*bandwidth = bw;
	return 0;
}

int hal_wl_bandwidth_supp(const struct iface *iface, uint32_t *bandwidth)
{
	/* Note: here we do not look directly on phy capabilities => what we report
	 * here is restricted by selected mode (legacy for 2g, N-only for 5g) */
	int bw;
	int i;
	/* 'bw_cap' could be unavailable in old wl versions */
	int mask = execl_get_int_base(16, F_DEV_NULL, GREP(NULL), AWK(0, NULL),
		PATH_WL, "-a", iface->name, "bw_cap", str16("%d", wl_get_band(iface->name)));
	if (mask <= 0)
		return -1;

	for (i = 3, bw = 160; i >= 0; i--, bw /= 2) {
		if (mask & (1 << i))
			break;
	}
	*bandwidth = bw;
	return 0;
}

int hal_wl_protocol(const struct iface *iface, uint32_t *protocol)
{
	int htmode = execl_get_int(0, GREP(NULL), AWK(0, NULL),
		PATH_WL, "-a", iface->name, "nmode");
	/* 'vhtmode' could be unavailable in old wl versions, but looks like only in 2.4G ones */
	int vhtmode = execl_get_int(F_DEV_NULL, GREP(NULL), AWK(0, NULL),
		PATH_WL, "-a", iface->name, "vhtmode");
	int band = wl_get_band(iface->name);

	if (band == 5)
		*protocol = (vhtmode > 0) ? PROTO_11AC : (PROTO_11N | PROTO_11A);
	else
		*protocol = (htmode > 0) ? (PROTO_11N | PROTO_11G) : PROTO_11G;
	return 0;
}

int hal_wl_protocol_supp(const struct iface *iface, uint32_t *protocol)
{
	/* Note: as hal_wl_bandwidth_supp depends on selected protocol,
	 * we can't use it here to report all supported protocols.
	 * Phy capabilities reported by wl also don't include ht/vht info. */
	return -ENOTSUP;
}

int hal_wl_ssid(const struct iface *iface, string32 ssid)
{
	char *str = execl_output_grep_awk(NULL, 0, 0, GREP(NULL), AWK(2, "\""),
		PATH_WL, "-a", iface->name, "ssid");

	if (!str)
		return -1;

	snprintf(ssid, sizeof(string32), "%s", str);
	free(str);
	return 0;
}

int hal_wl_bssid(const struct iface *iface, macaddr_t bssid)
{
	char *str = execl_output_grep_awk(NULL, 0, 0, GREP(NULL), AWK(2, SPACE),
		PATH_WL, "-a", iface->name, "cur_etheraddr");

	if (!str)
		return -1;

	str2mac(str, bssid);
	free(str);
	return 0;
}

int wl_iterate_assoclist(const struct iface *iface, char *halbuf, int *len,
	int (*callback)(const struct iface *iface, char *halbuf, int idx, char *macaddr))
{
	char buf[256];
	FILE *p;
	int idx;

	p = execl_popen(0, PATH_WL, "-a", iface->name, "assoclist");
	if (!p)
		return -1;

	for (idx = 0; fgets(buf, 256, p);) {
		macaddr_t macaddr;
		char *mac = gettok(buf, NULL, 1, SPACE);
		if (mac == NULL || str2mac(mac, macaddr))
			continue;
		if (halbuf && callback) {
			if (callback(iface, halbuf, idx, mac))
				break;
		}
		idx++;
	}
	execl_pclose(p);
	*len = idx;
	return 0;
}

int wl_assoc_list_cb(const struct iface *iface, char *halbuf, int idx, char *mac)
{
	struct assoc_stats *asbuf = (struct assoc_stats *)halbuf;
	struct assoc_stats *as = asbuf + idx;
	char buf[256];
	char *tok;
	FILE *p;
	int rssi;

	if (hal_buf_check_clear(halbuf, idx, sizeof(*as)))
		return -1;

	str2mac(mac, as->macaddr);
	as->macaddr_set = 1;

	/* Note: old wl versions don't report bandwidth at all =>
	 * we can't set default bandwidth to 20. */

	p = execl_popen(0, PATH_WL, "-a", iface->name, "sta_info", mac);
	if (!p)
		return -1;

	while (fgets(buf, 256, p)) {
		if (tok = strstr(buf, " 40MHz")) {
			FLDSET(as->bandwidth, 40);
		} else if (tok = gettok(buf, "in network ", 2, SPACE)) {
			FLDSET(as->time, atoi(tok));
		} else if (tok = gettok(buf, "last rx pkt:", 3, SPACE)) {
			FLDSET(as->rx_rate, atoi(tok) / 1000 * 1024);
		} else if (tok = gettok(buf, "last tx pkt:", 3, SPACE)) {
			FLDSET(as->tx_rate, atoi(tok) / 1000 * 1024);
		}
	}
	execl_pclose(p);

	rssi = execl_get_int(0, GREP(NULL), AWK(0, NULL), PATH_WL, "-a", iface->name, "rssi", mac);
	if (rssi > INT_MIN && rssi < 0)
		FLDSET(as->rssi, rssi);
	return 0;
}

int hal_wl_assoc_list(const struct iface *iface, char *halbuf, int *len)
{
	struct assoc_stats *asbuf = (struct assoc_stats *)halbuf;
	struct assoc_stats *as;
	int len1 = 0;
	int noise = wl_get_noise(iface->name);

	if (wl_iterate_assoclist(iface, halbuf, &len1, wl_assoc_list_cb))
		return -1;

	if (halbuf && noise < 0) {
		for (as = asbuf; as < asbuf + len1; as++) {
			if (as->rssi_set)
				FLDSET(as->snr, as->rssi - noise);
		}
	}
	*len = len1;
	return 0;
}

int wl_traffic_list_cb(const struct iface *iface, char *halbuf, int idx, char *mac)
{
	struct traffic_stats *tsbuf = (struct traffic_stats *)halbuf;
	struct traffic_stats *ts = tsbuf + idx;
	char buf[256];
	char *tok;
	FILE *p;

	if (hal_buf_check_clear(halbuf, idx, sizeof(*ts)))
		return -1;

	str2mac(mac, ts->macaddr);
	ts->macaddr_set = 1;

	p = execl_popen(0, PATH_WL, "-a", iface->name, "sta_info", mac);
	if (!p)
		return -1;

	while (fgets(buf, 256, p)) {
		if (tok = gettok(buf, "rx data bytes:", 3, SPACE)) {
			FLDSET(ts->rx_bytes, atoll(tok));
		} else if (tok = gettok(buf, "tx data bytes:", 3, SPACE)) {
			FLDSET(ts->tx_bytes, atoll(tok));
		} else if (tok = gettok(buf, "tx total bytes:", 3, SPACE)) {
			FLDSET(ts->tx_bytes, atoll(tok));
		} else if (tok = gettok(buf, "rx data pkts:", 3, SPACE)) {
			FLDSET(ts->rx_packets, atoi(tok));
		} else if (tok = gettok(buf, "tx data pkts:", 3, SPACE)) {
			FLDSET(ts->tx_packets, atoi(tok));
		} else if (tok = gettok(buf, "tx total pkts:", 3, SPACE)) {
			FLDSET(ts->tx_packets, atoi(tok));
		} else if (tok = gettok(buf, "tx pkts:", 2, SPACE)) {
			FLDSET(ts->tx_packets, atoi(tok));
		} else if (tok = gettok(buf, "rx mcast/bcast pkts:", 3, SPACE)) {
			if (ts->rx_unicast_set && !ts->rx_packets_set)
				FLDSET(ts->rx_packets, ts->rx_unicast + atoi(tok));
		} else if (tok = gettok(buf, "rx ucast pkts:", 3, SPACE)) {
			FLDSET(ts->rx_unicast, atoi(tok));
		} else if (tok = gettok(buf, "tx ucast pkts:", 3, SPACE)) {
			FLDSET(ts->tx_unicast, atoi(tok));
		} else if (tok = gettok(buf, "tx failures:", 2, SPACE)) {
			FLDSET(ts->tx_error, atoi(tok));
		} else if (tok = gettok(buf, "retried:", 1, SPACE)) {
			FLDSET(ts->tx_retries, atoi(tok));
		}
	}
	execl_pclose(p);
	return 0;
}

int hal_wl_traffic_list(const struct iface *iface, char *halbuf, int *len)
{
	int len1 = 0;
	if (wl_iterate_assoclist(iface, halbuf, &len1, wl_traffic_list_cb))
		return -1;
	*len = len1;
	return 0;
}

int hal_wl_phy_stats(const struct iface *iface, struct phy_stats *halps)
{
	int32_t noise = wl_get_noise(iface->name);
	uint32_t channel;
	int len;

	if (hal_wl_channel(iface, &channel))
		return -1;
	FLDSET(halps->channel, channel);

	if (noise < 0)
		FLDSET(halps->rx_noise, noise);

	if (wl_iterate_assoclist(iface, NULL, &len, NULL))
		return -1;

	FLDSET(halps->assoc, len);
	return 0;
}

int hal_wl_cca_stats(const struct iface *iface, struct cca_stats *cca)
{
	char buf[256];
	int stat[13];
	int i;

	if (execl_output_grep_awk(buf, 256, F_DEV_NULL | F_AT_START, GREP("0x"), AWK(0, NULL),
		PATH_WL, "-a", iface->name, "chanim_stats") == NULL)
		return -ENOTSUP;

	strtok(buf, SPACE);
	for (i = 0; i < 13; ++i) {
		char *tok = strtok(NULL, SPACE);
		if (!tok)
			return -1;
		stat[i] = atoi(tok) * 10;
	}

	if (stat[12] > 1000 || stat[12] < 0) {
		/* In old wl versions there is no idle parameter,
		 * but a big timestamp value instead. */
		stat[12] = 1000 - stat[0] - stat[1] - stat[2] - stat[3] - stat[4];
		if (stat[12] < 0)
			stat[12] = 0;
	}

	/*                 tx        rx        cci       [ac]ci?   aci       idle   */
	FLDSET(cca->total, stat[0] + stat[1] + stat[2] + stat[3] + stat[4] + stat[12]);
	FLDSET(cca->idle, stat[12]);
	FLDSET(cca->cs_ed, stat[2] + stat[3] + stat[4]);
	FLDSET(cca->rx, stat[1]);
	FLDSET(cca->tx, stat[0]);

	/* Note: it looks like stat[3] (nocat) could belong either to stat[2] (obss)
	 * or to stat[4] (nopkt), and it also looks like it is split between them
	 * according to proportion between stat[2] and stat[4], so approximately
	 * cci = stat[2] + (stat[2] / (stat[2] + stat[4])) * stat[3],
	 * aci = stat[4] + (stat[4] / (stat[2] + stat[4])) * stat[3]. */

	return 0;
}

int hal_wl_channel_list(const struct iface *iface, char *halbuf, int *len)
{
	struct channel_desc *chd = (struct channel_desc *)halbuf;
	char buf[256];
	/* chanspec_txpwr_max is not available in old wl versions */
	char *have_chanspec = execl_output_grep_awk(buf, 256, F_DEV_NULL, GREP("dbm"), AWK(0, NULL),
		PATH_WL, "chanspec_txpwr_max");
	char *cmd = (have_chanspec) ? "chanspec_txpwr_max" : "chan_info";
	FILE *p;
	int len1 = 0;

	snprintf(buf, 256, cmd, iface->name);
	p = execl_popen(F_DEV_NULL, PATH_WL, "-a", iface->name, cmd);
	if (!p)
		return -1;

	len1 = 0;
	while (fgets(buf, 256, p)) {
		char *tok = strtok(buf, SPACE);
		if (!have_chanspec)
			tok = strtok(NULL, SPACE);
		if (tok) {
			int channel = atoi(tok);
			int txpower = 0;

			/* process digit-only chanspecs (we are interested in beacon txpower) */
			if (channel == 0 || check_string(tok, isdigit))
				continue;

			strtok(NULL, SPACE);
			if (tok = strtok(NULL, SPACE)) {
				txpower = atoi(tok);
				if (txpower <= 1)
					continue;
			}

			if (hal_buf_check_clear(halbuf, len1, sizeof(*chd)))
				break;

			FLDSET(chd->channel, channel);
			if (txpower)
				FLDSET(chd->txpower, txpower);
			chd++;
			len1++;
		}
	}
	execl_pclose(p);
	*len = len1;
	return 0;
}

#define SCAN_DURATION 10
int hal_wl_scan_start(const struct iface *iface, const int force)
{
	return (execl_run(0, PATH_WL, "-a", iface->name, "scan", "-t", "passive")) ? -1 : 0;
}

int hal_wl_scan_duration(const struct iface *iface, uint32_t *duration)
{
	*duration = SCAN_DURATION;
	return 0;
}

int hal_wl_scan_status(const struct iface *iface, uint32_t *status)
{
	string16 buf;
	*status = (execl_output_grep_awk(buf, sizeof(buf), F_AT_START, GREP("Scan"), AWK(0, NULL),
		PATH_WL, "-a", iface->name, "channel")) ? SCAN_IN_PROGRESS : 0;
	return 0;
}

int hal_wl_scan_list(const struct iface *iface, char *halbuf, int *len)
{
	struct scan_stats *ss;
	char buf[256];
	char *tok;
	FILE *p;

	if (iface != iface->phy)
		return -1;

	p = execl_popen(0, PATH_WL, "-a", iface->name, "scanresults");
	if (!p)
		return -1;

	ss = (struct scan_stats *)halbuf - 1;
	*len = 0;
	while (fgets(buf, 256, p)) {
		if (tok = gettok(buf, "SSID: \"", 1, "\"")) {
			if (hal_buf_check_clear(halbuf, *len, sizeof(*ss)))
				break;
			ss++;
			(*len)++;
			FLDSET(ss->bandwidth, 20);
			strncpy(ss->ssid, tok, sizeof(string32) - 1);
			ss->ssid_set = 1;
		} else if (tok = gettok(buf, "BSSID:", 1, SPACE)) {
			str2mac(tok, ss->bssid);
			ss->bssid_set = 1;
		} else if (tok = gettok(buf, "RSSI:", 1, SPACE)) {
			FLDSET(ss->rssi, atoi(tok));
			if (tok = gettok(tok + 5, "Channel:", 1, SPACE)) {
				FLDSET(ss->channel, atoi(tok));
				if (ss->channel <= 14) {
					ss->protocol |= PROTO_11B;
					ss->protocol |= PROTO_11G;
				} else {
					ss->protocol |= PROTO_11A;
				}
				ss->protocol_set = 1;
			}
		} else if (tok = strstr(buf, "\tHT Capabilities:")) {
			ss->protocol |= PROTO_11N;
		} else if (tok = strstr(buf, "VHT Capabilities:")) {
			if (ss->channel > 14)
				ss->protocol |= PROTO_11AC;
		} else if (tok = gettok(buf, "Chanspec:", 4, SPACE)) {
			FLDSET(ss->bandwidth, atoi(tok));
		}
	}
	execl_pclose(p);
	return 0;
}

int wl_set_chan_bw(const struct iface *iface, uint32_t channel, uint32_t bandwidth)
{
	uint32_t curchan = 0;
	uint32_t curbw = 0;
	uint32_t bw;

	if (hal_wl_channel(iface, &curchan) || hal_wl_bandwidth(iface, &curbw))
		return -1;
	if (channel == 0)
		channel = curchan;
	if (bandwidth == 0)
		bandwidth = curbw;
	if (curchan == channel && curbw == bandwidth)
		return 0;

	if (curchan != channel) {
		if (execl_run(0, PATH_WL, "-a", iface->name, "channel", str16("%d", channel)))
			return -1;
	}

	/* When we set channel with "wl channel", bandwidth is reset to 20MHz.
	 * "wl chanspec" has to be available to adjust bandwidth.
	 * Here we are trying to set bandwidth closest to requested one. */
	for (bw = 160; bw >= 20; bw /= 2) {
		char *suffix = "";
		if (bandwidth < bw)
			continue;
		if (bw == 40 && channel <= 14)
			suffix = (channel <= 6) ? "l" : "u";
		if (execl_run(0, PATH_WL, "-a", iface->name, "chanspec",
			str16("%d/%d%s", channel, bw, suffix)) == 0)
			break;
	}
	if (execl_run(0, PATH_WL, "-a", iface->name, "down"))
		return -1;
	if (execl_run(0, PATH_WL, "-a", iface->name, "up"))
		return -1;
	return 0;
}

int hal_wl_set_channel(const struct iface *iface, uint32_t channel)
{
	return wl_set_chan_bw(iface, channel, 0);
}

int hal_wl_set_txpower(const struct iface *iface, int32_t txpower)
{
	return execl_run(0, PATH_WL, "-a", iface->name, "txpwr1", str16("%d", txpower)) ? -1 : 0;
}

int hal_wl_set_ssid(const struct iface *iface, char *ssid)
{
	return execl_run(0, PATH_WL, "-a", iface->name, "ssid", ssid) ? -1 : 0;
}

int hal_wl_set_bandwidth(const struct iface *iface, uint32_t bandwidth)
{
	return wl_set_chan_bw(iface, 0, bandwidth);
}


struct hal_ops hal_wl_ops = {
	.name = "wl",

	.init = NULL,
	.reinit = NULL,
	.probe = NULL,

	.mode = hal_wl_mode,
	.channel = hal_wl_channel,
	.txpower = hal_wl_txpower,
	.region = hal_wl_region,
	.bandwidth = hal_wl_bandwidth,
	.bandwidth_supp = hal_wl_bandwidth_supp,
	.protocol = hal_wl_protocol,
	.protocol_supp = hal_wl_protocol_supp,
	.ssid = hal_wl_ssid,
	.bssid = hal_wl_bssid,
	.phy_stats = hal_wl_phy_stats,
	.cca_stats = hal_wl_cca_stats,
	.channel_list = hal_wl_channel_list,
	.assoc_list = hal_wl_assoc_list,
	.traffic_list = hal_wl_traffic_list,
	.scan_start = hal_wl_scan_start,
	.scan_duration = hal_wl_scan_duration,
	.scan_status = hal_wl_scan_status,
	.scan_list = hal_wl_scan_list,

	.set_channel = hal_wl_set_channel,
	.set_txpower = hal_wl_set_txpower,
	.set_ssid = hal_wl_set_ssid,
	.set_bandwidth = hal_wl_set_bandwidth,
};
