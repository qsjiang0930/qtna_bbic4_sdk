/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include <ctype.h>
#include "qharvestd.h"
#include "qh_hal.h"
#include "qh_utils.h"

static int wl_ifup(char *ifname)
{
	/* On ASUS routers Wi-Fi interface could remain "up"
	 * in ifconfig even if it is down in wl driver.
	 * On the other hand, on some Askey/Mitrastar boards
	 * "wl isup" returns 1 even if interface is down.
	 * => we need to combine both methods here. */
	if (get_ifup(ifname) == 0)
		return 0;
	if (execl_get_int(F_DEV_NULL, GREP(NULL), AWK(0, NULL),
			PATH_WL, "-a", ifname, "isup") > 0)
		return 1;
	return 0;
}

static int init_iface_list_wl_dump(struct board *board)
{
	struct iface *head = NULL;
	struct iface **next = &head;
	struct iface *iface;
	char ifname[IFNAMSIZ];
	char buf[256];
	char *tok;
	FILE *p;

	board->ifnum = 0;
	board->head = NULL;

	p = execl_popen(0, PATH_IFCONFIG, "-a");
	if (!p)
		return -1;

	while (fgets(buf, 256, p)) {
		struct iface *phy = NULL;
		macaddr_t hwaddr;
		FILE *p1;

		if (isspace((unsigned char)buf[0]))
			continue;
		if ((tok = strtok(buf, SPACE)) == NULL)
			continue;
		snprintf(ifname, sizeof(ifname), "%s", tok);
		sanitize_ifname(ifname);

		/* Use it to check that interface type is 'Ethernet',
		 * because on non-ethernet interfaces wl could crash. */
		if (get_macaddr(ifname, hwaddr))
			continue;

		p1 = execl_popen(F_DEV_NULL, PATH_WL, "-a", ifname, "dump");
		if (!p1)
			continue;

		phy = NULL;
		while (fgets(buf, 256, p1)) {
			if (strstr(buf, "enable ") != buf)
				continue;
			if ((tok = gettok(buf, " \"", 0, SPACE"\"")) == NULL)
				continue;
			if (phy == NULL && strncmp(ifname, tok, sizeof(ifname)) != 0)
				break; /* not a phy */
			*next = iface = xcalloc(1, sizeof(*iface));
			next = &iface->next;
			snprintf(iface->name, sizeof(iface->name), "%s", tok);
			if (!phy)
				phy = iface;
			iface->phy = phy;
			iface->hal = &hal_wl_ops;
			iface->board = board;
			iface->up = wl_ifup(iface->name);
			(board->ifnum)++;
		}
		execl_pclose(p1);
	}
	execl_pclose(p);

	board->head = head;
	return 0;
}

static int init_iface_list_hwaddr(struct board *board)
{
	struct iface *head = NULL;
	struct iface **next = &head;
	struct iface *iface;
	char ifname[IFNAMSIZ];
	char buf[256];
	char *tok;
	FILE *p;
	int vap;

	board->ifnum = 0;
	board->head = NULL;

	/* Try to guess VAP <-> PHY relations using MAC addresses
	 * reported by ifconfig and wl perm_etheraddr. */
	for (vap = 0; vap <= 1; vap++) {
		p = execl_popen(0, PATH_IFCONFIG, "-a");
		if (!p)
			return -1;

		while (fgets(buf, 256, p)) {
			struct iface *phy = NULL;
			int is_vap;
			macaddr_t hwaddr;
			macaddr_t wladdr;

			if (isspace((unsigned char)buf[0]))
				continue;
			if (NULL == (tok = strtok(buf, SPACE)))
				continue;
			snprintf(ifname, sizeof(ifname), "%s", tok);
			sanitize_ifname(ifname);

			if (get_macaddr(ifname, hwaddr))
				continue;

			if (NULL == (tok = execl_output_grep_awk(NULL, 0, F_DEV_NULL,
				GREP(NULL), AWK(2, SPACE), PATH_WL, "-a", ifname, "perm_etheraddr")))
				continue;
			str2mac(tok, wladdr);
			free(tok);

			/* For PHY interfaces ifconfig hwaddr == wl perm_etheraddr. */
			is_vap = memcmp(hwaddr, wladdr, sizeof(macaddr_t));

			if (vap == 0) {
				if (is_vap)
					continue;
			} else {
				/* For VAP interfaces ifconfig hwaddr == wl cur_etheraddr
				 * and wl perm_etheraddr == MAC address of its PHY. */
				char *ifnames;
				char *phyname;

				if (!is_vap)
					continue;

				/* Grep only strings with interface names =>
				 * filter out strings with leading space. */
				ifnames = execl_output_grep_awk(NULL, 0,
					 F_AT_START | F_GREP_INV | F_GREP_ALL,
					GREP(" "), AWK(1, SPACE), PATH_IFCONFIG);
				if (!ifnames)
					continue;

				/* Search for the first broadcom Wi-Fi interface
				 * with the same ifconfig MAC as wladdr. */
				for (phyname = strtok(ifnames, SPACE);
				     phyname;
				     phyname = strtok(NULL, SPACE)) {
					macaddr_t mac;
					sanitize_ifname(phyname);
					if (get_macaddr(phyname, mac))
						continue;
					if (memcmp(mac, wladdr, sizeof(mac)))
						continue;
					if (execl_run(F_DEV_NULL,
					    PATH_WL, "-a", phyname, "perm_etheraddr") == 0)
						break;
				}

				for (phy = head; phy && phyname; phy = phy->next) {
					if (strcmp(phyname, phy->name) == 0)
						break;
				}
				free(ifnames);
				if (!phy)
					continue;
			}

			*next = iface = xcalloc(1, sizeof(*iface));
			next = &iface->next;
			snprintf(iface->name, sizeof(iface->name), "%s", ifname);
			if (!phy)
				phy = iface;
			iface->phy = phy;
			iface->hal = &hal_wl_ops;
			iface->board = board;
			iface->up = wl_ifup(iface->name);
			(board->ifnum)++;
		}
		execl_pclose(p);
	}

	board->head = head;
	return 0;
}

static int board_brcm_get_firmware_version(string32 version)
{
	return execl_output_grep_awk(version, sizeof(string32), F_POS_GREP,
		GREP("version"), AWK(2, SPACE), PATH_WL, "ver") ? 0 : -1;
}

int board_brcm_init_iface_list(struct board *board)
{
	string32 version;
	return execl_output_grep_awk(version, sizeof(string32), F_DEV_NULL | F_POS_GREP,
		GREP("version"), AWK(2, SPACE), PATH_WL, "dump") ?
		init_iface_list_wl_dump(board) : init_iface_list_hwaddr(board);
}

static inline int board_brcm_get_macaddr(macaddr_t macaddr)
{
#ifdef BRCM_MAC_PERM_ETHERADDR
	char *mode = "perm_etheraddr";
#else
	char *mode = "cur_etheraddr";
#endif
	string32 mac;
	if (NULL == execl_output_grep_awk(mac, sizeof(mac), 0,
		GREP(NULL), AWK(2, SPACE), PATH_WL, mode))
		return -1;
	if (str2mac(mac, macaddr))
		return -1;
	return 0;
}

int board_brcm_init(struct board *board)
{
	if (!board_brcm_get_macaddr(board->macaddr))
		board->macaddr_set = 1;
	if (!board_brcm_get_firmware_version(board->firmware))
		board->firmware_set = 1;
	return 0;
}

int board_brcm_upgrade(struct board *board, char *fw_file)
{
	return -ENOTSUP;
}

struct board board_brcm = {
	.name = "brcm",
	.init_iface_list = board_brcm_init_iface_list,
	.free_iface = NULL,
	.init = board_brcm_init,
	.upgrade = board_brcm_upgrade,
	.firmware_set = 0,
	.kernel_set = 0,
	.platform_set = 0,
	.reboot_cause_set = 0,
	.carrier_id_set = 0,
};
