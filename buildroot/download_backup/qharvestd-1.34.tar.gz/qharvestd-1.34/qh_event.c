/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#define _GNU_SOURCE
#include <fcntl.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include "qh_event.h"
#include "qh_utils.h"

#define BUSY_LOOP_THRES 1024

struct pollfd pollfd[EVENT_MAX];
qh_cb pollcb[EVENT_MAX];
void *pollarg[EVENT_MAX];
uint8_t pollarg_flags[EVENT_MAX];

void qh_event_set(int idx, int fd, int events)
{
	if (idx < 0 || idx >= EVENT_MAX)
		return;
	qh_event_cleanup(idx);
	pollfd[idx].fd = fd;
	pollfd[idx].events = events;
	pollarg_flags[idx] |= EVENTF_SET;
}

int qh_event_is_set(int idx)
{
	if (idx < 0 || idx >= EVENT_MAX)
		return 0;
	return (pollarg_flags[idx] & EVENTF_SET);
}

void qh_event_cleanup(int idx)
{
	if (idx < 0 || idx >= EVENT_MAX)
		return;
	pollfd[idx].fd = -1;
	pollfd[idx].events = 0;
	pollfd[idx].revents = 0;
	pollcb[idx] = NULL;
	if (pollarg[idx] && (pollarg_flags[idx] & EVENTF_ARG_AUTOFREE))
		free(pollarg[idx]);
	pollarg[idx] = NULL;
	pollarg_flags[idx] = 0;
}

void qh_event_init()
{
	int i;
	for (i = 0; i < EVENT_MAX; ++i)
		qh_event_cleanup(i);
}

struct pollfd *qh_event_get_pollfd(int idx)
{
	if (idx < 0 || idx >= EVENT_MAX)
		return NULL;
	return &pollfd[idx];
}

void qh_event_set_cb_ext(int idx, qh_cb cb, void *arg, int autofree)
{
	if (idx < 0 || idx >= EVENT_MAX)
		return;
	pollcb[idx] = cb;
	if (pollarg[idx] && (pollarg_flags[idx] & EVENTF_ARG_AUTOFREE))
		free(pollarg[idx]);
	pollarg[idx] = arg;
	pollarg_flags[idx] |= (autofree) ? EVENTF_ARG_AUTOFREE : 0;
}

int qh_event_listen(struct timespec *time)
{
	struct timespec remain;
	struct timespec nowait = { 0, 0 };
	int interrupt = 0;
	int busy = 0;

	timespec_set(&remain, (time) ? time : &nowait);

	while (timespec_cmp(&remain, NULL) >= 0) {
		struct timespec start;
		struct timespec end;
		struct timespec diff;
		int poll_request = 0;
		int listeners = 0;
		int busy_event = -1;
		int i;

		/* Here plain "event => callback" model doesn't work, because
		 * if we received multiple bidirectional commands in one shot,
		 * and the first one demanded interrupt (to send response by HTTP),
		 * other ones are still need to be processed on next iteration
		 * even if there is no incoming event => we need to call callbacks
		 * before any blocking poll and see whether they demand more data
		 * to be polled. */

		clock_gettime(CLOCK_MONOTONIC, &start);

		/* Non-blocking poll to update pollfd states. */
		(void) ppoll(pollfd, EVENT_MAX, &nowait, NULL);

		interrupt = 0;
		for (i = 0; i < EVENT_MAX; i++) {
			if (pollfd[i].fd < 0 || pollcb[i] == NULL)
				continue;
			listeners++;
			switch (pollcb[i](&pollfd[i], pollarg[i])) {
			case 0:
				busy_event = i;
				break;
			case -ECOMM:
				interrupt = -ECOMM;
				break;
			case -EINTR:
				if (interrupt == 0)  /* -ECOMM has priority over -EINTR */
					interrupt = -EINTR;
				break;
			case -ENODATA:
				poll_request++;
				break;
			case -ENOTCONN:
			default:
				listeners--;
				qh_event_cleanup(i);
			}
		}
		clock_gettime(CLOCK_MONOTONIC, &end);
		timespec_sub(&diff, &end, &start);
		timespec_sub(&remain, &remain, &diff);

		if (interrupt != 0 || listeners == 0)
			break;

		/* Do not block at poll if at least one callback has data to process. */
		if (poll_request == listeners) {
			busy = 0;
			clock_gettime(CLOCK_MONOTONIC, &start);
			(void) ppoll(pollfd, EVENT_MAX, &remain, NULL);
			clock_gettime(CLOCK_MONOTONIC, &end);
			timespec_sub(&diff, &end, &start);
			timespec_sub(&remain, &remain, &diff);
		}

		if (++busy == BUSY_LOOP_THRES) {
			DBG_INFO("event: possible busy loop: %d+ continuous iterations on event %d",
				busy, busy_event);
		}
	}
	if (time)
		timespec_set(time, &remain);
	return interrupt;
}

void qh_event_listen_sleep(struct timespec *time)
{
	int intr;
	for (intr = 1; intr != 0;)
		intr = qh_event_listen(time);
	/* there could be no event listeners => then we need just to sleep for remaining time */
	(void)nanosleep(time, NULL);
}

struct async_s {
	int event;
	int fd;
	pthread_t tid;
	async_f func;
	async_cb cb;
	void *data;
	int status;
};

static int run_async_cb(struct pollfd *pfd, void *data)
{
	int ret = -ENODATA;
	if (pfd->revents & (POLLERR | POLLHUP | POLLNVAL)) {
		struct async_s *s = (struct async_s *)data;

		pthread_join(s->tid, NULL);
		close(pfd->fd); // close read side
		qh_event_cleanup(s->event);
		if (s->cb)
			ret = s->cb(s->status, s->data);
		free(s);
	}
	return ret;
}

static void *run_async_func(void *data)
{
	struct async_s *s = (struct async_s *)data;
	if (s->func)
		s->status = s->func(s->data);
	close(s->fd); // close write side
	return NULL;
}

int run_async(int event, async_f func, async_cb cb, void *data)
{
	struct async_s *s;
	int pipefd[2];

	if (qh_event_is_set(event))
		return -1;
	if (pipe(pipefd))
		return -1;

	s = xmalloc(sizeof(struct async_s));

	qh_event_set(event, pipefd[0], 0);
	qh_event_set_cb(event, run_async_cb, (void *)s);

	s->event = event;
	s->fd = pipefd[1];
	s->func = func;
	s->cb = cb;
	s->data = data;
	s->status = 0;

	if (pthread_create(&s->tid, NULL, run_async_func, (void *)s) == 0)
		return 0;

	close(pipefd[0]);
	close(pipefd[1]);
	free(s);
	qh_event_cleanup(event);
	return -1;
}
