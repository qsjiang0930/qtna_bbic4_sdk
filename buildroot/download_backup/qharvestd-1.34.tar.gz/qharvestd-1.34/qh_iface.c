/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include "qh_iface.h"
#include "qh_json.h"
#include "qh_utils.h"
#include "qharvestd.h"
#include "qh_hal.h"

struct iface *iflist = NULL;
int ifnum = 0;
macaddr_t g_macaddr = { 0 };

struct iface* get_iface_list(int *ifnum)
{
	struct iface *head = NULL;
	struct iface **next = &head;
	int brd;

	*ifnum = 0;

	for (brd = 0; brd < boards_num; brd++) {
		struct board *board = boards[brd];

		board->init_iface_list(board);
		*next = board->head;
		while (*next)
			next = &((*next)->next);
		*ifnum += board->ifnum;
	}

	return head;
}

void free_iface_list(struct iface *head, int *ifnum)
{
	struct iface *next = head;
	*ifnum = 0;
	while (next) {
		head = next;
		next = head->next;
		if (head->board && head->board->free_iface)
			head->board->free_iface(head);
		else
			free(head);
	}
	return;
}

int get_wifi_mode(int default_mode)
{
	uint32_t mode = default_mode;
	struct iface *iface;

	for (iface = iflist; iface; iface = iface->next) {
		if (iface->up == 0)
			continue;
		iface->hal->mode(iface, &mode);

		/* report device mode as AP if at least one interface mode is AP */
		if (mode == WIFI_MODE_AP)
			break;
	}
	return mode;
}

int init_global_mac_addr(struct board *board)
{
	if (config.debug_config.mac) {
		if (str2mac(config.debug_config.mac, g_macaddr))
			return -1;
	} else if (board && board->macaddr_set) {
		memcpy(g_macaddr, board->macaddr, sizeof(macaddr_t));
	} else {
		return -1;
	}
	return 0;
}
