#!/bin/sh

. /usr/share/libubox/jshn.sh

ENOTIMPL=252

CMD="$1"
PARAM="$2"
VALUE="$3"
IFACE="$4"

get_cfg_section()
{
	local iface=$1
	local radio radios
	local item items
	local ifname section

	json_load "`wifi status`" || return 1
	json_get_keys radios
	for radio in $radios; do
		json_select "$radio"
		json_get_keys items "interfaces"
		json_select "interfaces"
			for item in $items; do
				json_select "$item"
				json_get_var section "section"
				json_get_var ifname "ifname"
				if [ "$ifname" = "$iface" ]; then
					echo -n "$section"
					return 0
				fi
				json_select ".."
			done
		json_select ".."
		json_select ".."
	done

	return 1
}

if [ -n "$IFACE" ]; then
	SECTION=`get_cfg_section $IFACE`
	RADIO=`uci get wireless.$SECTION.device`
	if [ -z "$SECTION" ] || [ -z "$RADIO" ]; then
		exit 1
	fi
fi

if [ "$CMD" = "get" ]; then
	case "$PARAM" in
	firmware)
		. /etc/openwrt_release && echo "$DISTRIB_DESCRIPTION";;
	*)
		exit $ENOTIMPL;;
	esac
elif [ "$CMD" = "set" ]; then
	[ -z "$VALUE" ] && exit 1

	case "$PARAM" in
	channel)
		uci set wireless.$RADIO.channel=$VALUE; uci commit wireless; wifi;;
	bandwidth)
		mode=HT
		uci get wireless.$RADIO.htmode | grep VHT > /dev/null && mode=VHT
		[ "$VALUE" -ge 80 ] && mode=VHT
		uci set wireless.$RADIO.htmode=$mode$VALUE; uci commit wireless; wifi;;
	txpower)
		uci set wireless.$RADIO.txpower=$VALUE
		if uci commit wireless; then
			# do not reset wifi on txpower adjustments
			iw dev $IFACE set txpower fixed $(($VALUE * 100))
		fi;;
	ssid)
		uci set wireless.$SECTION.ssid=$VALUE; uci commit wireless; wifi;;
	*)
		exit $ENOTIMPL;;
	esac
elif [ "$CMD" = "upgrade" ]; then
	exec sysupgrade "$2"
	exit 1
else
	exit 1;
fi
