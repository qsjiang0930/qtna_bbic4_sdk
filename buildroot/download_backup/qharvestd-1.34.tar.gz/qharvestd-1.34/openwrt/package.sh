#!/bin/sh

dir=`dirname $0`

if [  $# -lt  1 ]
then
	echo "Provide openwrt directory on command line"
	exit 1
else
	OWRTDIR=$1
	if [ ! -d $OWRTDIR ]; then
		echo "Directory $OWRTDIR does not exist - exiting"
		exit 1
	fi
fi

QHDIR=$OWRTDIR/package/utils/qharvestd
[ -d $QHDIR/files ] || mkdir -p $QHDIR/files

if [ "$2" = "git" ]; then
	if ! [ -d $dir/../.git ]; then
		echo "Couldn't find git repo at $dir/../.git"
		exit 1
	fi
	git -C $dir/.. archive --prefix=qharvestd/ -o /tmp/qharvestd.tar.gz HEAD
else
	tar -C $dir/.. --exclude-vcs --transform 's@^@qharvestd/@' \
		-czf /tmp/qharvestd.tar.gz `ls -A $dir/..`
fi

cp $dir/openwrt.mk $QHDIR/Makefile
cp $dir/qharvestd.init $QHDIR/files/
cp $dir/qharvestd.sh $QHDIR/files/

[ -d $OWRTDIR/dl ] || mkdir -p $OWRTDIR/dl
mv /tmp/qharvestd.tar.gz $OWRTDIR/dl
