/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include <syslog.h>
#include <stdarg.h>
#include <stdio.h>
#include "qharvestd.h"
#include "qh_printf.h"

const char *log_level_str[] = {"error", "warning", "notice", "info"};

void debug_printf(int level, const char *fmt, ...)
{
	va_list ap;
	char format[256];
	if (config.debug + LOG_CRIT < level)
		return;
	va_start(ap, fmt);
	snprintf(format, 256, "qharvestd[%s]: %s", log_level_str[level - LOG_ERR], fmt);
	if (config.debug_config.console_print) {
		vprintf(format, ap);
		printf("\n");
	} else if (config.syslog) {
		vsyslog(level, format, ap);
	}
	va_end(ap);
}
