/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#include "qharvestd.h"
#include "qh_curl_ws.h"
#include "qh_event.h"
#include "qh_utils.h"
#include "qh_json.h"
#include "qh_json_action.h"
#include "qh_json_rpc.h"

struct jsonrpc_request {
	char *version;
	char *method;
	JSON *params;
	int id;
	int timeout;
};

static struct data_description jsonrpc_request_desc[] = {
	{KEY_JSONRPC_VERSION, TYPE_STRING, FLAG_MANDATORY, OFFSET(jsonrpc_request, version)},
	{KEY_JSONRPC_METHOD,  TYPE_STRING,              0, OFFSET(jsonrpc_request, method)},
	{KEY_JSONRPC_PARAMS,  TYPE_OBJECT,              0, OFFSET(jsonrpc_request, params)},
	{KEY_JSONRPC_ID,      TYPE_S32,                 0, OFFSET(jsonrpc_request, id)},
	{KEY_JSONRPC_TIMEOUT, TYPE_S32,                 0, OFFSET(jsonrpc_request, timeout)},
	{NULL, TYPE_VOID, 0, 0}
};

struct jsonrpc_context {
	struct jsonrpc_request *req;
	char *out;
	char *err;
};

void *queue;

static int jsonrpc_schedule(struct jsonrpc_request *req);

static void jsonrpc_send_error(int id, int code, char *message, JSON *data)
{
	struct pollfd *ws = qh_event_get_pollfd(EVENT_WS);
	JSON *jobj;
	JSON *eobj;
	const char *json;

	if (ws == NULL || ws->fd < 0 || id < 0)
		return;

	jobj = JSON_NEW_OBJ();
	eobj = JSON_NEW_OBJ();
	JSON_ADD_STRING_FIELD(jobj, KEY_JSONRPC_VERSION, "2.0");
	JSON_ADD_INT_FIELD(jobj, KEY_JSONRPC_ID, id);
	JSON_ADD_INT_FIELD(eobj, KEY_JSONRPC_CODE, code);
	if (message == NULL)
		message = "";
	JSON_ADD_STRING_FIELD(eobj, KEY_JSONRPC_MESSAGE, message);
	if (data)
		JSON_ADD_FIELD(eobj, KEY_JSONRPC_DATA, data);
	JSON_ADD_FIELD(jobj, KEY_JSONRPC_ERROR, eobj);
	json = JSON_TO_STRING(jobj);
	if (send_ws_msg(ws->fd, WS_TEXT, json, strlen(json)) == 0)
		DBG_INFO("> ws: text: %s", json);
	JSON_FREE_STRING(json);
	JSON_PUT_REF(jobj);
}

static void jsonrpc_send_result(int id, int code, char *message, char *error)
{
	struct pollfd *ws = qh_event_get_pollfd(EVENT_WS);
	JSON *jobj;
	JSON *robj;
	const char *json;

	if (ws == NULL || ws->fd < 0 || id < 0)
		return;

	jobj = JSON_NEW_OBJ();
	robj = JSON_NEW_OBJ();
	JSON_ADD_STRING_FIELD(jobj, KEY_JSONRPC_VERSION, "2.0");
	JSON_ADD_INT_FIELD(jobj, KEY_JSONRPC_ID, id);
	JSON_ADD_INT_FIELD(robj, KEY_JSONRPC_CODE, code);
	if (message)
		JSON_ADD_STRING_FIELD(robj, KEY_JSONRPC_MESSAGE, message);
	if (error)
		JSON_ADD_STRING_FIELD(robj, KEY_JSONRPC_ERROR, error);
	JSON_ADD_FIELD(jobj, KEY_JSONRPC_RESULT, robj);
	json = JSON_TO_STRING(jobj);
	if (send_ws_msg(ws->fd, WS_TEXT, json, strlen(json)) == 0)
		DBG_INFO("> ws: text: %s", json);
	JSON_FREE_STRING(json);
	JSON_PUT_REF(jobj);
}

static struct jsonrpc_request *req_alloc(struct jsonrpc_request *req)
{
	struct jsonrpc_request *r = xmalloc(sizeof(*r));
	memcpy(r, req, sizeof(*r));
	r->method = xstrdup(req->method); // original string is tied to JSON object
	r->params = JSON_GET_REF(req->params);
	return r;
}

static void req_cleanup(struct jsonrpc_request *req)
{
	if (req == NULL)
		return;
	if (req->method)
		free(req->method);
	if (req->params)
		JSON_PUT_REF(req->params);
	free(req);
}

/* NOTE: passed request object is tied to context =>
 * its lifetime will be the same as context lifetime.
 */
static struct jsonrpc_context *ctx_alloc(struct jsonrpc_request *req)
{
	struct jsonrpc_context *ctx = xcalloc(1, sizeof(*ctx));
	ctx->req = req;
	return ctx;
}

static void ctx_cleanup(struct jsonrpc_context *ctx)
{
	if (ctx == NULL)
		return;
	if (ctx->out)
		free(ctx->out);
	if (ctx->err)
		free(ctx->err);
	req_cleanup(ctx->req);
	free(ctx);
}

/* This function runs in a separate thread and has not to use any
 * variables that are used in the main thread, as otherwise it
 * would require introduction of locks => only context should be used.
 * It means that we can't send JSONRPC messages from this function.
 */
static int jsonrpc_exec(void *data)
{
	struct jsonrpc_context *ctx = (struct jsonrpc_context *)data;
	struct jsonrpc_request *req = ctx->req;
	const char *argv[65] = { 0 };
	/* Total message length shouldn't exceed 64K.
	 * Also let's have some reserve for JSONRPC overhead. */
	int outl = 61440;
	int errl = 2048;

	argv[0] = config.script;
	argv[1] = req->method;

	if (req->params) {
		int i;
		if (JSON_GET_TYPE(req->params) != JSON_ARRAY)
			return JSONRPC_EPARAMS;
		for (i = 2; i < 64; i++) {
			JSON *jparam = JSON_GET_ITEM(req->params, i - 2);
			if (jparam == NULL)
				break;
			if (JSON_GET_TYPE(jparam) != JSON_STRING)
				return JSONRPC_EPARAMS;
			argv[i] = JSON_GET_STRING(jparam);
		}
	}
	return execv_run_ext_limit(0, &ctx->out, &outl, &ctx->err, &errl, req->timeout, argv);
}

static int jsonrpc_cb(int status, void *data)
{
	struct jsonrpc_context *ctx = (struct jsonrpc_context *)data;
	struct jsonrpc_request *req = ctx->req;

	/* Handle result of just finished command. */
	if (status > JSONRPC_EMAX)
		jsonrpc_send_result(req->id, status, ctx->out, ctx->err);
	else
		jsonrpc_send_error(req->id, status, NULL, NULL);
	ctx_cleanup(ctx);

	/* Schedule next command if any. */
	req = obj_dequeue(&queue);
	if (req)
		jsonrpc_schedule(req);

	/* The event is processed and is oneshot, but do not clean it up,
	 * as it has already been cleaned up before this callback and
	 * we optionally rearm it here if there are pending commands.
	 */
	return -ENODATA;
}

static int jsonrpc_schedule(struct jsonrpc_request *req)
{
	struct jsonrpc_context *ctx = ctx_alloc(req);
	if (run_async(EVENT_JSONRPC, jsonrpc_exec, jsonrpc_cb, (void *)ctx) != 0) {
		jsonrpc_send_error(req->id, JSONRPC_EINTERNAL, NULL, NULL);
		ctx_cleanup(ctx);
		return -1;
	}
	return 0;
}

int do_jsonrpc(JSON *jobj)
{
	struct jsonrpc_request req = { NULL, NULL, NULL, -1, DEFAULT_LIMIT_SEC };
	struct jsonrpc_request *r;

	if (parse_response(jobj, &req, jsonrpc_request_desc))
		return -EBADMSG;
	if (req.version == NULL || strcmp(req.version, "2.0"))
		return -EBADMSG;
	if (req.method == NULL) {
		jsonrpc_send_error(req.id, JSONRPC_EREQUEST, NULL, NULL);
		return -1;
	}
	if (req.timeout <= 0) {
		jsonrpc_send_error(req.id, JSONRPC_EPARAMS, "invalid timeout", NULL);
		return -1;
	}
	if (!config.script) {
		jsonrpc_send_error(req.id, JSONRPC_EMETHOD, NULL, NULL);
		return -1;
	}

	r = req_alloc(&req);
	if (qh_event_is_set(EVENT_JSONRPC)) {
		/* Another JSONRPC cmd is executing => enqueue the new one for later processing. */
		obj_enqueue(&queue, r);
		return 0;
	}
	return jsonrpc_schedule(r);
}
