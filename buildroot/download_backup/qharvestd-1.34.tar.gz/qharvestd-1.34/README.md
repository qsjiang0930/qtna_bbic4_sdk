**QHARVESTD README**
====================

Overview
--------

The agent (qharvestd) is a program designed to report various Wi-Fi related
device statistics to Quantenna cloud. It could optionally control certain
Wi-Fi settings, effectively putting a device Wi-Fi under control of the cloud.

The agent uses RESTful and Websocket APIs to communicate with a cloud backend.
The agent acts only as a client - it initiates connections instead of waiting
for incoming ones.
The oAuth 2.0 protocol is used for authentication and authorization purposes.

The agent supports multiple Wi-Fi HAL backends:

* QCSAPI (Quantenna);
* QWE (Quantenna's HAL for 3-rd party Wi-Fi radios);
* wl (Broadcom);
* nl80211 (Linux desktop, OpenWRT, LEDE).
* mtk (Custom iwpriv extensions for MediaTek).

For detailed changes history please see [CHANGELOG](CHANGELOG.md).


Dependencies
------------

The agent depends on the following 3-rd party open source libraries:

* libcurl 7.25.0 or higher.
* json-c 0.11 or higher. Version 0.10 - only for Quantenna SDK.
* OpenSSL 0.9.8w or higher.
* zlib 1.2.3 or higher (optional).

It also depends on the following utilities:

* ifconfig (**Mandatory**).
* md5sum (only for firmware upgrade support).
* iw 3.10 or higher (nl80211 only).
* route, arp (optional).


Compilation
-----------

* Compile with local QCSAPI within Quantenna SDK:

    `make SDK_DIR="..."`

* Compile with remote QCSAPI within Quantenna SDK:

    `make SDK_DIR="..." QCSAPI=remote`

* Compile with remote QCSAPI with qcsapi-client package:

    `make QCSAPI_CLIENT_DIR="..."`

* Compile with Quantenna QWE support:

    `make BOARD=qwe`

* Compile with Broadcom wl support:

    `make BOARD=brcm`

* Compile with MediaTek support:

    `make BOARD=mtk`

* Compile with nl80211 support (using libnl3 by default):

    `make BOARD=generic`

* Compile with dual HAL backends support (one of them has to be remote QCSAPI):

    `make BOARD=brcm QCSAPI_CLIENT_DIR="..."`


Configuration
-------------

### Command line options:

* `-V` - print version number of the agent.

* `-c <path to config>` - specify path to config.
  Default is /etc/qharvestd.conf for non-SDK builds and /mnt/jffs2/qharvestd.conf otherwise.

* `-t <seconds>` - timeout on startup before HAL backends initialization [0].

* `-T <seconds>` - timeout after initialization and before the first request to the cloud [120].

* `-F` - fast start. The same as `-T 1`.

* `-v` - enable verbose output to console (force debug=4 console_print=1 config options).

### Config file format:

* `[qharvestd]` section:
  - `baseurl` - URL of a cloud server. **Mandatory**.
  - `syslog` - whether to log to syslog [0].
  - `debug` - debug level. Use 3 for production, 4 for debug. Default is 0 - log nothing.
  - `logfile` - path to log file to send to the cloud [/var/log/messages].
  - `remote_protocol` - RPC protocol to use for remote QCSAPI (tcp, udp, raw, pci) [auto].
  - `remote_iface` - local interface to use for RAW protocol.
  - `remote` - IP address of remote board for TCP, UDP or MAC address for RAW protocol.
  - `script` - path to customization script.
  - `upgrade` - whether to enable firmware upgrade support [HAVE_FW_UPGRADE].
  - `pty` - whether to enable PTY support [CONFIG_PTY_DEFAULT].

* `[curl]` section:
  - `easy` - whether to use blocking 'easy' CURL API instead of non-blocking 'multi' one [0].
  - `ca_file` - path to CA bundle to use to verify server's certificate.
  - `verify_peer` - whether to verify server's certificate [0].
  - `verify_host` - whether to verify server's certificate name against host name in URL [1].
  - `verbose` - whether to enable debugging output from libcurl [0].
  - `bind_iface` - bind traffic to particular interface.
  - `dns_iface` - bind DNS requests to particular interface (requires libcurl 7.33.0+, libcares).
  - `dns_list` - list of DNS servers to use instead of system defaults (requires libcares).

* `[websockets]` section:
  - `url` - override WSS URL returned by the cloud.
  - `ping` - ping WSS server with specified interval, 0 to disable [45].
  - `compress` - apply permessage-deflate compression to websockets connection [HAVE_ZLIB].

* `[oauth]` section:
  - `client_id` - Quantenna-assigned per-client ID device belongs to. **Mandatory**.
  - `device_id` - Arbitrary string, unique device identifier
  [MAC address of the primary Wi-Fi interface].
  - `secret` - Arbitrary string, secret key used to authenticate `device_id` in the cloud [""].

* `[debug]` section:
  - `console_print` - whether to print to console instead of logging to syslog [0].
  - `mac` - device MAC address ID [MAC of the primary Wi-Fi interface of the primary board].

### Authentication notes

Agent needs to be authenticated and authorized in order to function.
Authentication is configured in the `[oauth]` section of the configuration file.

`client_id` is provided by Quantenna. `device_id` and `secret` could either be provided
by a client or be left unspecified, as the agent uses reasonable defaults.
A client should use `device_id` and `secret` to whitelist devices in the cloud.


Integration
-----------

Integration of the agent to various build systems is quite straightforward. It is usually
enough to pass relevant CC, AR, CFLAGS, LDFLAGS and PREFIX as environment variables to `make`
and select desired Wi-Fi HAL backend (see [OpenWRT recipe](openwrt/openwrt.mk) as an example).
But there are some more tips and options:

* **The agent can exit during operation on fatal error**. Although this is rare and usually
  means that there is not enough memory, it is better to wrap qharvestd execution with
  some watchdog script if this functionality is not provided by init system. The simplest
  shell script could be the following:

  ```bash
  while true; do $*; sleep 30; done
  ```

  Then the agent can be started as:

  ```bash
  nohup watchdog.sh qharvestd -c qharvestd.conf &
  ```

* If SSL-certificates are used, then system time has to be synchronized with UTC.
  It could be done by using NTP protocol.

* If compiled with remote QCSAPI support, the `remote` and `remote_protocol` config parameters
  can be set to specify connection parameters for remote QCSAPI. Four protocols are supported:
  * `pci` - `remote` parameter is not needed.
  * `raw` - `remote` parameter should contain remote MAC address.
  * `tcp`, `udp`  - `remote` parameter should contain remote IP address.

  By default remote protocol is autodetected by trying protocols in the following sequence:
  `tcp` -> `udp` -> `raw` -> `pci`. Therefore it is OK to leave `remote_protocol` parameter
  unspecified while providing `remote` parameter for either `raw` or `tcp`, `udp` protocols
  to try them first and use `pci` protocol as a fallback.

  Please note that not all Quantenna SDKs support `pci` and `raw` protocols.

* If compiled with dual HAL backends support, NPU board (index 0) is considered to be
  the primary one. EP board (index 1) could be set to be the primary one by adding
  `-DPRIMARY_BOARD=1` to CFLAGS.

* By default `.` is used by the agent as log file separator. It means that if log file path is
  `/var/log/messages`, then the agent will look for rotated log files like `/var/log/messages.N`
   where `N >= 0`.

  - `-DLOG_SEPARATOR="-"` can be added to CFLAGS to change log file separator symbol to `-`.
  - `-DLOGFILE="filename"` can be added to CFLAGS to change default log file name.

* The agent can call a customization script to get or set parameters. Path to the script
  can be set by the `script` parameter in the `[qharvestd]` section of configuration file.
  The script provides an easy way to reflect changes in Wi-Fi configuration, requested by
  the cloud, in a device config.

* By default paths to utilities used by the agent are resolved by OS based on `PATH` env variable,
  but these paths could be explicitly defined at compile time. For example, to define a path to
  `ifconfig` utility as `/sbin/ifconfig`, `-DPATH_IFCONFIG="/sbin/ifconfig"` option has to be
  added to CFLAGS. See [qharvestd.h](qharvestd.h) for a full list of used utilities.

* The agent can be linked with its dependencies statically if the following options are
  passed to `make`:
  - `LIBCURL_STATIC=y`
  - `LIBJSON_STATIC=y`
  - `LIBSSL_STATIC=y`
  - `LIBPKL_STATIC=y`

* `LDFLAGS_EXTRA` variable can be set to provide additional LDFLAGS at the very end of
   link command. This can be useful in rare corner cases, as linking options are
   position-dependent.

* `HAVE_PTY=y` can be passed to `make` to enable PTY support.

* `HAVE_ZLIB=n` can be passed to `make` to disable websockets compression support.

* `-DCONFIG_PTY_DEFAULT=1` can be added to CFLAGS to enable PTY functionality by default.
  This option assumes that `HAVE_PTY=y` and meaningless otherwise.

* `-DHAVE_FW_UPGRADE=1` can be added to CFLAGS to enable firmware upgrade functionality.
  This option is enabled by default only for builds within Quantenna SDK.

* `-DHAVE_RESOLVCONF_REREAD=0` can be added to CFLAGS to disable rereading of resolv.conf.
  This is a workaround for some C libraries that never do it automatically. Enabled by default.

* `-DHAVE_BIDICMD_REBOOT=0` can be added to CFLAGS to disable 'reboot' bidirectional command.
  Using this command the cloud can reboot device remotely. Enabled by default.

* `-DHAVE_CURL_MULTI=0` can be added to CFLAGS to disable usage of non-blocking 'multi' CURL API,
  which is enabled by default.

* *Broadcom*: by default `wl cur_etheraddr` command is used to get MAC address of the primary
   Wi-Fi interface. But it is possible to use `wl perm_etheraddr` instead by adding
   `-DBRCM_MAC_PERM_ETHERADDR` to CFLAGS.

* *nl80211*: by default nl80211 HAL implementation links with libnl3. `NL_CFLAGS`, `NL_LDFLAGS`
  and `NL_VERSION` variables can be set to alter default behavior. Here is an example of how
  to compile and link the agent against OpenWRT libnl-tiny:

  ```bash
  make BOARD=generic NL_CFLAGS=-I/usr/include/libnl-tiny NL_LDFLAGS=-lnl-tiny NL_VERSION=2
  ```

* *Quantenna*: `HAVE_PKTLOGGER=y` can be passed to `make` to enable pktlogger support.
  This option requires either `SDK_DIR` or `PKTLOGGER_DIR` parameter to be passed to `make`.

* *Quantenna*: `-DQTN_RBS_NO_SCAN` can be added to CFLAGS to disable scan on Wi-Fi interfaces
   running in RBS role.

* *Quantenna*: `-DHAVE_SONIQ=1` can be added to CFLAGS to enable SONiQ topology reports.
  This option is enabled by default only for builds within Quantenna SDK.


Customization script API
------------------------

Implementation of certain platform-dependent functions (mostly, configuration-related commands)
can be delegated to the customization script, an executable with the following API:

`script.sh ACTION PARAMETER [VALUE] [INTERFACE]`

The following combinations are supported:
* `get firmware` (at most 32 printable ASCII characters)
* `get platform` (at most 32 printable ASCII characters)
* `get commandsets` (at most 127 printable ASCII characters)
* `set channel VALUE INTERFACE` (1-14, 36-165)
* `set bandwidth VALUE INTERFACE` (20, 40, 80, 160)
* `set txpower VALUE INTERFACE` (in dBm)
* `set ssid VALUE INTERFACE` (at most 32 characters)
* `upgrade FIRMWARE_FILE`

`get` commands have to return empty string on error or if not implemented.

`set` and `upgrade` commands have to return code 252 (ENOTIMPL) if not implemented.

If path to the script is not set or if the script doesn't implement certain functionality,
then default built-in implementation is used.

OpenWRT-specific [customization script](openwrt/qharvestd.sh) may be used as an example.


Troubleshooting
---------------

* To enable debugging output, set `syslog=1`, `debug=4` in `[qharvestd]` section and
  `console_print=1` in `[debug]` section or just use `-v` command line option.
* If a string `qharvestd successfully initialized by the cloud` appears in an output
  of the agent, then the agent works as expected.
* If the server returns `{ "error": "invalid_client" }`, then check that oAuth `client_id`
  is correct an that device is whitelisted in the cloud.
* If the agent couldn't connect to the server, then check that:
  - the ports `80` (HTTP), `443` (HTTPS), `8443` (WebSocket over TLS) are open
    for outgoing traffic.
  - `nslookup qharvest-prod.quantenna.com` command returns IP address of the cloud server.
* If the agent reports that it `Failed to detect pktlogger support`, it means that
  pktlogger support has been enabled at compile time, but attempt to connect to
  pktlogger daemon failed. Check that pktlogger daemon is started before the agent.


License
-------
See the [LICENSE](LICENSE.md) file for license rights and limitations.
