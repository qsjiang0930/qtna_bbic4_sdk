/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QH_JSON_H
#define __QH_JSON_H

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#define KEY_MESSAGE_POLL_REQUEST			"poll_request"
#define KEY_MESSAGE_CONFIG_REQUEST			"config_request"
#define KEY_MESSAGE_CONFIG_PKTLOGGER_REQUEST		"config_pktlogger"
#define KEY_MESSAGE_LOG_MESSAGES_REQUEST		"log_messages_request"
#define KEY_MESSAGE_LOG_SCS_REPORT_ALL_REQUEST		"log_message_scs_report_all_request"
#define KEY_MESSAGE_LOG_GATHER_INFO_REQUEST		"log_gather_info_request"
#define KEY_MESSAGE_LOG_SCAN_REQUEST			"log_scan_request"
#define KEY_MESSAGE_LOG_BIDICMD_REQUEST			"log_bidicmd_request"
#define KEY_MESSAGE_LOG_CAPABILITIES_REQUEST		"log_capabilities_request"
#define KEY_MESSAGE_LOG_BUNDLED_STATS_REQUEST		"log_bundled_stats_request"
#define KEY_MESSAGE_UPGRADE_REQUEST			"upgrade_request"
#define KEY_MESSAGE_CHECK_HEALTH			"check_health"
#define KEY_MESSAGE_PING_WS				"ping_ws"
#define KEY_MESSAGE_OAUTH				"oauth"

#define KEY_POLL_ENABLE				"poll_enable"
#define KEY_POLL_INTERVAL			"poll_interval"
#define KEY_POLL_DELAY				"poll_delay"
#define KEY_CONFIG_ENABLE			"config_enable"
#define KEY_CONFIG_INTERVAL			"config_interval"
#define KEY_CONFIG_DELAY			"config_delay"
#define KEY_LOG_MESSAGES_ENABLE			"log_messages_enable"
#define KEY_LOG_MESSAGES_INTERVAL		"log_messages_interval"
#define KEY_LOG_MESSAGES_DELAY			"log_messages_delay"
#define KEY_LOG_SCS_REPORT_ALL_ENABLE		"log_scs_report_all_enable"
#define KEY_LOG_SCS_REPORT_ALL_INTERVAL		"log_scs_report_all_interval"
#define KEY_LOG_SCS_REPORT_ALL_DELAY		"log_scs_report_all_delay"
#define KEY_LOG_SCAN_ENABLE			"log_scan_enable"
#define KEY_LOG_SCAN_INTERVAL			"log_scan_interval"
#define KEY_LOG_SCAN_DELAY			"log_scan_delay"
#define KEY_LOG_GATHER_INFO_ENABLE		"log_gather_info_enable"
#define KEY_LOG_GATHER_INFO_INTERVAL		"log_gather_info_interval"
#define KEY_LOG_GATHER_INFO_DELAY		"log_gather_info_delay"
#define KEY_BIDICMD_ENABLE			"bidicmd_enable"
#define KEY_UPGRADE_ENABLE			"upgrade_enable"
#define KEY_UPGRADE_INTERVAL			"upgrade_interval"
#define KEY_UPGRADE_DELAY			"upgrade_delay"
#define KEY_LOG_CAPABILITIES_ENABLE		"log_capabilities_enable"
#define KEY_LOG_CAPABILITIES_INTERVAL		"log_capabilities_interval"
#define KEY_LOG_CAPABILITIES_DELAY		"log_capabilities_delay"
#define KEY_LOG_BUNDLED_STATS_ENABLE		"log_bundled_stats_enable"
#define KEY_LOG_BUNDLED_STATS_INTERVAL		"log_bundled_stats_interval"
#define KEY_LOG_BUNDLED_STATS_DELAY		"log_bundled_stats_delay"
#define KEY_CHECK_HEALTH_ENABLE			"dynamic_polling_enable"
#define KEY_CHECK_HEALTH_INTERVAL		"dynamic_polling_interval"
#define KEY_CHECK_HEALTH_DELAY			"dynamic_polling_delay"

#define KEY_HEALTH_METRICS			"dynamic_polling_metrics"
#define KEY_HEALTH_THRESHOLDS			"dynamic_polling_thresholds"
#define KEY_SMOOTH_WEIGHT			"dynamic_polling_smooth"

/* jsonrpc */
#define KEY_JSONRPC_VERSION	"jsonrpc"
#define KEY_JSONRPC_METHOD	"method"
#define KEY_JSONRPC_PARAMS	"params"
#define KEY_JSONRPC_ID		"id"
#define KEY_JSONRPC_RESULT	"result"
#define KEY_JSONRPC_ERROR	"error"
#define KEY_JSONRPC_CODE	"code"
#define KEY_JSONRPC_MESSAGE	"message"
#define KEY_JSONRPC_DATA	"data"
#define KEY_JSONRPC_TIMEOUT	"timeout" // Non-standard extension

enum {
	JSONRPC_EPARSE = -32700,
	JSONRPC_EREQUEST = -32600,
	JSONRPC_EMETHOD = -32601,
	JSONRPC_EPARAMS = -32602,
	JSONRPC_EINTERNAL = -32603,
	JSONRPC_EMAX = -32000,
};

/* firmware */
#define KEY_AGENT		"agent"
#define KEY_FW			"fw"
#define KEY_PLATFORM		"platform"
#define KEY_QTN_FW		"qtn_fw"
#define KEY_QTN_PLATFORM	"qtn_platform"

/* oauth */
#define KEY_USERNAME		"username"
#define KEY_PASSWORD		"password"
#define KEY_GRANT_TYPE		"grant_type"
#define KEY_SCOPE		"scope"
#define KEY_TOKEN		"access_token"
#define KEY_TOKEN_TYPE		"token_type"
#define KEY_EXPIRE		"expires_in"

#define KEY_VERSION		"version"
#define KEY_MACADDRESS		"mac_addr"
#define KEY_REDIRECT_URL	"poll_url"
#define KEY_BIDICMD_URL		"wss_url"
#define KEY_UPTIME		"uptime"
#define KEY_RUNTIME		"runtime"
#define KEY_REBOOT_CAUSE	"reboot_cause"
#define KEY_CARRIER_ID		"carrier_id"
#define KEY_SSID		"ssid"
#define KEY_BSSID		"bssid"
#define KEY_PROTOCOL		"protocol"
#define KEY_CHANNEL		"channel"
#define KEY_TXPWR		"txpwr"
#define KEY_BW			"bw"
#define KEY_UP			"up"

#define KEY_IFACE		"iface"
#define KEY_NAME		"name"
#define KEY_PHY			"physical"
#define KEY_INTERFACES		"interfaces"
#define KEY_CAPABILITIES	"capabilities"

#define KEY_WIFI_MODE		"wifi_mode"
#define KEY_WIFI_MODE_AP	"ap"
#define KEY_WIFI_MODE_STATION	"sta"
#define KEY_WIFI_MODE_WDS	"wds"
#define KEY_WIFI_MODE_UNKNOWN	"unknown"

#define KEY_REGION		"region"
#define KEY_MD5SUM		"md5sum"
#define KEY_URL			"url"
#define KEY_AP_ISOLATION	"ap_isolation"

/* association table */
#define KEY_ASSOC_TABLE		"assoc_table"

#define KEY_LINK_QUALITY	"link_quality"
#define KEY_RSSI		"rssi"
#define KEY_RSSI_DBM		"rssi_dbm"
#define KEY_SNR			"snr"
#define KEY_ASSOCIATION_TIME    "assoc_time"
#define KEY_MAX_QUEUED		"max_q"

#define KEY_VENDOR		"vendor"
#define KEY_RX_MCS		"rx_mcs"
#define KEY_TX_MCS		"tx_mcs"
#define KEY_RX_STREAMS		"rx_streams"
#define KEY_TX_STREAMS		"tx_streams"
#define KEY_HT_CAPS		"ht"
#define KEY_VHT_CAPS		"vht"


#define KEY_TX_BYTES		"tx_bytes"
#define KEY_TX_PACKETS		"tx_pkts"
#define KEY_TX_DISCARD		"tx_discard"
#define KEY_TX_ERROR		"tx_err"
#define KEY_TX_UNICAST		"tx_unicast"
#define KEY_TX_MULTICAST	"tx_multicast"
#define KEY_TX_BROADCAST	"tx_broadcast"

#define KEY_RX_BYTES		"rx_bytes"
#define KEY_RX_PACKETS		"rx_pkts"
#define KEY_RX_DISCARD		"rx_discard"
#define KEY_RX_ERROR		"rx_err"
#define KEY_RX_UNICAST		"rx_unicast"
#define KEY_RX_MULTICAST	"rx_multicast"
#define KEY_RX_BROADCAST	"rx_broadcast"

#define KEY_NODE_STATS_DIFF	"node_stats_diff"

#define KEY_TX_PHY_RATE		"tx_phy_rate"
#define KEY_TX_PHY_RATE_DIFF	"tx_phy_rate_diff"
#define KEY_TX_ACHIEVABLE_PHY_RATE "ach_tx_phy_rate"

#define KEY_RX_PHY_RATE		"rx_phy_rate"
#define KEY_RX_PHY_RATE_DIFF	"rx_phy_rate_diff"
#define KEY_RX_ACHIEVABLE_PHY_RATE "ach_rx_phy_rate"

/* phy stats */
#define KEY_PHY_STATS		"wireless_stats"

#define KEY_TIMESTAMP		"timestamp"
#define KEY_ASSOC		"assoc"
#define KEY_ATTEN		"atten"

#define KEY_CCA_TOTAL		"cca_total"
#define KEY_CCA_TX		"cca_tx"
#define KEY_CCA_RX		"cca_rx"
#define KEY_CCA_RX_TX		"cca_rx_tx"
#define KEY_CCA_RX_CS		"cca_rx_cs"
#define KEY_CCA_CS		"cca_cs"
#define KEY_CCA_ED		"cca_ed"
#define KEY_CCA_INT		"cca_int"
#define KEY_CCA_IDLE		"cca_idle"

#define KEY_RX_PKTS		"rx_pkts"
#define KEY_RX_GAIN		"rx_gain"
#define KEY_RX_CNT_CRC		"rx_cnt_crc"
#define KEY_RX_NOISE		"rx_noise"

#define KEY_TX_PKTS		"tx_pkts"
#define KEY_TX_DEFERS		"tx_defers"
#define KEY_TX_RETRIES		"tx_retries"

#define KEY_CNT_SP_FAIL		"cnt_sp_fail"
#define KEY_CNT_LP_FAIL		"cnt_lp_fail"
#define KEY_LAST_RX_MCS		"last_rx_mcs"
#define KEY_LAST_TX_MCS		"last_tx_mcs"
#define KEY_LAST_RSSI		"last_rssi"
#define KEY_LAST_RSSI_0		"last_rssi_0"
#define KEY_LAST_RSSI_1		"last_rssi_1"
#define KEY_LAST_RSSI_2		"last_rssi_2"
#define KEY_LAST_RSSI_3		"last_rssi_3"
#define KEY_LAST_RSSI_4		"last_rssi_4"
#define KEY_LAST_RSSI_5		"last_rssi_5"
#define KEY_LAST_RSSI_6		"last_rssi_6"
#define KEY_LAST_RSSI_7		"last_rssi_7"

#define KEY_LAST_RCPI		"last_rcpi"
#define KEY_LAST_EVM		"last_evm"
#define KEY_LAST_EVM_0		"last_evm_0"
#define KEY_LAST_EVM_1		"last_evm_1"
#define KEY_LAST_EVM_2		"last_evm_2"
#define KEY_LAST_EVM_3		"last_evm_3"
#define KEY_LAST_EVM_4		"last_evm_4"
#define KEY_LAST_EVM_5		"last_evm_5"
#define KEY_LAST_EVM_6		"last_evm_6"
#define KEY_LAST_EVM_7		"last_evm_7"

#define KEY_RF_TEMP		"rf_temp"
#define KEY_BB_TEMP		"bb_temp"

/* scs */
#define KEY_SCS_ENABLE		"scs_enable"
#define KEY_CCA_INTF		"cca_intf"

#define KEY_DFS			"dfs"
#define KEY_METRIC		"metric"
#define KEY_PMBL_AP		"pmbl_ap"
#define KEY_PMBL_STA		"pmbl_sta"
#define KEY_CHANNEL_REPORT	"channel_report"

#define KEY_NUM_APS		"num_aps"
#define KEY_AP_SSID		"ap_name_ssid"
#define KEY_AP_BSSID		"ap_mac_addr"
#define KEY_AP_CHANNEL		"ap_channel"
#define KEY_AP_RSSI		"ap_rssi"
#define KEY_AP_ENC_PROTO	"ap_protocol"
#define KEY_AP_ENC_MODES	"ap_encryption_modes"
#define KEY_AP_AUTH_MODE	"ap_authentication_mode"
#define KEY_AP_RATE		"ap_best_data_rate"
#define KEY_AP_WPS		"ap_wps"
#define KEY_AP_PROTO		"ap_80211_proto"
#define KEY_SCAN_RESULTS	"scan_results"

#define KEY_BIDICMD_COMMAND	"command"
#define KEY_BIDICMD_ARGUMENTS	"arguments"
#define KEY_BIDICMD_REQUEST_ID	"request_id"
#define KEY_BIDICMD_STATUS_CODE	"status_code"
#define KEY_BIDICMD_RESPONSE	"response"

#define KEY_TOPOLOGY		"topology"
#define KEY_ROLE		"role"
#define KEY_PEERS		"peers"
#define KEY_GW_MAC		"gw_mac_addr"

#ifdef USE_CJSON
#include <cJSON.h>

#define JSON					cJSON
#define JSON_STRING				cJSON_String
#define JSON_ARRAY				cJSON_Array

#define JSON_ADD_INT_FIELD(p, key, value)	(cJSON_AddNumberToObject((p), (key), (value)))
#define JSON_ADD_DOUBLE_FIELD(p, key, value)	(cJSON_AddNumberToObject((p), (key), (value)))
#define JSON_ADD_STRING_FIELD(p, key, value)	(cJSON_AddStringToObject((p), (key), (value)))
#define JSON_ADD_FIELD(p, key, value)		(cJSON_AddItemToObject((p), (key), (value)))
#define JSON_ADD_ITEM(p, o)			(cJSON_AddItemToArray((p), (o)))
#define JSON_NEW_OBJ()				(json_xnull(cJSON_CreateObject()))
#define JSON_NEW_ARRAY()			(json_xnull(cJSON_CreateArray()))
#define JSON_NEW_INT(value)			(json_xnull(cJSON_CreateNumber((value))))
#define JSON_NEW_STRING(value)			(json_xnull(cJSON_CreateString((value))))
#define JSON_GET_INT(p)				((p)->valueint)
#define JSON_GET_DOUBLE(p)			((p)->valuedouble)
#define JSON_GET_STRING(p)			((p)->valuestring)
#define JSON_GET_TYPE(p)			((p)->type)
#define JSON_GET_REF(p)				(cJSON_Duplicate((p), 1))
#define JSON_PUT_REF(p)				(cJSON_Delete((p)))
#define JSON_GET_OBJ(p, key, o)			(*(o) = cJSON_GetObjectItem((p), (key)))
#define JSON_GET_ITEM(p, idx)			(cJSON_GetArrayItem((p), (idx)))
#define JSON_PARSE(string)			(cJSON_Parse((string)))
#define JSON_TO_STRING(p)			(cJSON_PrintUnformatted((p)))
#define JSON_FREE_STRING(string)		(free(((char*)string)))

#define JSON_FOREACH(p, key, o) \
	char *key;\
	struct cJSON *o; \
	struct cJSON *o ## next = NULL; \
	for (o = p->child; \
	     (o ? (key = o->string, o ## next = o->next, o) : NULL); \
	     o = o ## next)

#else //json_c

#ifdef JSONC_COMPAT
#include <json/json.h>
#else
#include <json-c/json.h>
#endif

#define JSON					json_object
#define JSON_STRING				json_type_string
#define JSON_ARRAY				json_type_array

#define JSON_ADD_INT_FIELD(p, key, value)	(json_object_object_add((p), (key), json_object_new_int64((value))))
#define JSON_ADD_DOUBLE_FIELD(p, key, value)	(json_object_object_add((p), (key), json_object_new_double((value))))
#define JSON_ADD_STRING_FIELD(p, key, value)	(json_object_object_add((p), (key), json_object_new_string((value))))
#define JSON_ADD_FIELD(p, key, value)		(json_object_object_add((p), (key), (value)))
#define JSON_ADD_ITEM(p, o)			(json_object_array_add((p), (o)))
#define JSON_NEW_OBJ()				(json_xnull(json_object_new_object()))
#define JSON_NEW_ARRAY()			(json_xnull(json_object_new_array()))
#define JSON_NEW_INT(value)			(json_xnull(json_object_new_int64((value))))
#define JSON_NEW_STRING(value)			(json_xnull(json_object_new_string((value))))
#define JSON_GET_INT(p)				(json_object_get_int((p)))
#define JSON_GET_DOUBLE(p)			(json_object_get_double((p)))
#define JSON_GET_STRING(p)			(json_object_get_string((p)))
#define JSON_GET_TYPE(p)			(json_object_get_type((p)))
#define JSON_GET_REF(p)				(json_object_get((p)))
#define JSON_PUT_REF(p)				(json_object_put((p)))
#define JSON_GET_OBJ(p, key, o)			(json_object_object_get_ex((p), (key), (o)))
#define JSON_GET_ITEM(p, idx)			(json_object_array_get_idx((p), (idx)))
#define JSON_PARSE(string)			(json_tokener_parse((string)))
#define JSON_TO_STRING(p)			(json_object_to_json_string((p)))
#define JSON_FREE_STRING(string)

#define JSON_FOREACH(p, key, o)			json_object_object_foreach((p), key, (o))

#endif //USE_CJSON

#define JSON_ADD_IF_SET(p, key, type, var, val) \
	({if (var##_set) JSON_ADD_ ## type ## _FIELD(p, key, val);})

#define JSON_ADD_INT_IF_SET(p, key, var) JSON_ADD_IF_SET(p, key, INT, var, var)
#define JSON_ADD_DBL_IF_SET(p, key, var) JSON_ADD_IF_SET(p, key, DOUBLE, var, var)
#define JSON_ADD_STR_IF_SET(p, key, var) JSON_ADD_IF_SET(p, key, STRING, var, var)

#define JSON_ADD_INT_IF_VAL(p, key, var, val) JSON_ADD_IF_SET(p, key, INT, var, val)
#define JSON_ADD_DBL_IF_VAL(p, key, var, val) JSON_ADD_IF_SET(p, key, DOUBLE, var, val)
#define JSON_ADD_STR_IF_VAL(p, key, var, val) JSON_ADD_IF_SET(p, key, STRING, var, val)

static inline JSON* json_xnull(JSON* jobj)
{
	if (jobj == NULL)
		exit(1);
	return jobj;
}

enum {
	FLAG_ROTATION = 1 << 1,
	FLAG_INITIAL_SCAN = 1 << 2,
	FLAG_FORCE_SCAN = 1 << 3,
	FLAG_OAUTH = 1 << 4,
};

struct qh_file_list {
	char *file;
	char *tmp_file;		/* for some special file */
};

struct message_control;
typedef JSON *(*qh_get_json_func)(struct message_control *, int *);
typedef struct qh_file_list *(*qh_get_filelist_func)(void);
typedef int (*qh_action_on_json_func)(struct message_control *, JSON *, JSON *);

struct message_control {
	const char *name;
	const char *base_url;
	char *url;
	int enable;
	int interval;
	int timeout;
	qh_get_json_func get_json;
	qh_get_filelist_func get_filelist;
	qh_action_on_json_func action;
	unsigned int backoff;
	unsigned int flag;
	void *jobj;
};

struct message_control *get_message_control(const char *name);

enum {
	HEALTH_FLAG_CCA_INT = 0,
	HEALTH_FLAG_CCA_IDLE,
	HEALTH_FLAG_CNT_SP_FAIL,
	HEALTH_FLAG_CNT_LP_FAIL,
	HEALTH_FLAG_RSSI,
	HEALTH_FLAG_TX_PHY_RATE,
};
extern int g_health_flags;


struct health_stats {
	uint16_t cca_cs_ed;
	uint16_t cca_idle;
	uint32_t sp_fail;
	uint32_t lp_fail;
	int16_t rssi;
	uint32_t tx_rate;
};
extern struct health_stats g_smoothed_health_stats;

#endif
