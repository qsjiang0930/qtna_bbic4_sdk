/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#define _GNU_SOURCE
#include <arpa/inet.h>
#include <poll.h>
#include <errno.h>
#include <openssl/sha.h>
#if HAVE_ZLIB
#include <zlib.h>
#endif
#include "qh_curl_ws.h"
#include "qh_curl_post.h"
#include "qh_event.h"
#include "qh_json_rpc.h"
#include "qh_pty.h"
#include "qh_utils.h"
#include "qharvestd.h"
#ifdef HAL_QCSAPI
#include "qcsapi/pktlogger.h"
#endif

#define WS_RECONNECT_MIN_INTERVAL 60
#define WS_RECONNECT_MAX_INTERVAL 600
int ws_connect_cb(struct pollfd *pfd, void *arg);
int ws_receive_cb(struct pollfd *pfd, void *arg);

#define RECVBUFSZ 4096
char recvbuf[RECVBUFSZ + 1];
int received = 0;
int processed = 0;
int compression = 0;
CURL *curl = NULL;
struct timespec last_pong = { 0, 0 };

/* Return values of receive-related functions:
 *  0 - need more data;
 * -1 - error;
 * >0 - length of received/parsed message. */

int receive(struct pollfd *pfd, char *buf, int buflen)
{
	CURLcode ret;
	size_t len = 0;

	if (pfd->revents & (POLLERR | POLLHUP | POLLNVAL))
		return -1;
	/* We listen only for POLLIN event, but we need to check
	 * that there is no more data not only in fd, but also in
	 * internal libcurl buffer used for SSL => we need to call
	 * curl_easy_recv even if we have no poll event. It is safe,
	 * as fd under the hood is in non-block mode. */
	ret = curl_easy_recv(curl, buf, buflen, &len);
	if (ret == CURLE_AGAIN)
		return 0;
	if (ret != CURLE_OK) /* Connection closed by peer or error */
		return -1;
	return len;
}

int get_message(struct pollfd *pfd, msg_parser_t parser, void *data)
{
	int msglen;

	if (processed > 0) {
		received -= processed;
		memmove(recvbuf, recvbuf + processed, received);
		processed = 0;
	}

	msglen = parser(recvbuf, received, data);
	if (msglen == 0) {
		int len = receive(pfd, recvbuf + received, RECVBUFSZ - received);
		if (len < 0)
			return -1;
		if (len > 0) {
			received += len;
			msglen = parser(recvbuf, received, data);
		}
	}
	if (msglen > 0) {
		if (msglen > received)
			return -1;
		processed += msglen;
	}
	return msglen;
}

static int parse_http_msg(char *buf, int len, void *data)
{
	int offset = 0;
	struct http_hdr *msg = (struct http_hdr *)data;
	char *end = strnstr(buf, "\r\n\r\n", len);
	if (end == NULL) {
		if (len >= RECVBUFSZ)
			return -EMSGSIZE;
		return 0;
	}
	offset = end - buf + 4;
	if (msg) {
		msg->paylen = offset;
		msg->payload = buf;
	}
	return offset;
}

int parse_ws_msg(char *b, int len, void *data)
{
	int offset = 2;
	int paylen = 0;
	uint8_t *buf = (uint8_t*)b;
	struct ws_msg *msg = (struct ws_msg *)data;

	if (len < 2)
		return 0;
	if ((buf[0] & 0xB0) != 128) /* FIN not set or RSV2,RSV3 != 0 */
		return -EPROTO;
	if (!compression && (buf[0] & 0x40) != 0) /* Unexpected RSV1 */
		return -EPROTO;
	if (buf[1] > 127) /* MASK set */
		return -EPROTO;
	paylen = buf[1];
	if (paylen == 127) /* Not supported */
		return -EMSGSIZE;
	if (paylen == 126) {
		if (len < 4)
			return 0;
		offset += 2;
		paylen = ntohs(*((uint16_t *)(buf + 2)));
	}

	if (offset + paylen > RECVBUFSZ)
		return -EMSGSIZE;
	if (offset + paylen > len)
		return 0;

	if (msg) {
		msg->type = buf[0] & 0x0F;
		msg->deflated = buf[0] & 0x40;
		msg->paylen = paylen;
		msg->payload = b + offset;
	}

	offset += paylen;
	return offset;
}

static int send_msg(int sockfd, char *msg, int len)
{
	struct pollfd _poll;
	_poll.fd = sockfd;
	_poll.events = POLLOUT;
	_poll.revents = 0;
	struct timespec remain = { 10, 0 };

	char *p = msg;
	while (p < msg + len && timespec_cmp(&remain, NULL) > 0) {
		struct timespec start;
		struct timespec end;
		struct timespec diff;
		size_t bytes = 0;

		clock_gettime(CLOCK_MONOTONIC, &start);

		_poll.revents = 0;
		if (ppoll(&_poll, 1, &remain, NULL) > 0) {
			CURLcode ret = curl_easy_send(curl, p, len, &bytes);
			if (ret != CURLE_OK && ret != CURLE_AGAIN)
				return -1;
		}
		p += bytes;

		clock_gettime(CLOCK_MONOTONIC, &end);
		timespec_sub(&diff, &end, &start);
		timespec_sub(&remain, &remain, &diff);
	}
	if (p < msg + len)
		return -1;
	return 0;
}

#if HAVE_ZLIB
static void print_ratio(const char *type, int plain, int comp)
{
	if (!config.ws.verbose)
		return;
	DBG_INFO("%s: plain: %d, compressed: %d, ratio: %.2f",
		type, plain, comp, (double)plain / comp);
}
uint8_t deflate_trail[] = {0x00, 0x00, 0xFF, 0xFF};
#endif

static int deflate_payload(const char *payload, int len, char *out, int *outlen) {
#if HAVE_ZLIB
	z_stream strm = { 0 };
	int ret;

	if (payload == NULL || out == NULL || outlen == NULL)
		return -1;

	strm.zalloc = Z_NULL;
	strm.zfree = Z_NULL;
	strm.opaque = Z_NULL;
	ret = deflateInit2(&strm, Z_DEFAULT_COMPRESSION,
		Z_DEFLATED, -15, 8, Z_DEFAULT_STRATEGY);
	if (ret != Z_OK)
		goto bail;

	strm.avail_in = len;
	strm.next_in = (unsigned char *)payload;
	strm.avail_out = *outlen;
	strm.next_out = (unsigned char *)out;
	ret = deflate(&strm, Z_FINISH);
	if (ret != Z_STREAM_END || strm.avail_out == 0)
		goto bail;

	*outlen -= strm.avail_out;
	(void)deflateEnd(&strm);
	print_ratio("> ws: deflate", len, *outlen);
	return 0;
bail:
	if (strm.avail_out == 0) /* valid case - input is too small or hard to compress */
		ret = Z_BUF_ERROR;
	else
		DBG_INFO("deflate_payload(): [%d]%s: %s", ret, zError(ret), strm.msg);
	(void)deflateEnd(&strm);
	return (ret == Z_BUF_ERROR) ? -EMSGSIZE : -1;
#else
	return -1;
#endif
}

static int inflate_payload(const char *payload, int len, char* out, int *outlen) {
#if HAVE_ZLIB
	z_stream strm = { 0 };
	int ret;

	if (payload == NULL || out == NULL || outlen == NULL)
		return -1;

	strm.zalloc = Z_NULL;
	strm.zfree = Z_NULL;
	strm.opaque = Z_NULL;
	strm.avail_in = 0;
	strm.next_in = Z_NULL;
	ret = inflateInit2(&strm, -15);
	if (ret != Z_OK)
		goto bail;

	strm.avail_in = len;
	strm.next_in = (unsigned char *)payload;
	strm.avail_out = *outlen;
	strm.next_out = (unsigned char *)out;
	ret = inflate(&strm, Z_NO_FLUSH);
	if ((ret != Z_OK && ret != Z_STREAM_END) || strm.avail_out == 0)
		goto bail;

	strm.avail_in = sizeof(deflate_trail);
	strm.next_in = deflate_trail;
	ret = inflate(&strm, Z_SYNC_FLUSH);
	if ((ret != Z_OK && ret != Z_STREAM_END) || strm.avail_out == 0)
		goto bail;

	*outlen -= strm.avail_out;
	(void)inflateEnd(&strm);
	print_ratio("< ws: inflate", *outlen, len);
	return 0;
bail:
	if (strm.avail_out == 0)
		ret = Z_BUF_ERROR;
	DBG_ERROR("inflate_payload(): [%d]%s: %s", ret, zError(ret), strm.msg);
	(void)inflateEnd(&strm);
	return (ret == Z_BUF_ERROR) ? -EMSGSIZE : -1;
#else
	return -1;
#endif
}

static int _send_ws_msg(int sockfd, int type, const char *payload, int len, int deflated)
{
	unsigned char buf[len + 10];
	int offset = 0;
	/* Masking is used by WebSockets protocol just to prevent a caching proxy
	 * from unintentionally treating WebSockets data as a cacheable HTTP request. */
	/* coverity[dont_call] - it is safe to use rand() here */
	uint32_t mask = (uint32_t)rand();
	int i;

	buf[0] = 128 + ((deflated) ? 64 : 0) + type; //FIN + RSV1 + type
	buf[1] = 128; /* Set MASK bit, as per RFC 6455 all outgoing frames MUST be masked. */
	if (len < 126) {
		offset = 2;
		buf[1] += len;
	} else if (len < 65536) {
		uint16_t *sh = (uint16_t *)(buf + 2);
		offset = 4;
		buf[1] += 126;
		*sh = htons(len);
	} else {
		return -1;
	}

	for (i = 0; i < 4; i++) /* Set Masking-key */
		buf[offset++] = (mask >> (i * 8)) & 0xFF;

	if (payload && len) {
		memcpy(buf + offset, payload, len);
		for (i = 0; i < len; i++) /* Mask payload */
			buf[offset + i] ^= (mask >> ((i % 4) * 8)) & 0xFF;
	}
	return send_msg(sockfd, (char*)buf, len + offset);
}

int send_ws_msg(int sockfd, int type, const char *payload, int len) {
	/* Even for /dev/zero minimum compressed length is 5 */
	while (compression && len > 5) {
		char deflated[len];
		int deflen = len;

		if (type != WS_TEXT && type != WS_BINARY)
			break;
		if (deflate_payload(payload, len, deflated, &deflen))
			break;
		return _send_ws_msg(sockfd, type, deflated, deflen, 1);
	}
	return _send_ws_msg(sockfd, type, payload, len, 0);
}

static char *ws_get_key(char *buf, int size)
{
	int i;
	for (i = 0; i < size; i++) {
		/* Sec-Websocket-Key header is intended to prevent a caching proxy
		 * from re-sending a previous WebSocket conversation and
		 * does not provide any authentication, privacy or integrity. */
		/* coverity[dont_call] - it is safe to use rand() here */
		buf[i] = (char)rand();
	}
	return buf;
}

void curl_ws_cleanup(void)
{
	if (curl) {
		curl_easy_cleanup(curl);
		curl = NULL;
	}
	received = 0;
	processed = 0;
	compression = 0;
}

static int send_ws_close(uint16_t code) {
	struct pollfd *pfd = qh_event_get_pollfd(EVENT_WS);
	char payload[2];
	int ret;

	if (pfd->fd < 0)
		return -ENOTCONN;

	payload[0] = code >> 8;
	payload[1] = code & 0xFF;
	ret = send_ws_msg(pfd->fd, WS_CLOSE, payload, 2);
	if (!ret) {
		DBG_NOTICE("> ws: close: %d", (int)code);
	}
	return ret;
}

void qh_disconnect_ws(char *url)
{
	struct message_control *mctl = get_message_control(KEY_MESSAGE_LOG_BIDICMD_REQUEST);
	struct message_control *ping_ws = get_message_control(KEY_MESSAGE_PING_WS);
	struct pollfd *pfd = qh_event_get_pollfd(EVENT_WS);
	JSON *jobj = NULL;

	if (pfd->fd >= 0) {
		if (url) {
			struct timespec t;
			clock_gettime(CLOCK_MONOTONIC, &t);
			DBG_NOTICE("Disconnected from WSS %s at %d.%09ld",
				url, (int)t.tv_sec, t.tv_nsec);
		}
		curl_ws_cleanup();
	}
	ping_ws->enable = 0;
	qh_event_cleanup(EVENT_WS);
	pty_close();

	/* Dequeue and clean up all pending bidirectional commands. */
	while ((jobj = obj_dequeue(&mctl->jobj)))
		JSON_PUT_REF(jobj);

#if HAVE_PKTLOGGER
	if (config.debug_config.pktlogger)
		pktlogger_close();
#endif
}

void qh_disable_ws(void)
{
	struct message_control *mctl =
		get_message_control(KEY_MESSAGE_LOG_BIDICMD_REQUEST);
	(void)send_ws_close(WS_CLOSE_OK);
	qh_disconnect_ws(config.bidicmd_url);
	if (config.bidicmd_url) {
		free(config.bidicmd_url);
		config.bidicmd_url = NULL;
	}
	mctl->enable = 0;
}

int curl_ws_connect(void)
{
	CURLcode res = CURLE_OK;
	long http_code = 0;
	char payload[2048];
	char *p = payload;
	char key[16];
	char key_b64[32];
	char commandsets[128] = { 0 };
	long sockfd = -1;
	int error = 0;
	socklen_t errlen = sizeof(error);
	char *host;
	char *host_tok;
	char *urlpath;
	char *ws_ext = "";
	const int PROTOLEN = 8; /* to skip 'http://' or 'https://' */

	if (!config.bidicmd_url)
		goto bail;

	if (strlen(config.bidicmd_url) < PROTOLEN)
		goto bail;
	urlpath = config.bidicmd_url + PROTOLEN;
	urlpath = strchr(urlpath, '/');
	if (!urlpath)
		urlpath = "/";

	ws_get_key(key, sizeof(key));
	if (encode64(key_b64, sizeof(key_b64), key, sizeof(key)) == NULL)
		goto bail;
	if (!curl)
		curl = curl_easy_init();
	if (!curl)
		goto bail;

	qh_curl_set_connection_options(curl, IS_HTTPS(config.bidicmd_url));

	curl_easy_setopt(curl, CURLOPT_URL, config.bidicmd_url);
	curl_easy_setopt(curl, CURLOPT_CONNECT_ONLY, 1);

	/* Tests in the field show that connection can't get alive if
	 * disconnect period was more than ~90 seconds. Sometimes it is
	 * even smaller. This makes 600 seconds idle time unreasonable,
	 * especially given that WS server periodically sends pings, keeping
	 * the connection active, so keepalive shouldn't be activeted in
	 * a normal circumstances. With new settings on a typical Linux
	 * system qharvestd will treat connection as broken after 3 minutes:
	 * 90 secs of inactivity + 9 unresponded keepalive probes per 10 secs. */
	curl_easy_setopt(curl, CURLOPT_TCP_KEEPALIVE, 1);
	curl_easy_setopt(curl, CURLOPT_TCP_KEEPIDLE, 90);
	curl_easy_setopt(curl, CURLOPT_TCP_KEEPINTVL, 10);

	/* "Easy" interface has to be used here, as "multi" one
	 * doesn't correctly handle CURLOPT_CONNECT_ONLY option and
	 * returns -1 for sockfd. Anyway it is OK to use "easy" variant
	 * here, as it returns as soon as connection is established.
	 * Moreover, we have nothing to listen for or send asyncronously
	 * until WebSockets connection is established. */
	res = qh_curl_easy_perform_ext(curl, &http_code, CURL_FORCE_EASY);
	if (res != CURLE_OK) {
		if (res == CURLE_COULDNT_RESOLVE_HOST)
			qh_res_init();
		goto bail;
	}
	res = curl_easy_getinfo(curl, CURLINFO_LASTSOCKET, &sockfd);
	if (res != CURLE_OK)
		goto bail;
	if (getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &error, &errlen))
		goto bail;
	if (error)
		goto bail;

	if (config.ws.compress)
		ws_ext = WS_DEFLATE "; " WS_SRV_NOCTX "; " WS_CLI_NOCTX;

	p += sprintf(p, "GET %s HTTP/1.1\r\n", urlpath);
	p += sprintf(p, "Connection: Upgrade\r\n");
	p += sprintf(p, "Upgrade: websocket\r\n");
	host = xstrdup(config.bidicmd_url);
	strtok(host, "/");
	host_tok = strtok(NULL, "/");
	p += sprintf(p, "Host: %s\r\n", host_tok);
	free(host);
	p += sprintf(p, "Sec-WebSocket-Version: %d\r\n", WS_VERSION);
	p += sprintf(p, "Sec-WebSocket-Key: %s\r\n", key_b64);
	p += sprintf(p, "Sec-WebSocket-Extensions: %s\r\n", ws_ext);
	p += sprintf(p, "X-MAUI-Version: %s\r\n", __VERSION);
	p += sprintf(p, "X-MAUI-Protocols: bidi, json-rpc");
	if (HAVE_PTY && config.pty)
		p += sprintf(p, ", pty");
	p += sprintf(p, "\r\n");

	if (config.script)
		(void)execl_buf_output(commandsets, sizeof(commandsets), 0,
			config.script, "get", "commandsets");
	p += sprintf(p, "X-MAUI-RPC: %s\r\n", commandsets);

	if (config.oauth.enabled && config.oauth.token)
		p += sprintf(p, "%s%s\r\n", OAUTH_HEADER, config.oauth.token);
	p += sprintf(p, "\r\n");

	if (config.curl_config.verbose)
		fprintf(stderr, "> %s", payload);

	qh_event_set(EVENT_WS, sockfd, POLLIN);
	qh_event_set_cb_ext(EVENT_WS, ws_connect_cb, xstrdup(key_b64), EVENTF_ARG_AUTOFREE);
	if (send_msg(sockfd, payload, p - payload) < 0)
		goto bail;
	return 0;
bail:
	DBG_ERROR("Failed to connect to WSS %s", config.bidicmd_url);
	qh_disconnect_ws(NULL);
	return -1;
}

int ws_connect_cb(struct pollfd *pfd, void *arg)
{
	struct message_control *mctl =
		get_message_control(KEY_MESSAGE_LOG_BIDICMD_REQUEST);
	struct message_control *ping_ws =
		get_message_control(KEY_MESSAGE_PING_WS);
	struct http_hdr headers = { 0, 0 };
	struct timespec t;
	char key_b64[32];
	char sha1[20];
	char buf[sizeof(key_b64) + sizeof(WS_UUID)];
	int ret = get_message(pfd, parse_http_msg, &headers);

	if (ret < 0)
		goto bail;
	if (ret == 0)
		return -ENODATA;
	headers.payload[headers.paylen - 1] = 0; /* replace last '\n' of HTTP message */

	if (config.curl_config.verbose)
		fprintf(stderr, "< %s\n", headers.payload);

	snprintf(buf, sizeof(buf), "%s%s", (char *)arg, WS_UUID);
	SHA1((unsigned char*)buf, strlen(buf), (unsigned char*)sha1);
	if (encode64(key_b64, sizeof(key_b64), sha1, sizeof(sha1)) == NULL)
		goto bail;
	snprintf(buf, sizeof(buf), "Sec-WebSocket-Accept: %s", key_b64);
	if (!strncasestr(headers.payload, "101 Switching Protocols", headers.paylen) ||
	    !strncasestr(headers.payload, "Upgrade: websocket", headers.paylen) ||
	    !strncasestr(headers.payload, buf, headers.paylen))
		goto bail;

	while (config.ws.compress) {
		if (!strncasestr(headers.payload, WS_DEFLATE, headers.paylen)) {
			DBG_NOTICE("Requested compression method is not supported by WSS");
			break;
		}
		if (!strncasestr(headers.payload, WS_SRV_NOCTX, headers.paylen)) {
			DBG_ERROR("Failed to negotiate compression method with WSS");
			goto bail;
		}
		compression = 1;
		break;
	}

	clock_gettime(CLOCK_MONOTONIC, &t);
	DBG_NOTICE("Connected to WSS %s at %d.%09ld, compression: %s", config.bidicmd_url,
		(int)t.tv_sec, t.tv_nsec, compression ? "deflate" : "none");
	qh_event_set_cb(EVENT_WS, ws_receive_cb, NULL);
	mctl->enable = 0;
#if HAVE_PKTLOGGER
	if (config.debug_config.pktlogger)
		pktlogger_init(PKL_SEND_LZMA);
#endif
	if (config.ws.ping) {
		ping_ws->enable = 1;
		ping_ws->timeout = ping_ws->interval = config.ws.ping;
		clock_gettime(CLOCK_MONOTONIC, &last_pong);
		return -EINTR;
	}
	return 0;
bail:
	DBG_ERROR("Failed to connect to WSS %s", config.bidicmd_url);
	qh_disconnect_ws(NULL);
	if (mctl->enable == 0) /* paranoic, shouldn't be true */
		return ws_schedule_reconnect();
	return -ENOTCONN; /* rely on exponential backoff */
}

int ws_schedule_reconnect_timeout(int timeout)
{
	static time_t last = 0;
	struct message_control *mctl =
		get_message_control(KEY_MESSAGE_LOG_BIDICMD_REQUEST);

	/* If BIDICMD is disabled, then we need to reshedule it,
	 * as connection is established in its handler. */
	if (timeout <= 0) {
		struct timespec now = { 0, 0 };
		timeout = 1;

		/* Sometimes server accepts connection, but almost immediately drops it.
		 * It is a server bug, but we do not want to try to connect to the server
		 * every second => use WS_RECONNECT_MIN_INTERVAL. */
		clock_gettime(CLOCK_MONOTONIC, &now);
		if (last && now.tv_sec - last <= 2 * WS_RECONNECT_MIN_INTERVAL + 1) {
			/* coverity[dont_call] - it is safe to use rand() here */
			timeout = WS_RECONNECT_MIN_INTERVAL + rand() % WS_RECONNECT_MIN_INTERVAL;
		}
		last = now.tv_sec;
	}

	mctl->enable = 1;
	mctl->backoff = 0;
	/* NOTE: this timeout will be further decreased by scheduler
	 * if this function is called inside qh_event_listen(). */
	mctl->timeout = timeout;
	mctl->interval = WS_RECONNECT_MAX_INTERVAL;
	return -EINTR;
}

int ws_receive_cb(struct pollfd *pfd, void *arg)
{
	struct ws_msg msg = { 0, 0, 0 };
	uint16_t status = WS_CLOSE_GENERIC;
	int timeout = 0;
	int ret;
	char inflated[RECVBUFSZ];

	if (!config.bidicmd_url) {
		qh_disconnect_ws(NULL);
		return -ENOTCONN;
	}
	if (pfd->fd < 0)
		goto reconnect;

	ret = get_message(pfd, parse_ws_msg, &msg);
	if (ret < 0) {
		if (ret == -EMSGSIZE)
			status = WS_CLOSE_2BIG;
		if (ret == -EPROTO)
			status = WS_CLOSE_PROTO;
		goto reconnect;
	}

	if (msg.deflated) {
		int inflen = sizeof(inflated);
		switch (inflate_payload(msg.payload, msg.paylen, inflated, &inflen)) {
		case 0:
			msg.payload = inflated;
			msg.paylen = inflen;
			break;
		case -EMSGSIZE:
			status = WS_CLOSE_2BIG;
			/* fall through */
		default:
			goto reconnect;
		}
	}

	if (msg.type == WS_TEXT) {
		JSON *json;
		char *jsonstr = xmalloc(msg.paylen + 1);

		memcpy(jsonstr, msg.payload, msg.paylen);
		jsonstr[msg.paylen] = '\0';
		DBG_INFO("< ws: text: %s", jsonstr);
		json = JSON_PARSE(jsonstr);
		free(jsonstr);
		if (json != NULL && do_jsonrpc(json) == -EBADMSG) {
			struct message_control *mctl =
				get_message_control(KEY_MESSAGE_LOG_BIDICMD_REQUEST);
			/* With CURL multi enabled, we can get new bidicmds while the first one
			 * is processed, as we continue to listen for events even when HTTP
			 * request is in progress => let's store these bidicmds in a queue. */
			obj_enqueue(&mctl->jobj, json);
			mctl->enable = 1;
			mctl->timeout = 0;
			return -EINTR;
		}
		JSON_PUT_REF(json);
	} else if (msg.type == WS_PING) {
		DBG_INFO("< ws: ping");
		if (send_ws_msg(pfd->fd, WS_PONG, msg.payload, msg.paylen) == 0) {
			DBG_INFO("> ws: pong");
			clock_gettime(CLOCK_MONOTONIC, &last_pong);
		}
	} else if (msg.type == WS_PONG) {
		DBG_INFO("< ws: pong");
		clock_gettime(CLOCK_MONOTONIC, &last_pong);
	} else if (msg.type == WS_BINARY) {
		if (msg.paylen == 0)
			goto reconnect;
		switch (msg.payload[0]) {
		case WS_BIN_PTY:
			pty_process_ws(msg.payload + 1, msg.paylen - 1);
			break;
		default:
			goto reconnect;
		}
	} else if (msg.type == WS_CLOSE) {
		if (msg.paylen >= 2) {
			int code = (unsigned char)msg.payload[1] |
				(unsigned char)msg.payload[0] << 8;
			char *str = xmalloc(msg.paylen - 1);
			str[msg.paylen - 2] = '\0';
			memcpy(str, msg.payload + 2, msg.paylen - 2);
			DBG_NOTICE("< ws: close: %d %s", code, str);
			if (code == 1013)
				timeout = atoi(str);
			free(str);
		}
		status = WS_CLOSE_OK;
		goto reconnect;
	} else if (msg.type == 0) {
		return -ENODATA;
	} else {
		/* unexpected message type */
		status = WS_CLOSE_TYPE;
		goto reconnect;
	}
	return 0;
reconnect:
	(void)send_ws_close(status);
	qh_disconnect_ws(config.bidicmd_url);
	return ws_schedule_reconnect_timeout(timeout);
}

/* We can't rely solely on TCP keepalive, as it won't work if the agent
 * continues to send data to WSS (like if pktlogger is enabled).
 * The solution is to periodically send pings to WSS, if there were no
 * recent pings from the WSS itself, and wait for pongs. */
int do_ping_ws(struct message_control *mctl, JSON *obj, JSON *robj)
{
	struct pollfd *pfd = qh_event_get_pollfd(EVENT_WS);
	struct timespec now = { 0, 0 };
	struct timespec diff = { 0, 0 };
	clock_gettime(CLOCK_MONOTONIC, &now);
	timespec_sub(&diff, &now, &last_pong);

	if (pfd->fd < 0) {
		mctl->enable = 0;
		return 0;
	}

	if (diff.tv_sec >= 4 * config.ws.ping - 1) {
		DBG_NOTICE("ws: last pong was %ld seconds ago, connection is not alive",
			diff.tv_sec);
		qh_disconnect_ws(config.bidicmd_url);
		ws_schedule_reconnect();
		return 0;
	}

	if (diff.tv_sec >= 2 * config.ws.ping - 1) {
		if (send_ws_msg(pfd->fd, WS_PING, NULL, 0) == 0)
			DBG_INFO("> ws: ping");
	}
	return 0;
}
