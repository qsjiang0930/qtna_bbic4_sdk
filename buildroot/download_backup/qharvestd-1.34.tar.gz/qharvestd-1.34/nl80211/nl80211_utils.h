/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __NL80211_UTILS_H
#define __NL80211_UTILS_H

#include <linux/nl80211.h>

#include <netlink/netlink.h>
#include <netlink/genl/genl.h>
#include <netlink/genl/family.h>
#include <netlink/genl/ctrl.h>

/* libnl1 compatibility code */
#if !defined(CONFIG_LIBNL2) && !defined(CONFIG_LIBNL3)
#define nl_sock nl_handle
#endif

struct nl80211_state {
	struct nl_sock *nl_sock;
	int nl80211_id;
	int nlctrl_id;
};

struct nl80211_msg_conveyor {
	struct nl_msg *msg;
	struct nl_cb *cb;
};

void nl80211_close(void);
int nl80211_init(void);
void nl80211_free(struct nl80211_msg_conveyor *cv);
struct nl80211_msg_conveyor *nl80211_new(int family_id, int cmd, int flags);
struct nl80211_msg_conveyor *nl80211_ctl(int cmd, int flags);
struct nl80211_msg_conveyor *nl80211_msg(const char *ifname, int cmd, int flags);
struct nl80211_msg_conveyor *nl80211_send(struct nl80211_msg_conveyor *cv,
	int (*cb_func)(struct nl_msg *, void *), void *cb_arg);
struct nlattr **nl80211_parse(struct nl_msg *msg);

#endif
