/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <linux/nl80211.h>
#include <net/if.h>
#include "nl80211_utils.h"

/* Note: this code is based on iwinfo OpenWRT utility,
 * but also has some ideas borrowed from iw utility. */

/* libnl1 compatibility code */
#if !defined(CONFIG_LIBNL2) && !defined(CONFIG_LIBNL3)
static inline struct nl_sock *nl_socket_alloc(void)
{
	return nl_handle_alloc();
}

static inline void nl_socket_free(struct nl_sock *h)
{
	nl_handle_destroy(h);
}

static inline int nl_socket_set_buffer_size(struct nl_sock *sk,
					    int rxbuf, int txbuf)
{
	return nl_set_buffer_size(sk, rxbuf, txbuf);
}
#endif /* CONFIG_LIBNL20 && CONFIG_LIBNL30 */


static struct nl80211_state *nls = NULL;

void nl80211_close(void)
{
	if (nls)
	{
		if (nls->nl_sock)
			nl_socket_free(nls->nl_sock);

		free(nls);
		nls = NULL;
	}
}

int nl80211_init(void)
{
	int err, fd;

	if (nls)
		return 0;

	nls = malloc(sizeof(struct nl80211_state));
	if (!nls) {
		err = -ENOMEM;
		goto err;
	}
	memset(nls, 0, sizeof(*nls));

	nls->nl_sock = nl_socket_alloc();
	if (!nls->nl_sock) {
		err = -ENOMEM;
		goto err;
	}

	if (genl_connect(nls->nl_sock)) {
		err = -ENOLINK;
		goto err;
	}

	fd = nl_socket_get_fd(nls->nl_sock);
	if (fcntl(fd, F_SETFD, fcntl(fd, F_GETFD) | FD_CLOEXEC) < 0) {
		err = -EINVAL;
		goto err;
	}

	nls->nl80211_id = genl_ctrl_resolve(nls->nl_sock, "nl80211");
	if (nls->nl80211_id < 0) {
		err = -ENOENT;
		goto err;
	}

	nls->nlctrl_id = genl_ctrl_resolve(nls->nl_sock, "nlctrl");
	if (nls->nlctrl_id < 0) {
		err = -ENOENT;
		goto err;
	}

	return 0;
err:
	nl80211_close();
	return err;
}

static int nl80211_msg_error(struct sockaddr_nl *nla,
	struct nlmsgerr *err, void *arg)
{
	int *ret = arg;
	*ret = err->error;
	return NL_STOP;
}

static int nl80211_msg_finish(struct nl_msg *msg, void *arg)
{
	int *ret = arg;
	*ret = 0;
	return NL_SKIP;
}

static int nl80211_msg_ack(struct nl_msg *msg, void *arg)
{
	int *ret = arg;
	*ret = 0;
	return NL_STOP;
}

static int nl80211_msg_response(struct nl_msg *msg, void *arg)
{
	return NL_SKIP;
}

void nl80211_free(struct nl80211_msg_conveyor *cv)
{
	if (cv)
	{
		if (cv->cb)
			nl_cb_put(cv->cb);

		if (cv->msg)
			nlmsg_free(cv->msg);

		cv->cb  = NULL;
		cv->msg = NULL;
	}
}

struct nl80211_msg_conveyor *nl80211_new(int family_id, int cmd, int flags)
{
	static struct nl80211_msg_conveyor cv;
	struct nl_msg *req = NULL;
	struct nl_cb *cb = NULL;

	req = nlmsg_alloc();
	if (!req)
		goto err;

	cb = nl_cb_alloc(NL_CB_DEFAULT);
	if (!cb)
		goto err;

	genlmsg_put(req, 0, 0, family_id, 0, flags, cmd, 0);

	cv.msg = req;
	cv.cb  = cb;

	return &cv;

err:
	if (req)
		nlmsg_free(req);

	return NULL;
}

struct nl80211_msg_conveyor * nl80211_ctl(int cmd, int flags)
{
	if (nl80211_init() < 0)
		return NULL;

	return nl80211_new(nls->nlctrl_id, cmd, flags);
}

struct nl80211_msg_conveyor *nl80211_msg(const char *ifname, int cmd, int flags)
{
	int ifidx = -1;
	struct nl80211_msg_conveyor *cv;

	if (ifname == NULL)
		return NULL;

	if (nl80211_init() < 0)
		return NULL;

	ifidx = if_nametoindex(ifname);
	if (ifidx <= 0) /* Valid ifidx must be greater than 0 */
		return NULL;

	cv = nl80211_new(nls->nl80211_id, cmd, flags);
	if (!cv)
		return NULL;

	if (ifidx > -1)
		NLA_PUT_U32(cv->msg, NL80211_ATTR_IFINDEX, ifidx);

	return cv;

nla_put_failure:
	nl80211_free(cv);
	return NULL;
}

struct nl80211_msg_conveyor *nl80211_send(struct nl80211_msg_conveyor *cv,
	int (*cb_func)(struct nl_msg *, void *), void *cb_arg)
{
	static struct nl80211_msg_conveyor rcv;
	int err = 1;

	if (cb_func)
		nl_cb_set(cv->cb, NL_CB_VALID, NL_CB_CUSTOM, cb_func, cb_arg);
	else
		nl_cb_set(cv->cb, NL_CB_VALID, NL_CB_CUSTOM, nl80211_msg_response, &rcv);

	if (nl_send_auto_complete(nls->nl_sock, cv->msg) < 0)
		goto err;

	nl_cb_err(cv->cb,               NL_CB_CUSTOM, nl80211_msg_error,  &err);
	nl_cb_set(cv->cb, NL_CB_FINISH, NL_CB_CUSTOM, nl80211_msg_finish, &err);
	nl_cb_set(cv->cb, NL_CB_ACK,    NL_CB_CUSTOM, nl80211_msg_ack,    &err);

	/* coverity[loop_condition] - no infinite loop here, as 'err' is modified by callbacks */
	while (err > 0)
		nl_recvmsgs(nls->nl_sock, cv->cb);

	return &rcv;

err:
	nl_cb_put(cv->cb);
	nlmsg_free(cv->msg);

	return NULL;
}

struct nlattr **nl80211_parse(struct nl_msg *msg)
{
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	static struct nlattr *attr[NL80211_ATTR_MAX + 1];

	nla_parse(attr, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0),
		genlmsg_attrlen(gnlh, 0), NULL);

	return attr;
}
