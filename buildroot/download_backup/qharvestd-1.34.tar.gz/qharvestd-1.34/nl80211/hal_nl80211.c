/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#define _GNU_SOURCE
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include "qharvestd.h"
#include "qh_hal.h"
#include "qh_utils.h"
#include "nl80211_utils.h"

static int nl80211_get_sta_ssid_cb(struct nl_msg *msg, void *arg)
{
	int ielen;
	unsigned char *ie;
	char *ssid = arg;
	struct nlattr **tb = nl80211_parse(msg);
	struct nlattr *bss[NL80211_BSS_MAX + 1];

	static struct nla_policy bss_policy[NL80211_BSS_MAX + 1] = {
		[NL80211_BSS_INFORMATION_ELEMENTS] = { 0 },
		[NL80211_BSS_STATUS]               = { .type = NLA_U32 },
	};

	if (!tb[NL80211_ATTR_BSS] ||
	    nla_parse_nested(bss, NL80211_BSS_MAX, tb[NL80211_ATTR_BSS], bss_policy) ||
	    !bss[NL80211_BSS_BSSID] || !bss[NL80211_BSS_STATUS] ||
	    !bss[NL80211_BSS_INFORMATION_ELEMENTS]) {
		return NL_SKIP;
	}

	switch (nla_get_u32(bss[NL80211_BSS_STATUS]))
	{
	case NL80211_BSS_STATUS_ASSOCIATED:
	case NL80211_BSS_STATUS_AUTHENTICATED:
	case NL80211_BSS_STATUS_IBSS_JOINED:

		ie = nla_data(bss[NL80211_BSS_INFORMATION_ELEMENTS]);
		ielen = nla_len(bss[NL80211_BSS_INFORMATION_ELEMENTS]);

		while (ielen >= 2 && ielen >= ie[1]) {
			if (ie[0] == 0) {
				memcpy(ssid, ie + 2, (ie[1] < 32) ? ie[1] : 32);
				return NL_SKIP;
			}
			ielen -= ie[1] + 2;
			ie += ie[1] + 2;
		}

	default:
		return NL_SKIP;
	}
}

static int nl80211_get_sta_ssid(const char *ifname, string32 ssid)
{
	struct nl80211_msg_conveyor *req;

	ssid[0] = 0;

	/* try to find ssid from scan dump results */
	if (req = nl80211_msg(ifname, NL80211_CMD_GET_SCAN, NLM_F_DUMP))
	{
		nl80211_send(req, nl80211_get_sta_ssid_cb, ssid);
		nl80211_free(req);
	}
	return (ssid[0] == 0) ? -1 : 0;
}

static int nl80211_get_wifi_mode(int nl_mode)
{
	switch (nl_mode) {
		case 2:
			return WIFI_MODE_STA;
		case 3:
			return WIFI_MODE_AP;
		case 5:
			return WIFI_MODE_WDS;
		default:
			return WIFI_MODE_UNKNOWN;
	}
}

static int nl80211_parse_attr_bw(struct nlattr **tb)
{
	if (tb[NL80211_ATTR_CHANNEL_WIDTH]) {
		switch (nla_get_u32(tb[NL80211_ATTR_CHANNEL_WIDTH])) {
		case NL80211_CHAN_WIDTH_40:
			return 40;
		case NL80211_CHAN_WIDTH_80:
			return 80;
		case NL80211_CHAN_WIDTH_160:
		case NL80211_CHAN_WIDTH_80P80:
			return 160;
		default:
			return 20;
		}
	} else if (tb[NL80211_ATTR_WIPHY_CHANNEL_TYPE]) {
		switch (nla_get_u32(tb[NL80211_ATTR_WIPHY_CHANNEL_TYPE])) {
		case NL80211_CHAN_HT40MINUS:
		case NL80211_CHAN_HT40PLUS:
			return 40;
		default:
			return 20;
		}
	}
	return 0;
}

struct nl80211_iface_info {
	uint32_t ifidx;
	uint32_t phyidx;
	uint32_t mode;
	string32 ssid;
	macaddr_t macaddr;
	uint32_t channel;
	uint32_t freq;
	uint32_t bw;
	int32_t txpower; /* On most recent kernels only. Alternative: WEXT. */
};

static int nl80211_get_iface_info_cb(struct nl_msg *msg, void *arg)
{
	struct nl80211_iface_info *info = arg;
	struct nlattr **tb = nl80211_parse(msg);

	if (tb[NL80211_ATTR_IFINDEX])
		info->ifidx = nla_get_u32(tb[NL80211_ATTR_IFINDEX]);
	if (tb[NL80211_ATTR_WIPHY])
		info->phyidx = nla_get_u32(tb[NL80211_ATTR_WIPHY]);
	if (tb[NL80211_ATTR_IFTYPE])
		info->mode = nl80211_get_wifi_mode(nla_get_u32(tb[NL80211_ATTR_IFTYPE]));
	if (tb[NL80211_ATTR_WIPHY_TX_POWER_LEVEL])
		info->txpower = nla_get_u32(tb[NL80211_ATTR_WIPHY_TX_POWER_LEVEL]) / 100;
	if (tb[NL80211_ATTR_WIPHY_FREQ]) {
		info->freq = nla_get_u32(tb[NL80211_ATTR_WIPHY_FREQ]);
		info->channel = freq2chan(info->freq);
	}
	if (tb[NL80211_ATTR_MAC]) {
		uint8_t *mac = nla_data(tb[NL80211_ATTR_MAC]);
		if (mac)
			memcpy(info->macaddr, mac, sizeof(info->macaddr));
	}
	if (tb[NL80211_ATTR_SSID]) {
		char *ssid = nla_data(tb[NL80211_ATTR_SSID]);
		int ssid_len = nla_len(tb[NL80211_ATTR_SSID]);
		if (ssid)
			memcpy(info->ssid, ssid, ssid_len);
	}
	info->bw = nl80211_parse_attr_bw(tb);
	return NL_SKIP;
}

static int nl80211_get_iface_info(const char *ifname, struct nl80211_iface_info *info) {
	struct nl80211_msg_conveyor *req;

	memset(info, 0, sizeof(*info));
	info->phyidx = -1;

	if (req = nl80211_msg(ifname, NL80211_CMD_GET_INTERFACE, 0)) {
		nl80211_send(req, nl80211_get_iface_info_cb, info);
		nl80211_free(req);
	}
	/* SSID is available only for AP, for STA we need a workaround.
	 * Non-nl80211 alternative is to get SSID using WEXT (STA-only) */
	if (info->ssid[0] == 0)
		nl80211_get_sta_ssid(ifname, info->ssid);

	return (info->ifidx > 0) ? 0 : -1;
}

struct nl80211_buf_cnt {
	char *buf;
	int cnt;
};

static int nl80211_parse_ri_rate(struct nlattr **ri)
{
	uint32_t rate = 0;

	if (ri[NL80211_RATE_INFO_BITRATE32])
		rate = nla_get_u32(ri[NL80211_RATE_INFO_BITRATE32]);
	else if (ri[NL80211_RATE_INFO_BITRATE])
		rate = nla_get_u16(ri[NL80211_RATE_INFO_BITRATE]);
	return rate / 10 * 1024;
}

static int nl80211_parse_ri_mcs(struct nlattr **ri)
{
	if (ri[NL80211_RATE_INFO_VHT_MCS])
		return nla_get_u8(ri[NL80211_RATE_INFO_VHT_MCS]);
	else if (ri[NL80211_RATE_INFO_MCS])
		return nla_get_u8(ri[NL80211_RATE_INFO_MCS]);
	return -1;
}

static int nl80211_parse_ri_nss(struct nlattr **ri)
{
	if (ri[NL80211_RATE_INFO_VHT_NSS])
		return nla_get_u8(ri[NL80211_RATE_INFO_VHT_NSS]);
	return 0;
}

static int nl80211_parse_ri_bw(struct nlattr **ri)
{
	if (ri[NL80211_RATE_INFO_80P80_MHZ_WIDTH] || ri[NL80211_RATE_INFO_160_MHZ_WIDTH])
		return 160;
	else if (ri[NL80211_RATE_INFO_80_MHZ_WIDTH])
		return 80;
	else if (ri[NL80211_RATE_INFO_40_MHZ_WIDTH])
		return 40;
	return 20;
}

static int nl80211_get_assoclist_cb(struct nl_msg *msg, void *arg)
{
	struct nl80211_buf_cnt *bc = arg;
	struct assoc_stats *as = ((struct assoc_stats *)bc->buf) + bc->cnt;
	struct nlattr **attr = nl80211_parse(msg);
	struct nlattr *sinfo[NL80211_STA_INFO_MAX + 1];
	struct nlattr *rinfo[NL80211_RATE_INFO_MAX + 1];

	static struct nla_policy stats_policy[NL80211_STA_INFO_MAX + 1] = {
		[NL80211_STA_INFO_RX_BITRATE]    = { .type = NLA_NESTED },
		[NL80211_STA_INFO_TX_BITRATE]    = { .type = NLA_NESTED },
		[NL80211_STA_INFO_SIGNAL]        = { .type = NLA_U8     },
	};

	static struct nla_policy rate_policy[NL80211_RATE_INFO_MAX + 1] = {
		[NL80211_RATE_INFO_BITRATE]      = { .type = NLA_U16    },
		[NL80211_RATE_INFO_BITRATE32]    = { .type = NLA_U32    },
		[NL80211_RATE_INFO_MCS]          = { .type = NLA_U8     },
		[NL80211_RATE_INFO_VHT_MCS]      = { .type = NLA_U8     },
		[NL80211_RATE_INFO_VHT_NSS]      = { .type = NLA_U8     },
		[NL80211_RATE_INFO_40_MHZ_WIDTH] = { .type = NLA_FLAG   },
		[NL80211_RATE_INFO_80_MHZ_WIDTH] = { .type = NLA_FLAG   },
		[NL80211_RATE_INFO_SHORT_GI]     = { .type = NLA_FLAG   },
	};

	if (!attr[NL80211_ATTR_MAC])
		return NL_SKIP;

	if (bc->buf == NULL) {
		bc->cnt += 1;
		return NL_SKIP;
	}

	if (hal_buf_check_clear(bc->buf, bc->cnt, sizeof(*as)))
		return -1;

	memcpy(as->macaddr, nla_data(attr[NL80211_ATTR_MAC]), 6);
	as->macaddr_set = 1;
	bc->cnt += 1;

	if (attr[NL80211_ATTR_STA_INFO] &&
		!nla_parse_nested(sinfo, NL80211_STA_INFO_MAX,
			attr[NL80211_ATTR_STA_INFO], stats_policy))
	{
		if (sinfo[NL80211_STA_INFO_SIGNAL])
			FLDSET(as->rssi, (int8_t)nla_get_u8(sinfo[NL80211_STA_INFO_SIGNAL]));
		if (sinfo[NL80211_STA_INFO_TX_BITRATE] &&
			!nla_parse_nested(rinfo, NL80211_RATE_INFO_MAX,
				sinfo[NL80211_STA_INFO_TX_BITRATE], rate_policy))
		{
			uint32_t rate = nl80211_parse_ri_rate(rinfo);
			int mcs = nl80211_parse_ri_mcs(rinfo);
			int nss = nl80211_parse_ri_nss(rinfo);

			if (rate)
				FLDSET(as->tx_rate, rate);
			if (mcs >= 0)
				FLDSET(as->tx_mcs, mcs);
			if (nss)
				FLDSET(as->tx_streams, nss);
			FLDSET(as->bandwidth, nl80211_parse_ri_bw(rinfo));
		}
		if (sinfo[NL80211_STA_INFO_RX_BITRATE] &&
			!nla_parse_nested(rinfo, NL80211_RATE_INFO_MAX,
				sinfo[NL80211_STA_INFO_RX_BITRATE], rate_policy))
		{
			uint32_t rate = nl80211_parse_ri_rate(rinfo);
			int mcs = nl80211_parse_ri_mcs(rinfo);
			int nss = nl80211_parse_ri_nss(rinfo);

			if (rate)
				FLDSET(as->rx_rate, rate);
			if (mcs >= 0)
				FLDSET(as->rx_mcs, mcs);
			if (nss)
				FLDSET(as->rx_streams, nss);
			/* Note: in original qharvestd-openwrt we got bw from rx rate,
			 * so let's keep doing it and overwrite bw here if available. */
			FLDSET(as->bandwidth, nl80211_parse_ri_bw(rinfo));
		}
	}
	return NL_SKIP;
}

static int nl80211_get_trafficlist_cb(struct nl_msg *msg, void *arg)
{
	struct nl80211_buf_cnt *bc = arg;
	struct traffic_stats *ts = ((struct traffic_stats *)bc->buf) + bc->cnt;
	struct nlattr **attr = nl80211_parse(msg);
	struct nlattr *sinfo[NL80211_STA_INFO_MAX + 1];

	static struct nla_policy stats_policy[NL80211_STA_INFO_MAX + 1] = {
		[NL80211_STA_INFO_RX_PACKETS]    = { .type = NLA_U32    },
		[NL80211_STA_INFO_TX_PACKETS]    = { .type = NLA_U32    },
		[NL80211_STA_INFO_RX_BYTES]      = { .type = NLA_U32    },
		[NL80211_STA_INFO_TX_BYTES]      = { .type = NLA_U32    },
		[NL80211_STA_INFO_TX_RETRIES]    = { .type = NLA_U32    },
		[NL80211_STA_INFO_TX_FAILED]     = { .type = NLA_U32    },
	};

	if (!attr[NL80211_ATTR_MAC])
		return NL_SKIP;

	if (bc->buf == NULL) {
		bc->cnt += 1;
		return NL_SKIP;
	}

	if (hal_buf_check_clear(bc->buf, bc->cnt, sizeof(*ts)))
		return -1;

	memcpy(ts->macaddr, nla_data(attr[NL80211_ATTR_MAC]), 6);
	ts->macaddr_set = 1;
	bc->cnt += 1;

	if (attr[NL80211_ATTR_STA_INFO] &&
		!nla_parse_nested(sinfo, NL80211_STA_INFO_MAX,
			attr[NL80211_ATTR_STA_INFO], stats_policy))
	{
		if (sinfo[NL80211_STA_INFO_RX_BYTES])
			FLDSET(ts->rx_bytes, nla_get_u32(sinfo[NL80211_STA_INFO_RX_BYTES]));
		if (sinfo[NL80211_STA_INFO_TX_BYTES])
			FLDSET(ts->tx_bytes, nla_get_u32(sinfo[NL80211_STA_INFO_TX_BYTES]));
		if (sinfo[NL80211_STA_INFO_RX_PACKETS])
			FLDSET(ts->rx_packets, nla_get_u32(sinfo[NL80211_STA_INFO_RX_PACKETS]));
		if (sinfo[NL80211_STA_INFO_TX_PACKETS])
			FLDSET(ts->tx_packets, nla_get_u32(sinfo[NL80211_STA_INFO_TX_PACKETS]));
		if (sinfo[NL80211_STA_INFO_TX_RETRIES])
			FLDSET(ts->tx_retries, nla_get_u32(sinfo[NL80211_STA_INFO_TX_RETRIES]));
		if (sinfo[NL80211_STA_INFO_TX_FAILED])
			FLDSET(ts->tx_error,  nla_get_u32(sinfo[NL80211_STA_INFO_TX_FAILED]));
	}
	return NL_SKIP;
}

static int nl80211_get_assoc(const char *ifname, char *buf, int *len,
	int (*handler)(struct nl_msg *msg, void *arg))
{
	struct nl80211_msg_conveyor *req;
	struct nl80211_buf_cnt bc = { .buf = buf, .cnt = 0 };

	if (req = nl80211_msg(ifname, NL80211_CMD_GET_STATION, NLM_F_DUMP)) {
		nl80211_send(req, handler, &bc);
		nl80211_free(req);
		*len = bc.cnt;
		return 0;
	}
	return -1;
}

int iw_get_noise(const char *ifname, int32_t *noise)
{
	char buf[256];
	char *tok;
	FILE *p;
	int32_t n = 0;

	p = execl_popen(0, PATH_IW, "dev", ifname, "survey", "dump");
	if (!p)
		return -1;

	while (fgets(buf, 256, p)) {
		if (tok = strstr(buf, "[in use]"))
			break;
	}
	while (fgets(buf, 256, p)) {
		if (tok = gettok(buf, "noise:", 1, SPACE)) {
			n = atoi(tok);
			break;
		}
	}
	execl_pclose(p);

	if (n == 0)
		return -1;
	*noise = n;
	return 0;
}

int iw_get_proto_bw_supp(const struct iface *iface, uint32_t *protomask, uint32_t *bandwidth)
{
	char buf[256];
	FILE *p;
	char *tok;
	uint32_t bw = 20;
	uint32_t proto = 0;
	struct nl80211_iface_info info;

	if (nl80211_get_iface_info(iface->name, &info))
		return -1;

	p = execl_popen(0, PATH_IW, "phy", str16("phy%d", info.phyidx), "info");
	if (!p)
		return -1;
	while (fgets(buf, 256, p)) {
		if (tok = strstr(buf, "HT20/HT40")) {
			bw = 40;
		} else if (tok = strstr(buf, "* 2412 MHz [1]")) {
			proto |= PROTO_11B | PROTO_11G;
		} else if (tok = strstr(buf, "* 5180 MHz [36]")) {
			proto |= PROTO_11A;
		} else if (tok = strstr(buf, "Capabilities: ")) {
			proto |= PROTO_11N;
		} else if (tok = strstr(buf, "VHT Capabilities ")) {
			proto |= PROTO_11AC;
			bw = 80;
		}
	}
	execl_pclose(p);

	if (protomask)
		*protomask = proto;
	if (bandwidth)
		*bandwidth = bw;
	return 0;
}

int hal_nl80211_mode(const struct iface *iface, uint32_t *mode)
{
	struct nl80211_iface_info info;
	if (nl80211_get_iface_info(iface->name, &info))
		return -1;
	*mode = info.mode;
	return 0;
}

int hal_nl80211_probe(const char *ifname, int *phyidx)
{
	struct nl80211_iface_info info;
	struct stat st;

	if (stat(str64("/sys/class/net/%s/wireless", ifname), &st))
		return -1;
	if (nl80211_get_iface_info(ifname, &info))
		return -1;
	if (phyidx)
		*phyidx = info.phyidx;
	return 0;
}

int hal_nl80211_channel(const struct iface *iface, uint32_t *channel)
{
	struct nl80211_iface_info info;
	if (nl80211_get_iface_info(iface->name, &info))
		return -1;
	*channel = info.channel;
	return 0;
}

int hal_nl80211_txpower(const struct iface *iface, int32_t *txpower)
{
	struct nl80211_iface_info info;
	if (nl80211_get_iface_info(iface->name, &info))
		return -1;
	if (info.txpower == 0)
		return -ENOTSUP;
	*txpower = info.txpower;
	return 0;
}

int hal_nl80211_region(const struct iface *iface, string2 region)
{
	char buf[256];
	FILE *p;
	char *tok;

	p = execl_popen(0, PATH_IW, "reg", "get");
	if (!p)
		return -1;
	while (fgets(buf, 256, p) != NULL) {
		if (tok = gettok(buf, "country ", 1, SPACE":")) {
			if (validate_region(tok)) {
				pclose(p);
				return -1;
			}
			snprintf(region, sizeof(string2), "%s", tok);
			break;
		}
	}
	execl_pclose(p);
	return 0;
}

int hal_nl80211_bandwidth(const struct iface *iface, uint32_t *bandwidth)
{
	struct nl80211_iface_info info;
	if (nl80211_get_iface_info(iface->name, &info) || info.bw == 0)
		return -1;
	*bandwidth = info.bw;
	return 0;
}

int hal_nl80211_bandwidth_supp(const struct iface *iface, uint32_t *bandwidth)
{
	return iw_get_proto_bw_supp(iface, NULL, bandwidth);
}

int hal_nl80211_protocol(const struct iface *iface, uint32_t *protocol)
{
	return -ENOTSUP;
}

int hal_nl80211_protocol_supp(const struct iface *iface, uint32_t *protocol)
{
	return iw_get_proto_bw_supp(iface, protocol, NULL);
}

int hal_nl80211_ssid(const struct iface *iface, string32 ssid)
{
	struct nl80211_iface_info info;
	if (nl80211_get_iface_info(iface->name, &info))
		return -1;
	strncpy(ssid, info.ssid, sizeof(string32));
	return 0;
}

int hal_nl80211_bssid(const struct iface *iface, macaddr_t bssid)
{
	struct nl80211_iface_info info;
	if (nl80211_get_iface_info(iface->name, &info))
		return -1;
	memcpy(bssid, info.macaddr, sizeof(macaddr_t));
	return 0;
}

int hal_nl80211_assoc_list(const struct iface *iface, char *halbuf, int *len)
{
	int len1 = 0;

	if (nl80211_get_assoc(iface->name, halbuf, &len1, nl80211_get_assoclist_cb))
		return -1;

	if (halbuf) {
		struct assoc_stats *as;
		int32_t noise;
		int i;

		if (!iw_get_noise(iface->name, &noise)) {
			for (as = (struct assoc_stats *)halbuf, i = 0; i < len1; as++, i++) {
				if (as->rssi_set)
					FLDSET(as->snr, as->rssi - noise);
			}
		}
	}

	*len = len1;
	return 0;
}

int hal_nl80211_phy_stats(const struct iface *iface, struct phy_stats *halps)
{
	struct nl80211_iface_info info;
	int32_t noise;
	int len;

	if (nl80211_get_iface_info(iface->name, &info))
		return -1;
	if (!iw_get_noise(iface->name, &noise))
		FLDSET(halps->rx_noise, noise);
	FLDSET(halps->channel, info.channel);

	if (hal_nl80211_assoc_list(iface, NULL, &len))
		return -1;
	FLDSET(halps->assoc, len);

	return 0;
}

int hal_nl80211_cca_stats(const struct iface *iface, struct cca_stats *cca)
{
	char buf[256];
	char *tok;
	FILE *p;
	int64_t active = 0;
	int64_t busy = 0;
	int64_t rx = 0;
	int64_t tx = 0;
	int64_t intf = 0;

	p = execl_popen(0, PATH_IW, "dev", iface->name, "survey", "dump");
	if (!p)
		return -1;

	while (fgets(buf, 256, p)) {
		if (tok = strstr(buf, "[in use]"))
			break;
	}
	while (fgets(buf, 256, p)) {
		if (tok = gettok(buf, "active time:", 2, SPACE)) {
			active = atoi(tok);
		} else if (tok = gettok(buf, "busy time:", 2, SPACE)) {
			busy = atoi(tok);
		} else if (tok = gettok(buf, "receive time:", 2, SPACE)) {
			rx = atoi(tok);
		} else if (tok = gettok(buf, "transmit time:", 2, SPACE)) {
			tx = atoi(tok);
		} else if (tok = strstr(buf, "frequency:")) {
			break;
		}
	}
	execl_pclose(p);

	intf = busy - rx - tx;
	if (intf < 0)
		intf = 0;

	FLDSET(cca->total, active);
	FLDSET(cca->idle, active - busy);
	FLDSET(cca->ed, intf);
	FLDSET(cca->rx_cs, rx);
	FLDSET(cca->tx, tx);
	cca->cumulative = 1;

	return 0;
}

int hal_nl80211_channel_list(const struct iface *iface, char *halbuf, int *len)
{
	struct channel_desc *chd = (struct channel_desc *)halbuf;
	int phyidx;
	char buf[256];
	char *tok;
	FILE *p;

	if (hal_nl80211_probe(iface->name, &phyidx))
		return -1;

	p = execl_popen(0, PATH_IW, "phy", str16("phy%d", phyidx), "info");
	if (!p)
		return -1;

	*len = 0;
	while (fgets(buf, 256, p)) {
		if (tok = gettok(buf, "MHz [", 1, SPACE"[]")) {
			int channel;
			int txpower;

			channel = atoi(tok);
			tok = strtok(NULL, SPACE"[]().");
			txpower = atoi(tok);
			if (txpower == 0) /* NaN */
				continue;

			if (hal_buf_check_clear(halbuf, *len, sizeof(*chd)))
				break;

			FLDSET(chd->channel, channel);
			FLDSET(chd->txpower, txpower);
			chd++;
			(*len)++;
		}
	}
	execl_pclose(p);
	return 0;
}

int hal_nl80211_traffic_list(const struct iface *iface, char *halbuf, int *len)
{
	int len1 = 0;

	if (nl80211_get_assoc(iface->name, halbuf, &len1, nl80211_get_trafficlist_cb))
		return -1;

	*len = len1;
	return 0;
}

#define SCAN_DURATION 10
int hal_nl80211_scan_start(const struct iface *iface, const int force)
{
	/* ap-force flag is supported since iw-3.10 => since 2013 */
	if (execl_run(0, PATH_IW, "dev", iface->name, "scan", "trigger", "ap-force"))
		return -1;
	return 0;
}

int hal_nl80211_scan_duration(const struct iface *iface, uint32_t *duration)
{
	*duration = SCAN_DURATION;
	return 0;
}

int hal_nl80211_scan_status(const struct iface *iface, uint32_t *status)
{
	*status = 0; /*it is very fast => it is ok to return 0 here */
	return 0;
}

int hal_nl80211_scan_list(const struct iface *iface, char *halbuf, int *len)
{
	struct scan_stats *ss;
	char buf[256];
	char *tok;
	FILE *p;

	if (iface != iface->phy)
		return -1;

	p = execl_popen(0, PATH_IW, "dev", iface->name, "scan", "dump");
	if (!p)
		return -1;

	ss = (struct scan_stats *)halbuf - 1;
	*len = 0;
	while (fgets(buf, 256, p)) {
		if ((tok = strstr(buf, "BSS")) && tok == buf) {
			if (hal_buf_check_clear(halbuf, *len, sizeof(*ss)))
				break;
			ss++;
			(*len)++;
			FLDSET(ss->bandwidth, 20);
			tok = gettok(tok, NULL, 1, SPACE"(");
			str2mac(tok, ss->bssid);
			ss->bssid_set = 1;
		} else if (tok = gettok(buf, "freq:", 1, SPACE)) {
			int freq = atoi(tok);
			ss->protocol_set = 1;
			if (freq < 3000) {
				ss->protocol |= PROTO_11B;
				ss->protocol |= PROTO_11G;
			} else {
				ss->protocol |= PROTO_11A;
			}
			/* In theory, on 2.4G networks a beacon could be received on adjacent
			 * channel due to overlapping. Thats why we still need to look at
			 * "DS Parameter set" and "HT Operation" IEs. On the other hand,
			 * not every beacon has these elements, so in this case we need
			 * to fall back to a frequency at which the beacon was received. */
			FLDSET(ss->channel, freq2chan(freq));
		} else if (tok = gettok(buf, "signal:", 1, SPACE".")) {
			FLDSET(ss->rssi, atoi(tok));
		} else if (tok = gettok(buf, "SSID:", 1, SPACE)) {
			strncpy(ss->ssid, tok, sizeof(string32) - 1);
			ss->ssid_set = 1;
		} else if (tok = gettok(buf, "DS Parameter set:", 4, SPACE)) {
			FLDSET(ss->channel, atoi(tok));
		} else if (tok = gettok(buf, "primary channel:", 2, SPACE)) {
			FLDSET(ss->channel, atoi(tok));
		} else if (tok = strstr(buf, "\tHT capabilities")) {
			ss->protocol_set = 1;
			ss->protocol |= PROTO_11N;
		} else if (tok = strstr(buf, "VHT capabilities")) {
			ss->protocol_set = 1;
			ss->protocol |= PROTO_11AC;
		} else if (tok = strstr(buf, "HT20/HT40")) {
			FLDSET(ss->bandwidth, 40);
		} else if (tok = strstr(buf, "no secondary")) {
			FLDSET(ss->bandwidth, 20);
		} else if (tok = gettok(buf, "* channel width: ", 3, SPACE)) {
			switch (atoi(tok)) {
			case 1:
				FLDSET(ss->bandwidth, 80);
				break;
			case 2:
			case 3:
				FLDSET(ss->bandwidth, 160);
				break;
			}
		}
	}
	execl_pclose(p);
	return 0;
}

int hal_nl80211_set_channel(const struct iface *iface, uint32_t channel)
{
	return -ENOTSUP;
}

int hal_nl80211_set_txpower(const struct iface *iface, int32_t txpower)
{
	if (execl_run(0, PATH_IW, "dev", iface->name,
		"set", "txpower", "fixed", str16("%d", txpower * 100)))
		return -1;
	return 0;
}

int hal_nl80211_set_ssid(const struct iface *iface, char *ssid)
{
	return -ENOTSUP;
}

int hal_nl80211_set_bandwidth(const struct iface *iface, uint32_t bandwidth)
{
	return -ENOTSUP;
}


struct hal_ops hal_nl80211_ops = {
	.name = "nl80211",

	.init = NULL,
	.reinit = NULL,
	.probe = hal_nl80211_probe,

	.mode = hal_nl80211_mode,
	.channel = hal_nl80211_channel,
	.txpower = hal_nl80211_txpower,
	.region = hal_nl80211_region,
	.bandwidth = hal_nl80211_bandwidth,
	.bandwidth_supp = hal_nl80211_bandwidth_supp,
	.protocol = hal_nl80211_protocol,
	.protocol_supp = hal_nl80211_protocol_supp,
	.ssid = hal_nl80211_ssid,
	.bssid = hal_nl80211_bssid,
	.phy_stats = hal_nl80211_phy_stats,
	.cca_stats = hal_nl80211_cca_stats,
	.channel_list = hal_nl80211_channel_list,
	.assoc_list = hal_nl80211_assoc_list,
	.traffic_list = hal_nl80211_traffic_list,
	.scan_start = hal_nl80211_scan_start,
	.scan_duration = hal_nl80211_scan_duration,
	.scan_status = hal_nl80211_scan_status,
	.scan_list = hal_nl80211_scan_list,

	.set_channel = hal_nl80211_set_channel,
	.set_txpower = hal_nl80211_set_txpower,
	.set_ssid = hal_nl80211_set_ssid,
	.set_bandwidth = hal_nl80211_set_bandwidth,
};
