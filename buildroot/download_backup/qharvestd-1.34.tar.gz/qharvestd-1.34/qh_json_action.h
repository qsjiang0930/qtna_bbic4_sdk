/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QH_JSON_ACTION_H
#define __QH_JSON_ACTION_H

#include "qh_json.h"

#define OFFSET(STRUCT, MEMBER) (offsetof(struct STRUCT, MEMBER))

typedef enum {
	BIDICMD_REBOOT = 1,
	BIDICMD_SSID,
	BIDICMD_SCS,
	BIDICMD_SCS_REPORT,
	BIDICMD_CHANNEL,
	BIDICMD_OCAC,
	BIDICMD_BW,
	BIDICMD_TXPOWER,
	BIDICMD_WIRELESS_CONF,
	BIDICMD_MAC_FILTER,
	BIDICMD_FORCE_SCAN,
	BIDICMD_FORCE_POLL,
	BIDICMD_PKL_CONFIG,
} bidicmd_type;

typedef enum {
	TYPE_STRING,
	TYPE_U16,
	TYPE_S16,
	TYPE_U32,
	TYPE_S32,
	TYPE_U64,
	TYPE_S64,
	TYPE_DOUBLE,
	TYPE_BOOL,
	TYPE_VOID,
	TYPE_OBJECT,
} data_type;

enum {
	FLAG_MANDATORY = 0x1,
	FLAG_RECURSIVE = 0x2,
} data_flags;

struct data_description {
	const char *key;
	data_type type;
	int flag;
	intptr_t offset;
};

int parse_response(JSON *obj, void *data, struct data_description *data_desc);

int do_firmware_upgrade(struct message_control *mctl, JSON *obj, JSON *robj);

int do_poll(struct message_control *mctl, JSON *obj, JSON *robj);

#ifndef HAVE_BIDICMD_REBOOT
#define HAVE_BIDICMD_REBOOT 1
#endif

int do_bidicmd(struct message_control *mctl, JSON *obj, JSON *robj);

int do_check_health(struct message_control *mctl, JSON *obj, JSON *robj);

int do_oauth(struct message_control *mctl, JSON *obj, JSON *robj);

#endif
