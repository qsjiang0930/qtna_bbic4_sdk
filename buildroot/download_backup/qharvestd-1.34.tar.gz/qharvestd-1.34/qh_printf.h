/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2012 - 2019 Quantenna Communications, Inc.          **
**         All rights reserved.                                              **
**                                                                           **
*******************************************************************************
*/

#ifndef __QH_PRINTF_H
#define __QH_PRINTF_H

void debug_printf(int level, const char *fmt, ...) __attr_fmt(2, 3);
#define DBG(level, fmt, ...) debug_printf(level, fmt, ##__VA_ARGS__)
#define DBG_ERROR(fmt, ...) debug_printf(LOG_ERR, fmt, ##__VA_ARGS__)
#define DBG_WARNING(fmt, ...) debug_printf(LOG_WARNING, fmt, ##__VA_ARGS__)
#define DBG_NOTICE(fmt, ...) debug_printf(LOG_NOTICE, fmt, ##__VA_ARGS__)
#define DBG_INFO(fmt, ...) debug_printf(LOG_INFO, fmt, ##__VA_ARGS__)

#endif
