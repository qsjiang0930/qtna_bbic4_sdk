/* Automatically generated file.  Do not edit. */
#define QCSAPI_BLD_VER	(0x250407f7)
