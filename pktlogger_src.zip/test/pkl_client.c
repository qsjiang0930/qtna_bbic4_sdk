/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 Quantenna Communications Inc                   **
**                                                                           **
**  File        : pkl_client.c                                               **
**  Description : PKL library test app                                       **
**                                                                           **
*******************************************************************************
*/

#include <stdint.h>
#include <stdlib.h>            /* exit */
#include <stdio.h>             /* perror */
#include <errno.h>
#include <unistd.h>            /* usleep */
#include <string.h>            /* strncmp, malloc */
#include <assert.h>            /* assert */
#include <signal.h>            /* signal */
#include <sys/socket.h>        /* socket API */
#include <netinet/in.h>        /* sockaddr_in */
#include <sys/select.h>        /* select system call */
#include <sys/time.h>          /* struct timeval */
#include "pktlogger_common.h"
#include "pkl.h"

#ifndef MAX
#define MAX(a, b)			((a) > (b) ? (a) : (b))
#endif

#define PKL_CLIENT_VERSION			"0.0.7"

static void sig_handler(int signo);

uint8_t recv_buf[PKL_RECV_BUF_MAX_SIZE];
void *pkl = NULL;

#define DBG_PRINTF(n, fmt, args...)	do {						\
					fprintf(stderr, "CLIENT (%d): ", n);		\
					fprintf(stderr, fmt, ## args);			\
				} while (0)

static void sig_handler(int signo)
{
	if (signo == SIGINT) {
		DBG_PRINTF(-1, "Received SIGINT\n");
		/* Release resources. */
		pkl_close(pkl);
		exit(0);
	}
}

/* Example 1: Configure to receive the ‘stats’ data (entire structure) */
int main(int argc, char **argv)
{
	const uint32_t qdrv_netdebug_stats_history = 5;
	const uint32_t netdebug_dsp_stats_history = 10;
	const uint32_t netdebug_phy_stats_history = 5;
	const uint32_t netdebug_txbf_history = 5;
	const uint32_t netdebug_rate_history = 5;
	const uint32_t qdrv_radar_history = 5;

	const uint32_t qdrv_netdebug_stats_rate = 10;
	const uint32_t netdebug_dsp_stats_rate = 5;
	const uint32_t netdebug_phy_stats_rate = 5;
	const uint32_t netdebug_txbf_rate = 5;
	const uint32_t netdebug_rate_rate = 5;
	const uint32_t qdrv_radar_rate = 5;

	uint32_t qdrv_netdebug_stats_counter;
	uint32_t netdebug_dsp_stats_counter;
	uint32_t netdebug_phy_stats_counter;
	uint32_t netdebug_txbf_counter;
	uint32_t netdebug_rate_counter;
	uint32_t qdrv_radar_counter;

	struct pktlogger_radio_config_t *radio_cfg;
	struct pktlogger_config_one_t cfgone;
	struct pktlogger_config_t cfg;
	struct timeval stats_timeout;
	uint32_t history_data_len;
	uint32_t lzma_structs_len;
	int stats_socket = -1;
	int do_streaming;
	int test_num = 0;
	int num_entries;
	fd_set readfds;
	int last_fd;
	int type;
	int res;
	int i, j;

	DBG_PRINTF(test_num, "PKL client version: %s\n", PKL_CLIENT_VERSION);

	if (signal(SIGINT, sig_handler) == SIG_ERR)
		DBG_PRINTF(test_num, "Can't catch SIGINT\n");

	/* Step 1: Discover pktlogger daemon. Here, received structures are not used. */
	test_num = 1;

	lzma_structs_len = PKL_RECV_BUF_MAX_SIZE;
	if (pkl_open(&pkl, PKTLOGGER_D_NET_PORT, &recv_buf[0], &lzma_structs_len) == -1) {
		DBG_PRINTF(test_num, "Can't discover pktlogger daemon.\n");
		return -1; /* no error handling */
	}
	DBG_PRINTF(test_num, "%d bytes of compressed structs were received.\n", lzma_structs_len);

	pkl_debug_pk_verbose_set(pkl, PKL_DBG_ERROR);

	/* Step 2: Request for all current configurations. */
	test_num = 2;

	if (pkl_debug_pk_config_get(pkl, &cfg) == -1) {
		DBG_PRINTF(test_num, "Can't get pktlogger configuration.\n");
		pkl_close(pkl);
		return -1;
	}

	for (i = 0; i < PKTLOGGER_MAX_RADIOS; i++) {
		if (!(cfg.radio_mask & (1 << i)))
			continue;
		radio_cfg = &cfg.per_radio[i];
		DBG_PRINTF(test_num, "Current configuration on %s ->\n", (char *)radio_cfg->radioname);
		num_entries = radio_cfg->pktlog_ver_cnt & 0xFF;
		for (j = 0; j < num_entries; j++) {
			if (radio_cfg->pktlog_configs[j].type != PKTLOGGER_TYPE_UNUSED_0) {
				DBG_PRINTF(test_num, "\t %s: %d, %d-sec rate, %d-entry history\n", (char *)radio_cfg->pktlog_configs[j].name,
				           radio_cfg->pktlog_configs[j].flags,
				           radio_cfg->pktlog_configs[j].rate,
				           radio_cfg->pktlog_configs[j].history);
			}
		}
	}

	/* Step 3: Adjust wifi0 configuration in-place. */
	test_num = 3;

	radio_cfg = &cfg.per_radio[0];
	/* Enable STATS */
	if ((radio_cfg->pktlog_configs[PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS].type == PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS) &&
			(!strncmp((const char *)radio_cfg->pktlog_configs[PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS].name, "stats", 16))) {
		DBG_PRINTF(test_num, "tune %s:%s\n", (char *)radio_cfg->radioname, (char *)radio_cfg->pktlog_configs[PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS].name);
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS].flags |= PKTLOGGER_CONFIG_FLAGS_ENABLED;
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS].rate   = qdrv_netdebug_stats_rate;
	}
	else {
		DBG_PRINTF(test_num, "Wrong type.\n");
		pkl_close(pkl);
		return -1;
	}

	/* Disable PHY_STATS */
	if ((radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_PHY_STATS].type == PKTLOGGER_TYPE_NETDEBUG_PHY_STATS) &&
			(!strncmp((const char *)radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_PHY_STATS].name, "phy_stats", 16))) {
		DBG_PRINTF(test_num, "tune %s:%s\n", (char *)radio_cfg->radioname, (char *)radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_PHY_STATS].name);
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_PHY_STATS].flags &= ~PKTLOGGER_CONFIG_FLAGS_ENABLED;
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_PHY_STATS].rate   = netdebug_phy_stats_rate;
	}
	else {
		DBG_PRINTF(test_num, "Wrong type.\n");
		pkl_close(pkl);
		return -1;
	}

	/* Step 4: Set configurations. */
	test_num = 4;

	if (pkl_debug_pk_config_set(pkl, &cfg) == -1) {
		DBG_PRINTF(test_num, "Can't set pktlogger configuration.\n");
		pkl_close(pkl);
		return -1;
	}

	/* Step 5: Request for the new configurations. */
	test_num = 5;

	if (pkl_debug_pk_config_get(pkl, &cfg) == -1) {
		DBG_PRINTF(test_num, "Can't get pktlogger configuration.\n");
		pkl_close(pkl);
		return -1;
	}

	usleep(1000000);

	radio_cfg = &cfg.per_radio[0];
	DBG_PRINTF(test_num, "New configuration on %s ->\n", (char *)radio_cfg->radioname);
	num_entries = radio_cfg->pktlog_ver_cnt & 0xFF;
	for (i = 0; i < num_entries; i++) {
		if (radio_cfg->pktlog_configs[i].type != PKTLOGGER_TYPE_UNUSED_0) {
			DBG_PRINTF(test_num, "\t %s: %d, %d-sec rate, %d-entry history\n", (char *)radio_cfg->pktlog_configs[i].name,
			           radio_cfg->pktlog_configs[i].flags,
			           radio_cfg->pktlog_configs[i].rate,
			           radio_cfg->pktlog_configs[i].history);
		}
	}

	/* Step 6: Set one dsp_stats & qdrv_stats configuration for wifi0. */
	test_num = 6;

	if (pkl_debug_pk_config_one_get(pkl, &cfgone, 0, PKTLOGGER_TYPE_NETDEBUG_DSP_STATS) == -1) {
		DBG_PRINTF(test_num, "Can't get pktlogger configuration.\n");
		pkl_close(pkl);
		return -1;
	}

	cfgone.config.flags  |= PKTLOGGER_CONFIG_FLAGS_ENABLED;
	cfgone.config.history = netdebug_dsp_stats_history;
	cfgone.config.rate    = netdebug_dsp_stats_rate;

	if (pkl_debug_pk_config_one_set(pkl, &cfgone) == -1) {
		pkl_close(pkl);
		return -1;
	}

	if (pkl_debug_pk_config_one_get(pkl, &cfgone, 0, PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS) == -1) {
		DBG_PRINTF(test_num, "Can't get pktlogger configuration.\n");
		pkl_close(pkl);
		return -1;
	}

	cfgone.config.flags  |= PKTLOGGER_CONFIG_FLAGS_ENABLED;
	cfgone.config.history = qdrv_netdebug_stats_history;
	cfgone.config.rate    = qdrv_netdebug_stats_rate;

	if (pkl_debug_pk_config_one_set(pkl, &cfgone) == -1) {
		pkl_close(pkl);
		return -1;
	}

	usleep(1000000);

	/* Step 7: Request for the new (just set) configurations. */
	test_num = 7;

	if (pkl_debug_pk_config_one_get(pkl, &cfgone, 0, PKTLOGGER_TYPE_NETDEBUG_DSP_STATS) == -1) {
		DBG_PRINTF(test_num, "Can't get pktlogger configuration.\n");
		pkl_close(pkl);
		return -1;
	}

	DBG_PRINTF(test_num, "New DSP_STATS configuration ->\n");
	DBG_PRINTF(test_num, "\t %s: %d, %d-sec rate, %d-entry history\n", (char *)cfgone.config.name,
					cfgone.config.flags,
					cfgone.config.rate,
					cfgone.config.history);

	if (pkl_debug_pk_config_one_get(pkl, &cfgone, 0, PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS) == -1) {
		DBG_PRINTF(test_num, "Can't get pktlogger configuration.\n");
		pkl_close(pkl);
		return -1;
	}

	DBG_PRINTF(test_num, "New STATS configuration ->\n");
	DBG_PRINTF(test_num, "\t %s: %d, %d-sec rate, %d-entry history\n", (char *)cfgone.config.name,
					cfgone.config.flags,
					cfgone.config.rate,
					cfgone.config.history);

	/* Step 8: Obtain socket to receive pktlogger data */
	test_num = 8;

	pkl_debug_pk_get_stream_socket(pkl, &stats_socket);

	/* Step 9: Statistics streaming qdrv_stats, [1:3] history range only */
	test_num = 9;

	qdrv_netdebug_stats_counter = 3;
	pkl_debug_pk_send_stream_request(pkl, 0, PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS,
	                                 qdrv_netdebug_stats_counter, 1);
	do {
		stats_timeout.tv_sec  = 2 * qdrv_netdebug_stats_rate + 5;
		stats_timeout.tv_usec = 0;

		FD_ZERO(&readfds);
		FD_SET(stats_socket, &readfds);
		last_fd = stats_socket;

		res = select(last_fd + 1, &readfds, NULL, NULL, &stats_timeout);
		if (res < 0) {
			perror("CLIENT: select - ");
			pkl_close(pkl);
			return -1;
		}
		if (res == 0) {
			DBG_PRINTF(test_num, "data timeout elapsed.\n");
			break;
		}

		history_data_len = PKL_RECV_BUF_MAX_SIZE;
		res = pkl_debug_pk_recv_data(pkl, &recv_buf[0], &history_data_len, &type);
		if (res > 0)
			continue; /* wrong packet type */
		if (res < 0) {
			DBG_PRINTF(test_num, "Can't receive data from pktlogger daemon.\n");
			pkl_close(pkl);
			return -1;
		}

		DBG_PRINTF(test_num, "got %d data bytes (type=%d)\n", history_data_len, type);
		if (type == PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS)
			qdrv_netdebug_stats_counter--;

	} while (qdrv_netdebug_stats_counter);

	/* Step 10: Statistics streaming qdrv_stats (subsequent request) and dsp_stats (since the oldest entry) */
	test_num = 10;

	pkl_debug_pk_send_stream_request(pkl, 0, PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS,
	                                 PKTLOGGER_REQ_COUNT_WHOLE_HISTORY_AND_REAL_TIME_DATA, 0);
	pkl_debug_pk_send_stream_request(pkl, 0, PKTLOGGER_TYPE_NETDEBUG_DSP_STATS,
	                                 PKTLOGGER_REQ_COUNT_WHOLE_HISTORY_AND_REAL_TIME_DATA, 1);

	netdebug_dsp_stats_counter = qdrv_netdebug_stats_counter = 0;
	do_streaming = 2;
	while (do_streaming) {
		stats_timeout.tv_sec  = MAX(2 * qdrv_netdebug_stats_rate + 5, 2 * netdebug_dsp_stats_rate + 5);
		stats_timeout.tv_usec = 0;

		FD_ZERO(&readfds);
		FD_SET(stats_socket, &readfds);
		last_fd = stats_socket;

		res = select(last_fd + 1, &readfds, NULL, NULL, &stats_timeout);
		if (res < 0) {
			perror("CLIENT: select - ");
			pkl_close(pkl);
			return -1;
		}
		if (res == 0) {
			DBG_PRINTF(test_num, "data timeout elapsed.\n");
			break;
		}

		history_data_len = PKL_RECV_BUF_MAX_SIZE;
		pkl_debug_pk_recv_data(pkl, &recv_buf[0], &history_data_len, &type);
		DBG_PRINTF(test_num, "got %d data bytes (type=%d)\n", history_data_len, type);
		if (type == PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS)
			qdrv_netdebug_stats_counter++;
		if (type == PKTLOGGER_TYPE_NETDEBUG_DSP_STATS)
			netdebug_dsp_stats_counter++;

		/* whole history + 5 real-time data */
		if (qdrv_netdebug_stats_counter == (qdrv_netdebug_stats_history + 5)) {
			qdrv_netdebug_stats_counter = 0;
			pkl_debug_pk_stop_stream(pkl, 0, PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS);
			do_streaming--;
		}
		/* whole history + 5 real-time data */
		if (netdebug_dsp_stats_counter == (netdebug_dsp_stats_history + 5)) {
			netdebug_dsp_stats_counter = 0;
			pkl_debug_pk_stop_stream(pkl, 0, PKTLOGGER_TYPE_NETDEBUG_DSP_STATS);
			do_streaming--;
		}
	}

	/* Step 11: Negative test case. Statistics streaming for the disabled phy_stats */
	test_num = 11;

	pkl_debug_pk_send_stream_request(pkl, 0, PKTLOGGER_TYPE_NETDEBUG_PHY_STATS,
	                                 PKTLOGGER_REQ_COUNT_WHOLE_HISTORY_AND_REAL_TIME_DATA, 1);
	while (1) {
		stats_timeout.tv_sec  = 2 * netdebug_phy_stats_rate + 5;
		stats_timeout.tv_usec = 0;

		FD_ZERO(&readfds);
		FD_SET(stats_socket, &readfds);
		last_fd = stats_socket;

		res = select(last_fd + 1, &readfds, NULL, NULL, &stats_timeout);
		if (res < 0) {
			perror("CLIENT: select - ");
			pkl_close(pkl);
			return -1;
		}
		if (res == 0) {
			DBG_PRINTF(test_num, "data timeout elapsed.\n");
			break;
		}

		/* Receiving PHY_STATS is not possible for the negative test case, no data. */
		history_data_len = PKL_RECV_BUF_MAX_SIZE;
		pkl_debug_pk_recv_data(pkl, &recv_buf[0], &history_data_len, &type);
		DBG_PRINTF(test_num, "got %d data bytes (type=%d)\n", history_data_len, type);
		if (type == PKTLOGGER_TYPE_NETDEBUG_PHY_STATS) {
			DBG_PRINTF(test_num, "Received unexpected type = %d\n", type);
			pkl_close(pkl);
			return -1;
		}
	}

	/* Step 12: Stress test: request for one-configurations when data streaming is on */
	test_num = 12;

	pkl_debug_pk_send_stream_request(pkl, 0, PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS,
	                                 PKTLOGGER_REQ_COUNT_WHOLE_HISTORY_AND_REAL_TIME_DATA, 0);
	pkl_debug_pk_send_stream_request(pkl, 0, PKTLOGGER_TYPE_NETDEBUG_DSP_STATS,
	                                 PKTLOGGER_REQ_COUNT_WHOLE_HISTORY_AND_REAL_TIME_DATA, 1);

	DBG_PRINTF(test_num, "Let us request for statistics data, but do not read it off for 5 seconds...\n");
	usleep(5000000);

	if (pkl_debug_pk_config_one_get(pkl, &cfgone, 0, PKTLOGGER_TYPE_NETDEBUG_DSP_STATS) == -1) {
		DBG_PRINTF(test_num, "Can't get pktlogger configuration.\n");
		pkl_close(pkl);
		return -1;
	}

	DBG_PRINTF(test_num, "DSP_STATS configuration ->\n");
	DBG_PRINTF(test_num, "\t %s: %d, %d-sec rate, %d-entry history\n", (char *)cfgone.config.name,
					cfgone.config.flags,
					cfgone.config.rate,
					cfgone.config.history);

	if (pkl_debug_pk_config_one_get(pkl, &cfgone, 0, PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS) == -1) {
		DBG_PRINTF(test_num, "Can't get pktlogger configuration.\n");
		pkl_close(pkl);
		return -1;
	}

	DBG_PRINTF(test_num, "STATS configuration ->\n");
	DBG_PRINTF(test_num, "\t %s: %d, %d-sec rate, %d-entry history\n", (char *)cfgone.config.name,
					cfgone.config.flags,
					cfgone.config.rate,
					cfgone.config.history);

	pkl_debug_pk_stop_stream(pkl, 0, PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS);
	pkl_debug_pk_stop_stream(pkl, 0, PKTLOGGER_TYPE_NETDEBUG_DSP_STATS);

	/* Step 13: Try to set 0-sec rate. */
	test_num = 13;

	if (pkl_debug_pk_config_one_get(pkl, &cfgone, 0, PKTLOGGER_TYPE_NETDEBUG_DSP_STATS) == -1) {
		DBG_PRINTF(test_num, "Can't get pktlogger configuration.\n");
		pkl_close(pkl);
		return -1;
	}

	cfgone.config.flags  |= PKTLOGGER_CONFIG_FLAGS_ENABLED;
	cfgone.config.history = netdebug_dsp_stats_history;
	cfgone.config.rate    = 0;

	if (pkl_debug_pk_config_one_set(pkl, &cfgone) == -1) {
		DBG_PRINTF(test_num, "Can't set pktlogger configuration.\n");
		pkl_close(pkl);
		return -1;
	}

	if (pkl_debug_pk_config_one_get(pkl, &cfgone, 0, PKTLOGGER_TYPE_NETDEBUG_DSP_STATS) == -1) {
		DBG_PRINTF(test_num, "Can't get pktlogger configuration.\n");
		pkl_close(pkl);
		return -1;
	}

	usleep(1000000);

	DBG_PRINTF(test_num, "New DSP_STATS configuration ->\n");
	DBG_PRINTF(test_num, "\t %s: %d, %d-sec rate, %d-entry history\n", (char *)cfgone.config.name,
					cfgone.config.flags,
					cfgone.config.rate,
					cfgone.config.history);

	/* Step 14: Configure pktlogger as a whole and request for streaming. */
	test_num = 14;

	/* Receive config */
	if (pkl_debug_pk_config_get(pkl, &cfg) == -1) {
		DBG_PRINTF(test_num, "Can't get pktlogger configuration.\n");
		pkl_close(pkl);
		return -1;
	}
	/* Configure pktlogger as a whole:
	 * disable STATS and DSP_STATS
	 * enable PHY_STATS, TXBF, RATE and RADAR
	 */
	radio_cfg = &cfg.per_radio[0];
	if ((radio_cfg->pktlog_configs[PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS].type == PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS) &&
			(!strncmp((const char *)radio_cfg->pktlog_configs[PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS].name, "stats", 16))) {
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_QDRV_NETDEBUG_STATS].flags &= ~PKTLOGGER_CONFIG_FLAGS_ENABLED;
	}
	if ((radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_DSP_STATS].type == PKTLOGGER_TYPE_NETDEBUG_DSP_STATS) &&
			(!strncmp((const char *)radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_DSP_STATS].name, "dsp_stats", 16))) {
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_DSP_STATS].flags &= ~PKTLOGGER_CONFIG_FLAGS_ENABLED;
	}
	if ((radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_PHY_STATS].type == PKTLOGGER_TYPE_NETDEBUG_PHY_STATS) &&
			(!strncmp((const char *)radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_PHY_STATS].name, "phy_stats", 16))) {
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_PHY_STATS].flags  |= PKTLOGGER_CONFIG_FLAGS_ENABLED;
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_PHY_STATS].rate    = netdebug_phy_stats_rate;
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_PHY_STATS].history = netdebug_phy_stats_history;
	}
	if ((radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_TXBF].type == PKTLOGGER_TYPE_NETDEBUG_TXBF) &&
			(!strncmp((const char *)radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_TXBF].name, "txbf", 16))) {
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_TXBF].flags  |= PKTLOGGER_CONFIG_FLAGS_ENABLED;
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_TXBF].rate    = netdebug_txbf_rate;
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_TXBF].history = netdebug_txbf_history;
	}
	if ((radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_RATE].type == PKTLOGGER_TYPE_NETDEBUG_RATE) &&
			(!strncmp((const char *)radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_RATE].name, "rate", 16))) {
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_RATE].flags  |= PKTLOGGER_CONFIG_FLAGS_ENABLED;
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_RATE].rate    = netdebug_rate_rate;
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_RATE].history = netdebug_rate_history;
	}
	if ((radio_cfg->pktlog_configs[PKTLOGGER_TYPE_QDRV_RADAR_STATS].type == PKTLOGGER_TYPE_QDRV_RADAR_STATS) &&
			(!strncmp((const char *)radio_cfg->pktlog_configs[PKTLOGGER_TYPE_QDRV_RADAR_STATS].name, "radar", 16))) {
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_QDRV_RADAR_STATS].flags  |= PKTLOGGER_CONFIG_FLAGS_ENABLED;
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_QDRV_RADAR_STATS].rate    = qdrv_radar_rate;
		radio_cfg->pktlog_configs[PKTLOGGER_TYPE_QDRV_RADAR_STATS].history = qdrv_radar_history;
	}

	if (pkl_debug_pk_config_set(pkl, &cfg) == -1) {
		DBG_PRINTF(test_num, "Can't set pktlogger configuration.\n");
		pkl_close(pkl);
		return -1;
	}

	pkl_debug_pk_send_stream_request(pkl, 0, PKTLOGGER_TYPE_NETDEBUG_PHY_STATS,
	                                 PKTLOGGER_REQ_COUNT_WHOLE_HISTORY_AND_REAL_TIME_DATA, 1);
	pkl_debug_pk_send_stream_request(pkl, 0, PKTLOGGER_TYPE_NETDEBUG_TXBF,
	                                 PKTLOGGER_REQ_COUNT_WHOLE_HISTORY_AND_REAL_TIME_DATA, 1);
	pkl_debug_pk_send_stream_request(pkl, 0, PKTLOGGER_TYPE_NETDEBUG_RATE,
	                                 PKTLOGGER_REQ_COUNT_WHOLE_HISTORY_AND_REAL_TIME_DATA, 1);
	pkl_debug_pk_send_stream_request(pkl, 0, PKTLOGGER_TYPE_QDRV_RADAR_STATS,
	                                 PKTLOGGER_REQ_COUNT_WHOLE_HISTORY_AND_REAL_TIME_DATA, 1);

	netdebug_phy_stats_counter = netdebug_txbf_counter = netdebug_rate_counter = qdrv_radar_counter = 0;
	do_streaming = 4;
	while (do_streaming) {
		stats_timeout.tv_sec  = MAX(2 * netdebug_phy_stats_rate + 5, 2 * netdebug_txbf_rate + 5);
		stats_timeout.tv_sec  = MAX(stats_timeout.tv_sec, 2 * netdebug_rate_rate + 5);
		stats_timeout.tv_sec  = MAX(stats_timeout.tv_sec, 2 * qdrv_radar_rate + 5);
		stats_timeout.tv_usec = 0;

		FD_ZERO(&readfds);
		FD_SET(stats_socket, &readfds);
		last_fd = stats_socket;

		res = select(last_fd + 1, &readfds, NULL, NULL, &stats_timeout);
		if (res < 0) {
			perror("CLIENT: select - ");
			pkl_close(pkl);
			return -1;
		}
		if (res == 0) {
			DBG_PRINTF(test_num, "data timeout elapsed.\n");
			break;
		}

		history_data_len = PKL_RECV_BUF_MAX_SIZE;
		pkl_debug_pk_recv_data(pkl, &recv_buf[0], &history_data_len, &type);
		DBG_PRINTF(test_num, "got %d data bytes (type=%d)\n", history_data_len, type);
		if (type == PKTLOGGER_TYPE_NETDEBUG_PHY_STATS)
			netdebug_phy_stats_counter++;
		if (type == PKTLOGGER_TYPE_NETDEBUG_TXBF)
			netdebug_txbf_counter++;
		if (type == PKTLOGGER_TYPE_NETDEBUG_RATE)
			netdebug_rate_counter++;
		if (type == PKTLOGGER_TYPE_QDRV_RADAR_STATS)
			qdrv_radar_counter++;

		/* whole history + 5 real-time data */
		if (netdebug_phy_stats_counter == (netdebug_phy_stats_history + 5)) {
			netdebug_phy_stats_counter = 0;
			pkl_debug_pk_stop_stream(pkl, 0, PKTLOGGER_TYPE_NETDEBUG_PHY_STATS);
			do_streaming--;
		}
		/* whole history + 5 real-time data */
		if (netdebug_txbf_counter == (netdebug_txbf_history + 5)) {
			netdebug_txbf_counter = 0;
			pkl_debug_pk_stop_stream(pkl, 0, PKTLOGGER_TYPE_NETDEBUG_TXBF);
			do_streaming--;
		}
		/* whole history + 5 real-time data */
		if (netdebug_rate_counter == (netdebug_rate_history + 5)) {
			netdebug_rate_counter = 0;
			pkl_debug_pk_stop_stream(pkl, 0, PKTLOGGER_TYPE_NETDEBUG_RATE);
			do_streaming--;
		}
		/* whole history + 5 real-time data */
		if (qdrv_radar_counter == (qdrv_radar_history + 5)) {
			qdrv_radar_counter = 0;
			pkl_debug_pk_stop_stream(pkl, 0, PKTLOGGER_TYPE_QDRV_RADAR_STATS);
			do_streaming--;
		}
	}

	/* The End */
	pkl_close(pkl);
	return 0;
}
