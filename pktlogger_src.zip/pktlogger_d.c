/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 Quantenna Communications Inc                   **
**                                                                           **
**  File        : pktlogger_d.c                                              **
**  Description : pktlogger daemon                                           **
**                                                                           **
*******************************************************************************
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/param.h>
#include <sys/time.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <stdarg.h>
#include <netinet/ether.h>
#include "pktlogger_common.h"
#include "ql2t.h"

#define PKTLOGGER_D_P			"pktlogger_d_p"

#define PKTLOGGER_MAX_HISTORY_ENTRIES_PER_TYPE    60

#ifndef ARRAY_COUNT
#define ARRAY_COUNT(_x)			(sizeof(_x)/sizeof(_x[0]))
#endif

#define MEMBER_SIZE(type, member)	sizeof(((type *) 0)->member)

#define PKL_DPRINTF(fmt, args...)	do {							\
						if (g_pk_cfg.verbose)				\
							fprintf(stdout, fmt, ## args);		\
					} while (0)
#define PKL_EPRINTF(fmt, args...)	do {							\
						fprintf(stderr, fmt, ## args);			\
					} while (0)

/* FIXME: this should be part of some header - need to work out which one... */
/* MUST be prior to including pktlogger_nl_common.h so the pktlogger header structure
 * parses correctly.
 */
struct udphdr
{
	__u16 src;
	__u16 dest;
	__u16 len;
	__u16 check;
};

#include "pktlogger_nl_common.h"

struct pk_addr_t
{
#define PKTLOGGER_D_ADDR_IN	1	/* IP socket - only addr_in is used */
#define PKTLOGGER_D_ADDR_QL2T	2	/* QL2T socket - both addr_in and addr_ql2t are used;
					   addr_in is the address of the IP client */
	uint8_t type;
	struct sockaddr_in addr_in;
	ql2t_recv_cfg addr_ql2t;
};

/* Single consumer - address of the receiver */
struct pk_client_consumer_t
{
	struct pk_addr_t src;
};

/* Structure to save the context of an incoming client request from a pktlogger client */
struct pk_client_response_t
{
	struct pk_addr_t src;
	uint32_t net_mseq;
	uint32_t rsp_mseq;	/* transpt mseq or nl mseq to match against */
	/* For chaining when multiple queries are pending for different clients */
	struct pk_client_response_t *next;
};

/* Structure to record data requests and allow streaming back of data in a controlled
 * manner.
 */
struct pk_client_data_stream_t
{
	struct pk_pt_history_t *p_hist;
	struct pk_client_consumer_t stream_consumer;
	uint16_t requested_samples;
	uint16_t remaining;
	uint16_t samplenum;
	uint32_t net_mseq;
	struct pk_client_data_stream_t *p_tnext; /* List across this types */
	struct pk_client_data_stream_t *p_next; /* Global list across all types */
};

struct pk_pt_sample_t
{
	size_t len;	/* Allocated length */
	uint8_t buf[1]; /* Buffer to store the stats; also includes the actual stats len in the header */
};

/* Overall config of the daemon. */
struct pk_config_t {
	int listen_fd; /* to listen to pktlogger clients' requests. Clients can be remote or
			  local. */
	int transpt_fd;
	int netlink_ctrl_fd;
	int netlink_data_fd;
	pid_t nlmsg_pid;
	pid_t pkdata_pid;
	int8_t proxy;
	char local_if_name[IFNAMSIZ];
	uint8_t remote_mac_addr[ETH_ALEN];
	uint16_t port;
	int8_t en_remote_host;
	struct pk_client_response_t *p_response_list;
	uint32_t verbose;
	int arm_timer;
	int initialising;
};

/* History buffer shared between multiple clients */
struct pk_pt_hist_buffer_t
{
	uint32_t history_len; /* Number of entries in the sample array. */
	struct pk_pt_sample_t **p_samples; /* Array of pointers to 'history_len' samples of data.
					    * Circular buffer
					    */
	uint32_t ref_cnt;
	uint32_t sample_count;
};

/*
 * Structure to retain history for a given pktlogger type.
 *
 * The circular buffer is allocated based on the incoming configuration, and buffers are stored
 * sequentially as received. The read pointer starts at index 0, and will be automatically increased
 * as the circular buffer overflows, to make sure the read is always at the earliest sample.
 * write index automatically increases as data is consumed from the kernel.
 */
struct pk_pt_history_t {
	struct pk_pt_hist_buffer_t *p_histbuf;
	uint32_t type;
	uint32_t widx; /* Current write index */
	uint32_t ridx; /* Current read index */
	struct pk_client_consumer_t client_consumer;
	struct pk_client_data_stream_t *p_stream; /* Stream as requested by the client - on the
						     base entry only */
	struct pk_client_data_stream_t *p_mystream; /* To reference and not allocate more stream
						       objects */
	struct pk_pt_history_t *p_next; /* Chain into the next history consumer */
};

struct pk_pt_history_t *p_hist_list[PKTLOGGER_TYPE_MAX] = {NULL};

struct pk_struct_len {
	uint16_t struct_bsize;
	uint16_t struct_vsize;
};

struct pk_struct_len g_struct_len[PKTLOGGER_TYPE_MAX] = {{0,0}};

struct pk_client_data_stream_t *g_client_streams = NULL;

static struct pk_config_t g_pk_cfg = {
		.listen_fd = -1,
		.transpt_fd = -1,
		.netlink_ctrl_fd = -1,
		.netlink_data_fd = -1,
		.local_if_name = "",
		.remote_mac_addr = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF},
		.port = PKTLOGGER_D_NET_PORT
	};

/* FIXME: need to figure out how to make part of the config, or at least part of a function */
struct sockaddr_nl dest_addr;
struct iovec iov;

static void
pktlogger_close_fd(int *sock)
{
	if (*sock != -1) {
		close(*sock);
		*sock = -1;
	}
}

char *pktlogger_addr_ntoa(struct pk_addr_t addr) {
	if (addr.type == PKTLOGGER_D_ADDR_IN) {
		return inet_ntoa(addr.addr_in.sin_addr);
	} else if (addr.type == PKTLOGGER_D_ADDR_QL2T) {
		return ether_ntoa((struct ether_addr *)addr.addr_ql2t.remote_mac_addr);
	}

	return NULL;
}

int pktlogger_addr_equal(struct pk_addr_t addr1, struct pk_addr_t addr2)
{
	if (addr1.type != addr2.type)
		return 0;

	if ((addr1.type == PKTLOGGER_D_ADDR_IN) &&
			(addr1.addr_in.sin_addr.s_addr == addr2.addr_in.sin_addr.s_addr))
		return 1;

	if ((addr1.type == PKTLOGGER_D_ADDR_QL2T) &&
			!memcmp(&addr1.addr_ql2t, &addr2.addr_ql2t, sizeof(addr1.addr_ql2t)))
		return 1;

	return 0;
}

struct pktlogger_transpt_hdr_t
{
	struct sockaddr_in addr;	/* Address of the IP client */
};

struct pktlogger_transpt_pkt_t
{
	struct pktlogger_transpt_hdr_t hdr;
	uint8_t payload[0];
};

static void
pktlogger_transpt_send_daemon(void *p_msgbuf, size_t rxlen, struct pk_addr_t *p_src)
{
	uint16_t size = sizeof(struct pktlogger_transpt_hdr_t) + rxlen;
	uint8_t buf[size];
	struct pktlogger_transpt_pkt_t *p_pkt = (struct pktlogger_transpt_pkt_t *)buf;
	ql2t_send_cfg send_cfg;

	memcpy(send_cfg.remote_mac_addr, g_pk_cfg.remote_mac_addr, ETH_ALEN);
	send_cfg.remote_end_pt = QL2T_EP_PKTLOGGER;

	p_pkt->hdr.addr = p_src->addr_in; /* Send address of the IP client to daemon; will be sent
					     back by daemon to proxy to enable the proxy to respond
					     back to the IP client */
	memcpy(p_pkt->payload, p_msgbuf, rxlen);

	PKL_DPRINTF("send_daemon: Sending to %s\n",
		ether_ntoa((struct ether_addr *)send_cfg.remote_mac_addr));

	if (ql2t_send(g_pk_cfg.transpt_fd, &send_cfg, (char *)p_pkt, size) < 0) {
		PKL_EPRINTF("send_daemon: Failed to send over transpt_fd\n");
	}
}

static void
pktlogger_transpt_send_proxy(void *p_msgbuf, size_t rxlen, struct pk_addr_t *p_src)
{
	uint16_t size = sizeof(struct pktlogger_transpt_hdr_t) + rxlen;
	uint8_t buf[size];
	struct pktlogger_transpt_pkt_t *p_pkt = (struct pktlogger_transpt_pkt_t *)buf;

	p_pkt->hdr.addr = p_src->addr_in; /* Send back address of the IP client to proxy; will be
					     used by proxy to repond back to */
	memcpy(p_pkt->payload, p_msgbuf, rxlen);

	PKL_DPRINTF("send_proxy: Sending to %s\n",
		ether_ntoa((struct ether_addr *)p_src->addr_ql2t.remote_mac_addr));

	if (ql2t_send(g_pk_cfg.transpt_fd, &p_src->addr_ql2t, (char *)p_pkt, size) < 0) {
		PKL_EPRINTF("send_proxy: Failed to send over transpt_fd\n");
	}
}

/* Basic verification - ensure type value is in range. */
static int
pktlogger_type_valid(uint32_t type)
{
	if (type < PKTLOGGER_TYPE_MAX) {
		return 1;
	}
	return 0;
}

static void
pktlogger_rwidx_inc(struct pk_pt_history_t *p_base, uint32_t max_hist)
{
	uint32_t widx = p_base->widx;
	uint32_t ridx = p_base->ridx;
	widx++;
	if (widx >= max_hist) {
		widx = 0;
	}
	if (ridx == widx) {
		ridx = widx + 1;
		if (ridx >= max_hist) {
			ridx = 0;
		}
	}
	p_base->widx = widx;
	p_base->ridx = ridx;
	PKL_DPRINTF("upd: ridx %d, widx %d, max %d\n", p_base->ridx, p_base->widx, max_hist);
}

static void
pktlogger_ridx_inc(struct pk_pt_history_t *p_client, uint32_t max_hist)
{
	p_client->ridx++;
	if (p_client->ridx >= max_hist) {
		p_client->ridx = 0;
	}
}

static struct pk_pt_sample_t *
pktlogger_history_allocate_sample(size_t len)
{
	struct pk_pt_sample_t *p_sample;

	p_sample = calloc(1, sizeof(struct pk_pt_sample_t) - MEMBER_SIZE(struct pk_pt_sample_t, buf)
			+ len);
	if (p_sample) {
		p_sample->len = len;
	}

	return p_sample;
}

static void
pktlogger_history_free_sample(struct pk_pt_sample_t *p_sample)
{
	if (p_sample) {
		free(p_sample);
	}
}

/* Add a single sample (as received from the kernel) to the history buffer, and update various
 * client read/write indices as appropriate.
 */
static void
pktlogger_history_add_sample(struct pk_pt_history_t *p_base, const uint8_t *p_buf, uint32_t buf_len)
{
	struct pk_pt_hist_buffer_t *p_hist = p_base->p_histbuf;
	uint32_t widx = p_base->widx;
	uint32_t max_hist;
	struct pk_pt_history_t *p_client;
	int alloc_needed = 0;

	/* Check if a sample needs to be allocated or a previously allocated sample can be re-used */
	if (!p_hist->p_samples[widx]) {
		alloc_needed = 1;
	} else if (p_hist->p_samples[widx]->len < buf_len) {
		pktlogger_history_free_sample(p_hist->p_samples[widx]);
		p_hist->p_samples[widx] = NULL;
		alloc_needed = 1;
	}

	if (alloc_needed) {
		p_hist->p_samples[widx] = pktlogger_history_allocate_sample(buf_len);
		if (!p_hist->p_samples[widx]) {
			return;
		}
	}

	max_hist = p_hist->history_len;

	PKL_DPRINTF("Copied across %d bytes from %p to %p\n", buf_len, p_buf, p_hist->p_samples[widx]);
	memcpy(p_hist->p_samples[widx]->buf, p_buf, buf_len);

	pktlogger_rwidx_inc(p_base, max_hist);
	PKL_DPRINTF("base ridx %d, widx %d, max %d\n", p_base->ridx, p_base->widx, max_hist);

	if (p_hist->sample_count <= max_hist) {
		p_hist->sample_count++;
	}

	/* FIXME: chain into other clients and update their index */
	p_client = p_base->p_next;
	while (p_client) {
		PKL_DPRINTF("checking client %p for sample\n", p_client);
		pktlogger_rwidx_inc(p_client, p_client->p_histbuf->history_len);
		p_client = p_client->p_next;
	}
}

static struct pk_pt_history_t *
pktlogger_history_get_base(uint32_t type)
{
	if (pktlogger_type_valid(type)) {
		return p_hist_list[type];
	}
	return NULL;
}

static void
pktlogger_send_data_stream(uint8_t *p_buf, int buf_len, struct pk_client_data_stream_t *p_stream)
{
	struct pktlogger_net_history_stream_t *p_outmsg;
	struct pk_pt_history_t *p_hist = p_stream->p_hist;
	struct pk_client_consumer_t *p_cur_client = &p_stream->stream_consumer;
	int tot_len = sizeof(*p_outmsg) + buf_len;
	uint8_t *p_outbuf;

	PKL_DPRINTF("buf len %d, tot len %d\n", buf_len, tot_len);

	p_outmsg = (struct pktlogger_net_history_stream_t *)malloc(tot_len);
	if (!p_outmsg) {
		return;
	}
	/* Data is directly after the query response header */
	p_outbuf = (uint8_t *)&p_outmsg->stream.data[0];
	PKL_DPRINTF("Sending stream data to %s (nseq: %d, %d of %d) %p %p %p\n",
		pktlogger_addr_ntoa(p_cur_client->src), p_stream->net_mseq, p_stream->samplenum,
		p_stream->requested_samples, p_outmsg, p_outbuf, p_buf);
	/* Construct the required frame for the pktlogger client (struct pktlogger_net_query_t) */
	p_outmsg->hdr.magic = htonl(PKTLOGGER_NET_MAGIC);
	p_outmsg->hdr.version = htonl(0);
	p_outmsg->hdr.mlen = htonl(buf_len);
	p_outmsg->hdr.mtype = htonl(PKTLOGGER_MSG_DATA_STREAM);
	p_outmsg->hdr.mseq = htonl(p_stream->net_mseq);
	p_outmsg->stream.radio_index = htonl(0);
	p_outmsg->stream.type = htons((uint16_t)p_hist->type);
	p_outmsg->stream.totalcount = htons((uint16_t)p_hist->p_histbuf->history_len);
	p_outmsg->stream.samplenum = htons(p_stream->samplenum);
	p_outmsg->stream.requestedcount = htons(p_stream->requested_samples);
	/* Copy in the data from the buffer */
	memcpy(p_outbuf, p_buf, buf_len);

	/* Send back to the original transmitter - we saved this on the incoming network message. */
	if (p_cur_client->src.type == PKTLOGGER_D_ADDR_IN) {
		if ((sendto(g_pk_cfg.listen_fd, p_outmsg, tot_len, 0,
			(struct sockaddr *)&p_cur_client->src.addr_in,
			sizeof(p_cur_client->src.addr_in)) == -1) && g_pk_cfg.verbose) {
			perror("Error sending stream data to client");
		}
	} else {
		pktlogger_transpt_send_proxy(p_outmsg, tot_len, &p_cur_client->src);
	}
	free(p_outmsg);
}

static int
pktlogger_client_has_data(struct pk_pt_history_t *p_client, struct pk_pt_history_t *p_base)
{
	if (p_client->ridx != p_base->widx) {
		return 1;
	}
	return 0;
}

static struct pk_pt_sample_t *
pktlogger_sample_free(struct pk_pt_sample_t *p_sample)
{
	return p_sample;
}

static struct pk_pt_sample_t *
pktlogger_client_pull_buf(struct pk_pt_history_t *p_client, struct pk_pt_history_t *p_base)
{
	struct pk_pt_sample_t *p_sample = p_client->p_histbuf->p_samples[p_client->ridx];
	p_client->p_histbuf->p_samples[p_client->ridx] = pktlogger_sample_free(p_sample);
	pktlogger_ridx_inc(p_client, p_client->p_histbuf->history_len);
	return p_sample;
}

static struct pk_pt_sample_t *
pktlogger_hist_buf_remove_one(struct pk_pt_history_t *p_client)
{
	struct pk_pt_sample_t *p_sample = NULL;
	struct pk_pt_history_t *p_base = pktlogger_history_get_base(p_client->type);
	if (p_base && pktlogger_client_has_data(p_client, p_base)) {
		PKL_DPRINTF("Client %p has data (%d %d)\n", p_client, p_client->ridx, p_base->widx);
		p_sample = pktlogger_client_pull_buf(p_client, p_base);
	}
	return p_sample;
}

static int
pktlogger_history_flush_one(struct pk_client_data_stream_t *p_stream)
{
	struct pk_pt_sample_t *p_sample = pktlogger_hist_buf_remove_one(p_stream->p_hist);
	if (p_sample) {
		struct pktlogger_nl_pktlogger_hdr *p_hdr =
			(struct pktlogger_nl_pktlogger_hdr *)p_sample->buf;

		p_stream->samplenum++;
		if (p_stream->remaining) {
			p_stream->remaining--;
		}
		pktlogger_send_data_stream((uint8_t *)p_hdr, ntohs(p_hdr->hdr.len), p_stream);
		return 0;
	} else {
		PKL_DPRINTF("no more buffers for client %p - allow natural buffer buildup to "
			"occur\n", p_stream->p_hist);
	}
	return -1;
}

static void
pktlogger_stream_global_remove_client_ex(struct pk_client_data_stream_t *p_stream,
	struct pk_client_data_stream_t *p_pstream)
{
	if (p_pstream) {
		PKL_DPRINTF("Removing client from within linked list %p\n", p_stream);
		p_pstream->p_next = p_stream->p_next;
		p_stream->p_next = NULL;
		p_stream = p_pstream->p_next;
	} else {
		PKL_DPRINTF("Removing client from front %p\n", p_stream);
		g_client_streams = p_stream->p_next;
		p_stream->p_next = NULL;
	}
}

static void
pktlogger_stream_global_remove_client(struct pk_client_data_stream_t *p_stream)
{
	struct pk_client_data_stream_t *p_iter = g_client_streams;
	struct pk_client_data_stream_t *p_piter = NULL;
	while (p_iter) {
		PKL_DPRINTF("Checking client %p %p\n", p_iter, p_stream);
		if (p_iter == p_stream) {
			pktlogger_stream_global_remove_client_ex(p_iter, p_piter);
			PKL_DPRINTF("Removed...\n");
			return;
		}
		p_piter = p_iter;
		p_iter = p_iter->p_next;
	}
}

static void
pktlogger_stream_base_remove_client(struct pk_pt_history_t *p_type)
{
	struct pk_pt_history_t *p_base = pktlogger_history_get_base(p_type->type);
	struct pk_client_data_stream_t *p_match = p_type->p_mystream;
	struct pk_client_data_stream_t *p_iter;
	struct pk_client_data_stream_t *p_piter = NULL;
	if (!p_base) {
		return;
	}

	p_iter = p_base->p_stream;
	while (p_iter) {
		if (p_iter == p_match) {
			if (p_piter) {
				p_piter->p_tnext = p_match->p_tnext;
			} else {
				p_base->p_stream = p_match->p_tnext;
			}
			p_iter->p_tnext = NULL;
			return;
		}
		p_piter = p_iter;
		p_iter = p_iter->p_tnext;
	}
}

static void
pktlogger_history_del_client_stream(struct pk_pt_history_t *p_type)
{
	/* Remove the stream from existing lists, free it up */
	if (p_type->p_mystream) {
		pktlogger_stream_global_remove_client(p_type->p_mystream);
		pktlogger_stream_base_remove_client(p_type);
		free(p_type->p_mystream);
		p_type->p_mystream = NULL;
	}
}

static void
pktlogger_history_stream_data(struct pk_client_data_stream_t *p_client, uint32_t type)
{
	struct pk_client_data_stream_t *p_cur = p_client;
	PKL_DPRINTF("Stream check for client %p %d %d\n", p_cur, p_cur->remaining,
		p_cur->requested_samples);
	while (p_cur) {
		if (p_cur->remaining || p_cur->requested_samples == 0xFFFF) {
			int rv = pktlogger_history_flush_one(p_cur);
			if (rv != -1) {
				PKL_DPRINTF("DO stream for client %p %d %d\n", p_cur,
					p_cur->remaining, p_cur->requested_samples);
			} else {
				PKL_DPRINTF("Odd - streaming to client but no data (%p)\n", p_cur);
			}
		} else {
			pktlogger_history_del_client_stream(p_cur->p_hist);
		}
		p_cur = p_cur->p_tnext;
	}
}

static void
pktlogger_history_check_add_buf(const struct pktlogger_nl_pktlogger_hdr *p_hdr)
{
	uint16_t buf_len = ntohs(p_hdr->hdr.len);
	uint32_t stats_len = p_hdr->stats_len;
	uint8_t type = p_hdr->type;
	struct pk_pt_history_t *p_base;

	if (!pktlogger_type_valid(type)) {
		return;
	}
	p_base = pktlogger_history_get_base(type);
	PKL_DPRINTF("Type match for pktlogger data RX (%d)!\n", type);
	PKL_DPRINTF("Length of sample from config b:%d v:%d, Length of buffer %d (stats_len %d)\n",
		g_struct_len[type].struct_bsize,
		g_struct_len[type].struct_vsize,
		buf_len,
		stats_len);
	if (p_base) {
		/* Add sample to base, then update any other clients chained in */
		pktlogger_history_add_sample(p_base, (uint8_t *) p_hdr, buf_len);
		if (p_base->p_stream) {
			PKL_DPRINTF("Chaining into stream listeners\n");
			pktlogger_history_stream_data(p_base->p_stream, type);
		}
	}
}

static struct pk_pt_history_t *
pktlogger_history_get_first_client(uint32_t type)
{
	if (p_hist_list[type]) {
		return p_hist_list[type]->p_next;
	}
	return NULL;
}

static struct pk_pt_history_t *
pktlogger_history_deepcopy(struct pk_pt_history_t *p_in)
{
	return p_in;
}

static struct pk_pt_history_t *
pktlogger_history_get_client(uint32_t type, struct pk_addr_t *p_src)
{
	struct pk_pt_history_t *p_type = pktlogger_history_get_first_client(type);
	while (p_type) {
		PKL_DPRINTF("Checking client %p\n", p_type);
		if (pktlogger_addr_equal(p_type->client_consumer.src, *p_src)) {
			PKL_DPRINTF("Found client %p, returning\n", p_type);
			return p_type;
		}
		p_type = p_type->p_next;
	}
	return NULL;
}

static void
pktlogger_history_buf_put(struct pk_pt_history_t *p_client)
{
	if (p_client->p_histbuf) {
		PKL_DPRINTF("%p (%d) ref cnt %d\n", p_client->p_histbuf,
				p_client->type, p_client->p_histbuf->ref_cnt);
		p_client->p_histbuf->ref_cnt--;
		if (!p_client->p_histbuf->ref_cnt) {
			free(p_client->p_histbuf);
		}
	}
}

static void
pktlogger_history_del_client_buf(struct pk_pt_history_t *p_type)
{
	pktlogger_history_buf_put(p_type);
}

static void
pktlogger_history_del_client_list(uint32_t type, struct pk_pt_history_t *p_client)
{
	struct pk_pt_history_t *p_base = pktlogger_history_get_base(type);
	struct pk_pt_history_t *p_last = NULL;
	if (p_client == p_base) {
		return;
	}
	while (p_base) {
		if (p_base == p_client) {
			/* p_last will never be NULL, as the early return above guards. */
			p_last->p_next = p_base->p_next;
			p_base->p_next = NULL;
			return;
		}
		p_last = p_base;
		p_base = p_base->p_next;
	}
	/* Get to here, client not found. Error case. */
	PKL_DPRINTF("Client %p not found in list for type %d\n", p_client, type);
}

static void
pktlogger_history_add_client_list(uint32_t type, struct pk_pt_history_t *p_client)
{
	struct pk_pt_history_t *p_base = pktlogger_history_get_base(type);
	struct pk_pt_history_t *p_last = NULL;
	while (p_base) {
		p_last = p_base;
		p_base = p_base->p_next;
	}
	PKL_DPRINTF("Inserting client %p into type hist list %d\n", p_client, type);
	p_last->p_next = p_client;
}

static void
pktlogger_history_del_client(uint32_t type, struct pk_addr_t *p_src)
{
	struct pk_pt_history_t *p_type = pktlogger_history_get_client(type, p_src);
	if (p_type) {
		PKL_DPRINTF("Deleting client %s from type %d\n", pktlogger_addr_ntoa(*p_src), type);
		pktlogger_history_del_client_list(type, p_type);
		pktlogger_history_del_client_buf(p_type);
		pktlogger_history_del_client_stream(p_type);
		free(p_type);
	}
}

static void
pktlogger_history_set_base(uint32_t type, struct pk_pt_history_t *p_new)
{
	struct pk_pt_history_t *p_base = pktlogger_history_get_base(type);
	if (p_base) {
		PKL_DPRINTF("Error - history base already exists - ignoring\n");
		return;
	}
	p_hist_list[type] = p_new;
}

static struct pk_pt_hist_buffer_t *
pktlogger_history_get_resize_buffer(uint32_t type, uint32_t new_history_len)
{
	struct pk_pt_history_t *p_base = pktlogger_history_get_base(type);
	if (p_base) {
		struct pk_pt_hist_buffer_t *p_hist = p_base->p_histbuf;

		/* Need one extra entry to distinguish between an empty and full state */
		++new_history_len;

		if (p_hist->history_len < new_history_len) {
			uint32_t old_hist = p_hist->history_len;
			PKL_DPRINTF("Resizing history buffer from %u elts to %u elts\n",
				p_hist->history_len, new_history_len);
			p_hist->p_samples = (struct pk_pt_sample_t **)realloc(p_hist->p_samples,
				sizeof(struct pk_pt_sample_t *) * new_history_len);
			PKL_DPRINTF("New buf %p, len %zu, clearing new samples from %p\n",
				p_hist->p_samples, sizeof(struct pk_pt_sample_t *) * new_history_len,
				&p_hist->p_samples[old_hist]);
			memset(&p_hist->p_samples[old_hist], 0,
				(new_history_len - old_hist) * sizeof(struct pk_pt_sample_t *));
			p_hist->history_len = new_history_len;
		}
		return p_hist;
	}
	return NULL;
}

static struct pk_pt_history_t *
pktlogger_history_alloc_base(uint32_t type, uint32_t history_len)
{
	struct pk_pt_history_t *p_ret;

	/* Need one extra entry to differentiate between an empty and full state */
	++history_len;

	PKL_DPRINTF("About to allocate base; type %u, history_len %u\n", type, history_len);

	p_ret = (struct pk_pt_history_t *)calloc(1, sizeof(*p_ret));
	if (p_ret == NULL) {
		PKL_DPRINTF("Unable to allocate base; type %u\n", type);
		return NULL;
	}
	PKL_DPRINTF("Allocd base (%p); type %u\n", p_ret, type);
	p_ret->type = type;
	p_ret->p_histbuf = (struct pk_pt_hist_buffer_t *)calloc(1, sizeof(*p_ret->p_histbuf));
	/* Hist buffer shared object */
	if (p_ret->p_histbuf == NULL) {
		PKL_DPRINTF("Unable to allocate history buffer; type %u\n", type);
		free(p_ret);
		return NULL;
	}
	/* Initial ref count for the base object */
	p_ret->p_histbuf->ref_cnt = 1;
	PKL_DPRINTF("Allocd history buffer (%p); type %u\n", p_ret->p_histbuf, type);
	p_ret->p_histbuf->p_samples = (struct pk_pt_sample_t **)calloc(history_len,
						sizeof(struct pk_pt_sample_t *));
	if (p_ret->p_histbuf->p_samples == NULL) {
		PKL_DPRINTF("Unable to allocate %u samples; type %u\n", history_len, type);
		free(p_ret->p_histbuf);
		free(p_ret);
		return NULL;
	}
	p_ret->p_histbuf->history_len = history_len;
	PKL_DPRINTF("Allocd done\n");
	return p_ret;
}

static struct pk_pt_hist_buffer_t *
pktlogger_history_buf_get(uint32_t type, uint32_t reqd_len)
{
	struct pk_pt_hist_buffer_t *p_ret = pktlogger_history_get_resize_buffer(type, reqd_len);
	p_ret->ref_cnt++;
	return p_ret;
}

static void
pktlogger_history_base_init(uint32_t type, uint32_t hist_len)
{
	struct pk_pt_history_t *p_base;
	if (!hist_len) {
		PKL_DPRINTF("%s: hist_len cannot be 0\n", __func__);
		return;
	}

	p_base = pktlogger_history_alloc_base(type, hist_len);
	if (p_base == NULL) {
		return;
	}
	pktlogger_history_set_base(type, p_base);
}

static struct pk_pt_history_t *
pktlogger_history_add_client(uint32_t type, struct pk_addr_t *p_src, uint32_t hist_len)
{
	struct pk_pt_history_t *p_base;
	struct pk_pt_history_t *p_client_ret = pktlogger_history_get_client(type, p_src);
	if (!hist_len) {
		PKL_DPRINTF("%s: hist_len cannot be 0\n", __func__);
		return NULL;
	}


	if (p_client_ret) {
		/*
		 * Potentially resize the history buffer - don't increase the ref cnt, get the
		 * buffer directly
		 */
		p_client_ret->p_histbuf = pktlogger_history_get_resize_buffer(type, hist_len);
		return p_client_ret;
	}
	/* No such client - create it, and potentially the history buffer itself */
	p_base = pktlogger_history_get_base(type);
	if (p_base == NULL) {
		pktlogger_history_base_init(type, hist_len);
		p_base = pktlogger_history_get_base(type);
		if (p_base == NULL) {
			return NULL;
		}
	}
	p_client_ret = (struct pk_pt_history_t *)calloc(1, sizeof(*p_client_ret));
	if (p_client_ret == NULL) {
		PKL_DPRINTF("Unable to allocate client\n");
		return NULL;
	}
	PKL_DPRINTF("Allocating client %p for hist len %d\n", p_client_ret, hist_len);
	p_client_ret->type = type;
	p_client_ret->client_consumer.src = *p_src;
	p_client_ret->p_next = NULL;
	p_client_ret->p_histbuf = pktlogger_history_buf_get(type, hist_len);
	/* Set current read/write indices to the current sample in the history buffer */
	p_client_ret->widx = p_base->widx;
	p_client_ret->ridx = p_client_ret->widx;
	pktlogger_history_add_client_list(type, p_client_ret);
	return p_client_ret;
}

/*
 * Free up the netlink message after receive from the kernel (uses same buffer as sent to the
 * kernel)
 */
static void pktlogger_nl_msg_free(struct msghdr *p_msg)
{
	struct nlmsghdr *nlh;
	struct iovec *iov = p_msg->msg_iov;
	nlh = (struct nlmsghdr *)iov->iov_base;
	if (nlh) {
		free(nlh);
	}
}

/* Allocate and initialise a netlink buffer. Dual function to free is 'pktlogger_nl_msg_free' */
static void pktlogger_nl_msg_create(void *inmsg, int msglen, struct msghdr *p_msg)
{
	struct nlmsghdr *nlh;

	memset(&dest_addr, 0, sizeof(dest_addr));
	dest_addr.nl_family = AF_NETLINK;
	dest_addr.nl_pid = 0;
	dest_addr.nl_groups = 0;

	nlh = calloc(1, NLMSG_SPACE(msglen));
	if (nlh == NULL) {
		return;
	}

	if (inmsg) {
		memcpy(NLMSG_DATA(nlh), inmsg, msglen);
	}
	nlh->nlmsg_pid = g_pk_cfg.nlmsg_pid;
	nlh->nlmsg_len = NLMSG_SPACE(msglen);
#define QDRV_NETDEBUG_TYPE_PKTLOGGER 100
	nlh->nlmsg_type = QDRV_NETDEBUG_TYPE_PKTLOGGER;
	iov.iov_base = (void *)nlh;
	iov.iov_len = nlh->nlmsg_len;

	memset(p_msg, 0, sizeof(*p_msg));
	p_msg->msg_name = &dest_addr;
	p_msg->msg_namelen = sizeof(struct sockaddr_nl);
	p_msg->msg_iov = &iov;
	p_msg->msg_iovlen = 1;
}

static void pktlogger_d_cleanup(void)
{
	pktlogger_close_fd(&g_pk_cfg.netlink_data_fd);
	pktlogger_close_fd(&g_pk_cfg.netlink_ctrl_fd);
	if (g_pk_cfg.transpt_fd != -1) {
		ql2t_close(g_pk_cfg.transpt_fd);
		g_pk_cfg.transpt_fd = -1;
	}
	pktlogger_close_fd(&g_pk_cfg.listen_fd);
}

static int pktlogger_d_init(void)
{
	struct sockaddr_in listen_addr;
	struct sockaddr_nl src_addr;

	/* Listen fd for UDP data from the network */
	g_pk_cfg.listen_fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (g_pk_cfg.listen_fd < 0) {
		perror("failed to create listen socket");
		return -1;
	}

	memset(&listen_addr, 0, sizeof(listen_addr));
	listen_addr.sin_family = AF_INET;
	if (g_pk_cfg.en_remote_host)
		listen_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	else
		listen_addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
	listen_addr.sin_port = htons(g_pk_cfg.port);
	/* Bind to all interfaces, port as per the config structure */
	if (bind(g_pk_cfg.listen_fd, (struct sockaddr *)&listen_addr,
			sizeof(listen_addr)) < 0) {
		perror("cannot bind listen socket");
		pktlogger_d_cleanup();
		return -1;
	}

	/* If local_if_name has not been configured */
	if (g_pk_cfg.local_if_name[0] != '\0') {
		/* Transport fd for data between pktlogger_d and pktlogger_d_p */
		g_pk_cfg.transpt_fd = ql2t_open(g_pk_cfg.local_if_name, QL2T_EP_PKTLOGGER);
		if (g_pk_cfg.transpt_fd < 0) {
			perror("failed to create transpt socket");
			pktlogger_d_cleanup();
			return -1;
		}
	}

	/* Other fd's are not needed for pktlogger_d_p */
	if (g_pk_cfg.proxy)
		return 0;

	g_pk_cfg.nlmsg_pid = getpid();
	g_pk_cfg.pkdata_pid = 12345;

/* FIXME: this needs to go into a common and isolated header */
#define QDRV_NETLINK_PKTLOGGER 30
	/* Netlink FD for kernel messages for pktlogger config and control */
	g_pk_cfg.netlink_ctrl_fd = socket(PF_NETLINK, SOCK_RAW, QDRV_NETLINK_PKTLOGGER);
	if (g_pk_cfg.netlink_ctrl_fd < 0) {
		perror("failed to create netlink socket");
		pktlogger_d_cleanup();
		return -1;
	}

	memset(&src_addr, 0, sizeof(src_addr));
	src_addr.nl_family = AF_NETLINK;
	src_addr.nl_pid = g_pk_cfg.nlmsg_pid;

	if (bind(g_pk_cfg.netlink_ctrl_fd, (struct sockaddr *)&src_addr,
			sizeof(src_addr)) < 0) {
		perror("cannot bind netlink socket");
		pktlogger_d_cleanup();
		return -1;
	}

	/* Netlink FD for kernel messages for pktlogger config and control */
	g_pk_cfg.netlink_data_fd = socket(PF_NETLINK, SOCK_RAW, QDRV_NETLINK_PKTLOGGER);
	if (g_pk_cfg.netlink_data_fd < 0) {
		perror("failed to create netlink socket");
		pktlogger_d_cleanup();
		return -1;
	}

	memset(&src_addr, 0, sizeof(src_addr));
	src_addr.nl_family = AF_NETLINK;
	src_addr.nl_pid = g_pk_cfg.pkdata_pid;

	if (bind(g_pk_cfg.netlink_data_fd, (struct sockaddr *)&src_addr,
			sizeof(src_addr)) < 0) {
		perror("cannot bind netlink socket");
		pktlogger_d_cleanup();
		return -1;
	}

	return 0;
}

static void pktlogger_nl_hdr_init(struct pktlogger_nl_hdr_t *p_hdr, uint32_t mtype)
{
#define PKL_SEQ_NL	10
	static uint32_t s_seq = PKL_SEQ_NL;

	p_hdr->magic = PKTLOGGER_MSG_MAGIC;
	p_hdr->mver = 0;
	p_hdr->mtype = mtype;
	p_hdr->mseq = s_seq++;
}

static void pktlogger_nl_msg_send(struct msghdr *p_msg)
{
	int ret;
	ret = sendmsg(g_pk_cfg.netlink_ctrl_fd, p_msg, 0);
	if (ret == -1 && g_pk_cfg.verbose) {
		perror("Error sending netlink message to driver");
	}
}

/* Query into the kernelspace via netlink */
/* Returns a unique sequence number to correlate requests/responses */
static int
pktlogger_nl_query_driver(int query_num, uint32_t arg1, uint32_t arg2)
{
	struct pktlogger_nl_query_t query;
	struct msghdr msg;
	int mseq;
	memset(&query, 0, sizeof(query));
	pktlogger_nl_hdr_init(&query.hdr, PKTLOGGER_NETLINK_MTYPE_QUERY);
	query.query_num = query_num;
	query.arg1 = arg1;
	query.arg2 = arg2;
	query.hdr.mlen = sizeof(query);
	pktlogger_nl_msg_create(&query, sizeof(query), &msg);
	mseq = query.hdr.mseq;
	pktlogger_nl_msg_send(&msg);
	pktlogger_nl_msg_free(&msg);
	return mseq;
}

static void
pktlogger_d_get_config(void)
{

	if (g_pk_cfg.proxy) {
		/* TODO: Do we need to do this in proxy? */
		return;
	}

	/* Send netlink query to figure out the structures to return */
	pktlogger_nl_query_driver(PKTLOGGER_QUERY_CONFIG, 0, 0);
	/* The regular main loop will pick up the config */
}

static int
pktlogger_nl_set_config_one_driver(uint8_t *p_msgbuf, size_t rxlen)
{
	struct pktlogger_nl_config_oneset_t config;
	struct msghdr msg;
	int mseq = -1;
	if (rxlen >= sizeof(config.config)) {
		pktlogger_nl_hdr_init(&config.hdr, PKTLOGGER_NETLINK_MTYPE_CONFIG_ONE);
		PKL_DPRINTF("Copying across %zu bytes of incoming netconfig\n", rxlen);
		memcpy(&config.config, p_msgbuf, sizeof(config.config));
		config.hdr.mlen = rxlen;
		mseq = config.hdr.mseq;
		pktlogger_nl_msg_create(&config, sizeof(config), &msg);
		pktlogger_nl_msg_send(&msg);
		pktlogger_nl_msg_free(&msg);
	} else {
		PKL_DPRINTF("Size of incoming config structure wrong - needs to be at least %zu "
			"bytes, is %zu bytes\n", sizeof(config.config), rxlen);
	}
	return mseq;
}

static int
pktlogger_nl_set_config_driver(uint8_t *p_msgbuf, size_t rxlen)
{
	struct pktlogger_nl_config_set_t config;
	struct msghdr msg;
	int mseq = -1;
	if (rxlen >= sizeof(config.config)) {
		pktlogger_nl_hdr_init(&config.hdr, PKTLOGGER_NETLINK_MTYPE_CONFIG);
		PKL_DPRINTF("Copying across %zu bytes of incoming netconfig\n",
			sizeof(config.config));
		memcpy(&config.config, p_msgbuf, sizeof(config.config));
		config.hdr.mlen = rxlen;
		mseq = config.hdr.mseq;
		pktlogger_nl_msg_create(&config, sizeof(config), &msg);
		pktlogger_nl_msg_send(&msg);
		pktlogger_nl_msg_free(&msg);
	} else {
		PKL_DPRINTF("Size of incoming config structure wrong - needs to be at least %zu "
			"bytes, is %zu bytes\n", sizeof(config.config), rxlen);
	}
	return mseq;
}

static int client_balance = 0;

/* Save the client dest addr for reply later */
static void
pktlogger_save_client(struct pk_addr_t *p_src, uint32_t net_mseq, uint32_t rsp_mseq)
{
	/* For now don't maintain linked list - allow the request to come in a second time */
	struct pk_client_response_t *p_resp = calloc(1, sizeof(*p_resp));
	int check_cnt;
	struct pk_client_response_t *p_check;

	client_balance++;
	if (client_balance > 10) {
		PKL_EPRINTF("Client balance increasing... %d\n", client_balance);
	}

	if (!p_resp) {
		return;
	}

	p_resp->src = *p_src;
	p_resp->net_mseq = net_mseq;
	p_resp->rsp_mseq = rsp_mseq;

	if (g_pk_cfg.p_response_list) {
		PKL_DPRINTF("Chained responses %s (net mseq: %d, rsp mseq: %d)\n",
			pktlogger_addr_ntoa(p_resp->src), net_mseq, rsp_mseq);
		p_resp->next = g_pk_cfg.p_response_list;
	}
	PKL_DPRINTF("Saving response for client %s (net mseq: %d, rsp mseq: %d)\n",
		pktlogger_addr_ntoa(p_resp->src), net_mseq, rsp_mseq);
	g_pk_cfg.p_response_list = p_resp;


	/* Check the list isn't too long */
	if (client_balance <= 10) {
		return;
	}

	check_cnt = 0;
	p_check = g_pk_cfg.p_response_list;
	while (p_check) {
		p_check = p_check->next;
		check_cnt++;
		if (check_cnt > 10 && p_check) {
			/* Free all subsequent elements - too many queued */
			struct pk_client_response_t *p_check_free = p_check->next;
			p_check->next = NULL;
			/* Free up all other clients on the list */
			while (p_check_free) {
				p_check = p_check_free->next;
				PKL_DPRINTF("Freeing response %p\n", p_check_free);
				free(p_check_free);
				client_balance--;
				p_check_free = p_check;
			}
			break;
		}
	}
}

static void
pktlogger_hton_pktlog_config(struct pktlogger_nl_pktlog_config_t *p_conf)
{
	p_conf->type = htons(p_conf->type);
	p_conf->flags = htons(p_conf->flags);
	p_conf->rate = htonl(p_conf->rate);
	p_conf->history = htonl(p_conf->history);
	p_conf->struct_bsize = htons(p_conf->struct_bsize);
	p_conf->struct_vsize = htons(p_conf->struct_vsize);
}

static void
pktlogger_ntoh_pktlog_config(struct pktlogger_pktlog_config_t *p_conf)
{
	p_conf->type = ntohs(p_conf->type);
	p_conf->flags = ntohs(p_conf->flags);
	p_conf->rate = ntohl(p_conf->rate);
	p_conf->history = ntohl(p_conf->history);
	p_conf->struct_bsize = ntohs(p_conf->struct_bsize);
	p_conf->struct_vsize = ntohs(p_conf->struct_vsize);
}

static void
pktlogger_hton_config_one(uint8_t *p_resp, int resp_len)
{
	struct pktlogger_nl_config_one_t *p_nl_conf = (struct pktlogger_nl_config_one_t *)p_resp;
	struct pktlogger_nl_pktlog_config_t *p_conf;
	if (resp_len < sizeof(*p_nl_conf)) {
		PKL_DPRINTF("Ignoring undersized return value %d (exp: %zu)\n", resp_len,
			sizeof(*p_nl_conf));
		return;
	}
	p_nl_conf->radio_index = htonl(p_nl_conf->radio_index);
	p_conf = &p_nl_conf->config;
	pktlogger_hton_pktlog_config(p_conf);
}

static void
pktlogger_ntoh_config_one(uint8_t *p_c, int conf_len)
{
	struct pktlogger_net_config_one_t *p_conf = (struct pktlogger_net_config_one_t *)p_c;
	struct pktlogger_config_one_t *p_cconf = (struct pktlogger_config_one_t *)&p_conf->config;
	struct pktlogger_pktlog_config_t *p_pconf;
	if (conf_len < sizeof(*p_conf)) {
		PKL_DPRINTF("Ignoring undersized return value %d (exp: %zu)\n", conf_len,
			sizeof(*p_conf));
		return;
	}
	p_cconf->radio_index = ntohl(p_cconf->radio_index);
	p_pconf = &p_cconf->config;
	pktlogger_ntoh_pktlog_config(p_pconf);
}

static void
pktlogger_hton_one_radio(struct pktlogger_nl_radio_config_t *p_radio)
{
	int i;
	/* ONLY convert host endian - IP and UDP port are already net endian */
	p_radio->pktlog_ver_cnt = htonl(p_radio->pktlog_ver_cnt);
	for (i = 0; i < ARRAY_COUNT(p_radio->pktlog_configs); i++) {
		pktlogger_hton_pktlog_config(&p_radio->pktlog_configs[i]);
	}
}

static void
pktlogger_ntoh_one_radio(struct pktlogger_radio_config_t *p_radio)
{
	int i;
	/* ONLY convert host endian - IP and UDP port are already net endian */
	p_radio->pktlog_ver_cnt = ntohl(p_radio->pktlog_ver_cnt);
	for (i = 0; i < ARRAY_COUNT(p_radio->pktlog_configs); i++) {
		pktlogger_ntoh_pktlog_config(&p_radio->pktlog_configs[i]);
	}
}

static void
pktlogger_hton_config(uint8_t *p_resp, int resp_len)
{
	struct pktlogger_nl_config_t *p_conf = (struct pktlogger_nl_config_t *)p_resp;
	int count = 0;
	uint32_t rcontrol = p_conf->rcontrol;
	if (resp_len < sizeof(*p_conf)) {
		PKL_DPRINTF("Ignoring undersized return value %d (exp: %zu)\n", resp_len,
			sizeof(*p_conf));
		return;
	}
	p_conf->rev = htonl(p_conf->rev);
	p_conf->rcontrol = htonl(p_conf->rcontrol);
	while (rcontrol && count < 3) {
		struct pktlogger_nl_radio_config_t *p_radio = &p_conf->per_radio[count];
		pktlogger_hton_one_radio(p_radio);
		rcontrol >>= 1;
		count++;
	}
}

static void
pktlogger_ntoh_stream_req(uint8_t *p_msg, int req_len)
{
	struct pktlogger_net_history_stream_request_t *p_req =
		(struct pktlogger_net_history_stream_request_t *)p_msg;
	p_req->request.radio_index = ntohl(p_req->request.radio_index);
	p_req->request.type = ntohs(p_req->request.type);
	p_req->request.requestedcount = ntohs(p_req->request.requestedcount);
	p_req->request.flags = ntohl(p_req->request.flags);
}

static void
pktlogger_ntoh_config(uint8_t *p_resp, int resp_len)
{
	struct pktlogger_net_config_t *p_nconf = (struct pktlogger_net_config_t *)p_resp;
	struct pktlogger_config_t *p_conf = (struct pktlogger_config_t *)&p_nconf->config;
	int count = 0;
	uint32_t radio_mask;
	if (resp_len < sizeof(*p_conf)) {
		PKL_DPRINTF("Ignoring undersized return value %d (exp: %zu)\n", resp_len,
			sizeof(*p_conf));
		return;
	}
	p_conf->radio_mask = ntohl(p_conf->radio_mask);
	radio_mask = p_conf->radio_mask;
	p_conf->rev = ntohl(p_conf->rev);
	while (radio_mask && count < 3) {
		if (radio_mask & 0x1) {
			struct pktlogger_radio_config_t *p_radio = &p_conf->per_radio[count];
			pktlogger_ntoh_one_radio(p_radio);
			PKL_DPRINTF("Flipping radio %d\n", count);
		}
		radio_mask >>= 1;
		count++;
	}
}

static void
pktlogger_ntoh_config_onerequest(uint8_t *p_msg, int len)
{
	struct pktlogger_net_query_one_t *p_req = (struct pktlogger_net_query_one_t *)p_msg;
	p_req->radio_index = ntohl(p_req->radio_index);
	p_req->type = ntohl(p_req->type);
}

static void
pktlogger_hton(uint8_t *p_resp, int resp_len, int net_mtype)
{
	if (g_pk_cfg.proxy) {
		return;
	}

	switch(net_mtype) {
		case PKTLOGGER_MSG_CONFIG_RESPONSE:
		{
			pktlogger_hton_config(p_resp, resp_len);
			break;
		}
		case PKTLOGGER_MSG_CONFIG_ONERESPONSE:
		{
			pktlogger_hton_config_one(p_resp, resp_len);
			break;
		}
		case PKTLOGGER_MSG_STRUCT_RESPONSE:
		default:
			break;
	}
}

static void
pktlogger_ntoh(uint8_t *p_req, int req_len, int net_mtype)
{
	if (g_pk_cfg.proxy) {
		return;
	}

	switch(net_mtype) {
		case PKTLOGGER_MSG_CONFIG_ONEREQUEST:
		{
			pktlogger_ntoh_config_onerequest(p_req, req_len);
			break;
		}
		case PKTLOGGER_MSG_CONFIG_SET:
		{
			pktlogger_ntoh_config(p_req, req_len);
			break;
		}
		case PKTLOGGER_MSG_CONFIG_ONESET:
		{
			pktlogger_ntoh_config_one(p_req, req_len);
			break;
		}
		case PKTLOGGER_MSG_DATA_STREAM_REQUEST:
		{
			pktlogger_ntoh_stream_req(p_req, req_len);
			break;
		}
		case PKTLOGGER_MSG_STRUCT_REQUEST:
		case PKTLOGGER_MSG_CONFIG_REQUEST:
		default:
			break;
	}
}

static void
pktlogger_send_common(uint8_t *p_resp, int resp_len, uint32_t rsp_mseq, uint32_t net_mtype)
{
	/* Iterate through all clients for this message type */
	struct pk_client_response_t *p_cur_client = g_pk_cfg.p_response_list;
	struct pk_client_response_t *p_prev_client = NULL;

	PKL_DPRINTF("Chaining into saved clients (rsp mseq: %d, net mtype: %d)\n", rsp_mseq,
		net_mtype);

	pktlogger_hton(p_resp, resp_len, net_mtype);

	while (p_cur_client != NULL) {
		struct pktlogger_net_query_t *p_query;
		int query_len = sizeof(*p_query) + resp_len;

		PKL_DPRINTF("Checking client %p, rsp mseq: %d\n", p_cur_client,
			p_cur_client->rsp_mseq);

		if (p_cur_client->rsp_mseq == rsp_mseq) {
			/*
			 * Send back to the original transmitter - we saved this on the incoming
			 * network message.
			 */
			p_query = (struct pktlogger_net_query_t *)malloc(sizeof(*p_query) +
				resp_len);
			if (p_query) {
				/* Data is directly after the query response header */
				uint8_t *p_data = (uint8_t *)p_query + sizeof(*p_query);

				PKL_DPRINTF("Sending response to %s (rsp seq: %d, net seq: %d)\n",
					pktlogger_addr_ntoa(p_cur_client->src), rsp_mseq,
					p_cur_client->net_mseq);
				/*
				 * Construct the required frame for the pktlogger client (struct
				 * pktlogger_net_query_t)
				 */
				p_query->hdr.magic = htonl(PKTLOGGER_NET_MAGIC);
				p_query->hdr.version = htonl(0);
				p_query->hdr.mlen = htonl(resp_len);
				p_query->hdr.mtype = htonl(net_mtype);
				p_query->hdr.mseq = htonl(p_cur_client->net_mseq);
				/* Copy in the data from the kernel */
				memcpy(p_data, p_resp, resp_len);

				if (p_cur_client->src.type == PKTLOGGER_D_ADDR_IN) {
					if ((sendto(g_pk_cfg.listen_fd, p_query, query_len, 0,
						(struct sockaddr *)&p_cur_client->src.addr_in,
						sizeof(p_cur_client->src.addr_in)) == -1) &&
						g_pk_cfg.verbose) {
						perror("Error sending response to client");
					}
				} else {
					pktlogger_transpt_send_proxy(p_query, query_len,
						&p_cur_client->src);
				}
				free(p_query);
			}
			/* Unlink this client */
			if (p_prev_client) {
				p_prev_client->next = p_cur_client->next;
			} else {
				/* Modify the head entry as first time through the while loop */
				g_pk_cfg.p_response_list = p_cur_client->next;
			}
			/* Return memory allocated on initial message received from the network. */
			client_balance--;
			free(p_cur_client);
			/*
			 * Leave the remaining clients in the list to be iterated over again for
			 * subsequent messages
			 */
			return;
		}
		p_prev_client = p_cur_client;
		p_cur_client = p_cur_client->next;
	}
}

static void
pktlogger_d_process_struct_req_msg(uint8_t *p_msgbuf, size_t rxlen, struct pk_addr_t *p_src,
	uint32_t net_mseq)
{
	int mseq;

	if (g_pk_cfg.proxy) {
		/* Send the message over L2 transport */
		pktlogger_transpt_send_daemon(p_msgbuf, rxlen, p_src);
		return;
	}

	/* Send netlink query to figure out the structures to return */
	mseq = pktlogger_nl_query_driver(PKTLOGGER_QUERY_STRUCT, 0, 0);

	/* Save the client into a linked list of clients which will be responded to */
	pktlogger_save_client(p_src, net_mseq, mseq);
}

static void
pktlogger_d_process_config_req_msg(uint8_t *p_msgbuf, size_t rxlen, struct pk_addr_t *p_src,
	uint32_t net_mseq)
{
	int mseq;

	if (g_pk_cfg.proxy) {
		/* Send the message over L2 transport */
		pktlogger_transpt_send_daemon(p_msgbuf, rxlen, p_src);
		return;
	}

	/* Send netlink query to figure out the structures to return */
	mseq = pktlogger_nl_query_driver(PKTLOGGER_QUERY_CONFIG, 0, 0);

	/* Save the client into a linked list of clients which will be responded to */
	pktlogger_save_client(p_src, net_mseq, mseq);
}

static void
pktlogger_set_config_one_history(uint32_t type, struct pk_addr_t *p_src, uint32_t history)
{
	if (history) {
		if (history > PKTLOGGER_MAX_HISTORY_ENTRIES_PER_TYPE) {
			PKL_DPRINTF("History (%d entries) for ptype %d is too long - ignoring\n",
				history, type);
			return;
		}
		PKL_DPRINTF("Configuring history for ptype %d to %d entries\n", type, history);
		pktlogger_history_add_client(type, p_src, history);
	} else {
		pktlogger_history_del_client(type, p_src);
	}
}

static void
pktlogger_d_process_config_set_msg(uint8_t *p_msgbuf, size_t rxlen, struct pk_addr_t *p_src,
                                   uint32_t net_mseq)
{
	uint32_t radio_mask;
	uint32_t history;
	int count = 0;
	int i;

	if (g_pk_cfg.proxy) {
		/* Send the message over L2 transport */
		pktlogger_transpt_send_daemon(p_msgbuf, rxlen, p_src);
		return;
	}

	struct pktlogger_net_config_t *p_net_config = (struct pktlogger_net_config_t *)p_msgbuf;
	radio_mask = p_net_config->config.radio_mask;
	while (radio_mask && count < 3) {
		struct pktlogger_radio_config_t *p_radio = &p_net_config->config.per_radio[count];
		int num_entries = p_radio->pktlog_ver_cnt & 0xFF;
		if (num_entries > ARRAY_COUNT(p_radio->pktlog_configs)) {
			PKL_EPRINTF("Invalid input - too many radio configs (%d)\n", num_entries);
			return;
		}
		for (i = 0; i < ARRAY_COUNT(p_radio->pktlog_configs); i++) {
			struct pktlogger_pktlog_config_t *pconf = &p_radio->pktlog_configs[i];
			/* If history is configured, set up buffers etc. */
			history = pconf->history;
			if (!history && (pconf->flags & PKTLOGGER_CONFIG_FLAGS_ENABLED)) {
				/* Enable history of at least 1 entry when a type is enabled */
				history = 1;
				pconf->history = 1;
			}
			pktlogger_set_config_one_history(pconf->type, p_src, history);
		}

		radio_mask >>= 1;
		count++;
	}
	pktlogger_nl_set_config_driver((uint8_t *)&p_net_config->config, rxlen);
}

static void
pktlogger_d_process_config_oneset_msg(uint8_t *p_msgbuf, size_t rxlen, struct pk_addr_t *p_src,
                                      uint32_t net_mseq)
{
	if (g_pk_cfg.proxy) {
		/* Send the message over L2 transport */
		pktlogger_transpt_send_daemon(p_msgbuf, rxlen, p_src);
		return;
	}

	struct pktlogger_net_config_one_t *p_config = (struct pktlogger_net_config_one_t *)p_msgbuf;

	/* If history is configured, set up buffers etc. */
	uint32_t history = p_config->config.config.history;
	if (!history && (p_config->config.config.flags & PKTLOGGER_CONFIG_FLAGS_ENABLED)) {
		/* Enable history of atleast 1 entry when a type is enabled */
		history = 1;
		p_config->config.config.history = 1;
	}
	pktlogger_nl_set_config_one_driver((uint8_t *)&p_config->config, rxlen);
	pktlogger_set_config_one_history(p_config->config.config.type, p_src, history);
}

static const uint32_t max_mtype = PKTLOGGER_MSG_MAX_TYPE;

static void
pktlogger_d_process_config_onereq_msg(uint8_t *p_msgbuf, size_t rxlen, struct pk_addr_t *p_src,
	uint32_t net_mseq)
{
	int mseq;
	struct pktlogger_net_query_one_t *p_query = (struct pktlogger_net_query_one_t *)p_msgbuf;
	uint32_t radio;
	uint32_t ptype;

	if (g_pk_cfg.proxy) {
		/* Send the message over L2 transport */
		pktlogger_transpt_send_daemon(p_msgbuf, rxlen, p_src);
		return;
	}

	if (rxlen < sizeof(*p_query)) {
		return;
	}

	radio = p_query->radio_index;
	if (radio > 2) {
		PKL_DPRINTF("Invalid radio index %d\n", radio);
		return;
	}

	ptype = p_query->type;
	if (!pktlogger_type_valid(ptype)) {
		PKL_DPRINTF("Invalid pktlogger type %d\n", ptype);
		return;
	}

	/* Send netlink query to figure out the structures to return */
	mseq = pktlogger_nl_query_driver(PKTLOGGER_QUERY_CONFIG_ONE, radio, ptype);

	/* Save the client into a linked list of clients which will be responded to */
	pktlogger_save_client(p_src, net_mseq, mseq);
}

static void
pktlogger_stream_add_client(uint32_t type, struct pk_client_data_stream_t *p_client_stream)
{
	struct pk_pt_history_t *p_base = pktlogger_history_get_base(type);
	struct pk_client_data_stream_t *p_cur;
	struct pk_client_data_stream_t *p_prev = NULL;
	if (!p_base) {
		return;
	}
	p_cur = p_base->p_stream;
	PKL_DPRINTF("Adding new client stream to base %p\n", p_base);
	while (p_cur) {
		/* Make sure to not re-add to the linked list if already present */
		if (p_cur == p_client_stream) {
			PKL_DPRINTF("Not re-adding already in type list (%p)\n", p_client_stream);
			break;
		}
		p_prev = p_cur;
		p_cur = p_cur->p_tnext;
	}
	/* Only add if not already part of the list */
	if (p_cur != p_client_stream) {
		if (p_prev) {
			p_prev->p_tnext = p_client_stream;
		} else {
			p_base->p_stream = p_client_stream;
		}
	}

	/* Add to global list */
	p_cur = g_client_streams;
	p_prev = NULL;
	while (p_cur) {
		if (p_cur == p_client_stream) {
			PKL_DPRINTF("Not re-adding already in global list (%p)\n", p_client_stream);
			break;
		}
		p_prev = p_cur;
		p_cur = p_cur->p_next;
	}

	if (p_cur != p_client_stream) {
		if (p_prev) {
			PKL_DPRINTF("Added client %p to global list\n", p_client_stream);
			p_prev->p_next = p_client_stream;
		} else {
			PKL_DPRINTF("Added as first global %p\n", p_client_stream);
			g_client_streams = p_client_stream;
		}
	}

	/* Arm the timer - drain any queues, then do real-time monitoring per client */
	g_pk_cfg.arm_timer = 1;
}

static void
pktlogger_d_process_stream_request(uint8_t *p_msgbuf, size_t rxlen, struct pk_addr_t *p_src,
	uint32_t net_mseq)
{
	struct pk_client_data_stream_t *p_client_stream;
	struct pk_pt_history_t *p_hist;
	struct pk_pt_history_t *p_base;
	uint32_t reqcount;
	uint32_t type;
	uint32_t radio_index;
	struct pktlogger_net_history_stream_request_t *p_req =
		(struct pktlogger_net_history_stream_request_t *)p_msgbuf;

	if (g_pk_cfg.proxy) {
		/* Send the message over L2 transport */
		pktlogger_transpt_send_daemon(p_msgbuf, rxlen, p_src);
		return;
	}

	if (sizeof(*p_req) > rxlen) {
		PKL_DPRINTF("Incoming stream request structure too small - exp: %zu, got: %zu\n",
			sizeof(*p_req), rxlen);
		return;
	}

	type = p_req->request.type;
	if (!pktlogger_type_valid(type)) {
		PKL_DPRINTF("Incoming stream request structure invalid type:%d\n", type);
		return;
	}

	reqcount = p_req->request.requestedcount;
	radio_index = p_req->request.radio_index;

	p_base = pktlogger_history_get_base(type);
	if (!p_base) {
		PKL_DPRINTF("Ignoring stream request for not enabled pktlogger %d\n", type);
		return;
	}
	p_hist = pktlogger_history_get_client(type, p_src);
	if (!p_hist) {
		uint32_t history = p_base->p_histbuf->history_len;
		--history; /* Remove the prev allocated 1 extra entry to get the actual size */
		PKL_DPRINTF("Unsure as to what the client wants - defaulting to base history size "
			"(%d)\n", history);
		p_hist = pktlogger_history_add_client(type, p_src, history);
	}
	PKL_DPRINTF("Stream request coming in (req: %d, radio: %d type: %d), client %p\n", reqcount,
		radio_index, type, p_hist);
#if 0
	/* FIXME: This code will restrict the requests to reasonable values, but for now allow requests up to 2^16 samples, which drain in real time */
	if (reqcount > p_base->p_histbuf->history_len) {
		PKL_DPRINTF("Requested more samples than history (%d vs %d) - restricting to history len\n", reqcount, p_base->p_histbuf->history_len);
		reqcount = p_base->p_histbuf->history_len;
	}
	if (reqcount > p_base->p_histbuf->sample_count) {
		PKL_DPRINTF("Requested more samples than current history (%d vs %d) - restricting to current sample count\n", reqcount, p_base->p_histbuf->sample_count);
		reqcount = p_base->p_histbuf->sample_count;
	}
#endif
	if (p_hist->p_mystream) {
		p_client_stream = p_hist->p_mystream;
		PKL_DPRINTF("Reusing client stream %p\n", p_client_stream);
		if (p_req->request.flags & PKL_STREAM_REQ_FLAG_RESET_STREAM) {
			PKL_DPRINTF("Resetting client stream %p\n", p_client_stream);
			p_client_stream->p_hist->ridx = p_base->ridx;
			p_client_stream->p_hist->widx = p_base->widx;
		}
	} else {
		p_client_stream = calloc(1, sizeof(*p_client_stream));
		if (!p_client_stream) {
			return;
		}
		PKL_DPRINTF("Allocated client stream %p\n", p_client_stream);
		p_hist->p_mystream = p_client_stream;
		p_client_stream->p_hist = pktlogger_history_deepcopy(p_hist);
		p_client_stream->p_hist->ridx = p_base->ridx;
		p_client_stream->p_hist->widx = p_base->widx;
	}
	/* Fill out some details */
	p_client_stream->stream_consumer.src = *p_src;
	p_client_stream->requested_samples = reqcount;
	p_client_stream->remaining = p_client_stream->requested_samples;
	p_client_stream->samplenum = 0;
	p_client_stream->net_mseq = net_mseq;
	pktlogger_stream_add_client(type, p_client_stream);
}

/*
 * Main message process switch - determine what to do with incoming network messages and translate
 * into netlink messages for the kernel.
 */
static void
pktlogger_d_process_msg(uint8_t *p_msgbuf, size_t rxlen, struct pk_addr_t *p_src)
{
	struct pktlogger_net_hdr_t *p_hdr = (struct pktlogger_net_hdr_t *)p_msgbuf;
	uint32_t mtype;
	uint32_t net_mseq;

	/* Basic sanity */
	if (rxlen < sizeof(*p_hdr)) {
		return;
	}
	/* Header format is magic (32-bit int) - 0xFE09AA74 */
	if (ntohl(p_hdr->magic) != PKTLOGGER_NET_MAGIC) {
		PKL_DPRINTF("Magic wrong. Expected %08X, got %08X\n", PKTLOGGER_NET_MAGIC,
			ntohl(p_hdr->magic));
		return;
	}

	mtype = ntohl(p_hdr->mtype);
	if (mtype > max_mtype) {
		PKL_DPRINTF("Message type too large (%d, allow up to %d)\n", p_hdr->mtype,
			max_mtype);
		return;
	}
	net_mseq = ntohl(p_hdr->mseq);

	PKL_DPRINTF("%s: mseq: %d, mtype: %d\n", __func__, net_mseq, mtype);

	pktlogger_ntoh(p_msgbuf, rxlen, mtype);

	/* Message is sanitised, check the type and act accordingly */
	switch (mtype) {
	case PKTLOGGER_MSG_STRUCT_REQUEST:
		pktlogger_d_process_struct_req_msg(p_msgbuf, rxlen, p_src, net_mseq);
		break;
	case PKTLOGGER_MSG_CONFIG_REQUEST:
		pktlogger_d_process_config_req_msg(p_msgbuf, rxlen, p_src, net_mseq);
		break;
	case PKTLOGGER_MSG_CONFIG_ONEREQUEST:
		pktlogger_d_process_config_onereq_msg(p_msgbuf, rxlen, p_src, net_mseq);
		break;
	case PKTLOGGER_MSG_CONFIG_SET:
		pktlogger_d_process_config_set_msg(p_msgbuf, rxlen, p_src, net_mseq);
		break;
	case PKTLOGGER_MSG_CONFIG_ONESET:
		pktlogger_d_process_config_oneset_msg(p_msgbuf, rxlen, p_src, net_mseq);
		break;
	case PKTLOGGER_MSG_DATA_STREAM_REQUEST:
		pktlogger_d_process_stream_request(p_msgbuf, rxlen, p_src, net_mseq);
		break;
	default:
		PKL_EPRINTF("Invalid message type received (%d)\n", mtype);
		break;
	}
}

static void pktlogger_d_netlink_data_read(void)
{
	/* FIXME: this needs to be dynamically learned */
	uint8_t msgbuf[18000];
	struct msghdr msg;
	int ret;
	struct iovec *p_iov;
	struct pktlogger_nl_pktlogger_hdr *p_hdr;

	pktlogger_nl_msg_create(msgbuf, sizeof(msgbuf), &msg);

	ret = recvmsg(g_pk_cfg.netlink_data_fd, &msg, 0);
	if (ret <= 0) {
		pktlogger_nl_msg_free(&msg);
		return;
	}

	p_iov = (struct iovec *)msg.msg_iov;
	p_hdr = NLMSG_DATA(p_iov->iov_base);
	PKL_DPRINTF("Received %d (%zu) bytes of data from kernel (data)\n", ret, p_iov->iov_len);

	/* Pass data onto other parts of the system - this will store in history buffer
	 * and potentially unicast to listeners
	 */
	pktlogger_history_check_add_buf(p_hdr);
	pktlogger_nl_msg_free(&msg);
}

static void
pktlogger_nl_snoop_config(uint8_t *p_query)
{
	struct pktlogger_nl_config_t *p_config = (struct pktlogger_nl_config_t *)p_query;
	struct pktlogger_nl_radio_config_t *p_radio = &p_config->per_radio[0];
	int i;
	int num_entries = p_radio->pktlog_ver_cnt & 0xFF;

	if (num_entries > ARRAY_COUNT(p_radio->pktlog_configs)) {
		PKL_EPRINTF("Invalid input - too many radio configs (%d)\n", num_entries);
		return;
	}

	PKL_DPRINTF("Snooping config - %d pktloggers configured\n", num_entries);
	/* Extract the type to length values for each pktlogger type */
	for (i = 0; i < num_entries; i++) {
		struct pktlogger_nl_pktlog_config_t *p_pconf =
			(struct pktlogger_nl_pktlog_config_t *)&p_radio->pktlog_configs[i];
		uint32_t type = p_pconf->type;
		PKL_DPRINTF("Entry %d type %d len %d (var: %d)\n", i, p_pconf->type,
			p_pconf->struct_bsize, p_pconf->struct_vsize);
		if (pktlogger_type_valid(type)) {
			g_struct_len[type].struct_bsize = p_pconf->struct_bsize;
			g_struct_len[type].struct_vsize = p_pconf->struct_vsize;
		}
	}
	if (!g_pk_cfg.initialising) {
		return;
	}
	/*
	 * Initialisation only code below - run once at boot time to sync up the userspace config
	 * with kernelspace.
	 */

	/* First time through - apply the kernel config and setup some base structures */
	for(i = 0; i < num_entries; i++) {
		struct pktlogger_nl_pktlog_config_t *p_pconf =
			(struct pktlogger_nl_pktlog_config_t *)&p_radio->pktlog_configs[i];
		uint32_t type = p_pconf->type;
		if (pktlogger_type_valid(type)) {
			if (p_pconf->flags & PKTLOGGER_CONFIG_FLAGS_ENABLED) {
				PKL_DPRINTF("Enabling pktlogger type %d\n", type);
				/*
				 * FIXME: default to PKTLOGGER_MAX_HISTORY_ENTRIES_PER_TYPE entries of history - pass this flag to
				 * kernel, recover on restart
				 */
				pktlogger_history_base_init(type, 20);
			}
		}
	}
}

/* Snoop into the return netlink message - extract information we need for other operation. */
static void
pktlogger_nl_snoop(uint32_t resp_net_msg, uint8_t *p_query)
{
	switch(resp_net_msg) {
		case PKTLOGGER_MSG_CONFIG_RESPONSE:
			pktlogger_nl_snoop_config(p_query);
			break;
		default:
			break;
	}
}

static uint32_t
nl_mtype_to_net_mtype(uint32_t query_num)
{
	if (query_num == PKTLOGGER_QUERY_STRUCT) {
		return PKTLOGGER_MSG_STRUCT_RESPONSE;
	} else if (query_num == PKTLOGGER_QUERY_CONFIG) {
		return PKTLOGGER_MSG_CONFIG_RESPONSE;
	} else if (query_num == PKTLOGGER_QUERY_CONFIG_ONE) {
		return PKTLOGGER_MSG_CONFIG_ONERESPONSE;
	}
	return PKTLOGGER_MSG_INVALID;
}

/* Boilerplate code to deal with read of netlink socket from pktlogger kernel drivers */
static void pktlogger_d_netlink_read(void)
{
	/* FIXME: this needs to be dynamically learned */
	uint8_t msgbuf[65000];
	struct msghdr msg;
	int ret;
	struct iovec *p_iov;
	pktlogger_nl_msg_create(msgbuf, sizeof(msgbuf), &msg);

	ret = recvmsg(g_pk_cfg.netlink_ctrl_fd, &msg, 0);
	if (ret <= 0) {
		pktlogger_nl_msg_free(&msg);
		return;
	}

	struct pktlogger_nl_hdr_t *p_hdr;
	size_t query_resp_len;
	p_iov = (struct iovec *)msg.msg_iov;
	p_hdr = NLMSG_DATA(p_iov->iov_base);
	switch (p_hdr->mtype) {
	case PKTLOGGER_NETLINK_MTYPE_QUERY:
	{
		struct pktlogger_nl_query_t *p_query = (struct pktlogger_nl_query_t *)p_hdr;
		query_resp_len = ret - NLMSG_HDRLEN - sizeof(*p_query);
		PKL_DPRINTF("Received %d (%zu) bytes from kernel (ctrl) (%p)\n", ret, query_resp_len,
			p_query);
		if (query_resp_len != p_hdr->mlen) {
			PKL_EPRINTF("Expected %d bytes\n", p_hdr->mlen);
			break;
		}
		if (g_pk_cfg.p_response_list) {
			uint32_t resp_net_msg = nl_mtype_to_net_mtype(p_query->query_num);

			if (resp_net_msg != PKTLOGGER_MSG_INVALID) {
				pktlogger_nl_snoop(resp_net_msg, &p_query->data[0]);
				/*
				 * There are clients waiting for response to this message type -
				 * send out the data received
				 */
				pktlogger_send_common(&p_query->data[0], query_resp_len,
					p_hdr->mseq, resp_net_msg);
			}
		} else if (g_pk_cfg.initialising) {
			uint32_t resp_net_msg = nl_mtype_to_net_mtype(p_query->query_num);

			if (resp_net_msg != PKTLOGGER_MSG_INVALID) {
				pktlogger_nl_snoop(resp_net_msg, &p_query->data[0]);
			}
			g_pk_cfg.initialising = 0;
		}
		break;
	}
	default:
		break;
	}
	pktlogger_nl_msg_free(&msg);
}

static void
pktlogger_d_timer_tick(void)
{
	struct pk_client_data_stream_t *p_stream = g_client_streams;
	struct pk_client_data_stream_t *p_pstream = NULL;

	if (!g_client_streams) {
		g_pk_cfg.arm_timer = 0;
		return;
	}

	/* Something to process */
	while (p_stream) {
		int rv = pktlogger_history_flush_one(p_stream);
		if (p_stream->remaining && rv != -1) {
			PKL_DPRINTF("client has remaining buffers required:%d\n",
				p_stream->remaining);
			p_pstream = p_stream;
			p_stream = p_stream->p_next;
		} else {
			struct pk_client_data_stream_t *p_removed;
			/* Remove from the linked list of globals */
			/* Must get the next stream prior to removing from global list */
			p_removed = p_stream->p_next;
			pktlogger_stream_global_remove_client_ex(p_stream, p_pstream);
			p_stream = p_removed;
		}
	}
}

/* Boilerplate code to deal with read of transpt socket */
static void pktlogger_d_transpt_read(void)
{
	struct pk_addr_t src_addr = {.type = PKTLOGGER_D_ADDR_QL2T};
	/* FIXME: this needs to be dynamically learned */
	uint8_t msgbuf[65000];
	uint16_t len_copied = 0;

	if (ql2t_recv(g_pk_cfg.transpt_fd, &src_addr.addr_ql2t, (char *)&msgbuf,
		(uint16_t)sizeof(msgbuf), &len_copied) < 0) {
		PKL_EPRINTF("Failed to recv over transpt_fd\n");
		return;
	}

	if (len_copied < sizeof(struct pktlogger_transpt_hdr_t)) {
		PKL_EPRINTF("len_copied: expected = %zu, actual = %d\n",
			sizeof(struct pktlogger_transpt_hdr_t), len_copied);
		return;
	}
	len_copied -= sizeof(struct pktlogger_transpt_hdr_t);
	PKL_DPRINTF("Received %d bytes over transpt_fd\n", len_copied);

	struct pktlogger_transpt_pkt_t *p_pkt = (struct pktlogger_transpt_pkt_t *)msgbuf;

	src_addr.addr_in = p_pkt->hdr.addr;

	if (g_pk_cfg.proxy) {
		PKL_DPRINTF("Sending response to %s\n", inet_ntoa(src_addr.addr_in.sin_addr));

		if ((sendto(g_pk_cfg.listen_fd, p_pkt->payload, len_copied, 0,
			(struct sockaddr *)&src_addr.addr_in, sizeof(src_addr.addr_in)) == -1) &&
			g_pk_cfg.verbose) {
			perror("Error sending response to client");
		}
	} else {
		pktlogger_d_process_msg(p_pkt->payload, len_copied, &src_addr);
	}
}

/* Boilerplate code to read in from network UDP socket */
static void pktlogger_d_net_read(void)
{
	uint8_t msgbuf[2000];
	int ret;
	struct pk_addr_t src_addr = {.type = PKTLOGGER_D_ADDR_IN};
	socklen_t src_len = sizeof(src_addr.addr_in);

	memset(msgbuf, 0, sizeof(msgbuf));
	ret = recvfrom(g_pk_cfg.listen_fd, (void *)msgbuf, sizeof(msgbuf),
		0, (struct sockaddr *)&src_addr.addr_in, &src_len);
	if (ret > 0) {
		PKL_DPRINTF("Received %d bytes from socket %s\n", ret,
			pktlogger_addr_ntoa(src_addr));
		pktlogger_d_process_msg(msgbuf, ret, &src_addr);
	}
}

/* Main loop - while(1) set fds; read from fds; perform actions; done */
static void pktlogger_d_main(void)
{
	fd_set rfds;
	int last_fd;
	int ret;

	for (;;) {
		struct timeval tv;

		/* Re-generate rfds each time */
		FD_ZERO(&rfds);
		last_fd = 0;

		FD_SET(g_pk_cfg.listen_fd, &rfds);
		last_fd = MAX(last_fd, g_pk_cfg.listen_fd);

		if (g_pk_cfg.transpt_fd != -1) {
			FD_SET(g_pk_cfg.transpt_fd, &rfds);
			last_fd = MAX(last_fd, g_pk_cfg.transpt_fd);
		}

		if (g_pk_cfg.netlink_ctrl_fd != -1) {
			FD_SET(g_pk_cfg.netlink_ctrl_fd, &rfds);
			last_fd = MAX(last_fd, g_pk_cfg.netlink_ctrl_fd);
		}

		if (g_pk_cfg.netlink_data_fd != -1) {
			FD_SET(g_pk_cfg.netlink_data_fd, &rfds);
			last_fd = MAX(last_fd, g_pk_cfg.netlink_data_fd);
		}

		if (g_pk_cfg.arm_timer) {
			/* 1ms on the timer tick when active */
			tv.tv_sec = 0;
			tv.tv_usec = 1000;
		} else {
			tv.tv_sec = 0;
			tv.tv_usec = 1000000;
		}

		/* Wait until something happens or timeout */
		ret = select(last_fd + 1, &rfds, NULL, NULL, &tv);

		/* Check if there was an error */
		if (ret < 0) {
			if (errno == EINTR)
				continue;
			PKL_EPRINTF("select() failed - exiting\n");
			break;
		}

		/* Check if there was a timeout */
		if (ret == 0) {
			if (g_pk_cfg.arm_timer) {
				PKL_DPRINTF("\n=== timer tick - do some stuff\n");
				pktlogger_d_timer_tick();
				PKL_DPRINTF("=== timer tick: Done\n\n");
			}
			continue;
		}

		if (FD_ISSET(g_pk_cfg.listen_fd, &rfds)) {
			PKL_DPRINTF("\n=== Net\n");
			pktlogger_d_net_read();
			PKL_DPRINTF("=== Net: Done\n");
		}
		if ((g_pk_cfg.transpt_fd != -1) && FD_ISSET(g_pk_cfg.transpt_fd, &rfds)) {
			PKL_DPRINTF("\n=== Transpt\n");
			pktlogger_d_transpt_read();
			PKL_DPRINTF("=== Transpt: Done\n");
		}
		if ((g_pk_cfg.netlink_ctrl_fd != -1) && FD_ISSET(g_pk_cfg.netlink_ctrl_fd, &rfds)) {
			PKL_DPRINTF("\n=== Ctrl\n");
			pktlogger_d_netlink_read();
			PKL_DPRINTF("=== Ctrl: Done\n");
		}
		if ((g_pk_cfg.netlink_data_fd != -1) && FD_ISSET(g_pk_cfg.netlink_data_fd, &rfds)) {
			PKL_DPRINTF("\n=== Data\n");
			pktlogger_d_netlink_data_read();
			PKL_DPRINTF("=== Data: Done\n");
		}
	}
}

static void usage(char *argv_0)
{
	PKL_EPRINTF("Usage: %s [options]\n\n", argv_0);
	PKL_EPRINTF("Options:\n");
	PKL_EPRINTF("-i <local interface> : EP-only config  : Should not be used\n");
	PKL_EPRINTF("                     : NPU + EP config : Required for both daemon and proxy\n");
	PKL_EPRINTF("-p <server port>\n");
	PKL_EPRINTF("-r                   : Allow remote hosts to connect\n");
	PKL_EPRINTF("-v                   : Enable verbosity\n");
	if (g_pk_cfg.proxy)
		PKL_EPRINTF("-m                   : Remote MAC address (for proxy only)\n");
}

/* Basic getopt arguments */
static int parse_args(int argc, char *argv[])
{
	int c;
	while ((c = getopt(argc, argv, "i:m:p:rv")) != -1) {
		switch(c) {
		case 'i':
			if (strlen(optarg) > IFNAMSIZ - 1) {
				PKL_EPRINTF("-i: Exceeds max allowed len (%u)\n", IFNAMSIZ - 1);
				return -1;
			}

			strncpy(g_pk_cfg.local_if_name, optarg, IFNAMSIZ - 1);
			break;
		case 'm':
			if (g_pk_cfg.proxy) {
				int count;
				int mac_addr[ETH_ALEN];

				count = sscanf(optarg, "%02x:%02x:%02x:%02x:%02x:%02x",
							&mac_addr[0], &mac_addr[1], &mac_addr[2],
							&mac_addr[3], &mac_addr[4], &mac_addr[5]);
				if (count != ETH_ALEN) {
					PKL_EPRINTF("Incorrect MAC address format; expected "
						"xx:xx:xx:xx:xx:xx");
					return -1;
				}

				while (count--)
					g_pk_cfg.remote_mac_addr[count] = mac_addr[count];

			}
			break;
		case 'p':
			g_pk_cfg.port = atoi(optarg);
			break;
		case 'r':
			g_pk_cfg.en_remote_host = 1;
			break;
		case 'v':
			g_pk_cfg.verbose = 1;
			break;
		default:
			usage(argv[0]);
			return -1;
			break;
		}
	}

	/* Interface name is required for pkt_logger_d_p */
	if (g_pk_cfg.proxy && g_pk_cfg.local_if_name[0] == '\0') {
		usage(argv[0]);
		return -1;
	}

	return 0;
}

int main(int argc, char *argv[])
{
	char *substr;

	/* Using the program name to act as proxy or not */
	substr = strstr(argv[0], PKTLOGGER_D_P);
	if (substr && *(substr + sizeof(PKTLOGGER_D_P) - 1) == '\0')
		g_pk_cfg.proxy = 1;

	g_pk_cfg.initialising = 1;

	if (parse_args(argc, argv) < 0)
		return EXIT_FAILURE;

	if (pktlogger_d_init() < 0)
		return EXIT_FAILURE;

	pktlogger_d_get_config();

	pktlogger_d_main();

	return EXIT_SUCCESS;
}
