/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 Quantenna Communications Inc                   **
**                                                                           **
**  File        : pkl.c                                                      **
**  Description : API to communicate with pktlogger                          **
**                                                                           **
*******************************************************************************
*/

#include <stdint.h>
#include <stdlib.h>        /* calloc, malloc, srand, rand */
#include <string.h>        /* memset                      */
#include <sys/socket.h>    /* socket API, sockaddr        */
#include <arpa/inet.h>     /* inet_addr                   */
#include <netinet/in.h>    /* sockaddr_in, htonl, ntohl   */
#include <sys/select.h>    /* select system call          */
#include <unistd.h>        /* close socket                */
#include <sys/time.h>      /* struct timeval              */
#include <time.h>
#include <assert.h>        /* assert                      */
#include <errno.h>
#include <stdio.h>         /* printf, perror              */
#include "pktlogger_common.h"
#include "pkl.h"

/******************************************************
 *                      DEFINITIONS
 *****************************************************/
#define LOCAL_ADDR			"127.0.0.1"

#ifndef ARRAY_COUNT
#define ARRAY_COUNT(_x) (sizeof(_x)/sizeof(_x[0]))
#endif

#ifndef MIN
#define MIN(a, b)			((a) < (b) ? (a) : (b))
#endif

#define PKL_PERROR(msg)			perror(msg)
#define PKL_PRINTF(level, fmt, args...)	do {							\
						if (pkl.verbose >= level) {			\
							fprintf(stdout, "PKL LIB: ");		\
							fprintf(stdout, fmt, ## args);		\
						}						\
					} while (0)
#define PKL_PRINTF_BUF(level, bytes, buf)	do {								\
							if (pkl.verbose >= level) {				\
								int i;						\
								const int print_num = 32;			\
								fprintf(stdout, "PKL LIB: ");			\
								for(i = 0; i < MIN(print_num,bytes); i++)	\
									fprintf(stdout, "%02X", buf[i]&0xFF);	\
								if (bytes > print_num) fprintf(stdout, "...");	\
								fprintf(stdout, "\n");				\
							}							\
						} while (0)
#define PKL_ASSERT(expr)		assert(expr)

/******************************************************
 *                      LOCAL TYPES
 *****************************************************/

struct pkl_t {
	int query_sock;		/* To discover pktlogger_d and config it              */
	int seq;
	int verbose;
	struct sockaddr_in pktlogger_d_query_addr;
};

/******************************************************
 *                 LOCAL FUNCTIONS' PROTOTYPES
 *****************************************************/

static void pkl_build_net_header(struct pktlogger_net_hdr_t *hdr,
                                 enum pktlogger_net_msg type, size_t len);
static int  pkl_set_pktlogger_d_address(char *addr, uint16_t port);
static int  pkl_alloc_rx_buffer(void **buf);
static int  pkl_open_udp_query_sockets(void);
static int  pkl_get_structure(struct pktlogger_net_query_t *nqr);
static int  pkl_send_request(int req_type);
static int  pkl_recv_response(void *buf, size_t buf_size, size_t resp_size,
                              enum pktlogger_net_msg expected_resp, int sec, int seq);
static int  pkl_recv_data(void *buf, size_t buf_size, enum pktlogger_net_msg expected_resp);
static int  pkl_net_request_structure(struct pktlogger_net_query_t *resp);
static int  pkl_net_request_configuration(struct pktlogger_net_config_t *resp);
static int  pkl_net_request_one_configuration(int radio_index, int type,
                                              struct pktlogger_net_config_one_t *resp);
static void pkl_hton_pktlog_config(struct pktlogger_pktlog_config_t *p_conf);
static void pkl_ntoh_pktlog_config(struct pktlogger_pktlog_config_t *p_conf);
static void pkl_hton_one_radio(struct pktlogger_radio_config_t *p_radio);
static void pkl_ntoh_one_radio(struct pktlogger_radio_config_t *p_radio);
static void pkl_hton_config_one(uint8_t *p_req, unsigned int req_len);
static void pkl_ntoh_config_one(uint8_t *p_c, unsigned int conf_len);
static void pkl_ntoh_stream(uint8_t *p_s, unsigned int stream_len);
static void pkl_hton_config(uint8_t *p_req, unsigned int req_len);
static void pkl_ntoh_config(uint8_t *p_resp, unsigned int resp_len);
static void pkl_hton(uint8_t *p_req, unsigned int req_len, int mtype);
static void pkl_ntoh(uint8_t *p_resp, unsigned int resp_len, int mtype);

/******************************************************
 *                      GLOBAL VARIABLES
 *****************************************************/
static struct pkl_t pkl;

/******************************************************
 *                      LOCAL FUNCTIONS
 *****************************************************/

static void
pkl_build_net_header(struct pktlogger_net_hdr_t *hdr,
                     enum pktlogger_net_msg type, size_t len)
{
	hdr->magic   = htonl(PKTLOGGER_NET_MAGIC);
	hdr->version = htonl(PKTLOGGER_NET_VERSION);
	hdr->mtype   = htonl(type);
	hdr->mlen    = htonl(len);
	hdr->mseq    = htonl(pkl.seq);
	pkl.seq      = pkl.seq + 1;
}

static int
pkl_set_pktlogger_d_address(char *addr, uint16_t port)
{
	memset((void *) &pkl.pktlogger_d_query_addr, 0, sizeof(struct sockaddr_in));
	pkl.pktlogger_d_query_addr.sin_family      = AF_INET;
	pkl.pktlogger_d_query_addr.sin_port        = htons(port);
	pkl.pktlogger_d_query_addr.sin_addr.s_addr = inet_addr(addr);
	return 0;
}

static int
pkl_alloc_rx_buffer(void **buf)
{
	if ((*buf = malloc(PKL_RECV_BUF_MAX_SIZE)) == NULL) {
		PKL_PERROR("PKL LIB: alloc fail");
		return -1;
	}
	return 0;
}

static int
pkl_open_udp_query_sockets(void)
{
	if ((pkl.query_sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		PKL_PERROR("PKL LIB: open tx socket");
		return -1;
	}

	int bcst_permission = 1;
	if (setsockopt(pkl.query_sock, SOL_SOCKET, SO_BROADCAST, (void *)&bcst_permission, sizeof(bcst_permission)) < 0) {
		PKL_PERROR("PKL LIB: SO_BROADCAST");
		return -1;
	}
	int reuse_permission = 1;
	if (setsockopt(pkl.query_sock, SOL_SOCKET, SO_REUSEADDR, (void *)&reuse_permission, sizeof(reuse_permission)) < 0) {
		PKL_PERROR("PKL LIB: SO_REUSEADDR");
		return -1;
	}

	return 0;
}

static int
pkl_get_structure(struct pktlogger_net_query_t *nqr)
{
	int nqr_counter = 2;
	int res;

	do {
		res = pkl_net_request_structure(nqr);
		if (res < 0)
			return -1;
		else if (res > 0) {
			/* one more try with the same seq number */
			pkl.seq--;
			continue;
		}
		break;
	} while (--nqr_counter);

	if (nqr_counter <= 0)
		return -1;

	return 0;
}

static int
pkl_send_request(int req_type)
{
	struct pktlogger_net_query_t nqr;

	pkl_build_net_header(&nqr.hdr, req_type, 0);
	if (sendto(pkl.query_sock, (void *)&nqr, sizeof(nqr), 0,
			(struct sockaddr *)&pkl.pktlogger_d_query_addr,
			sizeof(struct sockaddr_in)) < 0) {
		PKL_PERROR("PKL LIB: send req (sendto)");
		return -1;
	}

	return 0;
}

/* Receive response from pktlogger_d
 * Input/output		dest buffer
 * Input		dest buffer size
 * Input		expected size to receive; response size cannot be 0, so 0 value is reserved for any size
 * Input		expected response id
 * Input		timeout in seconds (-1 - wait forever)
 * Input		request sequence number sent previously
 * Output:		result code (0 - success, >0 - timer elapsed OR wrong packet, <0 - fail)
 */
static int
pkl_recv_response(void *buf, size_t buf_size, size_t resp_size,
                  enum pktlogger_net_msg expected_resp, int sec, int seq)
{
	char addr_str[INET_ADDRSTRLEN];
	struct pktlogger_net_hdr_t *hdr;
	struct sockaddr_in recv_addr;
	struct timeval nqr_timeout;
	struct timeval *pt = NULL;
	socklen_t addr_len;
	time_t start, end;
        int seconds;
	fd_set readfds;
	int recv_bytes;
	int last_fd;
	int res;

	FD_ZERO(&readfds);
	FD_SET(pkl.query_sock, &readfds);
	last_fd = pkl.query_sock;

	time(&start);
	do {
		if (sec != -1) {
			nqr_timeout.tv_sec = 1; /* 1 sec to receive a socket event */
			nqr_timeout.tv_usec = 0;
			pt = &nqr_timeout;
		}

		res = select(last_fd + 1, &readfds, NULL, NULL, pt);
		if (res < 0) {
			PKL_PERROR("PKL LIB: response (select)");
			return -1;
		}
		if (res == 0) {
			PKL_PRINTF(PKL_DBG_WARNING, "One-try timeout elapsed.\n");
			time(&end);
			continue;
		}

		addr_len = sizeof(struct sockaddr_in);
		if ((recv_bytes = recvfrom(pkl.query_sock, buf, buf_size, 0,
					(struct sockaddr *)&recv_addr, &addr_len)) == -1) {
			PKL_PERROR("PKL LIB: response (recvfrom)");
			time(&end);
			continue;
		}

		/* IPv4 only */
		PKL_PRINTF(PKL_DBG_MESSAGE, "got %d bytes from %s\n", recv_bytes, inet_ntop(AF_INET, &recv_addr.sin_addr, addr_str, INET_ADDRSTRLEN));
		PKL_PRINTF_BUF(PKL_DBG_MESSAGE, recv_bytes, ((char *)buf));

		/* Validation #1: Header always goes first. Paranoid check. */
		hdr = (struct pktlogger_net_hdr_t *)buf;
		if (ntohl(hdr->magic) != PKTLOGGER_NET_MAGIC) {
			PKL_PRINTF(PKL_DBG_WARNING, "Packet corrupted.\n");
			time(&end);
			continue;
		}

		/* Validation #2: Match up seq and req/resp? */
		if ((seq != ntohl(hdr->mseq)) || (expected_resp != ntohl(hdr->mtype))) {
			PKL_PRINTF(PKL_DBG_WARNING, "Seq sent - %d, seq received - %d. mtype received - %d.\n", seq, ntohl(hdr->mseq), ntohl(hdr->mtype));
			time(&end);
			continue;
		}

		/* Validation #3: packet size. */
		if (resp_size && (recv_bytes != resp_size)) {
			PKL_PRINTF(PKL_DBG_WARNING, "Received UDP datagram size doesn't match expected size.\n");
			time(&end);
			continue;
		}

		/* TODO: Validation #4: should we check hdr->mlen? */
		hdr->mlen = ntohl(hdr->mlen);
		return 0;

	} while ((seconds = (int)difftime (end, start)) < sec);

	return 1;
}

/* Receive response from pktlogger_d. It is non-blocking,
 * select() or poll() can be used to determine when more data arrives.
 * Input/output		dest buffer
 * Input		dest buffer size
 * Input		expected response id
 * Output:		result code (0 - success, >0 - timer elapsed OR wrong packet, <0 - fail)
 */
static int
pkl_recv_data(void *buf, size_t buf_size, enum pktlogger_net_msg expected_resp)
{
	char addr_str[INET_ADDRSTRLEN];
	struct pktlogger_net_hdr_t *hdr;
	struct sockaddr_in recv_addr;
	socklen_t addr_len;
	int recv_bytes;
	int res;

	addr_len = sizeof(struct sockaddr_in);
	if ((recv_bytes = recvfrom(pkl.query_sock, buf, buf_size, MSG_DONTWAIT,
				(struct sockaddr *)&recv_addr, &addr_len)) == -1) {
		PKL_PERROR("PKL LIB: response (recvfrom)");
		return -1;
	}

	/* IPv4 only */
	PKL_PRINTF(PKL_DBG_MESSAGE, "got %d bytes from %s\n", recv_bytes, inet_ntop(AF_INET, &recv_addr.sin_addr, addr_str, INET_ADDRSTRLEN));
	PKL_PRINTF_BUF(PKL_DBG_MESSAGE, recv_bytes, ((char *)buf));

	/* Validation #1: Header always goes first. Paranoid check. */
	hdr = (struct pktlogger_net_hdr_t *)buf;
	if (ntohl(hdr->magic) != PKTLOGGER_NET_MAGIC) {
		PKL_PRINTF(PKL_DBG_WARNING, "Packet corrupted.\n");
		return 1;
	}

	/* Validation #2: Match up req/resp? */
	if (expected_resp != ntohl(hdr->mtype)) {
		PKL_PRINTF(PKL_DBG_WARNING, "mtype received - %d.\n", ntohl(hdr->mtype));
		return 1;
	}

	/* TODO: Validation #4: should we check hdr->mlen? */
	hdr->mlen = ntohl(hdr->mlen);

	return 0;
}

static int
pkl_net_request_structure(struct pktlogger_net_query_t *resp)
{
	int seq = pkl.seq;
	if (pkl_send_request(PKTLOGGER_MSG_STRUCT_REQUEST) < 0)
		return -1;
	return pkl_recv_response((void *)resp, PKL_RECV_BUF_MAX_SIZE, 0, PKTLOGGER_MSG_STRUCT_RESPONSE, 5, seq);
}

static int
pkl_net_request_configuration(struct pktlogger_net_config_t *resp)
{
	int seq = pkl.seq;
	if (pkl_send_request(PKTLOGGER_MSG_CONFIG_REQUEST) < 0)
		return -1;
	return pkl_recv_response((void *)resp, PKL_RECV_BUF_MAX_SIZE,
	                         sizeof(*resp), PKTLOGGER_MSG_CONFIG_RESPONSE, 5, seq);
}

static int
pkl_net_request_one_configuration(int radio_index, int type,
                                  struct pktlogger_net_config_one_t *resp)
{
	struct pktlogger_net_query_one_t req;
	int seq = pkl.seq;

	/* Header */
	pkl_build_net_header(&req.hdr, PKTLOGGER_MSG_CONFIG_ONEREQUEST, sizeof(req) - sizeof(req.hdr));
	/* Payload */
	req.radio_index = htonl(radio_index);
	req.type        = htonl(type);

	if (sendto(pkl.query_sock, (void *) &req, sizeof(req), 0,
	           (struct sockaddr *)&pkl.pktlogger_d_query_addr, sizeof(struct sockaddr_in)) < 0) {
		PKL_PERROR("PKL LIB: set config one (sendto)");
		return -1;
	}
	return pkl_recv_response((void *)resp, PKL_RECV_BUF_MAX_SIZE,
	                         sizeof(*resp), PKTLOGGER_MSG_CONFIG_ONERESPONSE, 5, seq);
}

static void
pkl_hton_pktlog_config(struct pktlogger_pktlog_config_t *p_conf)
{
	p_conf->type         = htons(p_conf->type);
	p_conf->flags        = htons(p_conf->flags);
	p_conf->rate         = htonl(p_conf->rate);
	p_conf->history      = htonl(p_conf->history);
	p_conf->struct_bsize = htons(p_conf->struct_bsize);
	p_conf->struct_vsize = htons(p_conf->struct_vsize);
}

static void
pkl_ntoh_pktlog_config(struct pktlogger_pktlog_config_t *p_conf)
{
	p_conf->type         = ntohs(p_conf->type);
	p_conf->flags        = ntohs(p_conf->flags);
	p_conf->rate         = ntohl(p_conf->rate);
	p_conf->history      = ntohl(p_conf->history);
	p_conf->struct_bsize = ntohs(p_conf->struct_bsize);
	p_conf->struct_vsize = ntohs(p_conf->struct_vsize);
}

static void
pkl_hton_one_radio(struct pktlogger_radio_config_t *p_radio)
{
	int i;
	/* ONLY convert host endian - IP and UDP port are already net endian */
	p_radio->pktlog_ver_cnt = htonl(p_radio->pktlog_ver_cnt);
	for (i = 0; i < ARRAY_COUNT(p_radio->pktlog_configs); i++)
		pkl_hton_pktlog_config(&p_radio->pktlog_configs[i]);
}

static void
pkl_ntoh_one_radio(struct pktlogger_radio_config_t *p_radio)
{
	int i;
	/* ONLY convert host endian - IP and UDP port are already net endian */
	p_radio->pktlog_ver_cnt = ntohl(p_radio->pktlog_ver_cnt);
	for (i = 0; i < ARRAY_COUNT(p_radio->pktlog_configs); i++)
		pkl_ntoh_pktlog_config(&p_radio->pktlog_configs[i]);
}

static void
pkl_hton_config_one(uint8_t *p_req, unsigned int req_len)
{
	struct pktlogger_config_one_t *p_conf_one = (struct pktlogger_config_one_t *)p_req;
	struct pktlogger_pktlog_config_t *p_conf;
	if (req_len < sizeof(*p_conf_one)) {
		PKL_PRINTF(PKL_DBG_WARNING, "Ignoring undersized return value %d (expected: %zu)\n", req_len, sizeof(*p_conf_one));
		return;
	}
	p_conf_one->radio_index = htonl(p_conf_one->radio_index);
	p_conf = &p_conf_one->config;
	pkl_hton_pktlog_config(p_conf);
}

static void
pkl_ntoh_config_one(uint8_t *p_c, unsigned int conf_len)
{
	struct pktlogger_config_one_t *p_cconf = (struct pktlogger_config_one_t *)p_c;
	struct pktlogger_pktlog_config_t *p_pconf;
	if (conf_len < sizeof(*p_cconf)) {
		PKL_PRINTF(PKL_DBG_WARNING, "Ignoring undersized return value %d (exp: %zu)\n", conf_len, sizeof(*p_cconf));
		return;
	}
	p_cconf->radio_index = ntohl(p_cconf->radio_index);
	p_pconf = &p_cconf->config;
	pkl_ntoh_pktlog_config(p_pconf);
}

static void
pkl_ntoh_stream(uint8_t *p_s, unsigned int stream_len)
{
	struct pktlogger_history_stream_t *p_stream = (struct pktlogger_history_stream_t *)p_s;
	p_stream->radio_index    = ntohl(p_stream->radio_index);
	p_stream->type           = ntohs(p_stream->type);
	p_stream->totalcount     = ntohs(p_stream->totalcount);
	p_stream->samplenum      = ntohs(p_stream->samplenum);
	p_stream->requestedcount = ntohs(p_stream->requestedcount);
	/* TODO: change data byte-order if needed */
}

static void
pkl_hton_config(uint8_t *p_req, unsigned int req_len)
{
	struct pktlogger_config_t *p_conf = (struct pktlogger_config_t *)p_req;
	int count = 0;
	uint32_t radio_mask;
	if (req_len < sizeof(*p_conf)) {
		PKL_PRINTF(PKL_DBG_WARNING, "Ignoring undersized return value %d (expected: %zu)\n", req_len, sizeof(*p_conf));
		return;
	}
	radio_mask = p_conf->radio_mask;
	p_conf->radio_mask = htonl(p_conf->radio_mask);
	p_conf->rev        = htonl(p_conf->rev);
	while(radio_mask && count < PKTLOGGER_MAX_RADIOS) {
		if (radio_mask & 0x1) {
			struct pktlogger_radio_config_t *p_radio = &p_conf->per_radio[count];
			pkl_hton_one_radio(p_radio);
		}
		radio_mask >>= 1;
		count++;
	}
}

static void
pkl_ntoh_config(uint8_t *p_resp, unsigned int resp_len)
{
	struct pktlogger_config_t *p_conf = (struct pktlogger_config_t *)p_resp;
	int count = 0;
	uint32_t radio_mask;
	if (resp_len < sizeof(*p_conf)) {
		PKL_PRINTF(PKL_DBG_WARNING, "Ignoring undersized return value %d (expected: %zu)\n", resp_len, sizeof(*p_conf));
		return;
	}
	p_conf->rev        = ntohl(p_conf->rev);
	p_conf->radio_mask = ntohl(p_conf->radio_mask);
	radio_mask = p_conf->radio_mask;
	while(radio_mask && count < PKTLOGGER_MAX_RADIOS) {
		if (radio_mask & 0x1) {
			struct pktlogger_radio_config_t *p_radio = &p_conf->per_radio[count];
			pkl_ntoh_one_radio(p_radio);
		}
		radio_mask >>= 1;
		count++;
	}
}

static void
pkl_hton(uint8_t *p_req, unsigned int req_len, int mtype)
{
	switch (mtype) {
		case PKTLOGGER_MSG_CONFIG_SET:
			pkl_hton_config(p_req, req_len);
			break;
		case PKTLOGGER_MSG_CONFIG_ONESET:
			pkl_hton_config_one(p_req, req_len);
			break;
		default:
			break;
	}
}

static void
pkl_ntoh(uint8_t *p_resp, unsigned int resp_len, int mtype)
{
	switch (mtype) {
		case PKTLOGGER_MSG_CONFIG_RESPONSE:
			pkl_ntoh_config(p_resp, resp_len);
			break;
		case PKTLOGGER_MSG_CONFIG_ONERESPONSE:
			pkl_ntoh_config_one(p_resp, resp_len);
			break;
		case PKTLOGGER_MSG_DATA_STREAM:
			pkl_ntoh_stream(p_resp, resp_len);
			break;
		default:
			break;
	}
}

/******************************************************
 *                      LIB API
 *****************************************************/

int pkl_debug_pk_config_set(void *desc, const struct pktlogger_config_t *cfg)
{
	struct pktlogger_net_config_t ncfg;

	/* Header */
	pkl_build_net_header(&ncfg.hdr, PKTLOGGER_MSG_CONFIG_SET, sizeof(ncfg.config));
	/* Payload */
	memcpy(&ncfg.config, cfg, sizeof(ncfg.config));
	pkl_hton((uint8_t *)&ncfg.config, sizeof(ncfg.config), PKTLOGGER_MSG_CONFIG_SET);

	if (sendto(pkl.query_sock, (void *) &ncfg, sizeof(ncfg), 0,
	           (struct sockaddr *)&pkl.pktlogger_d_query_addr, sizeof(struct sockaddr_in)) < 0) {
		PKL_PERROR("PKL LIB: set config (sendto)");
		return -1;
	}

	return 0;
}

int pkl_debug_pk_config_get(void *desc, struct pktlogger_config_t *cfg)
{
	struct pktlogger_radio_config_t *src_radio_cfg;
	struct pktlogger_radio_config_t *dst_radio_cfg;
	struct pktlogger_net_config_t *ncfg;
	int req_counter = 3;
	int types_number;
	uint16_t t;
	int i, j;
	int res;

	PKL_ASSERT(sizeof(*ncfg) < PKL_RECV_BUF_MAX_SIZE);
	if (pkl_alloc_rx_buffer((void **)&ncfg) != 0)
		return -1;

	do {
		res = pkl_net_request_configuration(ncfg);
		if (res < 0) {
			free(ncfg);
			return -1;
		}
		else if (res > 0) {
			/* one more try with the same seq number */
			pkl.seq--;
			continue;
		}
		break;
	} while (--req_counter);

	if (req_counter <= 0) {
		free(ncfg);
		return -1;
	}

	pkl_ntoh((uint8_t *)&ncfg->config, sizeof(ncfg->config), PKTLOGGER_MSG_CONFIG_RESPONSE);

	/* Sort configs to let PKL library client access array as expected
	 * pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_DSP_STATS] and check
	 * pktlog_configs[PKTLOGGER_TYPE_NETDEBUG_DSP_STATS].type == PKTLOGGER_TYPE_NETDEBUG_DSP_STATS
	 */
	cfg->rev        = ncfg->config.rev;
	cfg->radio_mask = ncfg->config.radio_mask;
	for (i = 0; i < PKTLOGGER_MAX_RADIOS; i++) {
		if (!(cfg->radio_mask & (1 << i)))
			continue;

		src_radio_cfg = &ncfg->config.per_radio[i];
		dst_radio_cfg = &cfg->per_radio[i];
		dst_radio_cfg->destip = src_radio_cfg->destip;
		dst_radio_cfg->srcip = src_radio_cfg->srcip;
		memcpy(dst_radio_cfg->destmac, src_radio_cfg->destmac, sizeof(dst_radio_cfg->destmac));
		memcpy(dst_radio_cfg->srcmac,  src_radio_cfg->srcmac,  sizeof(dst_radio_cfg->srcmac));
		dst_radio_cfg->destport = src_radio_cfg->destport;
		dst_radio_cfg->srcport = src_radio_cfg->srcport;
		dst_radio_cfg->pktlog_ver_cnt = src_radio_cfg->pktlog_ver_cnt;
		memcpy(dst_radio_cfg->radioname,  src_radio_cfg->radioname,  sizeof(dst_radio_cfg->radioname));

		/* First, clear types dst struct */
		for (j = 0; j < PKTLOGGER_TYPE_MAX; j++) {
			dst_radio_cfg->pktlog_configs[j].type = PKTLOGGER_TYPE_UNUSED_0;
		}

		/* Copy array of pktlogger_pktlog_config_t, each struct to appropriate index-place */
		types_number = src_radio_cfg->pktlog_ver_cnt & 0xFF;
		for (j = 0; j < types_number; j++) {
			t = src_radio_cfg->pktlog_configs[j].type;
			if (t >= PKTLOGGER_TYPE_MAX)
				continue;
			memcpy(&dst_radio_cfg->pktlog_configs[t],
			        &src_radio_cfg->pktlog_configs[j],
			        sizeof(dst_radio_cfg->pktlog_configs[0]));
		}
		dst_radio_cfg->pktlog_ver_cnt &= ~0xFF;
		dst_radio_cfg->pktlog_ver_cnt |= (PKTLOGGER_TYPE_MAX & 0xFF);
	}

	free(ncfg);
	return 0;
}

int pkl_debug_pk_config_one_set(void *desc, const struct pktlogger_config_one_t *cfg)
{
	struct pktlogger_net_config_one_t ncfg;

	if (cfg->radio_index >= PKTLOGGER_MAX_RADIOS)
		return -1;

	/* Header */
	pkl_build_net_header(&ncfg.hdr, PKTLOGGER_MSG_CONFIG_ONESET, sizeof(ncfg.config));
	/* Payload */
	memcpy(&ncfg.config, cfg, sizeof(ncfg.config));
	pkl_hton((uint8_t *)&ncfg.config, sizeof(ncfg.config), PKTLOGGER_MSG_CONFIG_ONESET);

	if (sendto(pkl.query_sock, (void *) &ncfg, sizeof(ncfg), 0,
	           (struct sockaddr *)&pkl.pktlogger_d_query_addr, sizeof(struct sockaddr_in)) < 0) {
		PKL_PERROR("PKL LIB: set config one (sendto)");
		return -1;
	}

	return 0;
}

int pkl_debug_pk_config_one_get(void *desc, struct pktlogger_config_one_t *cfg, int radio_index, int type)
{
	struct pktlogger_net_config_one_t *ncfg;
	int req_counter = 3;
	int res;

	if (radio_index >= PKTLOGGER_MAX_RADIOS)
		return -1;

	PKL_ASSERT(sizeof(*ncfg) < PKL_RECV_BUF_MAX_SIZE);
	if (pkl_alloc_rx_buffer((void **)&ncfg) != 0)
		return -1;

	do {
		res = pkl_net_request_one_configuration(radio_index, type, ncfg);
		if (res < 0) {
			free(ncfg);
			return -1;
		}
		else if (res > 0) {
			/* one more try with the same seq number */
			pkl.seq--;
			continue;
		}
		break;
	} while (--req_counter);

	if (req_counter <= 0) {
		free(ncfg);
		return -1;
	}

	pkl_ntoh((uint8_t *)&ncfg->config, sizeof(ncfg->config), PKTLOGGER_MSG_CONFIG_ONERESPONSE);

	/* Valid radio interface number? */
	if (!(ncfg->config.radio_index == radio_index)) {
		free(ncfg);
		return -1;
	}

	memcpy(cfg, (void *)&ncfg->config, sizeof(*cfg));
	free(ncfg);
	return 0;
}

int pkl_debug_pk_type_config_set(int index, int hist_prior, int hist_total,
	const struct pktlogger_ptype_config_t param_config[], unsigned int param_count)
{
	return 0;
}

int pkl_debug_pk_type_config_get(void *desc, int index, int *hist_prior, int *hist_total,
	struct pktlogger_ptype_config_t *param_config[], unsigned int *param_count)
{
	return 0;
}

/* TODO: index logic is not implemented yet. List of "index:ptr" structures? */
int pkl_debug_pk_type_data_config_all_set(void *desc, int index, int hist_len, int stats_type)
{
	return 0;
}

int pkl_debug_pk_get_stream_socket(void *desc, int *sock)
{
	*sock = pkl.query_sock;
	return 0;
}

/* Request for a statistics streaming
 * Input		descriptor
 * Input		radio index
 * Input		type of statistics (pktlogger_stat_types).
 * Input		number of statistics blocks
 * Input		flags: 0 - consecutive receiving; 1 - receive since the oldest one
 * Return:		result code (0 - success, <0 - fail)
 */
int pkl_debug_pk_send_stream_request(void *desc, int radio_index, int type, uint16_t history_count, uint32_t flags)
{
	struct pktlogger_net_history_stream_request_t req;

	/* Header */
	pkl_build_net_header(&req.hdr, PKTLOGGER_MSG_DATA_STREAM_REQUEST, sizeof(req) - sizeof(req.hdr));
	/* Payload */
	req.request.radio_index    = htonl(radio_index);
	req.request.type           = htons(type);
	req.request.requestedcount = htons(history_count);
	req.request.flags          = htonl(flags);

	if (sendto(pkl.query_sock, (void *) &req, sizeof(req), 0,
	           (struct sockaddr *)&pkl.pktlogger_d_query_addr, sizeof(struct sockaddr_in)) < 0) {
		PKL_PERROR("PKL LIB: stream req (sendto)");
		return -1;
	}
	return 0;
}

/* Receive statistics chunk
 * Output		data buf
 * Input/Output		Lib client sets max data length it can receive
 *			It is overwritten with the number of received bytes
 * Output		type of received statistics (pktlogger_stat_types)
 * Return:		result code (0 - success, <0 - fail)
 */
int pkl_debug_pk_recv_data(void *desc, uint8_t *data, unsigned int *data_len, int *type)
{
	struct pktlogger_net_history_stream_t *stream;
	int res;

	if (pkl_alloc_rx_buffer((void **)&stream) != 0) {
		*data_len = 0;
		return -1;
	}

	if ((res = pkl_recv_data((void *)stream, PKL_RECV_BUF_MAX_SIZE, PKTLOGGER_MSG_DATA_STREAM)) != 0) {
		free(stream);
		return res;
	}

	if ((stream->hdr.mlen) > 0 && (stream->hdr.mlen <= *data_len)) {
		pkl_ntoh((uint8_t *)&stream->stream, stream->hdr.mlen, PKTLOGGER_MSG_DATA_STREAM);
		memcpy(data, &stream->stream.data[0], stream->hdr.mlen);
		*data_len = stream->hdr.mlen;
		*type = stream->stream.type;
	}
	else
	{
		*data_len = 0;
		*type = PKTLOGGER_MSG_INVALID;
	}

	free(stream);
	return 0;
}

int pkl_debug_pk_stop_stream(void *desc, int radio_index, int type)
{
	return pkl_debug_pk_send_stream_request(desc, radio_index, type, PKTLOGGER_REQ_COUNT_STOP_STREAMING, 0);
}

int pkl_debug_pk_get_compressed_structure(void *desc, uint8_t *lzma_structs, uint32_t *structs_size)
{
	struct pktlogger_net_query_t *nqr;

	PKL_ASSERT(sizeof(*nqr) < PKL_RECV_BUF_MAX_SIZE);
	/* Now pktlogger_net_query_t and lzma structs are expected to be received,
	 * but lzma structs size is unknown.
	 */
	if (pkl_alloc_rx_buffer((void **)&nqr) != 0)
		return -1;

	if (pkl_get_structure(nqr) != 0) {
		free(nqr);
		return -1;
	}

	if (*structs_size < nqr->hdr.mlen) {
		free(nqr);
		return -1;
	}

	*structs_size = nqr->hdr.mlen;
	memcpy(lzma_structs, nqr + 1, nqr->hdr.mlen); /* copy everything following next to nqr->hdr */

	free(nqr);
	return 0;
}

void pkl_debug_pk_verbose_set(void *desc, int level)
{
	pkl.verbose = level;
}

/*
 * 1. Initialize PKL: Allocate and initialize PKL descriptor.
 * 2. Discover LOCAL pktlogger daemon: Look for pktlogger_d via 127.0.0.1.
 *
 * Input:		port to send requests to pktlogger
 * Input/Output:	Archived text file with supported structures
 * Input/Output:	Input - lzma_structs buffer size the client can receive, Output - actual size
 * Output:		result code
 */
int pkl_open(void **desc_pp, int port, uint8_t *lzma_structs, uint32_t *structs_size)
{
	char *addr;

	memset(&pkl, 0, sizeof(pkl));

	/* initialize random seq number */
	srand(time(NULL));
	pkl.seq = rand();

	pkl.verbose = PKL_DBG_ERROR;

	if (pkl_open_udp_query_sockets() != 0) {
		return -1;
	}

	pkl_set_pktlogger_d_address(LOCAL_ADDR, port);

	if (pkl_debug_pk_get_compressed_structure(&pkl, lzma_structs, structs_size) < 0) {
		close(pkl.query_sock);
		return -1;
	}

	/* TODO: Please consider resetting pktlogger's (or pktlogger filter's) parameters to default state for the corner scenario.
	 * 1. client A (qharvest or other instance) starts and discovers pktlogger
	 * 2. client A invokes API to make pktlogger send statistics messages to client A
	 * 3. ... work for a while ...
	 * 4. client A crashes/restarts for some reason
	 * 5. after a while, new client B starts and discovers pktlogger. In general case,
	 *	there can be no distinction between both clients, A and B, from pktlogger (or pktlogger filter) viewpoint.
	 * 6. pktlogger sends statistic to client B, which was originally addressed to client A.
	 */

	*desc_pp = &pkl;
	return 0;
}

/* Release lib resources */
void pkl_close(void *desc)
{
	close(pkl.query_sock);
	desc = NULL;
}
