/*
*******************************************************************************
**                                                                           **
**         Copyright (c) 2016 Quantenna Communications Inc                   **
**                                                                           **
**  File        : pkl_app.c                                                  **
**  Description : Pktlogger Application                                      **
**                                                                           **
*******************************************************************************
*/

#include <assert.h>	/* assert */
#include <errno.h>
#include <linux/udp.h>	/* "struct udphdr" needed by "pktlogger_nl_common.h" */
#include <fcntl.h>	/* open */
#include <net/if.h>	/* IFNAMSIZ */
#include <signal.h>	/* signal */
#include <stdint.h>
#include <stdio.h>	/* fprintf, perror */
#include <stdlib.h>	/* exit */
#include <string.h>	/* strncmp */
#include <sys/select.h>	/* select */
#include <sys/socket.h>	/* socket */
#include <sys/stat.h>	/* open */
#include <sys/types.h>	/* open */
#include <unistd.h>	/* getopt, write */
#include "pkl.h"
#include "pktlogger_nl_common.h"

#define __DPRINTF(fmt, args...)		do {						\
						if (g_verbose)				\
							fprintf(stdout, fmt, ## args);	\
					} while (0)

#define __EPRINTF(fmt, args...)		do {					\
						fprintf(stderr, fmt, ## args);	\
					} while (0)

#define __FILENAME_LEN			64
#define __FILE_BACKUP_COUNT		2

struct user_config_t {
	char radioname[16];
	char type_name[16];
	uint32_t rate;
	uint32_t history;
};

static char g_verbose = 0;

uint8_t g_recv_buf[PKL_RECV_BUF_MAX_SIZE];

#define __DIRNAME_LEN 256
static char g_dirname[__DIRNAME_LEN] = ".";

#define __FILE_SIZE (64 * 1024)
static size_t g_file_size = __FILE_SIZE;

static void *gp_pkl = NULL;

struct pktlogger_config_t g_cfg;

#define __IFNAME "wifi0_0"
static struct user_config_t g_user_cfg[] = {
	// {__IFNAME, "stats", 1, 5},
	// {__IFNAME, "radar", 1, 5},
	// {__IFNAME, "txbf", 1, 5},
	// {__IFNAME, "iwevent", 1, 5},
	{__IFNAME, "sysmsg", 0, 1},
	// {__IFNAME, "mem", 1, 5},
	// {__IFNAME, "rate", 1, 5},
	// {__IFNAME, "phy_stats", 1, 5},
	// {__IFNAME, "dsp_stats", 1, 5},
	// {__IFNAME, "evm_per_tone", 1, 5},
	{__IFNAME, "core_dump", 0, 1},
	{"\0", "\0", 0, 0}, /* Should be the last one */
};

static void config_print_all(struct pktlogger_config_t *p_cfg)
{
	int i, j, num_entries;
	struct pktlogger_radio_config_t *p_radio_cfg;

	assert(p_cfg != NULL);

	for (i = 0; i < PKTLOGGER_MAX_RADIOS; i++) {
		if (!(p_cfg->radio_mask & (1 << i)))
			continue;

		p_radio_cfg = &p_cfg->per_radio[i];
		num_entries = p_radio_cfg->pktlog_ver_cnt & 0xFF;
		__DPRINTF("Current configuration on %s (entries: %d) ->\n",
			(char *) p_radio_cfg->radioname, num_entries);
		for (j = 0; j < num_entries; j++) {
			if (p_radio_cfg->pktlog_configs[j].type != PKTLOGGER_TYPE_UNUSED_0) {
				int enabled = p_radio_cfg->pktlog_configs[j].flags &
						PKTLOGGER_CONFIG_FLAGS_ENABLED;
				__DPRINTF("%16s:\t%10s\t%4d sec rate\t%4d entry history\n",
					(char *) p_radio_cfg->pktlog_configs[j].name,
					enabled ? "enabled" : "disabled",
					p_radio_cfg->pktlog_configs[j].rate,
					p_radio_cfg->pktlog_configs[j].history);
			}
		}
	}
}

static int config_stats_one(struct pktlogger_config_t *p_cfg, struct user_config_t *p_user_cfg,
	int enable)
{
	int i, j, num_entries;
	struct pktlogger_radio_config_t *p_radio_cfg;

	assert(p_cfg != NULL);
	assert(p_user_cfg != NULL);

	for (i = 0; i < PKTLOGGER_MAX_RADIOS; i++) {
		if (!(p_cfg->radio_mask & (1 << i)))
			continue;

		p_radio_cfg = &p_cfg->per_radio[i];
		if (strncmp((char *) p_radio_cfg->radioname, p_user_cfg->radioname,
				sizeof(p_radio_cfg->radioname)))
			continue;

		num_entries = p_radio_cfg->pktlog_ver_cnt & 0xFF;
		for (j = 0; j < num_entries; j++) {
			if (strncmp((char *) p_radio_cfg->pktlog_configs[j].name,
					p_user_cfg->type_name,
					sizeof(p_radio_cfg->pktlog_configs[j].name)))
				continue;

			__DPRINTF("Configuring %s:%s, %s\n", (char *) p_radio_cfg->radioname,
				(char *) p_radio_cfg->pktlog_configs[j].name,
				enable ? "enable" : "disable");
			if (enable) {
				p_radio_cfg->pktlog_configs[j].flags |= PKTLOGGER_CONFIG_FLAGS_ENABLED;
				p_radio_cfg->pktlog_configs[j].rate = p_user_cfg->rate;
				p_radio_cfg->pktlog_configs[j].history = p_user_cfg->history;
			} else {
				p_radio_cfg->pktlog_configs[j].flags &= ~PKTLOGGER_CONFIG_FLAGS_ENABLED;
			}

			return 0;
		}
	}

	return -1;
}

static int config_stats(struct pktlogger_config_t *p_cfg, struct user_config_t *p_user_cfg,
	int enable)
{
	int i, j;

	assert(p_cfg != NULL);
	assert(p_user_cfg != NULL);

	/* Request for the current configuration. */
	if (pkl_debug_pk_config_get(gp_pkl, p_cfg) == -1) {
		__EPRINTF("Can't get pktlogger configuration.\n");
		return -1;
	}

	/* Enable the types requested by the user */
	for (i = 0; p_user_cfg[i].radioname[0]; i++) {
		config_stats_one(p_cfg, &p_user_cfg[i], enable);
	}

	/* Set the configuration */
	if (pkl_debug_pk_config_set(gp_pkl, p_cfg) == -1) {
		__EPRINTF("Can't set pktlogger configuration.\n");
		return -1;
	}

	return 0;
}

static int type_name_to_value(struct pktlogger_config_t *p_cfg, char *p_type_name, int *p_type_value)
{
	int i, j, num_entries;
	struct pktlogger_radio_config_t *p_radio_cfg;

	assert(p_cfg != NULL);
	assert(p_type_name != NULL);
	assert(p_type_value != NULL);

	for (i = 0; i < PKTLOGGER_MAX_RADIOS; i++) {
		if (!(p_cfg->radio_mask & (1 << i)))
			continue;

		/* All radio's would have the same name:value mapping - use the first valid radio */
		p_radio_cfg = &p_cfg->per_radio[i];
		num_entries = p_radio_cfg->pktlog_ver_cnt & 0xFF;
		for (j = 0; j < num_entries; j++) {
			if (strncmp((char *) p_radio_cfg->pktlog_configs[j].name, p_type_name,
					sizeof(p_radio_cfg->pktlog_configs[j].name)))
				continue;

			*p_type_value = p_radio_cfg->pktlog_configs[j].type;
			return 0;
		}
	}

	return -1;
}

static int type_value_to_name(struct pktlogger_config_t *p_cfg, int type_value, char *p_type_name,
	size_t len)
{
	int i, j, num_entries;
	struct pktlogger_radio_config_t *p_radio_cfg;

	assert(p_cfg != NULL);
	assert(p_type_name != NULL);
	assert(len >= 2); /* Atleast 1 byte + '\0' */

	for (i = 0; i < PKTLOGGER_MAX_RADIOS; i++) {
		if (!(p_cfg->radio_mask & (1 << i)))
			continue;

		/* All radio's would have the same name:value mapping - use the first valid radio */
		p_radio_cfg = &p_cfg->per_radio[i];
		num_entries = p_radio_cfg->pktlog_ver_cnt & 0xFF;
		for (j = 0; j < num_entries; j++) {
			if (p_radio_cfg->pktlog_configs[j].type != type_value)
				continue;

			strncpy(p_type_name, (char *) p_radio_cfg->pktlog_configs[j].name, len);
			return 0;
		}
	}

	return -1;
}

static int config_stream(struct pktlogger_config_t *p_cfg, struct user_config_t *p_user_cfg,
	int enable)
{
	int i;

	assert(p_cfg != NULL);
	assert(p_user_cfg != NULL);

	/* Ask pktlogger daemon to start streaming */
	for (i = 0; p_user_cfg[i].radioname[0]; i++) {
		int type = PKTLOGGER_TYPE_UNUSED_0;
		type_name_to_value(p_cfg, p_user_cfg[i].type_name, &type);
		if (enable)
			pkl_debug_pk_send_stream_request(gp_pkl, 0, type,
				PKTLOGGER_REQ_COUNT_WHOLE_HISTORY_AND_REAL_TIME_DATA, 1);
		else
			pkl_debug_pk_stop_stream(gp_pkl, 0, type);
	}

	return 0;
}

static void save_buf(char *p_name, uint8_t *p_buf, size_t len)
{
	char qual_name[__DIRNAME_LEN + 1 + __FILENAME_LEN];
	int fd;
	ssize_t written;

	assert(p_name != NULL);
	assert(p_buf != NULL);
	assert(len != 0);

	snprintf(qual_name, sizeof(qual_name), "%s/%s", g_dirname, p_name);

	fd = creat(qual_name, S_IRUSR | S_IRGRP);
	if (fd == -1) {
		__EPRINTF("Failed to open file (%s), err = %d\n", qual_name, -errno);
		return;
	}
	__DPRINTF("%s created\n", qual_name);

	do {
		written = write(fd, p_buf, len);
		if (written == -1) {
			__EPRINTF("Failed to write to file (%s), err = %d\n", qual_name, -errno);
			break;
		}

		p_buf += written;
		len -= written;
	} while (len);

	close(fd);
}

static void stats_rotate(char *p_name, uint8_t *p_buf, size_t len, int *p_first_run, int *p_ext)
{
	char qual_name[__DIRNAME_LEN + 1 + __FILENAME_LEN + 3]; /* 3 bytes:  ., suffix and '\0' */
	int fd;
	off_t offset;
	ssize_t written;

	assert(p_name != NULL);
	assert(p_buf != NULL);
	assert(len != 0);
	assert(p_first_run != NULL);
	assert(p_ext != NULL);

	snprintf(qual_name, sizeof(qual_name), "%s/%s.%d", g_dirname, p_name, *p_ext);

	if (*p_first_run) {
		*p_first_run = 0;
		fd = creat(qual_name, S_IRUSR | S_IRGRP);
		__DPRINTF("%s created\n", qual_name);
	} else {
		fd = open(qual_name, O_WRONLY | O_APPEND, S_IRUSR | S_IRGRP);
		__DPRINTF("%s appended\n", qual_name);
	}
	if (fd == -1) {
		__EPRINTF("Failed to open file (%s), err = %d\n", qual_name, -errno);
		return;
	}

	offset = lseek(fd, 0, SEEK_END);
	__DPRINTF("offset: %jd\n", (intmax_t)offset);
	if (offset + len > g_file_size) {
		close(fd);
		*p_ext += 1;
		if (*p_ext == __FILE_BACKUP_COUNT)
			*p_ext = 0;

		snprintf(qual_name, sizeof(qual_name), "%s/%s.%d", g_dirname, p_name, *p_ext);

		fd = creat(qual_name, S_IRUSR | S_IRGRP);
		if (fd == -1) {
			__EPRINTF("Failed to create file (%s), err = %d\n", qual_name, -errno);
			return;
		}
		__DPRINTF("%s created\n", qual_name);
	}

	do {
		written = write(fd, p_buf, len);
		if (written == -1) {
			__EPRINTF("Failed to write to file (%s), err = %d\n", qual_name, -errno);
			break;
		}

		p_buf += written;
		len -= written;
	} while (len);

	close(fd);
}

static void save_stats(char *p_filename, uint8_t *p_buf, size_t len)
{
	static int first_run = 1, ext = 0;

	assert(p_filename != NULL);
	assert(p_buf != NULL);
	assert(len != 0);

	stats_rotate(p_filename, p_buf, len, &first_run, &ext);
}

static void save_sysmsg(char *p_filename, uint8_t *p_buf, size_t len)
{
	static int first_run = 1, ext = 0;

	assert(p_filename != NULL);
	assert(p_buf != NULL);
	assert(len != 0);

	stats_rotate(p_filename, p_buf, len, &first_run, &ext);
}

static void sig_handler(int signo)
{
	if (signo == SIGINT) {
		__DPRINTF("Received SIGINT\n");
		/* Release resources. */
		config_stream(&g_cfg, g_user_cfg, 0);
		config_stats(&g_cfg, g_user_cfg, 0);
		pkl_close(gp_pkl);
		exit(0);
	}
}

static void usage(char *argv_0)
{
	__EPRINTF("Usage: %s [options]\n\n", argv_0);
	__EPRINTF("Options:\n");
	__EPRINTF("-d <dir>\t: Directory to save the stats\n");
	__EPRINTF("-i <interface>\t: Wi-Fi interface to enable the stats for\n");
	__EPRINTF("-s <size>\t: Max size of stats file\n\n");
}

/* TODO: Replace (and extend) this with a configuration file */
static int parse_args(int argc, char *argv[])
{
	char ifname[IFNAMSIZ] = __IFNAME;
	int c;
	while ((c = getopt(argc, argv, "d:i:s:v")) != -1) {
		switch(c) {
		case 'd':
			if (strlen(optarg) > sizeof(g_dirname) - 1) {
				__EPRINTF("-d: Exceeds max len (%zu)\n", sizeof(g_dirname) - 1);
				return -1;
			}

			strcpy(g_dirname, optarg);
			break;
		case 'i':
			if (strlen(optarg) > sizeof(ifname) - 1) {
				__EPRINTF("-i: Exceeds max len (%zu)\n", sizeof(ifname) - 1);
				return -1;
			}

			/* Save the ifname */
			int i;
			for (i = 0; g_user_cfg[i].radioname[0]; i++) {
				strcpy(g_user_cfg[i].radioname, optarg);
			}
			strcpy(ifname, optarg);

			break;
		case 's':
			g_file_size = atoi(optarg);
			break;
		case 'v':
			g_verbose = 1;
			break;
		default:
			usage(argv[0]);
			return -1;
			break;
		}
	}

	__EPRINTF("Using options:\n");
	__EPRINTF("\t-d : %s\n", g_dirname);
	__EPRINTF("\t-i : %s\n", ifname);
	__EPRINTF("\t-s : %zu\n\n", g_file_size);

	return 0;
}

int main(int argc, char *argv[])
{
	uint32_t recv_buf_len;
	int core_dump, core_dump_type, stats_socket = -1, sysmsg, sysmsg_type;

	if (parse_args(argc, argv) == -1)
		return -1;

	if (signal(SIGINT, sig_handler) == SIG_ERR)
		__DPRINTF("Can't catch SIGINT\n");

	/* Discover pktlogger daemon. Save the received structure. */
	recv_buf_len = sizeof(g_recv_buf);
	if (pkl_open(&gp_pkl, PKTLOGGER_D_NET_PORT, g_recv_buf, &recv_buf_len) == -1) {
		__EPRINTF("Can't discover pktlogger daemon.\n");
		return -1;
	}
	__DPRINTF("%d bytes of compressed structs were received.\n", recv_buf_len);
	save_buf("qtn_structs_db.bin", g_recv_buf, recv_buf_len);

	pkl_debug_pk_verbose_set(gp_pkl, PKL_DBG_ERROR);

	/* Enable the stats requested by the user */
	if (config_stats(&g_cfg, g_user_cfg, 1) == -1) {
		pkl_close(gp_pkl);
		return -1;
	}

	/* Get the stats and print them */
	if (pkl_debug_pk_config_get(gp_pkl, &g_cfg) == -1) {
		__EPRINTF("Can't get pktlogger configuration.\n");
		pkl_close(gp_pkl);
		return -1;
	}

	config_print_all(&g_cfg);

	/* Receive the pktlogger data */
	pkl_debug_pk_get_stream_socket(gp_pkl, &stats_socket);

	/* Special handling for core_dump and sysmsg types */
	core_dump = type_name_to_value(&g_cfg, "core_dump", &core_dump_type);
	sysmsg = type_name_to_value(&g_cfg, "sysmsg", &sysmsg_type);

	config_stream(&g_cfg, g_user_cfg, 1);

	while (1) {
		char type_name[16] = {0};
		fd_set readfds;
		int type = PKTLOGGER_TYPE_UNUSED_0;

		FD_ZERO(&readfds);
		FD_SET(stats_socket, &readfds);

		int ret = select(stats_socket + 1, &readfds, NULL, NULL, NULL);
		if (ret < 0) {
			perror("pktlogger: select - ");
			config_stream(&g_cfg, g_user_cfg, 0);
			pkl_close(gp_pkl);
			return -1;
		}
		if (ret == 0) {
			__DPRINTF("Timeout - No data received.\n");
			break;
		}

		recv_buf_len = sizeof(g_recv_buf);
		type = PKTLOGGER_TYPE_UNUSED_0;
		pkl_debug_pk_recv_data(gp_pkl, g_recv_buf, &recv_buf_len, &type);
		type_value_to_name(&g_cfg, type, type_name, sizeof(type_name));
		__DPRINTF("Got %d data bytes (type = %d, %s)\n", recv_buf_len, type, type_name);

#define PKTL_HDR_LEN	(sizeof(struct pktlogger_nl_pktlogger_hdr))
		if (!core_dump && core_dump_type == type) {
			/* Skip the header and save */
			save_buf("qtn_core_dump.bin", &g_recv_buf[PKTL_HDR_LEN],
				recv_buf_len - PKTL_HDR_LEN);
		} else if (!sysmsg && sysmsg_type == type) {
			/* Skip the header and save */
			save_sysmsg("qtn_sysmsg.txt", &g_recv_buf[PKTL_HDR_LEN],
				recv_buf_len - PKTL_HDR_LEN);
		} else {
			save_stats("qtn_stats.bin", g_recv_buf, recv_buf_len);
		}
	}

	/* Release resources. */
	config_stream(&g_cfg, g_user_cfg, 0);
	config_stats(&g_cfg, g_user_cfg, 0);
	pkl_close(gp_pkl);

	return 0;
}
