#!/usr/bin/python3

import sys
import argparse
import socket
import select
import datetime
import threading
import traceback
import time
import os
import ipaddress
try:
	import psutil
	print("Using psutil")
except:
	pass
try:
	import netifaces
	print("Using netifaces")
except:
	pass

from pktlogger_lib import *


global_verbose = False
global_client_version = "1.0.1"
global_max_recv_len = 65535

pktlogger_nethdr = """
#define PKTLOGGER_NET_MAGIC 0x706b746c

/* Incoming from network header */
struct pktlogger_net_hdr_t
{
	uint32_t magic;
	uint32_t version;
	uint32_t mtype;
	uint32_t mlen; /* Of the data field only */
	uint32_t mseq;
};

struct pktlogger_pktlog_config_t
{
	uint16_t type;
	uint16_t flags;
	char  name[16];
	uint32_t rate;
	uint32_t history;
	uint16_t struct_bsize;
	uint16_t struct_vsize;
};

struct pktlogger_config_t
{
	uint32_t rev;
	uint32_t rcontrol;
	struct pktlogger_radio_config_t per_radio[3];
};

struct pktlogger_radio_config_t
{
	uint32_t destip;
	uint32_t srcip;
	uint8_t  destmac[6];
	uint8_t  srcmac[6];
	uint16_t destport;
	uint16_t srcport;
	uint32_t pktlog_ver_cnt;
	char  radioname[16];
	struct pktlogger_pktlog_config_t pktlog_configs[16];
};

struct pktlogger_net_config_t
{
	struct pktlogger_net_hdr_t hdr;
	struct pktlogger_config_t config;
};


struct pktlogger_net_query_one_t
{
	struct pktlogger_net_hdr_t hdr;
	uint32_t radio_index;
	uint32 type;
};

struct pktlogger_config_one_t
{
	uint32_t radio_index;
	struct pktlogger_pktlog_config_t config;
};

struct pktlogger_net_config_one_t
{
	struct pktlogger_net_hdr_t hdr;
	struct pktlogger_config_one_t config;
};


struct pktlogger_net_query_t
{
	struct pktlogger_net_hdr_t hdr;
};

struct pktlogger_history_stream_request_t
{
	uint32_t radio_index;
	uint16_t type;
	uint16_t requestedcount;
	uint32_t flags;
};

struct pktlogger_net_history_stream_request_t
{
	struct pktlogger_net_hdr_t hdr;
	struct pktlogger_history_stream_request_t request;
};

struct pktlogger_history_stream_t
{
	uint32_t radio_index;
	uint16_t type;
	uint16_t totalcount;
	uint16_t samplenum;
	uint16_t requestedcount;
	uint8_t data[0];
};

struct pktlogger_net_history_stream_t
{
	struct pktlogger_net_hdr_t hdr;
	struct pktlogger_history_stream_t stream;
};

enum pktlogger_net_message
{
	PKTLOGGER_MSG_STRUCT_INVALID,
	PKTLOGGER_MSG_STRUCT_REQUEST,
	PKTLOGGER_MSG_STRUCT_RESPONSE,
	PKTLOGGER_MSG_CONFIG_SET,
	PKTLOGGER_MSG_CONFIG_REQUEST,
	PKTLOGGER_MSG_CONFIG_RESPONSE,
	PKTLOGGER_MSG_CONFIG_ONESET = 10,
	PKTLOGGER_MSG_CONFIG_ONEREQUEST,
	PKTLOGGER_MSG_CONFIG_ONERESPONSE,
	PKTLOGGER_MSG_CONFIG_DATA_STREAM_REQUEST = 13,
	PKTLOGGER_MSG_CONFIG_DATA_STREAM   = 14,
	PKTLOGGER_MSG_MAX_TYPE,
};

#endif
"""

msg_to_enum = {	"PKTLOGGER_MSG_STRUCT_REQUEST":1,
		"PKTLOGGER_MSG_STRUCT_RESPONSE":2,
		"PKTLOGGER_MSG_CONFIG_SET":3,
		"PKTLOGGER_MSG_CONFIG_REQUEST":4,
		"PKTLOGGER_MSG_CONFIG_RESPONSE":5,
		"PKTLOGGER_MSG_CONFIG_ONESET":10,
		"PKTLOGGER_MSG_CONFIG_ONEREQUEST":11,
		"PKTLOGGER_MSG_CONFIG_ONERESPONSE":12,
		"PKTLOGGER_MSG_DATA_STREAM_REQUEST":13,
		"PKTLOGGER_MSG_DATA_STREAM":14,
}

enum_to_clsname = {	1: "pktlogger_net_query_t",
			2: "pktlogger_net_query_t",
			3: "pktlogger_net_config_t",
			4: "pktlogger_net_query_t",
			5: "pktlogger_net_config_t",
			10: "pktlogger_net_config_one_t",
			11: "pktlogger_net_query_one_t",
			12: "pktlogger_net_config_one_t",
			13: "pktlogger_net_history_stream_request_t",
			14: "pktlogger_net_history_stream_t",
}

enum_to_msg = {}

def maclisttostring(list):
	return "%02X:%02X:%02X:%02X:%02X:%02X" %(list[0],list[1],list[2],list[3],list[4],list[5])

def bytetostring(bstring):
	return bstring.split(b'\0',1)[0].decode('utf-8')

def multi_getattr(obj, attr, default = None):
	"""
	Get a named attribute from an object; multi_getattr(x, 'a.b.c.d') is
	equivalent to x.a.b.c.d. When a default argument is given, it is
	returned when any attribute in the chain doesn't exist; without
	it, an exception is raised when a missing attribute is encountered. 
	"""
	attributes = attr.split(".")
	for i in attributes:
		try:
			obj = getattr(obj, i)
		except AttributeError:
			if default:
				return default
			else:
				raise
	return obj

class PktloggerMessageFactory:
	def __init__(self):
		#self.pktlogger_structs = pktlogger_lib.NDBClasses(header_string = pktlogger_nethdr)
		self.pktlogger_structs = NDBClasses(header_string = pktlogger_nethdr)

	def get_struct(self, structname, bytespacked = None):
		if structname in self.pktlogger_structs.all_classes:
			ts = self.pktlogger_structs.all_classes[structname]
			#print(structname, ts)
			ret = ts()
			if bytespacked:
				ret.unpack(bytespacked[0:len(ts)])
			return ret

# Messages passed across the network - between the embedded device and this program.
class NetdebugMessageFactory:
	def __init__(self):
		# Parse the structures using standard class
		self.pktlogger_structs = NDBClasses(header_string = pktlogger_nethdr)
		self.pktlogger_net_hdr_t = self.pktlogger_structs.all_classes['pktlogger_net_hdr_t']
		self.pktlogger_net_query_t = self.pktlogger_structs.all_classes['pktlogger_net_query_t']
		self.pktlogger_net_query_one_t = self.pktlogger_structs.all_classes['pktlogger_net_query_one_t']
		self.pktlogger_net_config_t = self.pktlogger_structs.all_classes['pktlogger_net_config_t']
		self.pktlogger_config_t = self.pktlogger_structs.all_classes['pktlogger_config_t']
		#self.pktlogger_net_config_one_t = self.pktlogger_structs.all_classes['pktlogger_net_config_one_t']
		self.pktlogger_config_one_t = self.pktlogger_structs.all_classes['pktlogger_config_one_t']
		self.pktlogger_pktlog_config_t = self.pktlogger_structs.all_classes['pktlogger_pktlog_config_t']
		self.enum_to_cls = self.configure_cls_enums()
		self.cls_to_enum = self.configure_enum_cls(self.enum_to_cls)
		if global_verbose > 1:
			print(self.cls_to_enum)
			print(self.enum_to_cls)
		for msg, enum in msg_to_enum.items():
			enum_to_msg[enum] = msg
		if global_verbose > 1:
			print("Pktlogger structs are: ")
			for st in self.pktlogger_structs.all_classes:
				print(st, len(self.pktlogger_structs.all_classes[st]()))

	def configure_enum_cls(self, enum_to_cls):
		ret = {}
		for ptype, cls in enum_to_cls.items():
			ret[cls] = ptype
		return ret

	def configure_cls_enums(self):
		global enum_to_clsname
		ret = {}
		for key, value in enum_to_clsname.items():
			this_class = self.pktlogger_structs.all_classes[value]
			ret[key] = this_class
		return ret

	def decap_msg(self, payload):
		if len(payload) >= len(self.pktlogger_net_hdr_t):
			#hdr = self.pktlogger_net_hdr_t()()
			hdr = self.get_struct("pktlogger_net_hdr_t")
			#print(hdr)
			hdr.unpack(payload[0:len(hdr)])
			if global_verbose > 2:
				print(hdr)
			msg_type = socket.htonl(hdr.mtype)
			#print("msg type %d" % msg_type)
			if msg_type in self.enum_to_cls:
				this_msg_obj = self.enum_to_cls[msg_type]()
				this_msg_obj.unpack(payload)
				return this_msg_obj
		return None

	def query_to_enum(self, qs):
		if qs in msg_to_enum:
			return msg_to_enum[qs]
		raise Exception("Unknown query type %s" % qs)

	def get_struct(self, structname, bytespacked = None):
		if structname in self.pktlogger_structs.all_classes:
			ts = self.pktlogger_structs.all_classes[structname]
			#print(structname, ts)
			ret = ts()
			if bytespacked:
				ret.unpack(bytespacked[0:len(ts)])
			return ret

	# Network query - example: query the structures supported on the embedded device
	def struct_query(self):
		return self.pktlogger_net_query_t

	def struct_query_one(self):
		return self.pktlogger_net_query_one_t

	def struct_config(self):
		return self.pktlogger_config_t

	def struct_config_one(self):
		return self.pktlogger_net_config_one_t

	# Network header - common header across all network messages
	def struct_hdr(self):
		return self.pktlogger_net_hdr_t

	def get_struct_net_hdr(self, payload):
		x = self.pktlogger_net_hdr_t()
		x.unpack(payload[0:len(self.pktlogger_net_hdr_t)])
		return x

	def get_struct_pktlogger_pktlog_config_t(self):
		return self.pktlogger_pktlog_config_t

	def add_net_header(self, s, seq, mtype):
		s.hdr = self.get_struct("pktlogger_net_hdr_t")
		s.hdr.magic = socket.htonl(self.net_magic())
		s.hdr.version = socket.htonl(0)
		s.hdr.mlen = socket.htonl(len(s) - len(s.hdr))
		s.hdr.mseq = socket.htonl(seq)
		s.hdr.mtype = socket.htonl(self.query_to_enum(mtype))

	def get_struct_query(self, seq, query_type):
		struct_config_query = self.struct_query()(hdr = self.struct_hdr()())
		struct_config_query.hdr.magic = socket.htonl(self.net_magic())
		struct_config_query.hdr.version = socket.htonl(0)
		struct_config_query.hdr.mlen = socket.htonl(0)
		struct_config_query.hdr.mseq = socket.htonl(seq)
		struct_config_query.hdr.mtype = socket.htonl(self.query_to_enum(query_type))
		msg = struct_config_query.pack()
		return msg

	def get_struct_query_one(self, seq, query_type, radio, ptype):
		struct_config_query_one = self.struct_query_one()(hdr = self.struct_hdr()(), type = socket.htonl(ptype), radio_index = socket.htonl(radio))
		struct_config_query_one.hdr.magic = socket.htonl(self.net_magic())
		struct_config_query_one.hdr.version = socket.htonl(0)
		struct_config_query_one.hdr.mlen = socket.htonl(8)
		struct_config_query_one.hdr.mseq = socket.htonl(seq)
		struct_config_query_one.hdr.mtype = socket.htonl(self.query_to_enum(query_type))
		msg = struct_config_query_one.pack()
		return msg

	# Message received from somewhere, turn it into an internal structure which can
	# be accessed.
	def decap_varmsg(self, msg):
		# Figure out the message type then go from there
		# ALL network queries have the pktlogger_net_hdr_t as the first element
		qr = self.pktlogger_net_hdr_t(msg[0:len(self.pktlogger_net_hdr_t)])
		payload = msg[len(self.pktlogger_net_hdr_t):]
		if socket.htonl(qr.mtype) == 1:
			qr = self.pktlogger_net_query_t(msg[0:len(self.pktlogger_net_query_t)])
		return qr, payload

	def net_magic(self):
		return 0x706b746c

# Class encapsulating a single radio configuration.
# Each instance of this class represents a single pktlogger_radio_config_t structure.
class PktloggerRadioConfig:
	def __init__(self, nmf, bytespacked=None, unpacked=None):
		self.nmf = nmf
		self.radioname = "unknown"
		self.typeidxs = []
		if bytespacked:
			self.uc = self.unpack_config(bytespacked)
		else:
			self.uc = unpacked
		if global_verbose > 1:
			print(self.pack_config())
		self.d, self.ts2ti = self.unpack_dict(self.uc)

	def name(self):
		return self.radioname

	def set_dest_ip(self, new_ip):
		# Set IP dest, reconfigure
		pass

	def set_dest_mac(self, new_mac):
		pass

	def set_config(self, the_config):
		pass

	def unpack_config(self, radio_config):
		struct_radio_config = self.nmf.get_struct("pktlogger_radio_config_t")
		if global_verbose > 1:
			print(radio_config, len(radio_config))
		struct_radio_config.unpack(radio_config)
		if global_verbose > 1:
			print(struct_radio_config)
		return struct_radio_config

	def unpack_dict(self, config):
		ret = {}
		ts2ti = {}
		radio_configs = {}
		self.radioname = bytetostring(config.radioname)
		ret["rname"] = self.radioname
		ret["destip"] = config.destip
		ret["srcip"] = config.srcip
		ret["destmac"] = config.destmac
		ret["srcmac"] = config.srcmac
		ret["destport"] = config.destport
		ret["srcport"] = config.srcport
		ret["pktlog_ver_cnt"] = socket.htonl(config.pktlog_ver_cnt)
		num_entries = ret["pktlog_ver_cnt"] & 0xFF
		if global_verbose > 1:
			print("Num entries %d" % num_entries)
		for i in range(0, num_entries):
			c = PktloggerConfig(self.nmf, unpacked = config.pktlog_configs[i])
			radio_configs[c.typeval()] = c
			ts2ti[c.name()] = c.typeval()
			if global_verbose > 2:
				print("ts2ti:", ts2ti)
			self.typeidxs.append(c.typeval())
		ret["pktlog_configs"] = radio_configs
		return ret, ts2ti

	def get_config(self, typestring):
		if global_verbose > 3:
			print("get_config: %s" % typestring)
			print(self.ts2ti)
		if typestring in self.ts2ti:
			if global_verbose > 3:
				print("Type found")
			typeidx = self.ts2ti[typestring]
			return self.d["pktlog_configs"][typeidx]
		return None

	def configure_pktlogger(self, typestring, enable, rate):
		if global_verbose > 1:
			print("Configuring type %s (%s, rate %s)" % (typestring, enable, rate))
		this_config = self.get_config(typestring)
		if this_config:
			this_config.conf(enable, rate)

	def get_pktlogger_configs(self):
		return self.d["pktlog_configs"]

	def set_pktlogger_configs(self, configs):
		self.d["pktlog_configs"] = configs

	def pack_dict(self):
		cd = self.d
		c = self.uc
		c.destip = cd["destip"]
		c.srcip = cd["srcip"]
		c.destmac = cd["destmac"]
		c.srcmac = cd["srcmac"]
		c.destport = cd["destport"]
		c.srcport = cd["srcport"]
		c.pktlog_ver_cnt = socket.ntohl(cd["pktlog_ver_cnt"])
		conf_dict = self.get_pktlogger_configs()
		for i in range(0, len(self.typeidxs)):
			if global_verbose > 2:
				print("XXX packing %d (%d)" %(i, self.typeidxs[i]))
			this_config = conf_dict[self.typeidxs[i]]
			if global_verbose > 2:
				print("this config:", this_config)
			c.pktlog_configs[i] = this_config.pack_dict()
		return c

	def pack_config(self):
		if global_verbose > 2:
			print("Pack:")
			print(self.uc)
		b = self.uc.pack()
		if global_verbose > 2:
			print("Byte rep:")
			print(b)
		return b

	def print(self):
		print("->radio %s" % self.radioname)
		d = self.d
		print(" ->ip dest: %s, src: %s, MAC dest: %s, MAC src: %s, UDP dest port: %d, UDP src port: %d" %(ipaddress.ip_address(socket.htonl(d["destip"])), ipaddress.ip_address(socket.htonl(d["srcip"])), maclisttostring(d["destmac"]), maclisttostring(d["srcmac"]), socket.htons(d["destport"]), socket.htons(d["srcport"])))
		for typeint, pc in d["pktlog_configs"].items():
			pc.print()

# Class encapsulating the underlying pktlogger config.
# Each instance of this class represents a single pktlogger_pktlog_config_t structure.
# The class deals with packing and unpacking the structure, and retains the values
# internally in a dictionary which is easily manipulated.
class PktloggerConfig:
	def __init__(self, nmf, bytepacked=None, unpacked=None):
		self.nmf = nmf
		if bytepacked:
			self.uc = self.unpack_config(bytepacked)
		else:
			self.uc = unpacked
		if global_verbose > 2:
			print(self.uc)
		self.d = self.unpack_dict(self.uc)

	def name(self):
		return self.d["name"]

	def typeval(self):
		return self.d["type"]

	def conf(self, enablestring, ratestring):
		do_enable = False
		if enablestring != "enable" and enablestring != "disable":
			raise Exception
		if enablestring == "enable":
			do_enable = True
		if do_enable:
			self.enable()
		else:
			self.disable()
		if ratestring:
			rate = eval(ratestring)
			self.set_rate(rate)

	def disable(self):
		new_flags = self.d["flags"] & ~0x1
		self.d["flags"] = 0
		if global_verbose > 1:
			print("New flags %d" % new_flags)

	def enable(self):
		new_flags = self.d["flags"] | 0x1
		self.d["flags"] = 0x1 #new_flags
		if global_verbose > 1:
			print("New flags %d" % new_flags)

	def set_rate(self, rate):
		self.d["rate"] = rate
		self.pack_config()

	def set_history(self, history):
		self.d["history"] = history

	def unpack_config(self, packet_config):
		struct_pklog_config = self.nmf.get_struct_pktlogger_pktlog_config_t()()
		if global_verbose > 2:
			print(packet_config, len(packet_config))
		struct_pklog_config.unpack(packet_config)
		if global_verbose > 2:
			print(struct_pklog_config)
		return struct_pklog_config

	def unpack_dict(self, config):
		ret = {}
		ret["type"] = socket.ntohs(config.type)
		ret["rate"] = socket.ntohl(config.rate)
		ret["flags"] = socket.ntohs(config.flags)
		ret["struct_bsize"] = socket.ntohs(config.struct_bsize)
		ret["struct_vsize"] = socket.ntohs(config.struct_vsize)
		ret["name"] = bytetostring(config.name)
		ret["history"] = socket.ntohl(config.history)
		return ret

	def pack_dict(self):
		cd = self.d
		c = self.uc
		c.rate = socket.htonl(cd["rate"])
		c.flags = socket.htons(cd["flags"])
		c.history = socket.htonl(cd["history"])
		return c

	def pack_config(self):
		if global_verbose > 2:
			print("Pack:")
			print(self.uc)
		b = self.uc.pack()
		if global_verbose > 2:
			print("Byte rep:")
			print(b)
		return b

	def print(self):
		d = self.d
		enabled = "disabled"
		var = "fixed"
		this_flags = d["flags"]
		if this_flags & 0x1:
			enabled = "enabled"
		if this_flags & 0x2:
			var = "variable(%d bytes per field)" % d["struct_vsize"]
		if this_flags & 0x4:
			var = "variable(string array)"
		print("  ->type %d (%s): state: %s, period: %d, history: %d, structure size %d, %s structure" %(d["type"], d["name"], enabled, d["rate"], d["history"], d["struct_bsize"], var))


# Netdebug structures - received from embedded device on the network
class NetdebugStructFactory:
	def __init__(self, ndb):
		self.ndb = ndb
		self.pktlogger_hdr = self.ndb.all_classes['qdrv_pktlogger_hdr']

	def payload_to_header(self, payload):
		return payload[0:len(self.pktlogger_hdr)]

	def parse_ph(self, payload):
		thishdr = self.pktlogger_hdr(self.payload_to_header(payload))
		if thishdr.type in self.ndb.idx_to_cls:
			if global_verbose > 1:
				print("Got header for type %d" % thishdr.type)
			if thishdr.type in self.ndb.special_ndb_indices:
				# Variable length structure - find appropriate dynamic class
				if global_verbose:
					print("Dynamic class required for NDB type %d" % thishdr.type)
				newclass = self.ndb.make_ndb_varstruct(self.ndb.idx_to_cls[thishdr.type], payload, len(payload) - len(thishdr))
				if newclass != None:
					if global_verbose:
						print("Class for this payload len %d type %d" %(len(payload) - len(thishdr), thishdr.type))
						print(newclass, len(newclass), len(payload))
					return thishdr, newclass(payload)
			if len(self.ndb.idx_to_cls[thishdr.type]) != len(payload):
				if global_verbose:
					print("XXX! payload len wrong (exp: %d, got %d)" %(len(self.ndb.idx_to_cls[thishdr.type]), len(payload)))
					if global_verbose > 1:
						print(payload)
				return thishdr, None
			return thishdr, self.ndb.idx_to_cls[thishdr.type](payload)
		else:
			print("Can't find header for pktlogger type %d" % thishdr.type)
		return thishdr, None

# Collect a series of samples, then dump out header + samples on demand
class NetdebugStructHistory:
	def __init__(self, ndb, structname, outdir, base_structname, max_samples = 3600):
		self.samples = []
		self.structname = structname
		self.outdir = outdir
		self.base_structname = base_structname
		self.max_samples = max_samples
		self.last_sample = None
		self.ndb = ndb
		self.is_vararray = self.ndb.cls_to_idx[self.ndb.all_ndb_classes[base_structname]] in self.ndb.vararray_indices
		#self.ndbsa = pktlogger_lib.NDBStructAdapter(self.ndb)
		#self.ndstg = pktlogger_lib.NetdebugStructTransformerGeneric(self.ndbsa, self.structname)
		self.ndbsa = NDBStructAdapter(self.ndb)
		self.ndstg = NetdebugStructTransformerGeneric(self.ndbsa, self.structname)
		self.sample_count = 0
		if not os.path.exists(outdir):
			os.mkdir(outdir)
		if not os.path.isdir(outdir):
			outdir = "%s-1" % outdir
			os.mkdir(outdir)
		self.filename, self.fd = self.file_open(self.outdir, self.base_structname)
		self.header_written = False

	def get_datestamp(self):
		x = datetime.datetime.now()
		return "%d-%d-%d.%d-%d-%d" %(x.year,x.month,x.day,x.hour,x.minute,x.second)

	def file_open(self, outdir, structname):
		global global_client_version
		t = self.get_datestamp()
		filename = "%s%snetdebug-%s-%s.csv" %(outdir, os.path.sep, structname, t)
		fd = open(filename, 'w+')
		fd.write("Pktlogger client version %s. File generated on %s\n" % (global_client_version, t))
		return filename, fd

	def add_sample(self, hdr, payload, structname):
		if self.is_vararray and self.last_sample and (len(self.last_sample) != len(payload)):
			#self.ndstg = pktlogger_lib.NetdebugStructTransformerGeneric(self.ndbsa, structname)
			self.ndstg = NetdebugStructTransformerGeneric(self.ndbsa, structname)
			# Force new header when the data payload changes size - ie, dynamic arrays
			self.header_written = False
		self.samples.append(payload)
		self.dump_samples()
		self.last_sample = payload

	def dump_header(self):
		str = ""
		top_csv = self.ndstg.all_csv_hdrs()
		for line in top_csv:
			str = str + line + "\n"
		return str

	def dump_samples(self):
		if not self.header_written:
			self.fd.write(self.dump_header())
			self.header_written = True
		for sample in self.samples:
			self.fd.write(self.ndstg.dump_sample(sample) + "\n")
		self.fd.flush()
		self.clear_samples()
		self.sample_count += 1
		if self.sample_count >= self.max_samples:
			self.fd.close()
			self.filename, self.fd = self.file_open(self.outdir, self.base_structname)
			self.sample_count = 0
			self.header_written = False

	def clear_samples(self):
		self.samples = []

class NetdebugDeviceStream:
	def __init__(self, nmf, config, nsf, ipaddr = None, cport = None):
		self.nmf = nmf
		self.nsf = nsf
		self.config = config
		self.ipaddr = ipaddr
		self.cport = cport

		self.seq = 92000

		self.net_config_active = (ipaddr != None)

		if self.net_config_active:
			self.config_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
			self.config_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
			self.config_sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
			self.config_sock.setblocking(0)

	def queue_and_send(self, msg, seq):
		if self.net_config_active:
			self.config_sock.sendto(msg, (self.ipaddr, self.cport))

	# Wait for the response from the underlying transport mechanism.
	# Returns a tuple of payload (with transport header stripped) + src address (transport specific address format)
	def wait_for_response(self, seq, timeout):
		if self.net_config_active:
			ready = select.select([self.config_sock], [], [], timeout)
			if ready[0]:
				payload, src = self.config_sock.recvfrom(global_max_recv_len)
				nmh = self.nmf.get_struct_net_hdr(payload)
				if socket.ntohl(nmh.mseq) == seq:
					return payload[len(nmh):], src
				if global_verbose:
					print("No match for seq (got %d, exp %d)" %(socket.ntohl(nmh.mseq), seq))
			elif global_verbose:
				print("Timeout waiting for response")
		return None, None

	def stream(self, radiostring, typestring, historystring):
		radio = self.config.radio_to_index[radiostring]
		type = self.config.type_radio_to_int(radiostring, typestring)
		history = eval(historystring)
		seq = self.seq
		self.seq += 1
		msg = self.prepare_stream_req(radio, type, history, seq)
		if global_verbose > 2:
			print(msg, len(msg), msg.pack())
		self.queue_and_send(msg.pack(), seq)
		print("seq %d" % seq)
		for i in range(0, history):
			payload, src = self.wait_for_response(seq, 5)
			if payload != None:
				dsh = self.nmf.get_struct("pktlogger_history_stream_t")
				dsh.unpack(payload[0:len(dsh)])
				#print(dsh, len(dsh))
				print("!!!!Received payload OK (%d of %d)" % (socket.ntohs(dsh.samplenum), socket.ntohs(dsh.requestedcount)))
				pkhdr = payload[len(dsh)-1:]
				#print(pkhdr[0:64])
				hdr, payload2 = self.nsf.parse_ph(pkhdr)
				print(hdr)
			else:
				print("No data received - try later")
				break

	def prepare_stream_req(self, radio, type, history_count, seq):
		request = self.nmf.get_struct("pktlogger_history_stream_request_t")
		request.radio_index = socket.htonl(radio)
		request.type = socket.htons(type)
		request.requestedcount = socket.htons(history_count)
		# Flag 0x1 - reset the stream
		request.flags = socket.htonl(0x1)
		#request.flags = 0x0

		# Encapsulate with appropriate wrapper
		if self.net_config_active:
			net_wrapper = self.nmf.get_struct("pktlogger_net_history_stream_request_t")
			net_wrapper.request = request
			self.nmf.add_net_header(net_wrapper, seq, "PKTLOGGER_MSG_DATA_STREAM_REQUEST")
			#net_wrapper.pack()
			return net_wrapper
		return None

	def unpack_stream(self, rbytes):
		# Create radio object for each interface present.
		# Each radio config will then create container objects for the pktlogger configs
		radios = {}
		radio_to_index = {}
		rc = self.nmf.get_struct("pktlogger_config_t", bytespacked = rbytes)
		if global_verbose > 1:
			print(rc)
		if rc:
			radios_present = socket.ntohl(rc.rcontrol)
			rev = socket.ntohl(rc.rev)
			if global_verbose > 1:
				print("Radios present mask %x, rev %d" %(radios_present, rev))
			radio_index = 0
			empty_radios = []
			while radios_present or radio_index < 3:
				if radios_present & 0x1:
					if global_verbose > 1:
						print("Creating radio config for index %d" % radio_index)
					r = PktloggerRadioConfig(self.nmf, unpacked = rc.per_radio[radio_index])
					# name to object dictionary
					radios[r.radioname] = r

					radio_to_index[r.radioname] = radio_index
				else:
					r = PktloggerRadioConfig(self.nmf, unpacked = rc.per_radio[radio_index])
					empty_radios.append(r)
				radio_index += 1
				radios_present >>= 1
		return radios, radio_to_index, empty_radios

class NetdebugDeviceConfiguration:
	def __init__(self, nmf, ipaddr = None, cport = None):
		self.ipaddr = ipaddr
		#self.sport = 29041
		self.cport = cport
		self.nmf = nmf
		self.seq = 20901
		self.configs = {0:{},1:{},2:{}}
		self.radio_to_index = {}

		self.net_config_active = (ipaddr != None)

		if self.net_config_active:
			self.config_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
			self.config_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
			self.config_sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
			self.config_sock.setblocking(0)
			#self.config_sock.bind(('', self.sport))

	def type_radio_to_int(self, radiostring, typestring):
		plc = self.find_pkl_config(radiostring, typestring)
		return plc.typeval()

	def unpack_single_config(self, rbytes):
		# Outer wrapper for the radio
		nc = self.nmf.get_struct("pktlogger_config_one_t", bytespacked = rbytes)
		if nc:
			c = PktloggerConfig(self.nmf, unpacked = nc.config)
			return c

	def unpack_config(self, rbytes):
		# Create radio object for each interface present.
		# Each radio config will then create container objects for the pktlogger configs
		radios = {}
		radio_to_index = {}
		rc = self.nmf.get_struct("pktlogger_config_t", bytespacked = rbytes)
		if global_verbose > 1:
			print(rc)
		if rc:
			radios_present = socket.ntohl(rc.rcontrol)
			rev = socket.ntohl(rc.rev)
			if global_verbose > 1:
				print("Radios present mask %x, rev %d" %(radios_present, rev))
			radio_index = 0
			empty_radios = []
			while radios_present or radio_index < 3:
				if radios_present & 0x1:
					if global_verbose > 1:
						print("Creating radio config for index %d" % radio_index)
					r = PktloggerRadioConfig(self.nmf, unpacked = rc.per_radio[radio_index])
					# name to object dictionary
					radios[r.radioname] = r

					radio_to_index[r.radioname] = radio_index
				else:
					r = PktloggerRadioConfig(self.nmf, unpacked = rc.per_radio[radio_index])
					empty_radios.append(r)
				radio_index += 1
				radios_present >>= 1
		return radios, radio_to_index, empty_radios

	def query(self):
		seq = self.seq
		self.seq += 1
		msg = self.nmf.get_struct_query(seq, "PKTLOGGER_MSG_CONFIG_REQUEST")
		self.queue_and_send(msg, seq)
		payload, src = self.wait_for_response(seq, 5)
		if payload:
			self.radios, self.radio_to_index, self.empty_radios = self.unpack_config(payload)
			return self.radios
		print("NO return from query")
		print(payload, src)
		return None

	def queue_and_send(self, msg, seq):
		if self.net_config_active:
			self.config_sock.sendto(msg, (self.ipaddr, self.cport))

	# Wait for the response from the underlying transport mechanism.
	# Returns a tuple of payload (with transport header stripped) + src address (transport specific address format)
	def wait_for_response(self, seq, timeout):
		if self.net_config_active:
			ready = select.select([self.config_sock], [], [], timeout)
			if ready[0]:
				payload, src = self.config_sock.recvfrom(global_max_recv_len)
				nmh = self.nmf.get_struct_net_hdr(payload)
				if socket.ntohl(nmh.mseq) == seq:
					return payload[len(nmh):], src
				if global_verbose:
					print("No match for seq (got %d, exp %d)" %(socket.ntohl(nmh.mseq), seq))
			elif global_verbose:
				print("Timeout waiting for response")
		return None, None


	def query_one(self, radio, ptype):
		seq = self.seq
		self.seq += 1
		msg = self.nmf.get_struct_query_one(seq, "PKTLOGGER_MSG_CONFIG_ONEREQUEST", radio, ptype)
		self.queue_and_send(msg, seq)
		payload, src = self.wait_for_response(seq, 5)
		output = self.unpack_single_config(payload)
		if output.typeval() not in self.configs[radio]:
			self.configs[radio][output.typeval()] = output
		return output

	def find_pkl_config(self, radiostring, typestring):
		radio_idx = self.radio_to_index[radiostring]
		if global_verbose > 2:
			print("finding %s on %s" % (typestring, radiostring))
		ret = self.radios[radiostring].get_config(typestring)
		if global_verbose > 2:
			print("ret %s" % ret)
		return ret

	def pktlogger_enable(self, radiostring, typestring):
		the_config = self.find_pkl_config(radiostring, typestring)
		the_config.enable()
		self.set_one(radiostring, the_config)

	# Take current all radio config and apply in one message
	def set_all(self):
		seq = self.seq
		seq += 1
		radio_structs = []
		radiocount = 0
		radioflags = 0
		for radioidx, radiocfg in self.radios.items():
			if global_verbose:
				print("Packing radio %s" % radiocfg.name())
			this_radio = radiocfg.pack_dict()
			radioflags |= 1<<radiocount

			radiocount += 1
			radio_structs.append(this_radio)

		config_struct = self.nmf.get_struct("pktlogger_config_t")
		config_struct.rev = 0
		config_struct.rcontrol = socket.htonl(radioflags)
		config_struct.per_radio = []
		for i in range(0, 3):
			if len(radio_structs) > i:
				config_struct.per_radio.append(radio_structs[i])
			else:
				config_struct.per_radio.append(self.empty_radios[0].pack_dict())
		if global_verbose > 2:
			print("Pre-encap pkt:")
			print(config_struct)
			print(config_struct.pack())
		if self.net_config_active:
			net_wrapper = self.nmf.get_struct("pktlogger_net_config_t")
			net_wrapper.config = config_struct
			self.nmf.add_net_header(net_wrapper, seq, "PKTLOGGER_MSG_CONFIG_SET")
			if global_verbose > 2:
				print("Full pkt:")
				print(net_wrapper)
				print(net_wrapper.pack())
			self.queue_and_send(net_wrapper.pack(), seq)

	def set_one(self, radiostring, the_config):
		seq = self.seq
		self.seq += 1
		radio_index = self.radio_to_index[radiostring]

		# Prepare the underlying config structure
		one_config = self.nmf.get_struct("pktlogger_config_one_t")
		# Fill in the new config values
		one_config.config = the_config.pack_dict()
		one_config.radio_index = socket.htonl(radio_index)

		# Encapsulate with appropriate wrapper
		if self.net_config_active:
			net_wrapper = self.nmf.get_struct("pktlogger_net_config_one_t")
			net_wrapper.config = one_config
			self.nmf.add_net_header(net_wrapper, seq, "PKTLOGGER_MSG_CONFIG_ONESET")
			net_wrapper.pack()
			if global_verbose > 2:
				print(net_wrapper, len(net_wrapper), net_wrapper.pack())
			self.queue_and_send(net_wrapper.pack(), seq)

	def pktlogger_configure_one(self, radiostring, typestring, enablestring, ratestring, historystring = None):
		if radiostring in self.radios:
			the_config = self.find_pkl_config(radiostring, typestring)
			if enablestring == "enable":
				if global_verbose:
					print("Enabling %s (%s)" % (typestring, typestring))
				the_config.enable()
			else:
				if global_verbose:
					print("Disabling %s (%s)" % (typestring, typestring))
				the_config.disable()
			if ratestring:
				rate = eval(ratestring)
				the_config.set_rate(rate)
			if historystring:
				history = eval(historystring)
				the_config.set_history(history)
			self.set_one(radiostring, the_config)

	def pktlogger_configure_all(self, radiostring, typestring, enablestring, ratestring):
		if radiostring in self.radios:
			this_radio = self.radios[radiostring]
			this_radio.configure_pktlogger(typestring, enablestring, ratestring)
			self.set_all()

	def print(self):
		print("Device IP %s" % self.ipaddr)
		for radioname, radioconfig in self.radios.items():
			radioconfig.print()

# Single device found on the network - listen and parse any netdebug structures received.
class NetdebugDevice(threading.Thread):
	def __init__(self, addr, query_response, nmf):
		self.ipaddr = addr[0]
		self.port = addr[1]
		# Pktlogger sends to this port and IP address is bcst
		self.ndb_dport = 6602
		self.nmf = nmf
		self.payload_objs = {}
		self.config = NetdebugDeviceConfiguration(nmf, ipaddr = self.ipaddr, cport=9041)
		print("Netdebug device found on %s:%d" %(self.ipaddr, self.port))

		qrh, payload = self.nmf.decap_varmsg(query_response)
		self.lstructs = payload
		#self.structs = pktlogger_lib.NDBStructAdapter.from_lzma(self.lstructs)
		self.structs = NDBStructAdapter.from_lzma(self.lstructs)
		self.fields_arrays = []
		if global_verbose > 1:
			print(self.structs)
		# __ns__ is used to differentiate the different devices on the network, which
		# may have different formats for the NDB structures. CStruct differentiates the
		# same structure name with a namespace (__ns__) variable.
		self.ndb = NDBClasses(header_string = self.structs, __ns__=self.ipaddr)
		self.nsf = NetdebugStructFactory(self.ndb)
		self.history = NetdebugDeviceStream(nmf, self.config, self.nsf, ipaddr = self.ipaddr, cport=9041)
		if global_verbose > 1:
			for cls in self.ndb.all_ndb_classes:
				print(cls)
		self.sample_count = 0
		self.running = False
		self.csv_output = True
		self.struct_fields = {}
		self.fields_arrays = {}

	def pktlogger_configure_all(self, radiostring, typestring, enablestring, ratestring):
		print("Configuring %s (%s %s %s %s)" %(self.ipaddr, radiostring, typestring, enablestring, ratestring))
		self.config.pktlogger_configure_all(radiostring, typestring, enablestring, ratestring)

	def pktlogger_configure_one(self, radiostring, typestring, enablestring, ratestring, historystring = None):
		print("Configuring single: %s (%s %s %s %s %s)" %(self.ipaddr, radiostring, typestring, enablestring, ratestring, historystring))
		self.config.pktlogger_configure_one(radiostring, typestring, enablestring, ratestring, historystring)

	def pktlogger_enable(self, radiostring, typestring):
		self.config.pktlogger_enable(radiostring, typestring)

	def pktlogger_query(self):
		self.radios_config = self.config.query()

	def pktlogger_query_one(self, radiostring, typestring):
		self.a_config = self.config.query_one(radiostring, typestring)

	def pktlogger_get_history(self, radiostring, typestring, historystring):
		self.history.stream(radiostring, typestring, historystring)

	def print_configuration(self):
		self.config.print()

	def monitor_fields(self, struct_fields):
		# Each field to be monitored is 'name.name.X' - traversing down through the
		# different layers of structures
		for structname, fields in struct_fields.items():
			this_structname = structname
			this_structclass = None
			if this_structname in self.ndb.all_ndb_classes:
				this_structclass = self.ndb.all_ndb_classes[this_structname]
				if global_verbose:
					print("Adding real-time monitored fields for struct %s:" % this_structname, fields)
				self.struct_fields[this_structclass] = fields
				self.fields_arrays[this_structclass] = {}
				# Figure out the dot + array indices for real-time monitoring
				for elt in fields:
					self.fields_arrays[this_structclass][elt] = self.split_field(elt)

	def set_csv_output(self, enable):
		self.csv_output = enable

	# Required as listening on UDP socket - UDP header isn't passed up.
	def pad_udp_header(self, payload):
		# FIXME: can re-construct based on src/dest and port numbers
		return b'\x00\x00\x00\x00\x00\x00\x00\x00' + payload

	def receive_stream(self):
		threading.Thread.__init__(self)
		self.running = True
		self.start()

	# Runs in a separate thread, so we can discover other devices
	def run(self):
		if global_verbose:
			print("Main thread of object")
		ndb_port = self.ndb_dport
		self.udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		self.udp_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		self.udp_sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
		self.udp_sock.bind(('', self.ndb_dport))
		while self.running:
			ready = select.select([self.udp_sock], [], [], 5)
			if ready[0]:
				payload, src = self.udp_sock.recvfrom(global_max_recv_len)
				if global_verbose > 1:
					print("Got payload len %d bytes" %len(payload))
				if src[0] != self.ipaddr:
					if global_verbose > 1:
						print("Discarding sample not for our dev (for %s)" % src[0])
					pass
				else:
					payload = self.pad_udp_header(payload)
					self.process_payload(payload)

	def stop(self):
		self.running = False

	def split_field(self, field):
		if field.find("[") != -1:
			ret = []
			all_elts = []
			# We are indexing into various parts of structures - split and conquer
			elts = field.split("[")
			elts_len = len(elts)
			# Elts consists of '<dotted string>', 'number]<dotted string>', ..., 'number]'
			# First element is fine as-is
			if global_verbose > 1:
				print("Parsing field %s" % field)
			for i in range(0, elts_len):
				this_elt = elts[i]
				# Can we split this elt?
				if global_verbose > 1:
					print("Processing partial field %s" % this_elt)
				idx = this_elt.find("]")
				if idx != -1:
					idxstr = this_elt[:idx]
					if global_verbose > 1:
						print("Idx found %s" % idxstr, len(this_elt), idx)
					all_elts.append(idxstr)
					if len(this_elt) > idx + 1:
						next_elt = this_elt[idx+2:]
						all_elts.append(next_elt)
						#print("Next elt parsed", next_elt)
				else:
					all_elts.append(this_elt)
			for i in range(0,len(all_elts),2):
				if i+1 < len(all_elts):
					#print(i, len(all_elts))
					this_tup = (all_elts[i], eval(all_elts[i+1]))
					ret.append(this_tup)
				else:
					this_tup = (all_elts[i], -1)
					ret.append(this_tup)
			#print(ret)
			return ret

		return [(field, -1)]

	def do_monitor(self, hdr, payload):
		for structclass, fields in self.struct_fields.items():
			if hdr.type != self.ndb.cls_to_idx[structclass]:
				continue
			all_fields_arrays = self.fields_arrays[structclass]
			struct_basename = type(payload).__name__
			if self.ndb.is_vararray_type(hdr.type):
				structclass = self.ndb.special_ndb_classes[struct_basename]

			if isinstance(payload, structclass):
				#print("Found the struct I'm monitoring...")
				for field in fields:
					fields_arrays = all_fields_arrays[field]
					intermediate_obj = payload
					if fields_arrays:
						for fname_index in fields_arrays:
							fname = fname_index[0]
							index = fname_index[1]
							if multi_getattr(intermediate_obj, fname):
								intermediate_obj = multi_getattr(intermediate_obj, fname)
								if index != -1:
									if len(intermediate_obj) >= index:
										intermediate_obj = intermediate_obj[index]
						print("%s:%s:" %(self.ipaddr, field), intermediate_obj)
				break


	def process_payload(self, payload):
		hdr, payload = self.nsf.parse_ph(payload)
		if payload == None:
			print("payload is None")
			return

		if self.struct_fields != {}:
			self.do_monitor(hdr, payload)

		if self.csv_output:
			typename = type(payload).__name__
			base_structname = self.ndb.varstruct_basename(typename, hdr.type)
			if base_structname in self.payload_objs:
				this_obj = self.payload_objs[base_structname]
			else:
				print("Monitoring structure %s for %s" %(base_structname, self.ipaddr))
				this_obj = NetdebugStructHistory(self.ndb, typename, self.ipaddr, base_structname)
				self.payload_objs[base_structname] = this_obj
			this_obj.add_sample(hdr, payload, typename)

class PktloggerDiscoveryAgent():
	def __init__(self, args = None):

		self.nmf = NetdebugMessageFactory()
		self.bcst_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		self.bcst_sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
		self.seq = 0
		self.ndb_devs = {}
		self.pktlogger_dport = 9041
		self.struct_fields = {}
		self.sleep_interval = 5
		self.ip_bcst = self.find_local_ip_bcst()
		if self.ip_bcst == []:
			self.ip_bcst.append('255.255.255.255')
		if global_verbose:
			print("ip_bcst: " + str(self.ip_bcst))

		self.args = args

		if args and args.structure:
			structs_to_monitor = args.structure
			struct_delim = structs_to_monitor.split("+")
			if global_verbose > 1:
				print(struct_delim)
			# Key: structname; value: list of fields to monitor
			all_structs_fields = {}
			for elt in struct_delim:
				the_fields = []
				elts = elt.split(":")
				the_struct = elts[0]
				for field in elts[1].split(","):
					the_fields.append(field)
				all_structs_fields[the_struct] = the_fields

			if global_verbose > 1:
				print(all_structs_fields)
			self.set_monitor_fields(all_structs_fields)

		self.query_dict = {}
		self.updates = []
		self.streams = []

		if args and args.query:
			self.query_dict = self.parse_query_string(args.query)
			#self.query_dicts["ip"] = "192.168.54.202"
			#print("Interactive query")
			if "ip" in self.query_dict and self.query_dict["ip"] == "255.255.255.255":
				self.query_dict["continuous"] = True
			self.sleep_interval = 0.5

		if args and args.configure:
			configure_dict = self.parse_query_string(args.configure)
			# dictionaries with wifi: as key, value being the type, newval tuples. type is int, newval is int
			if global_verbose:
				print("configuration set:", configure_dict)
			# wifi0:stats(enable|1);radar(disable|1)
			for radio, configstring in configure_dict.items():
				theseitems = configstring.split(";")
				for item in theseitems:
					if global_verbose > 2:
						print(item)
					loggertype = item[0:item.find("(")]
					state = None
					rate = None
					history = None
					try:
						state, rate, history = item[item.find("(")+1:-1].split("|")
					except:
						try:
							state, rate = item[item.find("(")+1:-1].split("|")
						except:
							state = item[item.find("(")+1:-1]
					this_tuple = [radio, loggertype, state, rate, history]
					if global_verbose > 2:
						print(this_tuple)
					self.updates.append(this_tuple)
			if global_verbose > 1:
				print(self.updates)

		if args and args.stream:
			stream_dict = self.parse_query_string(args.stream)
			# dictionaries with wifi: as key, value being the type, newval tuples. type is int, newval is int
			if global_verbose:
				print("stream set:", stream_dict)
			# wifi0:stats(depth);radar(depth)
			for radio, streamstring in stream_dict.items():
				theseitems = streamstring.split(";")
				for item in theseitems:
					if global_verbose > 2:
						print(item)
					loggertype = item[0:item.find("(")]
					depth = None
					try:
						depth = item[item.find("(")+1:-1]
					except:
						print("Unable to parse input:", item)
					this_tuple = [radio, loggertype, depth]
					if global_verbose > 2:
						print(this_tuple)
					self.streams.append(this_tuple)
			if global_verbose > 1:
				print(self.streams)

	def parse_query_string(self, query):
		ret = {}
		type_value_pairs = query.split(",")
		for elt in type_value_pairs:
			itype, value = elt.split(":")
			ret[itype] = value
		return ret

	def find_local_ip_bcst(self):
		ip_bcst_list = []

		try:
			for intfs,data in psutil.net_if_addrs().items():
				if global_verbose:
					print("intf:", intfs, data)
				bcst = data[0].broadcast
				if bcst != None:
					ip_bcst_list.append(bcst)
		except:
			pass
		try:
			for intf in netifaces.interfaces():
				ifaddrs = netifaces.ifaddresses(intf)[netifaces.AF_INET]
				for ifaddr in ifaddrs:
					if 'broadcast' in ifaddr:
						ip_bcst_list.append(ifaddr['broadcast'])
		except:
			pass
		return ip_bcst_list

	def set_monitor_fields(self, struct_fields):
		self.struct_fields = struct_fields

	def send_struct_query(self, addr):
		self.seq += 1
		struct_query = self.nmf.get_struct_query(self.seq, "PKTLOGGER_MSG_STRUCT_REQUEST")
		self.bcst_sock.sendto(struct_query, (addr, self.pktlogger_dport))

	def wait_for_response(self):
		ready = select.select([self.bcst_sock], [], [], 0.2)
		if ready[0]:
			if global_verbose > 2:
				print("Ready on response, seq:", self.seq)
			data, addrs = self.bcst_sock.recvfrom(global_max_recv_len)
			return data, addrs
		return None, None

	def discovery_loop(self):
		try:
			print("Discovering clients")
			if self.query_dict:
				print("Searching for %s" % self.query_dict["ip"])
			while True:
				data = None
				addrs = None
				for addr in self.ip_bcst:
					self.send_struct_query(addr)
					data, addrs = self.wait_for_response()
					if self.args and self.args.stresstest:
						for i in range(1, args.stresstest):
							self.send_struct_query(addr)
							data, addrs = self.wait_for_response()
				if data != None:
					if data != None:
						if addrs[0] not in self.ndb_devs:
							if self.query_dict:
								if self.query_dict["ip"] == "255.255.255.255" or self.query_dict["ip"] == "%s" % addrs[0]:
									print("Discovered device %s" % addrs[0])
									print("Sending query")
									query_dev = NetdebugDevice(addrs, data, self.nmf)
									query_dev.pktlogger_query()
									query_dev.print_configuration()
									query_dev.pktlogger_query_one(0, 1)
									if self.updates:
										for tup in self.updates:
											query_dev.pktlogger_configure_all(tup[0],tup[1],tup[2],tup[3])
											query_dev.pktlogger_configure_one(tup[0],tup[1],tup[2],tup[3],tup[4])
										#print("After reconfiguration:")
										#query_dev.pktlogger_query()
										#query_dev.print_configuration()
									if self.streams:
										for tup in self.streams:
											query_dev.pktlogger_get_history(tup[0], tup[1], tup[2])
									if self.args and not self.args.stresstest and "continuous" not in self.query_dict:
										break
									print("Searching for other clients...")
									self.ndb_devs[addrs[0]] = query_dev
							else:
								try:
									print("Creating new NDB object for IP %s" % addrs[0])
									self.ndb_devs[addrs[0]] = NetdebugDevice(addrs, data, self.nmf)
									self.ndb_devs[addrs[0]].pktlogger_query()
									self.ndb_devs[addrs[0]].monitor_fields(self.struct_fields)
									if self.args and self.args.nocsv:
										self.ndb_devs[addrs[0]].set_csv_output(False)
									self.ndb_devs[addrs[0]].receive_stream()
								except:
									traceback.print_exc()
									print("Unable to create NDB object for IP %s - try again later" % addrs[0])
									pass
				else:
					if global_verbose:
						print("No data - waiting...")
				if self.args and not self.args.stresstest:
					#print("Is stress?")
					time.sleep(5)
				elif self.args:
					time.sleep(0.01)
					for addr in self.ip_bcst:
						for i in range(1, args.stresstest):
							self.send_struct_query(addr)
							data, addrs = self.wait_for_response()
							time.sleep(0.01)

					for query_addr, query_dev in self.ndb_devs.items():
						if self.updates:
							for radio, typestring, state, rate in self.updates:
								query_dev.pktlogger_configure_all(radio, "stats", "enable", "5")
								query_dev.pktlogger_configure_all(radio, "rate", "disable", "1")
								query_dev.pktlogger_configure_all(radio, "rate", "enable", "5")
								query_dev.pktlogger_configure_all(radio, "stats", "disable", "1")
							print("After reconfiguration:")
							query_dev.pktlogger_query()
							query_dev.print_configuration()
		except:
			traceback.print_exc()
			for addr, elt in self.ndb_devs.items():
				print("Stopping %s" % addr)
				elt.stop()

	def __iter__(self):
		return iter(self.ndb_devs)

class PktloggerFileDecoder():
	def __init__(self, args = None):
		self.args = args
		self.nmf = NetdebugMessageFactory()

		if self.args and self.args.file:
			self.files = self.parse_query_string(self.args.file)
			if self.files["structs"] == None:
				print("struct file not specified")
				sys.exit(1)
			if self.files["stats"] == None:
				print("struct file not specified")
				sys.exit(1)

			self.decode_file()

	def parse_query_string(self, query):
		ret = {}
		type_value_pairs = query.split(",")
		for elt in type_value_pairs:
			itype, value = elt.split(":")
			ret[itype] = value
		return ret

	def read_file(self, filename):
		data = None
		f = open(filename, "rb")
		data = f.read()
		print("Read %d bytes from %s" % (len(data), filename))
		f.close()
		return data

	def decode_file(self):
		try:
			# Appending 20 bytes (dummy struct pktlogger_net_hdr_t) to the "structs" file
			buf_structs = (b'\x00' * 20) + self.read_file(self.files["structs"])
			if buf_structs != None:
				try:
					# addrs is set just to make NetdebugDevice happy
					addrs = ["decoded_file", 0]
					dev = NetdebugDevice(addrs, buf_structs, self.nmf)

					buf_stats = self.read_file(self.files["stats"])
					if buf_stats != None:
						# Extract one stats at a time
						pkt_off = 0
						tot_len = len(buf_stats)
						while pkt_off < tot_len:
							# Extract the len from the updheader
							s_off = pkt_off + 4
							e_off = pkt_off + 6
							pkt_len = int.from_bytes(buf_stats[s_off:e_off], byteorder="big")
							print("pkt_off = %d, pkt_len = %d, tot_len = %d" % (pkt_off, pkt_len, tot_len))
							dev.process_payload(buf_stats[pkt_off:pkt_off + pkt_len])
							pkt_off += pkt_len
					else:
						print("Could not read the structs file")
				except:
					traceback.print_exc()
					print("Unable to create NDB object for file - try again later")
					pass
			else:
				print("Could not read the stats file")
		except:
			traceback.print_exc()

def winbuild_instructions():
	print("1) Install py2exe.build_exe and python 3.4 on your build machine")
	print("2) Install netifaces on the build machine")
	print("3) VERY IMPORTANT: make sure to copy across clean versions of only the .py files onto the windows build machine - no .pyc or __pycache__ files")
	print("4) In a command prompt, run: py -3.4 -m py2exe.build_exe -b0 pktlogger.py")
	print("5) Copy the pktlogger.exe output to a different subdirectory to test it out")


def main(args):
	print("Pktlogger receiver started")
	global global_verbose
	global global_client_version
	if args.version:
		print("Client version %s" % global_client_version)
		sys.exit(1)
	if args.winbuild:
		winbuild_instructions()
		sys.exit(0)
	if args.verbose:
		global_verbose = eval(args.verbose)
	if args.stresstest:
		args.stresstest = eval(args.stresstest)

	if args and args.file:
		PktloggerFileDecoder(args)
		sys.exit(0)

	global pda
	pda = PktloggerDiscoveryAgent(args)
	pda.discovery_loop()

if __name__ == '__main__':
	parser = argparse.ArgumentParser(description="Pktlogger next gen script")
	parser.add_argument("--verbose", help="Verbose debug messages", action="store")
	parser.add_argument("--version", help="Version string", action="store_true")
	parser.add_argument("--winbuild", help="Dump out details on how to build the Windows executable")
	# Packets from the network
	parser.add_argument("--configure", help="Configure a pktlogger device on the command line interactively");
	parser.add_argument("--nocsv", help="No CSV file saving (real-time monitor only)", action="store_true")
	parser.add_argument("--query", help="Query a pktlogger device on the command line interactively");
	parser.add_argument("--stream", help="Query streams on the remote device, save locally");
	parser.add_argument("--stresstest", help="Stress test the system", action="store")
	parser.add_argument("--structure", help="Structure and field(s) to monitor on stdout")
	# Packets from a file
	parser.add_argument("--file", help="Use a file instead of packets from the network; Syntax: --file=structs:<structs_file>,stats:<stats_file>");
	args = parser.parse_args()
	#import pktlogger_lib
	main(args = args)
