#!/usr/bin/python3

import os
import sys
import pktlogger_lib.cstruct as cstruct
import struct
import re
import traceback
import sys
import argparse
import lzma
import datetime

# Class to take in a raw set of files - header file from cpp, and header file
# pre-processed by existing pktlogger scripts. The output will be a set of sanitised
# structures learned from the input files.
# For pktlogger structs, there is a tag in the comment prior to the structure to
# indicate the structure is required - MUST be able to be fully parsed so we can
# automatically parse pktlogger structs over the network.
class PktloggerStructParser:

	# all_headers_cpp is the output from running the ARC gcc C preprocessor on
	# the 'pktlogger_meta.h' file
	def __init__(self, all_headers_cpp, all_headers_string):
		self.all_headers_cpp = all_headers_cpp
		# All structures detected
		self.all_structs = {}
		# Important structures for pktlogger
		self.ndb_structs = {}
		# Final list of structures sanitised with all the crap removed
		self.sanitised_structs = {}
		# All #defines, so we can replace with numbers (which 'CStruct' can parse)
		self.all_defines = {}

		self.all_headers_string = all_headers_string
		if all_headers_cpp != None:
			self.all_headers_string = open(all_headers_cpp, encoding='utf-8').readlines()
		else:
			# Single string to list - as per readlines above
			all_lines = self.all_headers_string.splitlines()
			self.all_headers_string = all_lines
		cpp_all_structs, cpp_ndb_structs, cpp_all_defines, cpp_all_enums, cpp_ndb_csvs = self.parse_headers(self.all_headers_string)
		self.ndb_csvs = cpp_ndb_csvs

		# All structures we use the cpp file - cpp will replace #defines as much as possible
		self.all_structs = cpp_all_structs

		# Special structures - the ones for which we find all structure dependencies
		self.ndb_structs = cpp_ndb_structs

		self.all_enums = cpp_all_enums
		self.normalise_enums()

		# Go through and turn all the crap into nice clean structures/functions/inlines/...
		self.normalise_structs()

	def normalise_enums(self):
		for enum, values in self.all_enums.items():
			try:
				#print(enum)
				#print ("---")
				for line in values.split("\n"):
					this_line = line.strip().replace(",","")
					#print(this_line)
					elts = this_line.split("=")
					#print(elts)
					enum_name = elts[0].strip()
					enum_val = elts[1].strip()
					if enum_val in self.all_defines:
						self.all_defines[enum_name] = self.all_defines[enum_val]
						#print("Added pre-known define (%s) for %s = %s" %(self.all_defines[enum_val], enum_name, enum_val))
					else:
						eval(enum_val)
						self.all_defines[enum_name] = enum_val
						#print("Added define for %s = %d" % (elts[0].strip(), eval(elts[1].strip())))
			except:
				pass

	# Strip all the comments from the particular piece of text.
	def stripcomments(self, text):
		def replacer(match):
			s = match.group(0)
			if s.startswith('/'):
				return " " # note: a space and not an empty string
			else:
				return s
		pattern = re.compile(
				r'//.*?$|/\*.*?\*/|\'(?:\\.|[^\\\'])*\'|"(?:\\.|[^\\"])*"',
				re.DOTALL | re.MULTILINE
				)
		return re.sub(pattern, replacer, text)

	# Is the input string an integer? Any non-int input will cause failure
	def string_is_int(self, s):
		return re.match(r"[-+]?\d+$", s) is not None

	def normalise_structs(self):
		# Normalise ALL the structures first
		for stype, sval in self.all_structs.items():
			#print("------------------------------------")
			#print("Normalising struct %s:" %stype, sval)
			#print("------------------------------------")
			new_struct = self.normalise_single_struct(stype, sval)
			if new_struct != "":
				self.sanitised_structs[stype] = new_struct
				#print("normalised struct %s" % stype)

		# Now normalise the NetDebug structures
		for stype, sval in self.ndb_structs.items():
			for sname, sstring in sval.items():
				#print("------------------------------------")
				#print("Normalising:", sstring)
				#print("------------------------------------")
				new_struct = self.normalise_single_struct(sname, sstring)
				if new_struct != "":
					this_struct = {sname:new_struct}
					self.ndb_structs[stype] = this_struct
				else:
					print("FATAL! Can't expand core structure %s" % sname)
					raise Exception("Can't expand core netdebug structure %s" % sname)

	# Function to run multi-stage cleanup on the input structures which we think
	# are relevant
	# Input is a potentially multi-lined string which is cleaned up and added to the
	# overall structures list.
	def normalise_single_struct(self, stype, sval):
		# STEP 1: Remove comments
		stripped_struct = self.stripcomments(sval)

		# STEP 2: Remove whitespace lines
		individual_lines = []
		all_fields = stripped_struct.split("\n")
		total_string = ""
		for this_field in all_fields:
			if this_field.isspace() or this_field == "":
				pass
			else:
				individual_lines.append(this_field)
				total_string = total_string + this_field + "\n"

		normalised_lines = []

		# STEP 3: Remove any lines starting '#' and '#if 0' blocks
		in_if_discard = 0
		for i in range(0, len(individual_lines)):
			line = individual_lines[i]
			if line.strip().startswith("#if 0") or in_if_discard:
				# Discard until we find the endif
				in_if_discard = 1
			elif line.strip().startswith("#endif"):
				in_if_discard = 0
			elif line.strip().startswith("#"):
				pass
			else:
				normalised_lines.append(line)

		individual_lines = normalised_lines
		normalised_lines = []

		# STEP 4: One line per field - pull them all together
		tot_lines = len(individual_lines)
		i = 0
		while i < tot_lines:
			line = individual_lines[i].strip()
			comp_line = line
			while line[-1] != ";":
				i += 1;
				line = individual_lines[i].strip()
				comp_line = comp_line + " " + line
			normalised_lines.append(comp_line)
			i += 1

		individual_lines = normalised_lines
		normalised_lines = []
		# STEP 5: One more time - single line per.
		for i in range(0, len(individual_lines)):
			line = individual_lines[i].strip()
			#print("%d:%s" %(i, line))
			# Case 1: single line for the field, nicely formatted
			if line.endswith(";") or line.startswith("#"):
				normalised_lines.append(line)
				i += 1
				continue
			# Case 2: continuing on the next line
			composite_line = line
			i += 1
			while not line.endswith(";"):
				#print("->%d:%s" %(i, line))
				line = individual_lines[i].strip()
				composite_line = composite_line + line
				i += 1
			#print("line single-linified: %s" % composite_line)
			normalised_lines.append(composite_line)
		new_lines = []
		# STEP 6: Replace any array #defines or 'n + m' values with an actual
		# integer.
		for line in normalised_lines:
			# Replace any #defines
			idxstart = line.find("[")
			if idxstart != -1:
				idxend = line.find("]")
				arraysize = line[idxstart+1:idxend]
				new_define = arraysize
				# Non-integer within '[]', see if it can be replaced with numeric values
				if not self.string_is_int(arraysize) and len(arraysize) > 0:
					new_define = ""
					elts = arraysize.split()
					# Case 6.1: we have composite mathematical value (ie 'DEF1 * DEF2')
					if len(elts) > 1:
						# Support 'value <op> value <op> value ...' and nothing else
						operators = ['+', '*', '-', '/']
						for elt in elts:
							# Turn from defines into numeric + operator
							if elt in operators or self.string_is_int(elt):
								new_define = new_define + elt
							elif elt in self.all_defines:
								new_define = new_define + self.all_defines[elt]
							else:
								new_define = new_define + elt
					# Case 6.2: single entry or numeric value - try and replace
					else:
						if arraysize in self.all_defines:
							new_define = self.all_defines[arraysize]
						else:
							new_define = arraysize
				# Evaluate the expression - if it fails, too bad.
				if new_define != "":
					new_int = None
					try:
						new_int = eval(new_define)
						new_line = "%s%d%s" %(line[0:idxstart+1], new_int, line[idxend:])
						#print("Replacing %s with %s" %(line, new_line))
						line = new_line
					except:
						# If failure, simply allow the same line to be appended.
						#print("Can't determine array for line %s" % line)
						pass
			new_lines.append(line)

		#print("Anything left?")
		#print(new_lines)
		ret = ""
		# STEP 7: Add newline between each line - makes it a bit more readable.
		for line in new_lines:
			ret = ret + line + "\n"
		return ret

	# Helper function to determine if a structure definition is acceptable to us.
	def line_struct_ok(self, stripped_line, name="struct"):
		elts = stripped_line.split()
		ok = False
		# Case 1: same line has opening brace ({) - struct xyz { or struct xyz{
		if stripped_line[-1] == "{":
			# Case 1.1: Strip the 'struct xyz{' <- opening brace, so we get the pure structure name
			if elts[1][-1] == "{":
				elts[1] = elts[1][0:-1]
			ok = True
		# Case 2: 'struct xyz' with opening brace on next line
		if len(elts) == 2 and elts[0] == name:
			ok = True
		# Case 3: 'struct xyz {'
		if (len(elts) == 3 and elts[0] == name and elts[2] == "{"):
			ok = True
		# If we think it's good, the struct name is always the third element.
		if ok:
			return elts[1]

	# Heuristic reader to detect struct blocks.
	def parse_headers(self, all_lines):
		this_ndb_idx = -1
		this_ndb_csvs = {}
		in_struct = -1
		in_enum = -1
		this_struct = ""
		this_enum = ""
		the_ndb_structs = {}
		the_ndb_csvs = {}
		the_all_structs = {}
		the_all_defines = {}
		the_all_enums = {}
		for line in all_lines:
			#print(line)
			# Case 1: already within a 'struct' definition
			if in_struct != -1:
				# collecting struct defn
				if line[0] == "}":
					# End of struct
					in_struct = -1
					total_struct = {this_struct_name:this_struct}
					if this_ndb_idx != -1:
						the_ndb_structs[this_ndb_idx] = total_struct
						the_ndb_csvs[this_ndb_idx] = this_ndb_csvs
					else:
						#print("Adding struct to all structs %s" %this_struct)
						the_all_structs[this_struct_name] = this_struct
					this_struct_name = None
					this_struct = ""
					this_ndb_idx = -1
					this_ndb_csvs = {}
				elif line[0] == "{": # Single { on the next line - skip
					pass
				else:
					# Check and replace 'STAILQ'
					if line.find("stqh_first") != -1 or line.find("tqe_next") != -1:
						#print("FOUND XTAILQ |%s| %s" % (line, this_struct_name))
						# Name of the stailq is the final element in the stripped line
						stq_name = line.split()[-1][:-1]
						replacement = "uint32_t %s_first;\nuint32_t %s_last;\n" %(stq_name, stq_name)
						#print("Replacing STAILQ expansion %s with %s" %(line, replacement))
						this_struct = this_struct + replacement
					else:
						this_struct = this_struct + line
			# Case 1.5: inside enum?
			elif in_enum != -1:
			# Case 2: try and find the start of a structure definition or #define
				if line[0] == "}":
					#print("Term enum %s" % this_enum_name)
					in_enum = -1
					the_all_enums[this_enum_name] = this_enum
					this_enum_name = None
					this_enum = ""
				elif line[0] == "{":
					pass
				else:
					this_enum = this_enum + line
			else:
				# This is #define - try and add it into the global list
				if line.find("#define") != -1:
					if line[len(line)-1] == "\\":
						# Multi-line #define - we ignore.
						#print("Define across multi-lines - ignore", line)
						pass
					else:
						elts = line.split()[1:]
						if len(elts) > 1:
							the_all_defines[elts[0]] = elts[1]
							#print("Adding define %s %s" % (elts[0], elts[1]))
						else:
							#print("NOT adding define %s" % line)
							pass
					continue
				# Look for NDB tags - these are special structures
				offset = line.find("@NDB@")
				if offset != -1:
					# Start of a net debug structure - one we want to keep
					csvs = line[offset:].split()[1]
					# CSV elements to give us information on the format of the structure.
					for type_value in csvs.split(","):
						t, value = type_value.split("=")
						if t == "type":
							idx = eval(value)
							this_ndb_idx = idx
						this_ndb_csvs[t] = value
				else:
					#Look for 'struct'
					if line.find("struct") == 0:
						stripped_line = line.strip()
						# Accept either struct and nothing else (modulo stripping whitespace)
						# or 'struct{' or 'struct {' or any variant of this

						#elts = stripped_line.split()

						# Case 1: single line 'struct' - most likely a forward decl.
						if stripped_line[-1] == ";":
							pass
							#print("Not a struct %s" % line)
						# Case 2: check if we have 'struct XYZ {' or 'struct xyz\n'
						else:
							sname = self.line_struct_ok(stripped_line)
							if sname != None:
								in_struct = 1
								this_struct_name = sname
								#print("Found what I think is struct: %s" %line)
							#else:
								#print("Not a struct - ignore: %s" % line)
					elif line.find("enum") == 0:
						stripped_line = line.strip()
						# Accept either struct and nothing else (modulo stripping whitespace)
						# or 'struct{' or 'struct {' or any variant of this

						#elts = stripped_line.split()

						# Case 1: single line 'struct' - most likely a forward decl.
						if stripped_line[-1] == ";":
							pass
							#print("Not a struct %s" % line)
						# Case 2: check if we have 'struct XYZ {' or 'struct xyz\n'
						else:
							sname = self.line_struct_ok(stripped_line, name="enum")
							if sname != None:
								in_enum = 1
								this_enum_name = sname
								#print("Found what I think is an enum: %s" %line)
							#else:
								#print("Not an enum - ignore: %s" % line)

		return the_all_structs, the_ndb_structs, the_all_defines, the_all_enums, the_ndb_csvs

class NDBClasses:
	def __init__(self, header_file = None, header_string = None, __ns__="default", verbose=0):
		self.pls = PktloggerStructParser(header_file, header_string)
		self.all_classes = {}
		self.all_ndb_classes = {}
		self.verbose = verbose
		self.cls_to_idx = {}
		self.idx_to_cls = {}
		self.idx_to_clsdef = {}
		self.idx_to_clsname = {}
		self.special_ndb_indices = []
		self.vararray_indices = []
		self.varstring_indices = []
		self.ns = __ns__
		for idx, csvs in self.pls.ndb_csvs.items():
			if 'payload' in csvs:
				self.special_ndb_indices.append(idx)
				ptype = csvs['payloadtype']
				if ptype.find("varstring") != -1:
					self.varstring_indices.append(idx)
				elif ptype.find("vararray") != -1:
					self.vararray_indices.append(idx)
		if self.verbose:
			print("Dynamic class indices follow:", self.special_ndb_indices)
		self.special_ndb_classes = {}
		self.special_to_basename = {}
		self.parse_headers()

	def parse_headers(self):
		to_retry = {}
		the_endian = cstruct.LITTLE_ENDIAN
		# Try and make some Python structure representations of the structures we've read in.
		for sname, sdef in self.pls.sanitised_structs.items():
			try:
				x = type(sname, (cstruct.CStruct,), dict(__struct__=sdef, __byte_order__=the_endian, __ns__=self.ns))
				if self.verbose:
					print("Created new structure class for %s" % (sname))
				self.all_classes[sname] = x
				new_retry = {}

				for sname2, sdef2 in to_retry.items():
					# Each time we create a new structure with no exception, try regenerating the
					# previously deferred structures
					try:
						x = type(sname2, (cstruct.CStruct,), dict(__struct__=sdef2, __byte_order__=the_endian, __ns__=self.ns))
						# Success - add the class to the overall list
						self.all_classes[sname2] = x
						if self.verbose:
							print("Created deferred structure class for %s" %(sname2))
					except:
						# Still fails - re-add for retry later
						#traceback.print_exc()
						new_retry[sname2] = sdef2
				to_retry = new_retry
			except:
				# Initial failure - retry later once new structures are available in-memory
				#traceback.print_exc()
				to_retry[sname] = sdef

		# Remove any stragglers from the end of the parsing.
		if to_retry != {}:
			loops_through = len(to_retry)
			# Have to iterate through 'n' times to make sure any co-dependencies in the structures
			# are cleaned up. Pathological case is it takes 'n' loops to resolve all structures - ie, the
			# list is entirely backwards
			if self.verbose > 1:
				print("Retry %d times loop" % loops_through)
			for i in range(0, loops_through):
				#print("Retry %d" % i)
				new_retry = {}
				for sname2, sdef2 in to_retry.items():
					# Each time we create a new structure with no exception, try regenerating the
					# previously deferred structures
					try:
						x = type(sname2, (cstruct.CStruct,), dict(__struct__=sdef2, __byte_order__=the_endian, __ns__=self.ns))
						# Success - add the class to the overall list
						self.all_classes[sname2] = x
						if self.verbose:
							print("Created deferred structure class in retry list for %s" %(sname2))
					except:
						# Still fails - re-add for retry later
						#traceback.print_exc()
						new_retry[sname2] = sdef2

		to_retry = {}
		ndb_exc = ""
		# NDB structures - the important ones
		for typeidx, structdef in self.pls.ndb_structs.items():
			for sname, sdef in structdef.items():
				try:
					x = type(sname, (cstruct.CStruct,), dict(__struct__=sdef, __byte_order__=the_endian, __ns__=self.ns))
					if self.verbose:
						print("Created new NDB structure class for %s" % sname)
					self.all_ndb_classes[sname] = x
					self.cls_to_idx[x] = typeidx
					self.idx_to_cls[typeidx] = x
					self.idx_to_clsdef[typeidx] = sdef
					self.idx_to_clsname[typeidx] = sname
					new_retry = {}
					for sname, sdef in to_retry.items():
						try:
							x = type(sname, (cstruct.CStruct,), dict(__struct__=sdef, __byte_order__=the_endian, __ns__=self.ns))
							# Success - add to overall list
							self.all_ndb_classes[sname] = x
							if self.verbose:
								print("Created deferred NDB structure class for %s" %(sname2))
						except:
							# Failure - try again later
							new_retry[sname] = sdef
					to_retry = new_retry
				except:
					# Failure of NDB structure - somewhat fatal
					#print("Can't create structure %s" % sname)
					ndb_exc = traceback.format_exc()
					to_retry[sname] = sdef
		if to_retry != {}:
			if self.verbose:
				print("ERROR: could not create critical NDB structure for the following items:")
				print(self.all_classes)
				print(self.all_ndb_classes)
			string_print = ""
			for sname, svalue in to_retry.items():
				string_print += "Unable to parse %s:" % sname + "\n" + svalue + "------------------------------------\n"
				string_print += "Exception:\n%s" % ndb_exc
			raise Exception("Unable to parse required NDB structures as printed:\n%s" % string_print)

	def get_ndb_index(self, cls):
		if cls in self.cls_to_idx:
			return self.cls_to_idx[cls]
		return -1

	def cls_to_csvs(self, idx):
		ret = ""
		this_csvs = self.pls.ndb_csvs[idx]

		# Python dictionaries are unordered. Converting it into a list and then sorting
		# it results in a deterministic output
		temp_list = []
		for t, v in this_csvs.items():
			temp_list.append("%s=%s" % (t, v))

		temp_list.sort()

		for i in temp_list:
			if ret != "":
				ret = ret + ","
			ret = ret + i
		return ret

	def is_vararray_type(self, hdr_type):
		if hdr_type in self.vararray_indices:
			return True
		return False

	def varstruct_basename(self, clsname, hdr_type):
		if clsname in self.special_to_basename:
			return self.special_to_basename[clsname]
		return clsname

	def make_ndb_varstruct(self, cls, buf, payload_len): #, cnt = 0, size = 0):
		this_ndb_csvs = {}
		is_string = 0
		is_array = 0
		if cls not in self.cls_to_idx:
			if self.verbose:
				print("Class %s is not NDB struct - not creating VARSTRUCT" % cls)
			return None
		this_idx = self.cls_to_idx[cls]
		this_ndb_csvs = self.pls.ndb_csvs[this_idx]
		# Variable length pktlogger structures have 'payload' as part of their TLVs - check it.
		if "payload" not in this_ndb_csvs or "payloadtype" not in this_ndb_csvs:
			if self.verbose:
				print("No payload in the NDB CSVs, not valid. CSVs follow", this_ndb_csvs)
			return None
		pn = this_ndb_csvs["payload"]
		pt = this_ndb_csvs["payloadtype"]
		if pt.find("vararray") != -1:
			is_array = 1
		if pt.find("varstring") != -1:
			is_string = 1
		repl_array = -1
		# String is easy - replace array with the size of the payload
		if is_string:
			repl_array = payload_len
			if self.verbose:
				print("String length for string array is %s" % payload_len)
		# Array - instantiate the structure and 
		if is_array:
			offset = pt.find("(")
			if offset == -1:
				return None
			cnt_field = pt[offset+1:-1]
			if self.verbose:
				print("Field count for var array is %s" % cnt_field)
			if len(buf) >= len(cls):
				# If incoming buffer is large enough, instantiate the object to find the var cnt field
				obj = cls(buf[0:len(cls)])
			# Find the array count element
			openbr = offset + 1
			closebr = pt.find(")")
			cntvar = pt[openbr:closebr]
			if hasattr(obj, cntvar):
				cnt = getattr(obj,cntvar)
				#print("Found var count field: %s:%d" %(cntvar, cnt))
				repl_array = cnt

		if repl_array == -1:
			return None

		# Does such a structure exist? If so, reuse it
		orig_sname = self.idx_to_clsname[this_idx]
		structname = "%s-%dlen" %(orig_sname, repl_array)
		if structname in self.special_ndb_classes:
			return self.special_ndb_classes[structname]
		# Make a modified structure
		this_clsdef = self.idx_to_clsdef[this_idx]
		new_clsdef = ""
		# Replace the array element (either a buffer size or array count) with
		# the value found earlier. For strings this is the length of the buffer, for
		# structures it's the count of # structures.
		for line in this_clsdef.splitlines():
			if line.find(pn) != -1:
				pre_upd = line.find("[")
				if pre_upd != -1:
					# Found the array for replacement
					this_line = line[0:pre_upd+1] + "%d];" % repl_array
					new_clsdef = new_clsdef + this_line + "/*x*/   \n"
				else:
					# This is the case where the 'cnt' var is a substring of another field in the structure
					new_clsdef = new_clsdef + line + "    \n"
			else:
				new_clsdef = new_clsdef + line + "     \n"
			new_clsdef = new_clsdef + "\n"
		if self.verbose:
			print("New class def:")
			print(new_clsdef)
		the_endian = cstruct.LITTLE_ENDIAN
		x = type(structname, (cstruct.CStruct,), dict(__struct__=new_clsdef, __byte_order__=the_endian, __ns__=self.ns))
		if self.verbose > 1:
			print(x, len(x), x(), x.__struct__, x.__fields__, x.__fields_types__)
		self.special_ndb_classes[structname] = x
		self.special_to_basename[structname] = orig_sname

		return x

# Adapter class - creates output from the internal struct representation into different
# forms.
class NDBStructAdapter:

	def __init__(self, ndb_classes, verbose=0):
		self.ndb_classes = ndb_classes
		self.verbose = verbose
		self.all_reqd_structs = {}
		for sname, scontents in ndb_classes.all_ndb_classes.items():
			self.all_reqd_structs[sname] = scontents
			for field in scontents.__fields__:
				ftype = scontents.__fields_types__[field]
				inner = ftype[0]
				if type(inner) is cstruct.CStructMeta:
					this_struct = ndb_classes.all_classes[inner.__name__]
					if self.verbose:
						print("Found CStructMesage Structure defn ", this_struct)
					self.all_reqd_structs[inner.__name__] = this_struct
			#print("------")

		if self.verbose:
			print(self.all_reqd_structs)
		adding_more = True
		count = 0
		# Now pick up all the structure dependencies
		while adding_more:
			count += 1
			if self.verbose > 1:
				print("Iteraction count %d" % count)
			add_reqd_structs = {}
			for sname, scontents in self.all_reqd_structs.items():
				for field in scontents.__fields__:
					ftype = scontents.__fields_types__[field]
					inner = ftype[0]
					#print(inner, dir(inner))
					if type(inner) is cstruct.CStructMeta and not inner.__name__ in self.all_reqd_structs:
						this_struct = ndb_classes.all_classes[inner.__name__]
						if self.verbose > 1:
							print("ADD more Structure defn ", this_struct)
						add_reqd_structs[inner.__name__] = this_struct
					#elif type(inner) is cstruct.CStructMeta:
						#print("Not adding again %s" % inner.__name__)
			if add_reqd_structs == {}:
				if self.verbose:
					print("Terminating - no more structs added (%d loops)" % count)
				adding_more = False
			self.all_reqd_structs.update(add_reqd_structs)
		self.ordered_names = list(self.all_reqd_structs.keys())
		self.ordered_names.sort()

	def struct_beautify(self, sdef):
		ret = ""
		for line in sdef.splitlines():
			elts = line.split(";")
			if len(elts) > 1 and elts[1] != '':
				for elt in elts:
					if elt != '':
						ret = ret + elt.strip() + ";\n"
			else:
				ret = ret + line + "\n"
		return ret

	# String containing all the required headers
	def to_string(self):
		internal_string = ""
		for sname in self.ordered_names:
			sclass = self.all_reqd_structs[sname]
			if self.verbose:
				print("Struct %s required for NDB (fmt: %s)" % (sname, sclass.__fmt__))
			if sname in self.ndb_classes.all_ndb_classes:
				idx = self.ndb_classes.cls_to_idx[sclass]
				csvs = self.ndb_classes.cls_to_csvs(idx)
				if idx != -1:
					internal_string += "/* @NDB@: %s */\n" % (csvs)
			internal_string += "struct %s {\n" % sname
			internal_string += "%s" % self.struct_beautify(sclass.__struct__.strip())
			internal_string += "};\n"
		return internal_string

	# LZMA compressed header containing the struct strings
	def to_lzma_header(self):
		lzma_output = self.to_lzma()
		lzma_string = "/* Automatically generated on %s - do not edit */\n" % datetime.datetime.now()
		lzma_string += "const char pktlogger_structs[] = {\n"
		i = 0
		for i in range(0,len(lzma_output)):
			if i and (i % 16 == 0):
				lzma_string += ",\n"
			elif i:
				lzma_string += ", "
			lzma_string += "0x%02X" % lzma_output[i]
		lzma_string += "};\n"
		return lzma_string

	def to_lzma(self):
		internal_string = self.to_string()
		return lzma.compress(bytearray(internal_string, 'utf-8'))

	# Translate the LZMA data back into a structure list
	@classmethod
	def from_lzma(cls, lzma_bytes):
		return lzma.decompress(lzma_bytes).decode('utf-8')


# Generic structure transformation module.
class NetdebugStructTransformerGeneric:
	def __init__(self, ndb, structname, verbose = 0):
		self.ndb = ndb
		self.structname = structname
		self.verbose = verbose
		self.depth = 0
		self.maxdepth = self.depth
		self.structclass = None
		self.all_layers = {}
		# layers indexed by depth in the structure
		self.cur_idx = 0
		if self.structname in self.ndb.all_reqd_structs:
			self.structclass = self.ndb.all_reqd_structs[structname]
		if self.structclass == None:
			if self.verbose:
				print("Can't find structure %s, perhaps is dynamic created at runtime?" %structname)
			if self.structname in self.ndb.ndb_classes.special_ndb_classes:
				self.structclass = self.ndb.ndb_classes.special_ndb_classes[self.structname]
				if self.verbose:
					print("Found dynamic struct %s" % structname)
		self.recurse_find(structname, depth=self.depth, cur_idx=self.cur_idx)

	def recurse_find(self, structname, depth = 0, cur_idx = -1):
		depth = depth + 1
		this_structclass = None
		if depth > self.maxdepth:
			self.maxdepth = depth
		if structname in self.ndb.all_reqd_structs:
			this_structclass = self.ndb.all_reqd_structs[structname]
		if structname in self.ndb.ndb_classes.special_ndb_classes:
			this_structclass = self.ndb.ndb_classes.special_ndb_classes[structname]
			#print("Found special struct ", this_structclass)
		if this_structclass == None:
			return None
		this_layer_fields = {}
		for field in this_structclass.__fields__:
			field_tuple = this_structclass.__fields_types__[field]
			field_type = field_tuple[0]
			# Recurse in and decode underlayers
			if isinstance(field_type, cstruct.CStructMeta):
				struct_count = int(field_tuple[1] / len(field_type))
				for i in range(0, struct_count):
					fieldname = ""
					if struct_count > 1:
						fieldname = "%s[%d]" %(field, i)
					else:
						fieldname = field
					this_layer_fields[self.cur_idx] = fieldname

					self.cur_idx = self.recurse_find(field_type.__name__, depth=depth, cur_idx = self.cur_idx)
			else:
				struct_count = int(field_tuple[1])
				if field_type in cstruct.string_types:
					struct_count = 1
				for i in range(0, struct_count):
					fieldname = field
					if struct_count > 1:
						fieldname = "%s[%d]" %(field, i)
					this_layer_fields[self.cur_idx] = fieldname
					self.cur_idx += 1

		# Add this layer fields to existing layer fields
		all_layer_fields = None
		if depth in self.all_layers:
			# Merge the two dictionaries together
			all_layer_fields = self.all_layers[depth]
			all_layer_fields.update(this_layer_fields)
		else:
			self.all_layers[depth] = this_layer_fields
		return self.cur_idx

	def all_csv_hdrs(self):
		ret_str = []
		tot_len = self.cur_idx
		for i in range(1,self.maxdepth+1):
			ret = ""
			layer = self.all_layers[i]
			for idx in range(0, tot_len):
				if idx in layer:
					ret += "%s," % layer[idx]
				else:
					ret += ","
			ret_str.append(ret)
		return ret_str

	def dump_sample(self, sample):
		return sample.csv()


class NetdebugStructTransformerStats(NetdebugStructTransformerGeneric):
	def __init__(self, structname):
		super(NetdebugStructTransformerStats, self).__init__(structname)


# Simple unit test
if __name__ == "__main__":

	import argparse
	import os

	parser = argparse.ArgumentParser(description="Test pktlogger library",)
	parser.add_argument("--verbose", help="Verbose log messages", action="store")
	args = parser.parse_args()

	if args.verbose:
		args.verbose = eval(args.verbose)
	else:
		args.verbose = 0

	ndb = NDBStructAdapter(NDBClasses(header_file = "./headers.txt", verbose=args.verbose), verbose=args.verbose)
	if args.verbose:
		for cls in ndb.ndb_classes.all_ndb_classes:
			print(cls)
	pkthdr = ndb.ndb_classes.all_classes['qdrv_pktlogger_hdr']
	phys_b = ndb.ndb_classes.all_ndb_classes['qdrv_netdebug_phystats']
	buf=bytearray(os.urandom(len(phys_b)))
	if args.verbose:
		print(buf)
	obj = phys_b(buf)
	obj.per_node_stats_count = 1
	new_b = obj.pack()
	sc2 = ndb.ndb_classes.make_ndb_varstruct(phys_b, new_b, len(phys_b) - len(pkthdr))
	x = ndb.ndb_classes.all_ndb_classes['qdrv_netdebug_sysmsg']
	buf=bytearray(os.urandom(129))
	buf = buf[0:80] + bytearray("this is the message from syslog", encoding="utf-8")
	if args.verbose:
		print(buf)
	obj = pkthdr(buf[0:len(pkthdr)])
	sc1 = ndb.ndb_classes.make_ndb_varstruct(x, buf, len(buf) - len(pkthdr))
	if args.verbose:
		print(sc1,sc2)
		print(sc1(buf))
	phys = ndb.ndb_classes.all_classes['qdrv_netdebug_per_node_phystats']
	phys2 = ndb.ndb_classes.all_classes['qtn_node_shared_stats']
	phys3 = ndb.ndb_classes.all_classes['qtn_node_shared_stats_tx']
	phys4 = ndb.ndb_classes.all_classes['qtn_node_shared_stats_rx']
	if args.verbose:
		print(len(phys), len(phys2), len(phys3), len(phys4))
		print(len(phys_b))
		print(phys2.__fields__)
		print(phys2.__fields_types__)
	print("Done")
